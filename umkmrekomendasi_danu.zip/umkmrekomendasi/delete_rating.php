<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once BASE_PATH . '/classes/Rating.php';

error_log("=== DELETE RATING START ===");
error_log("Method: " . $_SERVER['REQUEST_METHOD']);
error_log("POST data: " . json_encode($_POST));

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("Not POST request");
    header("Location: index.php");
    exit();
}

$product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;

error_log("Product ID: $product_id");

if (!$product_id) {
    error_log("Validation failed - no product_id");
    $_SESSION['message'] = 'Data tidak valid';
    $_SESSION['message_type'] = 'danger';
    header("Location: product_detail.php?id=" . $product_id);
    exit();
}

try {
    $rating_obj = new Rating($conn);
    
    // Get current identity (user atau guest)
    // CRITICAL: Konsistensi guest_id harus sama dengan di product_detail.php dan submit_rating.php
    if (isLoggedIn()) {
        $user_id = intval($_SESSION['user_id']);
        $guest_id = null;
        error_log("User logged in - User ID: $user_id");
    } else {
        $user_id = null;
        $guest_id = getGuestId();
        error_log("User not logged in - Guest ID: $guest_id");
        
        // Validate guest_id
        if (!$guest_id || trim($guest_id) === '') {
            error_log("WARNING: Guest ID invalid or empty, generating new one");
            // Force regenerate
            initializeGuestId();
            $guest_id = getGuestId();
            
            if (!$guest_id) {
                error_log("ERROR: Still unable to generate valid guest ID for delete!");
                $_SESSION['message'] = 'Session guest ID invalid. Coba refresh halaman.';
                $_SESSION['message_type'] = 'danger';
                header("Location: product_detail.php?id=" . intval($product_id));
                exit();
            }
        }
    }
    
    // Delete rating
    $result = $rating_obj->deleteRating($user_id, $product_id, $guest_id);
    
    error_log("Delete result: " . json_encode($result));
    
    $_SESSION['message'] = $result['message'];
    $_SESSION['message_type'] = $result['success'] ? 'success' : 'danger';
    
} catch (Exception $e) {
    error_log("Delete rating error: " . $e->getMessage());
    $_SESSION['message'] = 'Gagal menghapus rating: ' . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
}

error_log("=== DELETE RATING END ===");
header("Location: product_detail.php?id=" . intval($product_id));
?>
