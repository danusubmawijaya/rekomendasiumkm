# MANUAL BOOK WEBSITE UMKM RECOMMEND

## 1. Gambaran Umum Aplikasi

### Nama Aplikasi
UMKM Recommend - Website Rekomendasi Produk UMKM

### Tujuan Website
Website ini dirancang untuk membantu pengguna menemukan produk UMKM makanan terbaik berdasarkan preferensi dan rekomendasi personal. Sistem ini menggunakan teknologi collaborative filtering untuk memberikan rekomendasi produk yang relevan dengan selera pengguna.

### Fungsi Utama Website
- **Browsing Produk**: Pengguna dapat melihat daftar produk UMKM yang tersedia dengan berbagai kategori
- **Pencarian Produk**: Fitur pencarian untuk menemukan produk berdasarkan nama
- **Rating Produk**: Pengguna dapat memberikan rating untuk setiap produk
- **Rekomendasi Personal**: Sistem otomatis merekomendasikan produk berdasarkan rating pengguna lain yang memiliki preferensi serupa
- **Lokasi Produk**: Menampilkan informasi lokasi penjual produk
- **Profil Pengguna**: Manajemen akun dan data personal pengguna

### Siapa Pengguna Website
- **Pengguna Umum (Guest)**: Dapat melihat daftar produk dan memberikan rating tanpa perlu membuat akun
- **Pengguna Terdaftar**: Pengguna yang sudah mendaftar dan login, mendapatkan rekomendasi personal
- **Admin**: Mengelola produk, pengguna, dan melihat evaluasi sistem

### Cara Kerja Website dari Sisi Pengguna
1. Pengguna membuka website dan melihat halaman utama dengan daftar produk
2. Pengguna dapat mencari produk atau memilih kategori
3. Pengguna dapat melihat detail produk termasuk rating dan lokasi
4. Pengguna dapat memberikan rating untuk produk (sebagai guest atau member)
5. Pengguna yang sudah memberikan beberapa rating dapat melihat rekomendasi produk personal
6. Pengguna terdaftar dapat mengelola profil dan melihat riwayat rating mereka

---

## 2. Kebutuhan Sistem

### Perangkat/Hardware
- Komputer atau perangkat mobile dengan spesifikasi standar (RAM minimal 1 GB, CPU standar)
- Layar dengan resolusi minimal 320px (mobile) hingga desktop
- Tidak ada kebutuhan spesifikasi hardware khusus

### Browser yang Didukung
- Chrome (versi terbaru)
- Firefox (versi terbaru)
- Safari (versi terbaru)
- Edge (versi terbaru)
- Browser mobile standar

### Koneksi Internet
- Koneksi internet stabil diperlukan untuk akses website
- Kecepatan minimum: 1 Mbps (untuk browsing normal)
- Kecepatan yang direkomendasikan: 5 Mbps atau lebih (untuk pengalaman optimal)

### Software/Environment (Jika Dijalankan Secara Lokal)
- Web Server: Apache dengan PHP support
- PHP: Versi 7.4 atau lebih tinggi
- Database: MySQL atau MariaDB
- Browser web untuk akses

---

## 3. Cara Mengakses Website

### URL Website
[URL WEBSITE DIISI SESUAI WEBSITE DEPLOYMENT]

### Cara Membuka Website
1. Buka browser web di perangkat Anda
2. Ketikkan URL website di address bar
3. Tekan Enter atau klik tombol Go
4. Website akan memuat halaman utama

### Halaman Pertama yang Muncul
Halaman utama menampilkan:
- Daftar produk UMKM dalam bentuk grid/kartu
- Fitur pencarian di bagian atas
- Filter kategori produk
- Rating dan informasi singkat untuk setiap produk
- Tombol "Detail" dan "Rating" pada setiap produk

### Kondisi Jika Pengguna Belum Login
- Pengguna dapat melihat semua produk dan kategori
- Pengguna dapat memberikan rating sebagai "Guest" (tamu)
- Pengguna tidak dapat melihat halaman rekomendasi personal
- Menu navigasi menampilkan tombol "Login" dan "Daftar"

### Kondisi Jika Pengguna Sudah Login
- Pengguna dapat melihat nama mereka di navigasi
- Pengguna dapat mengakses halaman "Profil"
- Pengguna dapat melihat halaman "Rekomendasi" (jika sudah memberikan rating)
- Menu navigasi menampilkan tombol "Logout"
- Rating yang diberikan terhubung dengan akun pengguna

---

## 4. Panduan Penggunaan USER

### 4.1 Halaman Home / Daftar Produk

#### Fungsi Halaman
Halaman utama menampilkan semua produk UMKM dengan fitur filtering dan pencarian.

#### Bagian/Menu yang Tersedia
- **Judul Halaman**: "Semua Produk" dengan subtitle
- **Bar Pencarian**: Untuk mencari produk berdasarkan nama
- **Filter Kategori**: Tombol-tombol kategori untuk memfilter produk
  - Semua (menampilkan semua produk)
  - Makanan Berat
  - Jajanan & Street Food
  - Minuman
  - Makanan Rumahan
  - Dan kategori lainnya yang ada di database
- **Daftar Produk**: Ditampilkan dalam bentuk kartu dengan informasi:
  - Gambar produk
  - Nama produk
  - Deskripsi singkat
  - Rating rata-rata
  - Jumlah rating
  - Badge "Terverifikasi" (jika ada minimal 10 rating bintang 4 atau 5)
  - Tombol "Detail" dan "Rating"

#### Apa yang Dapat Dilakukan Pengguna
- Melihat semua produk yang tersedia
- Mencari produk dengan mengetik nama di bar pencarian
- Memilih kategori produk
- Melihat rating dan review dari produk
- Membuka detail produk dengan klik tombol "Detail"
- Memberikan rating dengan klik tombol "Rating"
- Menghapus filter pencarian dengan klik tombol X pada bar pencarian

---

### 4.2 Halaman Register / Pendaftaran Akun

#### Cara Membuka Halaman Register
- Klik tombol "Daftar di sini" di halaman login
- Atau klik menu "Daftar" di navigasi (jika belum login)

#### Field yang Harus Diisi
1. **Nama Lengkap**: Masukkan nama Anda (minimal 3 karakter)
2. **Email**: Masukkan email yang valid dan belum terdaftar
3. **Password**: Masukkan password (minimal 6 karakter)
   - Strength bar akan menunjukkan kekuatan password secara real-time
   - Password yang lebih kuat disarankan (mengandung huruf besar, huruf kecil, angka, dan simbol)
4. **Konfirmasi Password**: Ulangi password yang sama

#### Proses Pendaftaran
1. Isi semua field yang wajib diisi
2. Baca keterangan tentang persyaratan password
3. Klik tombol "Daftar Sekarang"
4. Jika berhasil, Anda akan langsung login dan diarahkan ke halaman home
5. Rating yang Anda berikan sebagai guest sebelumnya akan otomatis dipindahkan ke akun Anda

#### Validasi/Error yang Mungkin Muncul
- **"Semua field harus diisi"**: Pastikan semua field tidak kosong
- **"Nama minimal 3 karakter"**: Nama yang dimasukkan terlalu pendek
- **"Password minimal harus 6 karakter"**: Password yang dimasukkan terlalu pendek
- **"Password tidak cocok"**: Password dan konfirmasi password tidak sama
- **"Format email tidak valid"**: Email yang dimasukkan tidak valid atau tidak memiliki domain
- **"Email sudah terdaftar"**: Email sudah digunakan oleh akun lain

---

### 4.3 Halaman Login

#### Cara Login
1. Buka halaman login
2. Masukkan email dan password Anda
3. Klik tombol "Login"

#### Field yang Harus Diisi
1. **Email**: Email yang digunakan saat registrasi
2. **Password**: Password yang digunakan saat registrasi

#### Kondisi Login Berhasil
- Anda akan diarahkan ke halaman home atau halaman yang ingin Anda akses sebelumnya
- Nama Anda akan muncul di navigasi website
- Rating yang sebelumnya diberikan sebagai guest akan otomatis dipindahkan ke akun Anda

#### Kondisi Login Gagal
- Pesan error "Email atau password tidak valid" akan muncul
- Ini berarti email tidak terdaftar atau password salah
- Silakan cek kembali email dan password Anda
- Jika lupa password, gunakan fitur "Lupa Password"

---

### 4.4 Halaman Lupa Password / Reset Password

#### Cara Membuka
- Klik tombol "Lupa password?" di halaman login

#### Proses Reset Password
1. Masukkan email yang terdaftar di sistem
2. Klik tombol "Kirim Link Reset"
3. Cek email Anda untuk menerima link reset password
4. Klik link di email untuk membuka halaman reset password
5. Masukkan password baru dan konfirmasi password
6. Klik tombol "Reset Password"
7. Jika berhasil, Anda akan dapat login dengan password baru

#### Informasi Penting
- Link reset password hanya berlaku untuk waktu tertentu
- Jika link sudah expired, silakan lakukan proses lupa password kembali
- Pastikan email yang dimasukkan sama dengan email yang terdaftar

---

### 4.5 Daftar Produk

#### Cara Melihat Produk
- Produk otomatis ditampilkan di halaman home
- Tidak perlu melakukan aksi khusus untuk melihat daftar produk

#### Informasi yang Ditampilkan
Setiap kartu produk menampilkan:
- **Gambar Produk**: Thumbnail visual produk
- **Kategori**: Badge menunjukkan kategori produk
- **Nama Produk**: Judul produk
- **Deskripsi Singkat**: Penjelasan singkat tentang produk
- **Rating**: Bintang rating dan nilai rata-rata
- **Jumlah Rating**: Berapa banyak orang yang memberikan rating
- **Badge Terverifikasi**: Menunjukkan produk memiliki banyak rating tinggi (minimal 10 rating 4-5 bintang)

#### Cara Memilih Produk
1. Klik tombol "Detail" untuk melihat informasi lengkap produk
2. Klik tombol "Rating" untuk langsung memberikan rating
3. Atau klik pada kartu produk untuk membuka detail

---

### 4.6 Pencarian Produk

#### Cara Menggunakan Pencarian
1. Lihat bar pencarian di bagian atas halaman
2. Ketik nama produk yang ingin dicari
3. Tekan Enter atau sistem akan otomatis mencari saat Anda selesai mengetik
4. Hasil pencarian akan ditampilkan dalam bentuk daftar produk

#### Hasil Pencarian
- Produk yang sesuai dengan kata kunci akan ditampilkan
- Jika tidak ada hasil, pesan "Tidak ada produk ditemukan" akan muncul
- Anda dapat mengubah filter atau mencoba kata kunci lain
- Klik tombol X pada bar pencarian untuk menghapus hasil pencarian

#### Contoh Pencarian
- Cari "rendang" akan menampilkan semua produk dengan nama yang mengandung "rendang"
- Cari "ayam" akan menampilkan semua produk makanan ayam
- Pencarian tidak case-sensitive (huruf besar/kecil tidak berpengaruh)

---

### 4.7 Filter Kategori Produk

#### Cara Memilih Kategori
1. Lihat bagian "Filter Kategori" di halaman home
2. Klik tombol kategori yang ingin Anda lihat
3. Produk akan difilter sesuai kategori yang dipilih

#### Kategori yang Tersedia
- **Semua**: Menampilkan semua produk tanpa filter
- **Makanan Berat**: Produk makanan berat seperti nasi, mie, dsb
- **Jajanan & Street Food**: Produk jajanan dan makanan ringan
- **Minuman**: Produk minuman berbagai jenis
- **Makanan Rumahan**: Produk makanan tradisional rumahan
- **Kategori lain**: Sesuai dengan kategori yang ditambahkan admin

#### Hasil yang Ditampilkan
- Hanya produk dari kategori yang dipilih akan ditampilkan
- Kategori yang sedang aktif akan ditandai dengan warna berbeda
- Anda dapat memilih kategori lain untuk mengganti filter

---

### 4.8 Halaman Detail Produk

#### Informasi yang Ditampilkan
Halaman detail menampilkan informasi lengkap:
- **Nama Produk**: Judul produk besar dan jelas
- **Gambar Produk**: Foto produk dengan ukuran lebih besar
- **Rating Rata-rata**: Bintang dan nilai rating
- **Deskripsi Lengkap**: Penjelasan detail tentang produk
- **Badge Terverifikasi**: Jika produk memiliki banyak rating tinggi
- **Kategori**: Kategori produk
- **Lokasi Penjual**: Daftar lokasi penjual produk dengan alamat
- **Koordinat Geografis**: Latitude dan longitude lokasi (jika tersedia)
- **Rating Terbaru**: Daftar 10 rating terakhir yang diberikan pengguna lain

#### Lokasi Produk
- **Informasi Lokasi**: Menampilkan nama lokasi penjual produk
- **Alamat Lengkap**: Alamat detail lokasi penjual
- **Koordinat GPS**: Latitude dan longitude untuk navigasi (jika tersedia)
- **Tombol "Lokasi Terdekat"**: Untuk menemukan lokasi penjual yang paling dekat dari posisi Anda (memerlukan izin akses GPS)

#### Rating di Halaman Detail
- **Rating Rata-rata**: Nilai rata-rata dari semua rating
- **Total Rating**: Berapa banyak orang yang memberikan rating
- **Distribusi Rating**: Menampilkan berapa banyak rating untuk setiap bintang
- **Rating Terbaru**: Daftar 10 rating terakhir dengan nama pemberi rating (atau "Guest" jika anonim)

#### Tombol/Fungsi yang Tersedia
- **Tombol Kembali**: Kembali ke halaman daftar produk
- **Tombol "Lokasi Terdekat"**: Menampilkan lokasi penjual yang paling dekat dari posisi GPS Anda
- **Bagian Rating**: Untuk memberikan atau mengubah rating produk Anda

---

### 4.9 Rating Produk

#### Cara Memberikan Rating
1. Buka halaman detail produk
2. Scroll ke bagian rating di bawah
3. Klik bintang untuk memilih rating (1 hingga 5 bintang)
4. Teks di samping akan menampilkan nilai yang Anda pilih
5. Klik tombol "Kirim Rating" untuk menyimpan rating Anda
6. Pesan sukses akan muncul jika rating berhasil disimpan

#### Nilai Rating yang Tersedia
- **1 Bintang**: Sangat Buruk
- **2 Bintang**: Buruk
- **3 Bintang**: Cukup
- **4 Bintang**: Baik
- **5 Bintang**: Sangat Baik

#### Kondisi Pengguna Belum Login
- Pengguna dapat memberikan rating sebagai "Guest" (tamu)
- Setiap rating guest disimpan dengan ID unik
- Jika kemudian pengguna membuat akun dan login, semua rating guest mereka akan dipindahkan ke akun mereka

#### Cara Mengubah Rating
1. Jika Anda sudah pernah memberikan rating untuk produk, rating sebelumnya akan ditampilkan
2. Klik bintang lagi untuk mengubah rating
3. Klik tombol "Kirim Rating" untuk menyimpan perubahan
4. Rating lama akan diganti dengan rating baru

#### Informasi Penting Rating
- Setiap user/guest hanya bisa memberikan 1 rating per produk
- Rating Anda akan terlihat dalam daftar rating di halaman detail (sebagai nama Anda atau "Guest")
- Rating membantu sistem memberikan rekomendasi yang lebih baik untuk pengguna lain

---

### 4.10 Rekomendasi Produk

#### Cara Membuka Halaman Rekomendasi
- Klik menu "Rekomendasi" di navigasi website
- Menu hanya tersedia jika Anda sudah memberikan minimal 1 rating

#### Persyaratan Akses
- Harus sudah memberikan minimal 1 rating produk
- Jika belum memberikan rating, Anda akan diarahkan ke halaman home
- Baik pengguna terdaftar maupun guest dapat mengakses rekomendasi (jika sudah memberikan rating)

#### Apa yang Ditampilkan
- **Daftar Rekomendasi**: Produk yang direkomendasikan berdasarkan preferensi Anda
- **Jumlah Rekomendasi**: Maksimal 5 produk top yang direkomendasikan
- **Informasi Produk**: Nama, kategori, rating, dan informasi dasar setiap produk
- **Pesan Sistem**: Penjelasan tentang bagaimana rekomendasi dihasilkan

#### Bagaimana Pengguna Menggunakan Hasil Rekomendasi
1. Lihat daftar produk yang direkomendasikan
2. Klik salah satu produk untuk melihat detail lengkapnya
3. Berikan rating jika Anda ingin mencoba produk tersebut
4. Rating baru Anda akan mempengaruhi rekomendasi di masa depan

#### Metode Collaborative Filtering (Penjelasan Singkat)
Sistem rekomendasi menggunakan metode **User-Based Collaborative Filtering** yang bekerja sebagai berikut:
- Sistem menemukan pengguna lain yang memiliki preferensi rating serupa dengan Anda
- Sistem melihat produk apa yang disukai pengguna serupa tersebut
- Sistem merekomendasikan produk tersebut kepada Anda
- Semakin banyak rating Anda berikan, semakin akurat rekomendasi yang diterima

---

### 4.11 Profil User

#### Cara Membuka Profil
1. Pastikan Anda sudah login
2. Klik menu "Profil" di navigasi website
3. Halaman profil akan terbuka

#### Melihat Profil
Halaman profil menampilkan:
- **Nama Lengkap**: Nama yang terdaftar di sistem
- **Email**: Email akun Anda
- **Informasi Akun**: Status akun dan data lainnya

#### Mengubah Nama/Email
1. Buka halaman profil
2. Klik tombol "Edit Profil" atau "Ubah Profil"
3. Ubah nama dan/atau email sesuai keinginan
4. Jika mengganti email, pastikan email baru belum digunakan akun lain
5. Klik tombol "Simpan Perubahan"
6. Pesan sukses akan muncul jika perubahan berhasil disimpan

#### Mengubah Password
1. Buka halaman profil
2. Cari bagian "Ubah Password"
3. Masukkan password lama Anda untuk verifikasi
4. Masukkan password baru (minimal 6 karakter)
5. Masukkan konfirmasi password baru
6. Klik tombol "Ubah Password"
7. Pesan sukses akan muncul dan Anda akan diminta login kembali dengan password baru

#### Informasi Penting Profil
- Ubah email hanya bisa dilakukan jika email baru belum terdaftar
- Ubah password memerlukan verifikasi password lama
- Semua perubahan profil akan langsung tersimpan di sistem

---

### 4.12 Logout

#### Cara Logout
1. Buka menu navigasi
2. Klik tombol "Logout"
3. Konfirmasi logout jika diminta
4. Anda akan logout dari sistem

#### Halaman Setelah Logout
- Anda akan diarahkan ke halaman home
- Nama Anda tidak lagi tampil di navigasi
- Anda akan kembali ke status "Guest"
- Untuk login kembali, silakan klik tombol "Login"

#### Informasi Penting
- Rating yang Anda berikan sebagai pengguna terdaftar akan tetap tersimpan di akun Anda
- Jika Anda login kembali, semua data profil dan rating akan kembali
- Session akan otomatis logout jika tidak ada aktivitas dalam waktu tertentu

---

### 4.13 Halaman Informasi

#### Halaman Tentang (About)
**Cara Membuka**: Klik menu "Tentang" di navigasi website

**Konten**: 
- Penjelasan tentang UMKM Recommend
- Misi dan visi website
- Informasi tentang fitur-fitur utama
- Keuntungan menggunakan website

#### Halaman FAQ (Frequently Asked Questions)
**Cara Membuka**: Klik menu "FAQ" atau "Bantuan" di navigasi website

**Konten**:
- Daftar pertanyaan umum pengguna
- Jawaban untuk masalah umum
- Tips dan trik penggunaan website
- Informasi kontak jika ada pertanyaan

#### Halaman Kontak
**Cara Membuka**: Klik menu "Kontak" di navigasi website

**Fitur**:
- Form untuk menghubungi tim website
- Masukkan nama, email, dan pesan
- Tim akan merespons email Anda

#### Halaman Syarat & Ketentuan
**Cara Membuka**: Klik menu "Syarat & Ketentuan" atau "Terms of Service" di footer

**Konten**:
- Syarat penggunaan website
- Kebijakan privasi
- Aturan pemberian rating
- Hak dan kewajiban pengguna

#### Halaman DMCA
**Cara Membuka**: Biasanya tersedia di footer website

**Konten**:
- Informasi tentang hak cipta digital
- Prosedur jika ada pelanggaran hak cipta
- Kontak untuk laporan DMCA

---

## 5. Panduan Penggunaan ADMIN

### 5.1 Login Admin

#### Cara Login sebagai Admin
1. Buka halaman login website
2. Masukkan email admin dan password
3. Klik tombol "Login"
4. Jika berhasil, Anda akan diarahkan ke dashboard admin

#### Persyaratan
- Harus memiliki akun dengan status admin di database
- Email dan password harus sesuai dengan data admin

#### Akses Halaman Admin
- Dashboard admin biasanya dapat diakses di: `[URL WEBSITE]/khususjier/admin/dashboard.php`
- Atau otomatis diarahkan ke dashboard setelah login sebagai admin

---

### 5.2 Dashboard Admin

#### Informasi yang Ditampilkan
Dashboard admin menampilkan:
- **Total Produk**: Jumlah seluruh produk yang terdaftar di sistem
- **Total Pengguna Aktif**: Jumlah pengguna yang sudah terdaftar
- **Total Rating**: Jumlah rating yang diberikan oleh semua pengguna
- **Rating Rata-rata Keseluruhan**: Nilai rata-rata rating di sistem

#### Tombol/Menu Utama
- **Kelola Produk**: Untuk menambah, mengedit, atau menghapus produk
- **Kelola Pengguna**: Untuk melihat dan mengelola data pengguna
- **Evaluasi Sistem**: Untuk melihat evaluasi performa sistem rekomendasi
- **Profil Admin**: Untuk mengelola profil admin
- **Logout**: Untuk keluar dari halaman admin

#### Statistik Real-time
- Data statistik dapat diperbarui secara real-time
- Admin dapat melihat update terbaru tanpa perlu me-refresh halaman

---

### 5.3 Kelola Produk

#### Melihat Daftar Produk
1. Klik menu "Kelola Produk" di dashboard admin
2. Halaman akan menampilkan daftar semua produk dalam bentuk tabel
3. Untuk setiap produk, tersedia informasi:
   - ID Produk
   - Nama Produk
   - Kategori
   - Deskripsi
   - Gambar (jika ada)
   - Tombol Aksi (Edit, Hapus, Lihat Detail)

#### Menambah Produk
1. Klik tombol "Tambah Produk" atau "Add New Product"
2. Isi form dengan data produk:
   - **Nama Produk**: Nama produk (wajib diisi)
   - **Deskripsi**: Penjelasan detail tentang produk (wajib diisi)
   - **Kategori**: Pilih kategori produk (wajib dipilih)
   - **Gambar**: Upload gambar produk (opsional, bisa ditambah nanti)
   - **Lokasi**: Tambah satu atau lebih lokasi penjual produk
     - Untuk setiap lokasi, masukkan:
       - Nama Lokasi
       - Latitude (opsional)
       - Longitude (opsional)
3. Klik tombol "Simpan Produk"
4. Produk baru akan ditampilkan di website

#### Mengedit Produk
1. Di daftar produk, klik tombol "Edit" pada produk yang ingin diubah
2. Halaman edit akan terbuka dengan data produk yang ada
3. Ubah data yang ingin dimodifikasi
4. Klik tombol "Simpan Perubahan"
5. Perubahan akan tersimpan dan langsung tampil di website

#### Menghapus Produk
1. Di daftar produk, klik tombol "Hapus" pada produk yang ingin dihapus
2. Konfirmasi penghapusan akan muncul
3. Klik "Ya" untuk mengkonfirmasi penghapusan
4. Produk akan dihapus dari sistem (termasuk semua rating untuk produk tersebut)

#### Data Lokasi Produk
- Lokasi disimpan di tabel terpisah (product_locations)
- Setiap produk bisa memiliki satu atau lebih lokasi
- Admin dapat menambah, mengedit, atau menghapus lokasi untuk setiap produk
- Koordinat GPS digunakan untuk fitur "Lokasi Terdekat"

---

### 5.4 Kelola Pengguna

#### Melihat Daftar Pengguna
1. Klik menu "Kelola Pengguna" di dashboard admin
2. Halaman akan menampilkan daftar semua pengguna terdaftar
3. Untuk setiap pengguna, tersedia informasi:
   - ID Pengguna
   - Nama Lengkap
   - Email
   - Status Admin (Ya/Tidak)
   - Tanggal Daftar
   - Tombol Aksi (Edit, Hapus, Lihat Detail)

#### Fungsi yang Tersedia
- **Lihat Detail**: Melihat informasi lengkap pengguna dan rating mereka
- **Edit**: Mengubah nama atau status pengguna
- **Hapus**: Menghapus akun pengguna dari sistem (dan semua rating mereka)
- **Ubah Status Admin**: Memberikan atau mencabut akses admin untuk pengguna

#### Informasi Pengguna
- Untuk setiap pengguna dapat dilihat:
  - Nama lengkap
  - Email terdaftar
  - Jumlah rating yang diberikan
  - Tanggal pembuatan akun
  - Status akun (aktif/tidak aktif)

---

### 5.5 Evaluasi Sistem

#### Cara Membuka Halaman Evaluasi
1. Klik menu "Evaluasi Sistem" di dashboard admin
2. Halaman evaluasi akan menampilkan data performa sistem rekomendasi

#### Informasi Evaluasi yang Ditampilkan

##### MAE (Mean Absolute Error)
- Nilai yang menunjukkan rata-rata kesalahan prediksi rating dari sistem
- Semakin kecil nilai MAE, semakin akurat sistem rekomendasi
- Dihitung dari selisih antara rating prediksi dan rating aktual pengguna

##### Detail Evaluasi / LOOCV (Leave-One-Out Cross-Validation)
- Metode untuk mengevaluasi akurasi sistem secara menyeluruh
- Setiap pengguna digunakan sebagai test case satu per satu
- Sistem memprediksi rating pengguna berdasarkan pengguna lain
- MAE dihitung dari perbedaan prediksi dengan rating sebenarnya

#### Tombol/Fungsi yang Tersedia
- **Jalankan Evaluasi**: Memulai proses evaluasi sistem (memakan waktu tergantung jumlah data)
- **Lihat Detail**: Melihat hasil evaluasi terperinci untuk setiap pengguna
- **Download Laporan**: Mengunduh laporan evaluasi dalam format PDF
- **Reset Evaluasi**: Menghapus hasil evaluasi sebelumnya

#### Informasi Penting
- Evaluasi mungkin memakan waktu jika ada banyak pengguna dan rating
- Hasil evaluasi hanya untuk internal monitoring, tidak ditampilkan kepada pengguna biasa
- Admin dapat menjalankan evaluasi berkala untuk memantau kualitas sistem

---

### 5.6 Profil Admin

#### Cara Membuka Profil Admin
1. Klik menu "Profil" atau "Profil Admin" di dashboard admin
2. Halaman profil admin akan terbuka

#### Informasi yang Dapat Dilihat
- Nama admin
- Email admin
- Status admin

#### Mengubah Data Profil
1. Klik tombol "Edit Profil"
2. Ubah nama atau email sesuai kebutuhan
3. Klik tombol "Simpan Perubahan"
4. Perubahan akan tersimpan

#### Mengubah Password Admin
1. Di halaman profil, cari bagian "Ubah Password"
2. Masukkan password lama untuk verifikasi
3. Masukkan password baru
4. Konfirmasi password baru
5. Klik "Ubah Password"
6. Anda akan diminta login kembali dengan password baru

---

### 5.7 Logout Admin

#### Cara Logout
1. Klik tombol "Logout" di halaman admin
2. Anda akan logout dan diarahkan ke halaman login
3. Untuk mengakses admin kembali, silakan login dengan akun admin

#### Informasi Penting
- Jika logout, semua data yang belum disimpan akan hilang
- Session admin akan berakhir untuk keamanan
- Pastikan semua perubahan sudah disimpan sebelum logout

---

## 6. Troubleshooting

### Masalah: Login Gagal

**Penyebab Kemungkinan:**
- Email atau password salah
- Akun belum didaftarkan
- Huruf besar/kecil di email

**Solusi:**
1. Pastikan email dan password benar (case-sensitive untuk password)
2. Cek kembali email yang Anda gunakan saat registrasi
3. Jika lupa password, gunakan fitur "Lupa Password"
4. Jika belum punya akun, silakan daftar terlebih dahulu

### Masalah: Email Tidak Diterima saat Lupa Password

**Penyebab Kemungkinan:**
- Email masuk ke folder spam/junk
- Email tidak terdaftar di sistem
- Sistem email tidak berfungsi dengan baik

**Solusi:**
1. Cek folder spam/junk di email Anda
2. Pastikan email yang dimasukkan sama dengan email terdaftar
3. Tunggu beberapa menit dan coba lagi
4. Jika masih tidak ada, hubungi tim support melalui halaman kontak

### Masalah: Data Produk Tidak Muncul

**Penyebab Kemungkinan:**
- Filter kategori atau pencarian aktif
- Browser cache lama
- Database belum memiliki produk

**Solusi:**
1. Hapus filter pencarian dengan klik tombol X
2. Pilih kategori "Semua"
3. Refresh halaman (Ctrl+R atau Cmd+R)
4. Clear browser cache
5. Jika masih tidak ada, hubungi admin

### Masalah: Rating Tidak Tersimpan

**Penyebab Kemungkinan:**
- Koneksi internet putus saat menyimpan
- Browser script diblokir
- Session timeout

**Solusi:**
1. Pastikan koneksi internet stabil
2. Cek apakah JavaScript diaktifkan di browser
3. Refresh halaman dan coba lagi
4. Jika problem berlanjut, logout dan login kembali

### Masalah: Rekomendasi Tidak Muncul

**Penyebab Kemungkinan:**
- Belum memberikan rating apapun
- Baru memberikan 1 rating, sistem masih memproses
- Belum ada pengguna lain dengan preferensi serupa

**Solusi:**
1. Pastikan sudah memberikan minimal 1 rating
2. Berikan lebih banyak rating untuk rekomendasi yang lebih baik
3. Tunggu sistem memproses data (beberapa menit)
4. Refresh halaman setelah memberikan rating baru

### Masalah: Akses Admin Ditolak

**Penyebab Kemungkinan:**
- Login sebagai user biasa, bukan admin
- Session admin expired
- Akun belum punya status admin

**Solusi:**
1. Pastikan login dengan akun admin yang benar
2. Logout dan login kembali
3. Jika yakin akun harus admin, hubungi super admin/owner
4. Cek browser untuk memastikan cookie/session aktif

### Masalah: Database/Koneksi Bermasalah

**Gejala:**
- Error message "Database connection error"
- Halaman tidak memuat data

**Penyebab:**
- Server database offline
- Konfigurasi database salah
- Server hosting down

**Solusi (User Biasa):**
1. Tunggu beberapa saat, mungkin server sedang maintenance
2. Refresh halaman
3. Hubungi admin melalui email atau halaman kontak
4. Coba akses di lain waktu

**Solusi (Admin/Developer):**
1. Cek koneksi database di config/database.php
2. Pastikan MySQL/Database server running
3. Cek credentials database (host, user, password, database name)
4. Cek error log di server untuk informasi lebih detail

### Masalah: Gambar Produk Tidak Muncul

**Penyebab Kemungkinan:**
- File gambar tidak diunggah
- Path gambar salah
- Format file tidak didukung

**Solusi (Admin):**
1. Saat tambah/edit produk, pastikan upload gambar dengan format: JPG, PNG, GIF
2. Pastikan ukuran file tidak terlalu besar (< 5MB recommended)
3. Jika gagal upload, coba file lain
4. Cek permission folder uploads di server

---

## 7. Lampiran / Daftar Screenshot

Berikut adalah daftar screenshot yang diperlukan untuk dokumentasi manual book lengkap. Untuk setiap screenshot, gunakan format placeholder di bawah. Screenshot asli website dapat dimasukkan kemudian:

### Screenshot Halaman User

[SCREENSHOT: halaman_home]
Caption: Gambar 1. Halaman Home - Daftar Produk dengan Filter Kategori

[SCREENSHOT: halaman_register]
Caption: Gambar 2. Halaman Register - Form Pendaftaran Akun Baru

[SCREENSHOT: halaman_login]
Caption: Gambar 3. Halaman Login - Form Login Pengguna

[SCREENSHOT: halaman_search]
Caption: Gambar 4. Halaman Hasil Pencarian - Produk Sesuai Kata Kunci

[SCREENSHOT: halaman_kategori]
Caption: Gambar 5. Halaman Filter Kategori - Produk Berdasarkan Kategori

[SCREENSHOT: halaman_product_detail]
Caption: Gambar 6. Halaman Detail Produk - Informasi Lengkap dan Rating

[SCREENSHOT: halaman_rating_form]
Caption: Gambar 7. Formulir Rating - Pemilihan Bintang dan Pengiriman Rating

[SCREENSHOT: halaman_lokasi_produk]
Caption: Gambar 8. Halaman Detail Produk - Informasi Lokasi Penjual

[SCREENSHOT: halaman_rekomendasi]
Caption: Gambar 9. Halaman Rekomendasi - Daftar Produk Rekomendasi Personal

[SCREENSHOT: halaman_profil_user]
Caption: Gambar 10. Halaman Profil User - Informasi dan Edit Akun

[SCREENSHOT: halaman_about]
Caption: Gambar 11. Halaman Tentang - Informasi Website

[SCREENSHOT: halaman_faq]
Caption: Gambar 12. Halaman FAQ - Daftar Pertanyaan Umum

[SCREENSHOT: halaman_kontak]
Caption: Gambar 13. Halaman Kontak - Form Hubungi Kami

### Screenshot Halaman Admin

[SCREENSHOT: halaman_admin_login]
Caption: Gambar 14. Halaman Login Admin - Form Login Admin

[SCREENSHOT: halaman_admin_dashboard]
Caption: Gambar 15. Dashboard Admin - Statistik Sistem

[SCREENSHOT: halaman_admin_products]
Caption: Gambar 16. Halaman Kelola Produk - Daftar Produk Admin

[SCREENSHOT: halaman_admin_add_product]
Caption: Gambar 17. Form Tambah Produk - Formulir Input Produk Baru

[SCREENSHOT: halaman_admin_edit_product]
Caption: Gambar 18. Form Edit Produk - Mengubah Data Produk

[SCREENSHOT: halaman_admin_users]
Caption: Gambar 19. Halaman Kelola Pengguna - Daftar Pengguna Sistem

[SCREENSHOT: halaman_admin_evaluasi]
Caption: Gambar 20. Halaman Evaluasi Sistem - Hasil Evaluasi MAE/LOOCV

[SCREENSHOT: halaman_admin_profil]
Caption: Gambar 21. Profil Admin - Informasi dan Edit Akun Admin

---

## Catatan Penting

1. **URL Website**: Ganti placeholder `[URL WEBSITE DIISI SESUAI WEBSITE DEPLOYMENT]` dengan URL asli website setelah deployment
2. **Screenshots**: Setiap placeholder `[SCREENSHOT: ...]` harus diganti dengan screenshot asli dari website
3. **Pembaruan Berkala**: Manual book ini perlu diperbarui jika ada fitur baru atau perubahan signifikan
4. **Support**: Untuk pertanyaan teknis, hubungi tim developer melalui email atau sistem support yang tersedia

---

**Dokumen ini dihasilkan sebagai panduan penggunaan UMKM Recommend. Terakhir diperbarui: [TANGGAL PERBARUAN]**

**Versi: 1.0**

---
