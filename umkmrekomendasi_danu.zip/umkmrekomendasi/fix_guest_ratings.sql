-- ============================================================================
-- Script untuk MEMPERBAIKI masalah Foreign Key pada Guest Ratings
-- MASALAH: Guest rating dengan user_id = 0 melanggar foreign key constraint
-- SOLUSI: Ubah semua guest ratings dari user_id = 0 menjadi user_id = NULL
-- ============================================================================

-- Step 1: Matikan foreign key checks untuk menghindari constraint violation saat update
SET FOREIGN_KEY_CHECKS=0;

-- Step 2: Konversi semua guest ratings dari user_id = 0 ke user_id = NULL
-- Guest ratings adalah ratings dengan user_id = 0 dan guest_id bukan NULL
UPDATE `ratings` 
SET `user_id` = NULL 
WHERE `user_id` = 0 AND `guest_id` IS NOT NULL;

-- Step 3: Aktifkan kembali foreign key checks
SET FOREIGN_KEY_CHECKS=1;

-- Step 4: Verifikasi hasilnya (jalankan query ini secara manual untuk cek)
-- SELECT id, user_id, guest_id, product_id, rating, created_at 
-- FROM ratings 
-- WHERE user_id IS NULL AND guest_id IS NOT NULL 
-- LIMIT 10;

-- ============================================================================
-- Hasil yang diharapkan: Semua guest ratings sekarang memiliki user_id = NULL
-- dan guest_id yang valid, sehingga memenuhi foreign key constraint
-- ============================================================================
