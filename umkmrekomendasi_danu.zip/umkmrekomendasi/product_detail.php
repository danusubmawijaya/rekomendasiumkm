    <?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    ini_set('log_errors', 1);

    require_once 'config/database.php';
    require_once 'config/session.php';
    require_once BASE_PATH . '/classes/Product.php';
    
    $page_title = "Detail Produk";
    require_once 'includes/header.php';

    try {
        $is_logged_in = isLoggedIn();
        $user_id = $is_logged_in ? intval($_SESSION['user_id']) : null;
        $guest_id = !$is_logged_in ? getGuestId() : null;
        $product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        if (!$product_id) {
            header("Location: home.php");
            exit();
        }

        // AMBIL DETAIL PRODUK
        $stmt = $conn->prepare("SELECT id, nama_produk, deskripsi, gambar, lokasi FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($p_id, $p_nama, $p_desc, $p_gambar, $p_lokasi);
        $product = null;
        if ($stmt->num_rows > 0) {
            $stmt->fetch();
            $product = array('id' => $p_id, 'nama_produk' => $p_nama, 'deskripsi' => $p_desc, 'gambar' => $p_gambar, 'lokasi' => $p_lokasi);
        }
        $stmt->close();

        if (!$product) {
            header("Location: home.php");
            exit();
        }

        // AMBIL LOKASI DARI PRODUCT_LOCATIONS TABLE (Prioritas)
        $locations = [];
        
        // Coba ambil dari product_locations table terlebih dahulu
        $loc_stmt = $conn->prepare("SELECT lokasi, latitude, longitude FROM product_locations WHERE product_id = ? ORDER BY id");
        $loc_stmt->bind_param("i", $product_id);
        $loc_stmt->execute();
        $loc_stmt->store_result();
        $loc_stmt->bind_result($pl_name, $pl_lat, $pl_lng);
        
        while ($loc_stmt->fetch()) {
            $locations[] = array(
                'id' => count($locations) + 1,
                'lokasi' => trim($pl_name),
                'latitude' => $pl_lat,
                'longitude' => $pl_lng,
                'alamat_lengkap' => trim($pl_name)
            );
        }
        $loc_stmt->close();
        
        // Jika product_locations kosong, coba baca dari kolom lokasi di products table
        if (empty($locations) && !empty($product['lokasi'])) {
            $parts = explode(' | ', $product['lokasi']);
            
            for ($i = 0; $i < count($parts); $i += 2) {
                if (isset($parts[$i])) {
                    $loc_name = trim($parts[$i]);
                    $coords = isset($parts[$i + 1]) ? trim($parts[$i + 1]) : '';
                    
                    if (!empty($coords)) {
                        $coord_parts = explode(',', $coords);
                        
                        if (count($coord_parts) == 2 && is_numeric($coord_parts[0]) && is_numeric($coord_parts[1])) {
                            $locations[] = array(
                                'id' => count($locations) + 1,
                                'lokasi' => $loc_name,
                                'latitude' => floatval($coord_parts[0]),
                                'longitude' => floatval($coord_parts[1]),
                                'alamat_lengkap' => $loc_name
                            );
                        } else {
                            $locations[] = array(
                                'id' => count($locations) + 1,
                                'lokasi' => $loc_name,
                                'latitude' => null,
                                'longitude' => null,
                                'alamat_lengkap' => $loc_name
                            );
                        }
                    } else {
                        $locations[] = array(
                            'id' => count($locations) + 1,
                            'lokasi' => $loc_name,
                            'latitude' => null,
                            'longitude' => null,
                            'alamat_lengkap' => $loc_name
                        );
                    }
                }
            }
        }
        
        // Jika tidak ada lokasi yang valid, gunakan default
        if (empty($locations)) {
            $locations[] = array(
                'id' => 1,
                'lokasi' => 'Bekasi Utara',
                'latitude' => -6.1650,
                'longitude' => 107.0188,
                'alamat_lengkap' => 'Bekasi Utara'
            );
        }
        $query = "SELECT r.rating, u.name FROM ratings r LEFT JOIN users u ON r.user_id = u.id WHERE r.product_id = ? ORDER BY r.created_at DESC LIMIT 10";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($rating_val, $user_name);
        $all_ratings = [];
        while ($stmt->fetch()) {
            $all_ratings[] = array('rating' => $rating_val, 'name' => $user_name ?: 'Guest');
        }
        $stmt->close();

        // AMBIL RATING PENGGUNA (user atau guest)
        $user_rating = 0;
        
        if ($user_id) {
            $stmt = $conn->prepare("SELECT rating FROM ratings WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("ii", $user_id, $product_id);
        } else {
            // Guest: user_id harus NULL
            $stmt = $conn->prepare("SELECT rating FROM ratings WHERE user_id IS NULL AND guest_id = ? AND product_id = ?");
            $stmt->bind_param("si", $guest_id, $product_id);
        }
        
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($ur);
        if ($stmt->num_rows > 0) {
            $stmt->fetch();
            $user_rating = intval($ur);
        }
        $stmt->close();

        // AMBIL RATING RATA-RATA
        $avg_rating = 0;
        $total_ratings = 0;
        $stmt = $conn->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_ratings FROM ratings WHERE product_id = ?");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($avg_rating, $total_ratings);
        if ($stmt->num_rows > 0) {
            $stmt->fetch();
            $avg_rating = $avg_rating ? floatval($avg_rating) : 0;
            $total_ratings = intval($total_ratings);
        }
        $stmt->close();
        
        // Cek apakah produk ini terverifikasi
        // Kriteria: minimal 10 rating bintang 5 OR 10 rating bintang 4 (salah satu saja)
        $is_verified = false;
        $verified_query = "
            SELECT 
                SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five_star_count,
                SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four_star_count
            FROM ratings 
            WHERE product_id = ?
        ";
        $stmt = $conn->prepare($verified_query);
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $stmt->bind_result($five_count, $four_count);
        if ($stmt->fetch()) {
            if ($five_count >= 10 || $four_count >= 10) {
                $is_verified = true;
            }
        }
        $stmt->close();

    } catch (Exception $e) {
        error_log("Product Detail Error: " . $e->getMessage());
        echo '<div style="color: red; padding: 20px;">';
        echo '<h2>Error Loading Product</h2>';
        echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
        echo '</div>';
        exit();
    }
    ?>


    <style>
        :root {
            --primary-color: #FF6A00;
            --primary-light: #FFF1E6;
            --primary-lighter: #ffe8cc;
            --secondary-color: #E85D04;
            --dark-color: #1a1a1a;
            --light-bg: #f9fafb;
            --text-color: #08090aff;
            --border-color: #e5e7eb;
            --gray-200: #eeeeee;
            --gray-300: #d0d0d0;
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.07);
            --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
        }

        .product-detail-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px 16px;
            background: #FFFFFF;
        }

        @media (min-width: 768px) {
            .product-detail-container {
                padding: 28px 20px;
            }
        }

        @media (max-width: 480px) {
            .product-detail-container {
                padding: 12px 12px;
            }
        }

        .breadcrumb-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 22px;
            margin-bottom: 20px;
            color: white !important;
            background: #FF6A00;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            border-radius: 18px;
            box-shadow: 0 6px 16px rgba(255,106,0,0.25);
            min-height: 42px;
            cursor: pointer;
            position: relative;
            overflow: hidden;
            border: none;
        }

        .breadcrumb-link i {
            font-size: 1rem;
            color: white !important;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            transition: all 0.3s ease;
        }

        .breadcrumb-link * {
            color: white !important;
        }

        .breadcrumb-link:hover {
            background: #E85D04;
            transform: translateY(-2px);
            box-shadow: 0 10px 24px rgba(255,106,0,0.35);
            color: white !important;
        }

        .breadcrumb-link:hover i {
            color: white !important;
        }

        .breadcrumb-link:hover * {
            color: white !important;
        }

        .breadcrumb-link:active {
            transform: translateY(0);
            box-shadow: 0 4px 12px rgba(255,106,0,0.2);
            color: white !important;
        }

        .breadcrumb-link:active * {
            color: white !important;
        }

        @media (max-width: 480px) {
            .breadcrumb-link {
                padding: 10px 18px;
                min-height: 40px;
                font-size: 0.85rem;
                gap: 6px;
                margin-bottom: 16px;
            }

            .breadcrumb-link i {
                font-size: 0.9rem;
            }
        }

        /* Force white text untuk semua child elements dan text nodes */
        .breadcrumb-link,
        .breadcrumb-link:visited,
        .breadcrumb-link:link {
            color: white !important;
        }

        .section-card {
            background: white;
            border-radius: 24px;
            border: none;
            padding: 20px;
            margin-bottom: 16px;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            animation: fadeUpIn 0.6s ease-out forwards;
            opacity: 0;
        }

        @keyframes fadeUpIn {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .section-card:nth-child(1) { animation-delay: 0.1s; }
        .section-card:nth-child(2) { animation-delay: 0.2s; }
        .section-card:nth-child(3) { animation-delay: 0.3s; }
        .section-card:nth-child(4) { animation-delay: 0.4s; }
        .section-card:nth-child(5) { animation-delay: 0.5s; }

        @media (min-width: 640px) {
            .section-card {
                padding: 22px;
                margin-bottom: 18px;
                border-radius: 24px;
            }
        }

        @media (min-width: 768px) {
            .section-card {
                padding: 24px;
                margin-bottom: 20px;
            }
        }

        @media (max-width: 480px) {
            .section-card {
                padding: 16px;
                margin-bottom: 12px;
                border-radius: 20px;
            }
        }

        .section-card:hover {
            box-shadow: 0 10px 24px rgba(0, 0, 0, 0.12);
            transform: translateY(-2px);
        }

        .hero-section-detail {
            display: flex;
            gap: 20px;
            align-items: center;
            padding: 0;
        }

        @media (max-width: 640px) {
            .hero-section-detail {
                gap: 16px;
                padding: 0;
            }
        }

        @media (max-width: 480px) {
            .hero-section-detail {
                gap: 14px;
                padding: 0;
            }
        }

        .product-image-detail {
            width: 110px;
            height: 110px;
            aspect-ratio: 1 / 1;
            background: #FF6A00;
            border-radius: 20px;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: rgba(255, 255, 255, 0.7);
            flex-shrink: 0;
            box-shadow: 0 8px 16px rgba(255,106,0,0.2);
            transition: all 0.3s ease;
        }

        .product-image-detail:hover {
            transform: scale(1.05);
            box-shadow: 0 12px 24px rgba(255,106,0,0.3);
        }

        @media (max-width: 640px) {
            .product-image-detail {
                width: 110px;
                height: 110px;
                border-radius: 20px;
            }
        }

        @media (max-width: 480px) {
            .product-image-detail {
                width: 100px;
                height: 100px;
                border-radius: 18px;
                font-size: 1.8rem;
            }
        }

        .product-image-detail img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .product-header-detail {
            display: flex;
            flex-direction: column;
            gap: 8px;
            flex: 1;
            justify-content: center;
        }

        @media (max-width: 640px) {
            .product-header-detail {
                gap: 7px;
            }
        }

        @media (max-width: 480px) {
            .product-header-detail {
                gap: 6px;
            }
        }

        .product-title-detail {
            font-size: 1.15rem;
            font-weight: 800;
            color: var(--dark-color);
            line-height: 1.3;
            margin: 0;
            letter-spacing: -0.3px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        @media (max-width: 640px) {
            .product-title-detail {
                font-size: 1.05rem;
            }
        }

        @media (max-width: 480px) {
            .product-title-detail {
                font-size: 0.95rem;
                -webkit-line-clamp: 2;
            }
        }

        .rating-summary {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 0;
            flex-wrap: nowrap;
        }

        @media (max-width: 480px) {
            .rating-summary {
                gap: 6px;
            }
        }

        .star-display {
            display: flex;
            gap: 2px;
            font-size: 0.9rem;
            align-items: center;
        }

        @media (max-width: 480px) {
            .star-display {
                font-size: 0.8rem;
                gap: 1px;
            }
        }

        .star-display i {
            color: #D9D9D9;
            transition: all 0.2s ease;
        }

        .star-display i.star-full {
            color: #FFC107 !important;
        }

        .star-display i.star-half {
            color: #D9D9D9 !important;
        }

        .star-display i.star-empty {
            color: #D9D9D9 !important;
        }

        .rating-text {
            font-size: 0.85rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        @media (max-width: 480px) {
            .rating-text {
                font-size: 0.75rem;
            }
        }

        .rating-count {
            font-size: 0.65rem;
            color: var(--primary-color);
            background: rgba(45, 159, 82, 0.15);
            padding: 4px 8px;
            border-radius: 14px;
            font-weight: 700;
            box-shadow: none;
            border: none;
            white-space: nowrap;
        }

        @media (max-width: 480px) {
            .rating-count {
                font-size: 0.6rem;
                padding: 3px 6px;
            }
        }

        .badge-verified {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: rgba(45, 159, 82, 0.15);
            padding: 4px 9px;
            border-radius: 14px;
            font-size: 0.65rem;
            color: var(--primary-color);
            font-weight: 700;
            box-shadow: none;
            border: none;
        }

        @media (max-width: 480px) {
            .badge-verified {
                font-size: 0.6rem;
                padding: 3px 7px;
            }
        }

        .badge-verified i {
            font-size: 0.65rem;
            color: var(--primary-color);
        }

        @media (max-width: 480px) {
            .badge-verified i {
                font-size: 0.6rem;
            }
        }

        .location-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            background: rgba(45, 159, 82, 0.15);
            padding: 4px 9px;
            border-radius: 14px;
            font-size: 0.65rem;
            color: var(--primary-color);
            font-weight: 700;
            box-shadow: none;
            border: none;
            white-space: nowrap;
        }

        @media (max-width: 480px) {
            .location-badge {
                font-size: 0.6rem;
                padding: 3px 7px;
            }
        }

        .location-badge i {
            font-size: 0.65rem;
        }

        @media (max-width: 480px) {
            .location-badge i {
                font-size: 0.6rem;
            }
        }

        .section-title-detail {
            font-size: 1.15rem;
            font-weight: 800;
            color: var(--dark-color);
            margin: 0 0 16px 0;
            display: flex;
            align-items: center;
            gap: 10px;
            letter-spacing: -0.3px;
        }

        @media (max-width: 480px) {
            .section-title-detail {
                font-size: 1rem;
                margin: 0 0 14px 0;
                gap: 8px;
            }
        }

        .section-title-detail i {
            color: white;
            font-size: 0.95rem;
            background: var(--primary-color);
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(255, 106, 0, 0.25);
            flex-shrink: 0;
        }

        @media (max-width: 480px) {
            .section-title-detail i {
                font-size: 0.85rem;
                width: 28px;
                height: 28px;
                border-radius: 6px;
            }
        }

        .description-text {
            color: #4b5563;
            line-height: 1.6;
            font-size: 0.95rem;
            white-space: pre-wrap;
            word-wrap: break-word;
            margin: 0;
            letter-spacing: 0.2px;
        }

        @media (max-width: 480px) {
            .description-text {
                font-size: 0.9rem;
                line-height: 1.5;
            }
        }

        .location-list {
            display: grid;
            gap: 10px;
        }

        .location-item {
            background: #f9fafb;
            padding: 14px;
            border-radius: 12px;
            border-left: 4px solid var(--primary-color);
            display: flex;
            gap: 10px;
            align-items: flex-start;
        }

        @media (max-width: 480px) {
            .location-item {
                padding: 12px;
                gap: 8px;
                border-radius: 10px;
            }
        }

        .location-number {
            background: var(--primary-color);
            color: white;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            flex-shrink: 0;
            font-size: 0.85rem;
        }

        @media (max-width: 480px) {
            .location-number {
                width: 26px;
                height: 26px;
                font-size: 0.8rem;
            }
        }

        .location-detail {
            flex: 1;
        }

        .location-name {
            font-weight: 700;
            color: var(--dark-color);
            font-size: 0.9rem;
            margin: 0 0 2px 0;
        }

        @media (max-width: 480px) {
            .location-name {
                font-size: 0.85rem;
                margin: 0 0 2px 0;
            }
        }

        .location-address {
            color: #666;
            font-size: 0.8rem;
            margin: 0 0 6px 0;
            line-height: 1.4;
        }

        @media (max-width: 480px) {
            .location-address {
                font-size: 0.75rem;
                margin: 0 0 4px 0;
            }
        }

        .location-coords {
            display: flex;
            align-items: center;
            gap: 4px;
            font-size: 0.75rem;
            color: #5e35b1;
        }

        @media (max-width: 480px) {
            .location-coords {
                font-size: 0.7rem;
            }
        }

        .btn-nearest {
            padding: 12px 24px;
            background: #FF6A00;
            color: white;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-weight: 700;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-family: 'Poppins', sans-serif;
            box-shadow: 0 6px 16px rgba(255,106,0,0.25);
            position: relative;
            overflow: hidden;
        }

        .btn-nearest::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .btn-nearest:active::before {
            width: 300px;
            height: 300px;
        }

        .btn-nearest:hover {
            background: #E85D04;
            transform: translateY(-2px);
            box-shadow: 0 10px 24px rgba(255,106,0,0.3);
        }

        .btn-nearest:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        @media (max-width: 480px) {
            .btn-nearest {
                padding: 10px 20px;
                font-size: 0.85rem;
                gap: 5px;
            }
        }

        .nearest-result {
            background: white;
            padding: 14px;
            border-radius: 16px;
            border-left: 5px solid var(--primary-color);
            line-height: 1.5;
            animation: slideInUp 0.4s ease-out;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
        }
        
        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        @media (max-width: 768px) {
            .nearest-result {
                padding: 12px;
                border-radius: 12px;
            }
            
            .nearest-result > div {
                display: grid !important;
                gap: 10px !important;
            }
        }

        .rating-section {
            background: white;
            border-radius: 24px;
            padding: 22px;
            border: none;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
            animation: fadeUpIn 0.6s ease-out 0.4s forwards;
            opacity: 0;
        }

        @media (max-width: 480px) {
            .rating-section {
                padding: 16px;
                border-radius: 20px;
            }
        }

        .rating-form {
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        .star-selector {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
        }

        .star-selector button {
            background: none;
            border: none;
            font-size: 2rem;
            cursor: pointer;
            color: #ddd;
            transition: all 0.3s ease;
            padding: 0;
            line-height: 1;
        }

        @media (max-width: 480px) {
            .star-selector button {
                font-size: 1.8rem;
            }
        }

        .star-selector button:hover {
            color: #ffc107;
            transform: scale(1.2) rotate(-5deg);
            text-shadow: 0 3px 8px rgba(255, 193, 7, 0.3);
        }

        .star-selector button.active {
            color: #ffc107;
            transform: scale(1.2);
            text-shadow: 0 3px 8px rgba(255, 193, 7, 0.3);
        }

        .rating-text-display {
            font-size: 0.9rem;
            color: var(--primary-color);
            font-weight: 700;
            background: var(--primary-lighter);
            padding: 8px 12px;
            border-radius: 10px;
            display: inline-block;
        }

        @media (max-width: 480px) {
            .rating-text-display {
                font-size: 0.85rem;
                padding: 6px 10px;
            }
        }

        .btn-submit-rating {
            width: 100%;
            background: #FF6A00;
            color: white;
            padding: 14px;
            border-radius: 12px;
            font-weight: 700;
            border: none;
            cursor: pointer;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            box-shadow: 0 6px 16px rgba(255,106,0,0.25);
            position: relative;
            overflow: hidden;
        }

        .btn-submit-rating::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.3);
            transform: translate(-50%, -50%);
            transition: width 0.6s, height 0.6s;
        }

        .btn-submit-rating:active::before {
            width: 300px;
            height: 300px;
        }

        .btn-submit-rating:hover:not(:disabled) {
            background: #E85D04;
            transform: translateY(-2px);
            box-shadow: 0 10px 24px rgba(255,106,0,0.3);
        }

        .btn-submit-rating:disabled {
            opacity: 0.5;
            cursor: not-allowed;
            background: #ccc;
        }

        .btn-submit-rating:disabled:hover {
            transform: none;
            box-shadow: none;
        }

        @media (max-width: 480px) {
            .btn-submit-rating {
                padding: 12px;
                font-size: 0.9rem;
            }
        }

        .alert-message {
            padding: 12px 14px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 16px;
            font-weight: 600;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.06);
            font-size: 0.9rem;
        }

        @media (max-width: 480px) {
            .alert-message {
                padding: 10px 12px;
                font-size: 0.85rem;
                gap: 8px;
                margin-bottom: 12px;
            }
        }

        .alert-message.success {
            background: #ffe8cc;
            color: #FF6A00;
            border: none;
        }

        .alert-message.warning {
            background: #fff3cd;
            color: #856404;
            border: none;
        }

        .alert-message.error {
            background: #f8d7da;
            color: #721c24;
            border: none;
        }

        .user-reviews {
            margin-top: 28px;
            animation: fadeUpIn 0.6s ease-out 0.5s forwards;
            opacity: 0;
        }

        .reviews-title {
            font-size: 1.15rem;
            font-weight: 800;
            color: var(--dark-color);
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
            letter-spacing: -0.3px;
        }

        @media (max-width: 480px) {
            .reviews-title {
                font-size: 1rem;
                margin-bottom: 14px;
                gap: 8px;
            }
        }

        .reviews-title i {
            color: white;
            font-size: 0.95rem;
            background: var(--primary-color);
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(255, 106, 0, 0.25);
            flex-shrink: 0;
        }

        @media (max-width: 480px) {
            .reviews-title i {
                font-size: 0.85rem;
                width: 28px;
                height: 28px;
                border-radius: 6px;
            }
        }

        .review-item {
            background: white;
            border: none;
            padding: 14px;
            border-radius: 14px;
            margin-bottom: 10px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.06);
            transition: all 0.3s ease;
            border-left: 4px solid var(--primary-lighter);
        }

        @media (max-width: 480px) {
            .review-item {
                padding: 12px;
                border-radius: 12px;
                margin-bottom: 8px;
            }
        }

        .review-item:hover {
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.08);
            transform: translateY(-1px);
            border-left-color: var(--primary-color);
        }

        .review-header {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 8px;
        }

        @media (max-width: 480px) {
            .review-header {
                gap: 8px;
                margin-bottom: 6px;
            }
        }

        .review-avatar {
            width: 36px;
            height: 36px;
            background: #FF6A00;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 800;
            flex-shrink: 0;
            font-size: 0.85rem;
            box-shadow: 0 3px 8px rgba(255, 106, 0, 0.15);
        }

        @media (max-width: 480px) {
            .review-avatar {
                width: 32px;
                height: 32px;
                font-size: 0.8rem;
            }
        }

        .review-name {
            font-weight: 700;
            color: var(--dark-color);
            font-size: 0.9rem;
            margin: 0;
        }

        @media (max-width: 480px) {
            .review-name {
                font-size: 0.85rem;
            }
        }

        .review-stars {
            display: flex;
            gap: 2px;
            font-size: 0.8rem;
            color: #ffc107;
            transition: all 0.3s ease;
        }

        @media (max-width: 480px) {
            .review-stars {
                font-size: 0.75rem;
                gap: 1px;
            }
        }

        .review-item:hover .review-stars {
            transform: scale(1.05);
            filter: drop-shadow(0 1px 3px rgba(255, 193, 7, 0.2));
        }

        @media (max-width: 767px) {
            .product-detail-container {
                padding: 16px;
            }

            .section-card {
                padding: 16px;
                margin-bottom: 16px;
            }

            .hero-section-detail {
                gap: 16px;
            }

            .product-title-detail {
                font-size: 1.5rem;
            }
        }

        /* Back to Top Button */
        .back-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: #FF6A00;
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: none;
            align-items: center;
            justify-content: center;
            box-shadow: 0 8px 20px rgba(255,106,0,0.3);
            transition: all 0.3s cubic-bezier(0.33, 1, 0.68, 1);
            z-index: 999;
            font-size: 1.2rem;
        }

        .back-to-top.show {
            display: flex;
        }

        .back-to-top:hover {
            background: #E85D04;
            transform: translateY(-5px);
            box-shadow: 0 12px 30px rgba(255,106,0,0.4);
        }

        .back-to-top:active {
            transform: translateY(-2px);
        }
    </style>

    <!-- Container -->
    <div class="product-detail-container">

    <!-- Back Button -->
    <a href="index.php" class="breadcrumb-link">
        <i class="fas fa-arrow-left"></i> Kembali
    </a>

    <!-- Hero Section: Photo + Info -->
    <div class="section-card">
        <div class="hero-section-detail">
            <!-- Photo -->
            <div class="product-image-detail">
                <?php if ($product['gambar']): ?>
                    <img src="<?php echo htmlspecialchars($product['gambar']); ?>" alt="<?php echo htmlspecialchars($product['nama_produk']); ?>" onerror="this.parentNode.innerHTML='<i class=\'fas fa-image\'></i>'">
                <?php else: ?>
                    <i class="fas fa-image"></i>
                <?php endif; ?>
            </div>

            <!-- Info Section -->
            <div class="product-header-detail">
                <!-- Product Name -->
                <h1 class="product-title-detail">
                    <?php echo htmlspecialchars($product['nama_produk']); ?>
                </h1>

                <!-- Rating Summary -->
                <div class="rating-summary">
                    <div class="star-display">
                        <?php 
                        // Logic untuk menampilkan bintang dengan warna: kuning untuk penuh, abu-abu untuk partial/kosong
                        for ($i = 1; $i <= 5; $i++): 
                            if ($i <= floor($avg_rating)) {
                                // Bintang penuh (kuning)
                                echo '<i class="fas fa-star star-full"></i>';
                            } else {
                                // Bintang partial atau kosong (abu-abu)
                                echo '<i class="fas fa-star star-empty"></i>';
                            }
                        endfor; 
                        ?>
                    </div>
                    <span class="rating-text">
                        <?php echo number_format($avg_rating, 1); ?>
                    </span>
                    <span class="rating-count">
                        (<?php echo $total_ratings; ?> rating)
                    </span>
                </div>

                <!-- Verified Badge + Location Count -->
                <div style="display: flex; flex-wrap: wrap; gap: 6px; align-items: center; margin-top: 4px;">
                    <?php if ($is_verified): ?>
                        <div class="badge-verified">
                            <i class="fas fa-check-circle"></i>
                            <span>Terverifikasi</span>
                        </div>
                    <?php endif; ?>
                    
                    <div class="location-badge">
                        <i class="fas fa-store"></i>
                        <span><?php echo count($locations); ?> Penjual</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Description Card -->
    <div class="section-card">
        <h2 class="section-title-detail">
            <i class="fas fa-list"></i>
            Deskripsi Produk
        </h2>
        <p class="description-text">
            <?php echo htmlspecialchars($product['deskripsi']); ?>
        </p>
    </div>

    <!-- Nearest Location Card -->
    <div class="section-card">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; gap: 12px; flex-wrap: wrap;">
            <h2 class="section-title-detail" style="margin: 0;">
                <i class="fas fa-location-arrow"></i>
                Lokasi UMKM Produk ini
            </h2>
            <button id="btnNearest" class="btn-nearest">
                <i class="fas fa-compass"></i> Cari
            </button>
        </div>
        <div id="nearestResult" style="display: none;" class="nearest-result"></div>
    </div>

    <!-- Rating Card -->
    <div class="rating-section" id="rating">
        <!-- Feedback Message -->
        <?php if (isset($_SESSION['message'])): ?>
        <div class="alert-message <?php echo $_SESSION['message_type'] === 'success' ? 'success' : 'error'; ?>">
            <i class="fas fa-<?php echo $_SESSION['message_type'] === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
            <span><?php echo htmlspecialchars($_SESSION['message']); ?></span>
        </div>
        <?php 
            unset($_SESSION['message']);
            unset($_SESSION['message_type']);
        ?>
        <?php endif; ?>

        <h2 class="section-title-detail" style="margin-bottom: 24px;">
            <i class="fas fa-star"></i>
            <?php echo $user_rating > 0 ? 'Rating Anda: ' . $user_rating . ' ⭐' : 'Berikan Rating'; ?>
        </h2>
        
        <?php if (!$is_logged_in && $user_rating > 0): ?>
        <!-- GUEST SUDAH RATING: Tampilkan rating + tombol edit/hapus -->
        <div style="background: #fff5e6; padding: 18px; border-radius: 12px; border-left: 4px solid #FF6A00; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
                <div>
                    <p style="margin: 0 0 8px 0; color: #2d3748; font-size: 0.95rem; font-weight: 600;">Rating Anda untuk produk ini:</p>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star" style="color: <?php echo $i <= $user_rating ? '#ffc107' : '#ddd'; ?>; font-size: 1.2rem;"></i>
                        <?php endfor; ?>
                        <span style="margin-left: 8px; font-size: 1rem; font-weight: 700; color: #FF6A00;"><?php echo $user_rating; ?>/5</span>
                    </div>
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="button" class="btn btn-sm" style="padding: 8px 16px; background: #FF6A00; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 0.85rem; transition: all 0.3s;" onmouseover="this.style.background='#E85D04'; this.style.transform='translateY(-2px)';" onmouseout="this.style.background='#FF6A00'; this.style.transform='';" onclick="toggleEditRatingGuest()">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button type="button" class="btn btn-sm" style="padding: 8px 16px; background: #dc2626; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 0.85rem; transition: all 0.3s;" onmouseover="this.style.background='#b91c1c'; this.style.transform='translateY(-2px)';" onmouseout="this.style.background='#dc2626'; this.style.transform='';" onclick="deleteGuestRating()">
                        <i class="fas fa-trash"></i> Hapus
                    </button>
                </div>
            </div>
        </div>

        <!-- Form edit rating untuk guest -->
        <form action="submit_rating.php" method="POST" id="editRatingFormGuest" class="rating-form" style="display: none;">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <input type="hidden" id="editGuestRatingValue" name="rating" value="0">
            
            <h4 style="margin: 0 0 16px 0; color: #2d3748; font-size: 0.95rem; font-weight: 600;">Ubah Rating Anda:</h4>
            
            <div class="star-selector" id="editRatingStarsGuest">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                    <button type="button" class="rating-star guest-rating-star" data-rating="<?php echo $i; ?>" onclick="setEditGuestRating(<?php echo $i; ?>)">
                        <i class="fas fa-star"></i>
                    </button>
                <?php endfor; ?>
            </div>
            <p class="rating-text-display" id="editGuestRatingText" style="margin-top: 16px;">Rating saat ini: <?php echo $user_rating; ?> bintang</p>
            
            <div style="display: flex; gap: 10px; margin-top: 16px;">
                <button type="submit" id="submitEditRatingBtnGuest" class="btn-submit-rating" disabled>
                    <i class="fas fa-check"></i> Simpan Perubahan
                </button>
                <button type="button" class="btn-submit-rating" style="flex: 1; background: #6b7280;" onclick="toggleEditRatingGuest()">
                    <i class="fas fa-times"></i> Batal
                </button>
            </div>
        </form>
        
        <?php elseif (!$is_logged_in && $user_rating === 0): ?>
        <!-- GUEST BARU/BELUM RATING: Form rating baru -->
        <form action="submit_rating.php" method="POST" id="ratingFormGuest" class="rating-form">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <input type="hidden" id="guestRatingValue" name="rating" value="0">
            
            <div class="star-selector" id="ratingStarsGuest">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                    <button type="button" class="rating-star guest-rating-star" data-rating="<?php echo $i; ?>" onclick="setGuestRating(<?php echo $i; ?>)">
                        <i class="fas fa-star"></i>
                    </button>
                <?php endfor; ?>
            </div>
            <p class="rating-text-display" id="guestRatingText" style="margin-top: 16px;">Pilih rating (1-5 bintang)</p>
            <button type="submit" id="submitRatingBtnGuest" class="btn-submit-rating" disabled>
                <i class="fas fa-check"></i> Simpan Rating
            </button>
        </form>
        <?php elseif ($is_logged_in && $user_rating > 0): ?>
        <!-- USER LOGIN SUDAH RATING: Tampilkan info + tombol edit/hapus -->
        <div style="background: #fff5e6; padding: 18px; border-radius: 12px; border-left: 4px solid #FF6A00; margin-bottom: 20px;">
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 16px; flex-wrap: wrap;">
                <div>
                    <p style="margin: 0 0 8px 0; color: #2d3748; font-size: 0.95rem; font-weight: 600;">Rating Anda untuk produk ini:</p>
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <i class="fas fa-star" style="color: <?php echo $i <= $user_rating ? '#ffc107' : '#ddd'; ?>; font-size: 1.2rem;"></i>
                        <?php endfor; ?>
                        <span style="margin-left: 8px; font-size: 1rem; font-weight: 700; color: #FF6A00;"><?php echo $user_rating; ?>/5</span>
                    </div>
                </div>
                <div style="display: flex; gap: 10px;">
                    <button type="button" class="btn btn-sm" style="padding: 8px 16px; background: #FF6A00; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 0.85rem; transition: all 0.3s;" onmouseover="this.style.background='#E85D04'; this.style.transform='translateY(-2px)';" onmouseout="this.style.background='#FF6A00'; this.style.transform='';" onclick="toggleEditRating()">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <form action="delete_rating.php" method="POST" style="display: inline;" onsubmit="return confirm('Hapus rating ini?');">
                        <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                        <button type="submit" class="btn btn-sm" style="padding: 8px 16px; background: #dc2626; color: white; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; font-size: 0.85rem; transition: all 0.3s;" onmouseover="this.style.background='#b91c1c'; this.style.transform='translateY(-2px)';" onmouseout="this.style.background='#dc2626'; this.style.transform='';">
                            <i class="fas fa-trash"></i> Hapus
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Form edit rating untuk user login -->
        <form action="submit_rating.php" method="POST" id="editRatingForm" class="rating-form" style="display: none;">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <input type="hidden" id="editRatingValue" name="rating" value="0">
            
            <h4 style="margin: 0 0 16px 0; color: #2d3748; font-size: 0.95rem; font-weight: 600;">Ubah Rating Anda:</h4>
            
            <div class="star-selector" id="editRatingStars">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                    <button type="button" class="rating-star" data-rating="<?php echo $i; ?>" onclick="setEditRating(<?php echo $i; ?>)">
                        <i class="fas fa-star"></i>
                    </button>
                <?php endfor; ?>
            </div>
            <p class="rating-text-display" id="editRatingText" style="margin-top: 16px;">Rating saat ini: <?php echo $user_rating; ?> bintang</p>
            
            <div style="display: flex; gap: 10px; margin-top: 16px;">
                <button type="submit" id="submitEditRatingBtn" class="btn-submit-rating" disabled>
                    <i class="fas fa-check"></i> Simpan Perubahan
                </button>
                <button type="button" class="btn-submit-rating" style="flex: 1; background: #6b7280;" onclick="toggleEditRating()">
                    <i class="fas fa-times"></i> Batal
                </button>
            </div>
        </form>
        <?php elseif ($is_logged_in && $user_rating === 0): ?>
        <!-- USER LOGIN BELUM RATING: Form rating baru -->
        <form action="submit_rating.php" method="POST" id="ratingForm" class="rating-form" onsubmit="return submitRating()">
            <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
            <div class="star-selector" id="ratingStars">
                <?php for ($i = 1; $i <= 5; $i++): ?>
                    <button type="button" class="rating-star" data-rating="<?php echo $i; ?>" onclick="setRating(<?php echo $i; ?>)">
                        <i class="fas fa-star"></i>
                    </button>
                <?php endfor; ?>
            </div>
            <input type="hidden" id="ratingValue" name="rating" value="0">
            <p class="rating-text-display" id="ratingText">Pilih rating (1-5 bintang)</p>
            <button type="submit" id="submitRatingBtn" class="btn-submit-rating" disabled>
                <i class="fas fa-check"></i> Simpan Rating
            </button>
        </form>
        <?php endif; ?>
    </div>

    <!-- Recommendation Alternatives Section -->
    <div style="padding: 20px; background: #ffe8cc; border-radius: 20px; margin-top: 20px; border: 2px solid #FF6A00;">
        <h3 style="margin: 0 0 12px 0; color: #FF6A00; display: flex; align-items: center; gap: 10px; font-size: 1.1rem; font-weight: 700;">
            <i class="fas fa-lightbulb"></i> Cari Alternatif
        </h3>
        <p style="margin: 0 0 16px 0; color: #2d3748; font-size: 0.95rem; line-height: 1.5;">
            Ingin mencoba produk lain dengan rating tinggi? Lihat rekomendasi produk terbaik kami.
        </p>
        <a href="home.php#rekomendasi" class="btn btn-success" style="display: inline-flex; align-items: center; gap: 8px; padding: 12px 24px; background-color: #FF6A00 !important; color: white !important; text-decoration: none !important; border-radius: 8px; font-weight: 700 !important; font-size: 0.95rem; transition: all 0.3s ease; box-shadow: 0 2px 8px rgba(255, 106, 0, 0.2);">
            <i class="fas fa-sparkles"></i> 
            <span>Lihat Rekomendasi</span>
        </a>
    </div>

    </div><!-- End container -->

    <script>
    // Function untuk submit rating langsung tanpa modal (untuk guest dan user)
    function submitRatingDirect(event) {
        event.preventDefault();
        
        // Get rating value
        const ratingValue = document.getElementById('ratingValue');
        if (!ratingValue || !ratingValue.value) {
            alert('Pilih rating terlebih dahulu');
            return;
        }
        
        // Submit rating via form
        const form = document.getElementById('ratingForm');
        if (form) {
            form.submit();
        }
    }

    // Function untuk set guest rating
    function setGuestRating(rating) {
        const ratingInput = document.getElementById('guestRatingValue');
        const ratingText = document.getElementById('guestRatingText');
        const submitBtn = document.getElementById('submitRatingBtnGuest');
        const stars = document.querySelectorAll('.guest-rating-star');
        
        if (ratingInput) {
            ratingInput.value = rating;
        }
        
        if (ratingText) {
            ratingText.textContent = rating + ' dari 5 bintang';
        }
        
        if (submitBtn) {
            submitBtn.disabled = false;
        }
        
        // Update visual feedback
        stars.forEach((s, idx) => {
            if ((idx + 1) <= rating) {
                s.style.color = '#ffc107';
                s.classList.add('active');
            } else {
                s.style.color = '#d1d5db';
                s.classList.remove('active');
            }
        });
    }

    // Function untuk toggle edit rating form
    function toggleEditRating() {
        const editForm = document.getElementById('editRatingForm');
        if (editForm) {
            if (editForm.style.display === 'none') {
                editForm.style.display = 'block';
            } else {
                editForm.style.display = 'none';
            }
        }
    }

    // Function untuk toggle edit rating form guest
    function toggleEditRatingGuest() {
        const editForm = document.getElementById('editRatingFormGuest');
        if (editForm) {
            if (editForm.style.display === 'none') {
                editForm.style.display = 'block';
            } else {
                editForm.style.display = 'none';
            }
        }
    }

    // Function untuk set edit guest rating
    function setEditGuestRating(rating) {
        const ratingInput = document.getElementById('editGuestRatingValue');
        const ratingText = document.getElementById('editGuestRatingText');
        const submitBtn = document.getElementById('submitEditRatingBtnGuest');
        const stars = document.querySelectorAll('#editRatingStarsGuest .rating-star');
        
        if (ratingInput) {
            ratingInput.value = rating;
        }
        
        if (ratingText) {
            ratingText.textContent = rating + ' dari 5 bintang';
        }
        
        if (submitBtn) {
            submitBtn.disabled = false;
        }
        
        // Update visual feedback
        stars.forEach((s, idx) => {
            if ((idx + 1) <= rating) {
                s.style.color = '#ffc107';
                s.classList.add('active');
            } else {
                s.style.color = '#d1d5db';
                s.classList.remove('active');
            }
        });
    }

    // Function untuk delete guest rating
    function deleteGuestRating() {
        if (confirm('Apakah Anda yakin ingin menghapus rating ini? Anda bisa memberi rating lagi setelahnya.')) {
            const productId = document.querySelector('input[name="product_id"]').value;
            
            // Submit delete request
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'delete_rating.php';
            
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'product_id';
            input.value = productId;
            
            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Flag login dari PHP
        const isLoggedIn = <?php echo json_encode($is_logged_in); ?>;
        
        // Rating stars functionality
        const ratingStars = document.querySelectorAll('.rating-star');
        ratingStars.forEach(star => {
            star.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Proses rating untuk user yang sudah login
                const rating = this.dataset.rating;
                const ratingValue = document.getElementById('ratingValue');
                if (ratingValue) {
                    ratingValue.value = rating;
                }
                
                const ratingText = document.getElementById('ratingText');
                if (ratingText) {
                    ratingText.textContent = rating + ' dari 5 bintang';
                }
                
                // Update visual feedback untuk semua bintang
                ratingStars.forEach((s, idx) => {
                    if ((idx + 1) <= rating) {
                        s.style.color = '#ffc107';
                        s.classList.add('active');
                    } else {
                        s.style.color = '#ddd';
                        s.classList.remove('active');
                    }
                });
                
                // Enable submit button
                const submitBtn = document.getElementById('submitRatingBtn');
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.style.opacity = '1';
                    submitBtn.style.cursor = 'pointer';
                }
            });
        });

        // Form submission validation
        const ratingForm = document.getElementById('ratingForm');
        if (ratingForm) {
            ratingForm.addEventListener('submit', function(e) {
                const ratingValue = document.getElementById('ratingValue');
                if (!ratingValue) {
                    e.preventDefault();
                    alert('Form tidak valid: ratingValue tidak ditemukan');
                    return false;
                }
                
                const rating = parseInt(ratingValue.value);
                if (!rating || rating < 1 || rating > 5) {
                    e.preventDefault();
                    alert('Silakan pilih rating terlebih dahulu (1-5 bintang)');
                    return false;
                }
            });
        }

        // Calculate distance from user to first location
        // PENTING: Ini harus SELALU konsisten dengan koordinat yang ada di database
        const productId = <?php echo $product_id; ?>;
        const locationLat = <?php echo !empty($locations) && $locations[0]['latitude'] !== null ? $locations[0]['latitude'] : 'null'; ?>;
        const locationLng = <?php echo !empty($locations) && $locations[0]['longitude'] !== null ? $locations[0]['longitude'] : 'null'; ?>;
        
        // DEBUG: Log koordinat yang digunakan
        console.log("Product Detail - Using coordinates:", locationLat, locationLng);

        function updateDistance(userLat, userLng) {
            // Cari lokasi yang BENAR-BENAR terdekat dari semua lokasi yang ada
            const nearest = findNearestLocation(userLat, userLng);
            
            if (nearest) {
                const distanceElement = document.getElementById('userDistance');
                if (distanceElement) {
                    console.log("Nearest location found:", nearest.name, nearest.distance.toFixed(2), "km");
                    distanceElement.textContent = nearest.distance.toFixed(2) + ' km';
                }
            } else {
                // Fallback jika tidak ada lokasi dengan koordinat valid
                const distanceElement = document.getElementById('userDistance');
                if (distanceElement) {
                    distanceElement.textContent = '--';
                }
            }
        }

        function calculateDistance(lat1, lon1, lat2, lon2) {
            // Haversine formula - HARUS SAMA dengan PHP version
            const R = 6371; // Radius bumi dalam km
            
            // Konversi ke radian
            const lat1Rad = lat1 * Math.PI / 180;
            const lon1Rad = lon1 * Math.PI / 180;
            const lat2Rad = lat2 * Math.PI / 180;
            const lon2Rad = lon2 * Math.PI / 180;
            
            // Hitung perbedaan dalam radian
            const dLat = lat2Rad - lat1Rad;
            const dLon = lon2Rad - lon1Rad;
            
            // Rumus Haversine
            const a = 
                Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(lat1Rad) * Math.cos(lat2Rad) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            return R * c;
        }

        // Array semua lokasi dari database (harus disinkronkan dengan data PHP)
        const allLocations = [
            <?php 
            foreach ($locations as $loc) {
                $lat = $loc['latitude'] !== null ? $loc['latitude'] : 'null';
                $lng = $loc['longitude'] !== null ? $loc['longitude'] : 'null';
                echo "{ name: '" . addslashes($loc['lokasi']) . "', lat: $lat, lng: $lng },";
            }
            ?>
        ];
        console.log("All locations loaded:", allLocations);

        function findNearestLocation(userLat, userLng) {
            let nearest = null;
            let minDistance = Infinity;
            
            allLocations.forEach(loc => {
                if (loc.lat !== null && loc.lng !== null) {
                    const dist = calculateDistance(userLat, userLng, loc.lat, loc.lng);
                    if (dist < minDistance) {
                        minDistance = dist;
                        nearest = { name: loc.name, distance: dist, lat: loc.lat, lng: loc.lng };
                    }
                }
            });
            
            return nearest;
        }

        // Get user location
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                function(pos) {
                    updateDistance(pos.coords.latitude, pos.coords.longitude);
                },
                function() {
                    // Default to Bekasi if geolocation fails - HARUS SAMA dengan yang di API
                    updateDistance(-6.19, 106.99);
                },
                { timeout: 5000 }
            );
        } else {
            // Browser tidak support geolocation, gunakan default
            updateDistance(-6.19, 106.99);
        }

        // Nearest location button
        const btn = document.getElementById('btnNearest');
        const result = document.getElementById('nearestResult');

        if (btn) {
            btn.addEventListener('click', function() {
                btn.disabled = true;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
                result.style.display = 'block';
                result.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mencari lokasi terdekat...';

                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                        function(pos) {
                            const lat = pos.coords.latitude;
                            const lng = pos.coords.longitude;
                            console.log('User location:', lat, lng);
                            fetchNearestLocations(lat, lng);
                        },
                        function(error) {
                            console.log('Geolocation error:', error);
                            result.innerHTML = '<div style="text-align: center; padding: 20px; color: #f59e0b;"><i class="fas fa-location-arrow" style="font-size: 2rem; margin-bottom: 8px; display: block;"></i> Izin lokasi ditolak. Menampilkan hasil dengan algoritma default.</div>';
                            fetchNearestLocations(-6.19, 106.99);
                        },
                        { 
                            timeout: 10000,
                            enableHighAccuracy: true
                        }
                    );
                } else {
                    result.innerHTML = '<div style="text-align: center; padding: 20px; color: #d32f2f;"><i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 8px; display: block;"></i> Browser tidak mendukung Geolocation API</div>';
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-location-arrow"></i> Lokasi Terdekat';
                }
            });
        }

        function fetchNearestLocations(lat, lng) {
            console.log("Fetching nearest locations for product", productId, "from user location", lat, lng);
            fetch('api_nearest_location.php?product_id=' + productId + '&lat=' + lat + '&lng=' + lng)
                .then(r => {
                    console.log("Response status:", r.status, r.statusText);
                    if (!r.ok) {
                        return r.text().then(text => {
                            throw new Error('HTTP ' + r.status + ': ' + text);
                        });
                    }
                    return r.text();
                })
                .then(text => {
                    console.log("Raw response:", text);
                    try {
                        const data = JSON.parse(text);
                        console.log("Parsed data:", data);
                        if (data.error) {
                            result.innerHTML = '<div style="text-align: center; padding: 20px; color: #d32f2f;"><i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 8px; display: block;"></i> ' + data.error + '</div>';
                        } else {
                            const dataArray = Array.isArray(data) ? data : (data && typeof data === 'object' ? [data] : []);
                            
                            if (dataArray.length === 0) {
                                result.innerHTML = '<div style="text-align: center; padding: 20px; color: #f57c00;"><i class="fas fa-info-circle" style="font-size: 2rem; margin-bottom: 8px; display: block;"></i> Lokasi tidak ditemukan</div>';
                            } else {
                                let html = '<div style="display: grid; gap: 12px; margin: 0; padding: 0;">';
                                
                                dataArray.forEach((loc, i) => {
                                    // Medal badge
                                    let medalIcon = '';
                                    if (i === 0) {
                                        medalIcon = '🥇';
                                    } else if (i === 1) {
                                        medalIcon = '🥈';
                                    } else if (i === 2) {
                                        medalIcon = '🥉';
                                    }
                                    
                                    html += '<div style="';
                                    html += 'background: #FFFFFF; ';
                                    html += 'border-radius: 16px; ';
                                    html += 'border: 1px solid #e5e7eb; ';
                                    html += 'padding: 16px; ';
                                    html += 'box-shadow: 0 4px 12px rgba(0,0,0,0.08); ';
                                    html += 'transition: all 0.3s ease; ';
                                    html += 'position: relative; ';
                                    html += 'overflow: hidden; ';
                                    html += '">';
                                    
                                    // Medal badge di pojok kanan
                                    if (medalIcon) {
                                        html += '<div style="';
                                        html += 'position: absolute; ';
                                        html += 'top: -8px; right: -8px; ';
                                        html += 'font-size: 2.5rem; ';
                                        html += 'opacity: 0.8; ';
                                        html += '">' + medalIcon + '</div>';
                                    }
                                    
                                    // Header: Distance label dan alamat
                                    html += '<div style="margin-bottom: 14px;">';
                                    html += '<div style="color: #999; font-size: 0.75rem; font-weight: 600; text-transform: uppercase; margin-bottom: 6px;">';
                                    if (i === 0) html += '⭐ Terdekat';
                                    else html += 'Pilihan ' + (i + 1);
                                    html += '</div>';
                                    html += '<h3 style="margin: 0 0 8px 0; color: #1f2937; font-size: 1.05rem; font-weight: 700; word-break: break-word; line-height: 1.3;">';
                                    html += '📍 ' + (loc.lokasi || 'Unknown');
                                    html += '</h3>';
                                    html += '</div>';
                                    
                                    // Distance info
                                    if (loc.distance !== undefined && loc.distance !== null) {
                                        html += '<div style="';
                                        html += 'color: #10b981; ';
                                        html += 'font-size: 0.85rem; ';
                                        html += 'font-weight: 600; ';
                                        html += 'margin-bottom: 12px; ';
                                        html += 'padding: 6px 0; ';
                                        html += 'border-bottom: 1px solid #f0f0f0; ';
                                        html += 'padding-bottom: 12px; ';
                                        html += '">';
                                        html += '<i class="fas fa-location-arrow" style="margin-right: 4px;"></i>';
                                        html += 'Jarak: ' + loc.distance.toFixed(2) + ' km';
                                        html += '</div>';
                                    }
                                    
                                    // Coordinates display
                                    if (loc.latitude !== null && loc.longitude !== null) {
                                        html += '<div style="';
                                        html += 'margin-top: 12px; ';
                                        html += 'padding-top: 12px; ';
                                        html += 'border-top: 1px solid #f0f0f0; ';
                                        html += 'color: #999; ';
                                        html += 'font-size: 0.75rem; ';
                                        html += 'background: #f5f5f5; ';
                                        html += 'padding: 8px; ';
                                        html += 'border-radius: 6px; ';
                                        html += 'word-break: break-all; ';
                                        html += 'font-family: monospace; ';
                                        html += '">';
                                        html += parseFloat(loc.latitude).toFixed(6) + ', ' + parseFloat(loc.longitude).toFixed(6);
                                        html += '</div>';
                                    }
                                    
                                    html += '</div>';
                                });
                                
                                html += '</div>';
                                result.innerHTML = html;
                            }
                        }
                    } catch (e) {
                        console.error('Parse error:', e, "Text was:", text);
                        result.innerHTML = '<div style="text-align: center; padding: 20px; color: #d32f2f;"><i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 8px; display: block;"></i> Error: ' + e.message + '</div>';
                    }
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-location-arrow"></i> Lokasi Terdekat';
                })
                .catch(e => {
                    console.error('Fetch error:', e);
                    result.innerHTML = '<div style="text-align: center; padding: 20px; color: #d32f2f;"><i class="fas fa-exclamation-circle" style="font-size: 2rem; margin-bottom: 8px; display: block;"></i> Error: ' + e.message + '</div>';
                    btn.disabled = false;
                    btn.innerHTML = '<i class="fas fa-location-arrow"></i> Lokasi Terdekat';
                });
        }
    });
    </script>

    <!-- Modal Login/Register untuk Rating - Professional & Modern -->
    <div class="modal fade" id="authModal" tabindex="-1" aria-hidden="true" style="color-scheme: light !important;">
        <div class="modal-dialog modal-dialog-centered modal-lg" style="color-scheme: light !important;">
            <div class="modal-content" style="color-scheme: light !important; background: #FFFFFF !important; color: #2d3748 !important;">
                <!-- Header dengan Tabs -->
                <div class="modal-header" style="color-scheme: light !important; background: #FFFFFF !important; color: #1a1a1a !important;">
                    <ul class="nav nav-tabs w-100 border-0" role="tablist" id="authTabs">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="login-tab" data-bs-toggle="tab" data-bs-target="#login-pane" type="button" role="tab">
                                <i class="fas fa-sign-in-alt"></i> Masuk
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="register-tab" data-bs-toggle="tab" data-bs-target="#register-pane" type="button" role="tab">
                                <i class="fas fa-user-plus"></i> Daftar
                            </button>
                        </li>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!-- Tab Content -->
                <div class="modal-body" style="color-scheme: light !important; background: #FFFFFF !important; color: #2d3748 !important;">
                    <div class="tab-content" id="authTabContent">
                        <!-- Login Tab -->
                        <div class="tab-pane fade show active" id="login-pane" role="tabpanel">
                            <div style="color: #2d3748 !important;">
                                <h5 style="color: #1a1a1a !important; font-weight: 800 !important;">Masuk ke Akun Anda</h5>
                                <p style="color: #6b7280 !important;">Login untuk memberikan rating dan rekomendasi pada produk favorit Anda</p>
                            </div>

                            <form id="loginForm" method="POST" action="login.php">
                                <div class="mb-3">
                                    <label for="loginEmail" class="form-label" style="color: #1a1a1a !important;">
                                        <i class="fas fa-envelope" style="margin-right: 4px;"></i> Email
                                    </label>
                                    <input type="email" class="form-control" id="loginEmail" name="email" 
                                        placeholder="example@email.com" required 
                                        autocomplete="email"
                                        style="background: #ffffff !important; border-color: #e5e7eb !important;">
                                </div>

                                <div class="mb-3">
                                    <label for="loginPassword" class="form-label" style="color: #1a1a1a !important;">
                                        <i class="fas fa-lock" style="margin-right: 4px;"></i> Password
                                    </label>
                                    <input type="password" class="form-control" id="loginPassword" name="password" 
                                        placeholder="Masukkan password Anda" required 
                                        autocomplete="current-password"
                                        style="background: #ffffff !important; border-color: #e5e7eb !important;">
                                </div>

                                <input type="hidden" name="product_id" id="loginProductId" value="0">

                                <button type="submit" class="btn w-100">
                                    <i class="fas fa-sign-in-alt"></i> Masuk Sekarang
                                </button>
                            </form>

                            <div class="text-center">
                                <a href="forgot_password.php">
                                    <i class="fas fa-question-circle"></i> Lupa password?
                                </a>
                            </div>
                        </div>

                        <!-- Register Tab -->
                        <div class="tab-pane fade" id="register-pane" role="tabpanel">
                            <div style="color: #2d3748 !important;">
                                <h5 style="color: #1a1a1a !important; font-weight: 800 !important;">Buat Akun Baru</h5>
                                <p style="color: #6b7280 !important;">Daftar sekarang dan bergabung dengan komunitas UMKM Recommend</p>
                            </div>

                            <form id="registerForm" method="POST" action="register.php">
                                <div class="mb-3">
                                    <label for="registerName" class="form-label" style="color: #1a1a1a !important;">
                                        <i class="fas fa-user" style="margin-right: 4px;"></i> Nama Lengkap
                                    </label>
                                    <input type="text" class="form-control" id="registerName" name="name" 
                                        placeholder="Nama lengkap Anda" required 
                                        autocomplete="name"
                                        style="background: #ffffff !important; border-color: #e5e7eb !important;">
                                </div>

                                <div class="mb-3">
                                    <label for="registerEmail" class="form-label" style="color: #1a1a1a !important;">
                                        <i class="fas fa-envelope" style="margin-right: 4px;"></i> Email
                                    </label>
                                    <input type="email" class="form-control" id="registerEmail" name="email" 
                                        placeholder="example@email.com" required 
                                        autocomplete="email"
                                        style="background: #ffffff !important; border-color: #e5e7eb !important;">
                                </div>

                                <div class="mb-3">
                                    <label for="registerPassword" class="form-label" style="color: #1a1a1a !important;">
                                        <i class="fas fa-lock" style="margin-right: 4px;"></i> Password
                                    </label>
                                    <input type="password" class="form-control" id="registerPassword" name="password" 
                                        placeholder="Minimal 6 karakter" required 
                                        autocomplete="new-password"
                                        style="background: #ffffff !important; border-color: #e5e7eb !important;">
                                </div>

                                <div class="mb-3">
                                    <label for="registerPasswordConfirm" class="form-label" style="color: #1a1a1a !important;">
                                        <i class="fas fa-check-circle" style="margin-right: 4px;"></i> Konfirmasi Password
                                    </label>
                                    <input type="password" class="form-control" id="registerPasswordConfirm" name="password_confirm" 
                                        placeholder="Ulangi password Anda" required 
                                        autocomplete="new-password"
                                        style="background: #ffffff !important; border-color: #e5e7eb !important;">
                                </div>

                                <input type="hidden" name="product_id" id="registerProductId" value="0">

                                <button type="submit" class="btn w-100">
                                    <i class="fas fa-user-plus"></i> Daftar Sekarang
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    </div><!-- End container-main -->

    <!-- Footer -->
    <?php require_once 'includes/footer.php'; ?>

    <!-- Back to Top Button -->
    <button class="back-to-top" id="backToTopBtn" aria-label="Kembali ke atas">
        <i class="fas fa-chevron-up"></i>
    </button>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/home.js"></script>
    <script>
        // Back to Top Button Functionality
        const backToTopBtn = document.getElementById('backToTopBtn');
        
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        });
        
        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        // Rating functions
        function setRating(value) {
            console.log("Setting rating to: " + value);
            const ratingValueInput = document.getElementById('ratingValue');
            if (ratingValueInput) {
                ratingValueInput.value = value;
                console.log("Rating input value set to: " + ratingValueInput.value);
            } else {
                console.error("ratingValue input not found");
            }
            
            const ratingText = document.getElementById('ratingText');
            if (ratingText) {
                ratingText.textContent = value + ' dari 5 bintang';
            }
            
            // Update visual
            const ratingStars = document.querySelectorAll('#ratingStars .rating-star');
            ratingStars.forEach((star, idx) => {
                if ((idx + 1) <= value) {
                    star.style.color = '#ffc107';
                    star.classList.add('active');
                } else {
                    star.style.color = '#ddd';
                    star.classList.remove('active');
                }
            });
            
            // Enable submit button
            const submitBtn = document.getElementById('submitRatingBtn');
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.style.opacity = '1';
                submitBtn.style.cursor = 'pointer';
            }
        }

        function submitRating() {
            console.log("Submit rating called");
            const ratingValue = document.getElementById('ratingValue');
            const rating = ratingValue ? parseInt(ratingValue.value) : 0;
            console.log("Rating value: " + rating);
            
            if (!rating || rating < 1 || rating > 5) {
                alert('Silakan pilih rating terlebih dahulu (1-5 bintang)');
                return false;
            }
            console.log("Rating validation passed, submitting form");
            return true;
        }
    </script>
    </body>
    </html>
