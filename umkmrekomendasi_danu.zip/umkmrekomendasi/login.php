<?php
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Start session hanya jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
        header("Location: khususjier/admin/dashboard.php");
    } else {
        header("Location: index.php");
    }
    exit();
}

$message = '';
$message_type = '';
$prefilled_email = $_GET['email'] ?? '';
$success_register = isset($_GET['success']);

if ($success_register) {
    $message = 'Registrasi berhasil! Silakan login dengan akun Anda.';
    $message_type = 'success';
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = isset($_POST['email']) ? trim(strtolower($_POST['email'])) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    
    if (empty($email) || empty($password)) {
        $message = 'Email dan password harus diisi';
        $message_type = 'danger';
    } else {
        require_once 'config/database.php';
        
        // Direct query untuk debug
        $email_escaped = $conn->real_escape_string($email);
        $query = "SELECT id, name, email, password, is_admin FROM users WHERE email = '$email_escaped'";
        $result = $conn->query($query);
        
        if (!$result || $result->num_rows == 0) {
            $message = 'Email atau password tidak valid';
            $message_type = 'danger';
        } else {
            $row = $result->fetch_assoc();
            
            // Check if password is hashed or plain text
            $password_valid = false;
            
            // Try bcrypt verify first
            if (substr($row['password'], 0, 4) === '$2y$' || substr($row['password'], 0, 4) === '$2a$' || substr($row['password'], 0, 4) === '$2b$') {
                $password_valid = password_verify($password, $row['password']);
            } else {
                // Fallback to plain text comparison (for migration)
                $password_valid = ($password === $row['password']);
            }
            
            if ($password_valid) {
                // Login sukses - Migrasi guest ratings ke user account
                require_once 'config/session.php';
                
                // Ambil guest_id dari cookie
                $guest_id = getGuestId();
                $user_id = $row['id'];
                
                // Migrasi: UPDATE ratings SET user_id = ?, guest_id = NULL WHERE guest_id = ?
                if ($guest_id) {
                    $migrate_query = "UPDATE ratings SET user_id = " . intval($user_id) . ", guest_id = NULL WHERE guest_id = '" . $conn->real_escape_string($guest_id) . "' AND user_id = 0";
                    $conn->query($migrate_query);
                    error_log("Guest ID '" . $guest_id . "' migrated to User ID " . $user_id);
                }
                
                // Set session
                session_regenerate_id(true);
                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $row['name'];
                $_SESSION['user_email'] = $row['email'];
                $_SESSION['is_admin'] = $row['is_admin'];
                
                // Determine redirect
                $redirect_url = 'index.php';
                if (intval($_SESSION['is_admin']) == 1) {
                    $redirect_url = 'khususjier/admin/dashboard.php';
                } elseif ($product_id > 0) {
                    $redirect_url = 'product_detail.php?id=' . $product_id . '#rating';
                }
                header("Location: " . $redirect_url);
                exit();
            } else {
                $message = 'Email atau password tidak valid';
                $message_type = 'danger';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    
 <link rel="apple-touch-icon" sizes="180x180" href="/umkmrekomendasi/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/umkmrekomendasi/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/umkmrekomendasi/favicon-16x16.png">
<link rel="icon" href="/umkmrekomendasi/favicon.ico">
<link rel="manifest" href="/umkmrekomendasi/site.webmanifest">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6A00;
            --primary-light: #FFF1E6;
            --primary-lighter: #FFF1E6;
            --secondary-color: #E85D04;
            --dark-color: #1a1a1a;
            --text-color: #2d3748;
            --border-color: #e5e7eb;
            --light-bg: #f9fafb;
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.07);
            --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
            --shadow-xl: 0 20px 40px rgba(255, 106, 0, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', 'Inter', sans-serif;
            background: linear-gradient(135deg, #D84315 0%, #FF6A00 50%, #FFB347 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -100px;
            left: -100px;
            z-index: 0;
            animation: float 6s ease-in-out infinite;
        }

        body::after {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 50%;
            bottom: -50px;
            right: -50px;
            z-index: 0;
            animation: float 8s ease-in-out infinite reverse;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(30px); }
        }

        .login-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
            max-width: 1200px;
            width: 100%;
            position: relative;
            z-index: 1;
        }

        .login-illustration {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
            animation: slideInLeft 0.8s ease-out;
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .login-illustration-icon {
            font-size: 6rem;
            margin-bottom: 32px;
            opacity: 0.95;
            animation: float 4s ease-in-out infinite;
            filter: drop-shadow(0 10px 20px rgba(0, 0, 0, 0.2));
        }

        .login-illustration h2 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 16px;
            letter-spacing: -1px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }

        .login-illustration p {
            font-size: 1.1rem;
            opacity: 0.95;
            line-height: 1.8;
            max-width: 350px;
            text-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }

        .login-container {
            background: white;
            border-radius: 20px;
            box-shadow: var(--shadow-xl);
            padding: 50px;
            width: 100%;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: slideInRight 0.8s ease-out;
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .login-header {
            margin-bottom: 32px;
        }

        .login-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 10px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .login-header h1 i {
            color: var(--primary-color);
            font-size: 1.6rem;
        }

        .login-header p {
            color: #64748b;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .form-group {
            margin-bottom: 22px;
            position: relative;
        }

        .form-label {
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 10px;
            display: block;
            font-size: 0.95rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-control {
            border-radius: 12px;
            border: 2px solid var(--border-color);
            padding: 14px 18px;
            font-size: 0.95rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-family: 'Poppins', sans-serif;
            width: 100%;
            background: white;
            color: var(--text-color);
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(29, 126, 63, 0.12);
            outline: none;
            background: rgba(29, 126, 63, 0.02);
        }

        .form-control:hover {
            border-color: var(--primary-light);
        }

        .form-control::placeholder {
            color: #cbd5e1;
        }

        .info-box {
            background: linear-gradient(135deg, rgba(255, 106, 0, 0.1) 0%, rgba(232, 93, 4, 0.08) 100%);
            border-left: 4px solid var(--primary-color);
            padding: 16px 18px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 0.9rem;
            color: #D84315;
            font-weight: 500;
            backdrop-filter: blur(5px);
        }

        .info-box i {
            margin-right: 10px;
            font-size: 1rem;
            color: var(--primary-color);
        }

        .info-box a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 700;
            transition: all 0.3s;
        }

        .info-box a:hover {
            text-decoration: underline;
            color: var(--secondary-color);
        }

        .btn-login {
            background: var(--primary-color);
            border: none;
            color: white;
            padding: 14px 24px;
            font-weight: 700;
            border-radius: 12px;
            width: 100%;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            margin-top: 8px;
            font-family: 'Poppins', sans-serif;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 15px rgba(255, 106, 0, 0.3);
            position: relative;
            overflow: hidden;
        }

        .btn-login:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(255, 106, 0, 0.4);
            background: var(--secondary-color);
        }

        .btn-login:active {
            transform: translateY(-1px);
        }

        .alert {
            border-radius: 12px;
            border: 2px solid;
            margin-bottom: 20px;
            font-size: 0.9rem;
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.4s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-danger {
            background: #fef2f2;
            color: #991b1b;
            border-color: #fecaca;
        }

        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-color: #bbf7d0;
        }

        .alert i {
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        .login-footer {
            text-align: center;
            margin-top: 28px;
            padding-top: 28px;
            border-top: 2px solid var(--border-color);
        }

        .login-footer p {
            color: #64748b;
            font-size: 0.9rem;
            margin: 8px 0;
            font-weight: 500;
        }

        .login-footer a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 700;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .login-footer a:hover {
            color: var(--primary-dark);
            transform: translateX(2px);
        }

        @media (max-width: 992px) {
            .login-wrapper {
                grid-template-columns: 1fr;
                gap: 40px;
            }

            .login-illustration {
                display: none;
            }

            .login-container {
                padding: 40px 30px;
            }

            .login-header h1 {
                font-size: 1.6rem;
            }
        }

        @media (max-width: 640px) {
            body {
                padding: 16px;
            }

            .login-container {
                padding: 30px 20px;
                border-radius: 16px;
            }

            .login-header h1 {
                font-size: 1.4rem;
            }

            .login-header p {
                font-size: 0.9rem;
            }

            .form-group {
                margin-bottom: 18px;
            }

            .form-label {
                font-size: 0.85rem;
            }

            .form-control {
                padding: 12px 16px;
                font-size: 0.9rem;
                border-radius: 10px;
            }

            .btn-login {
                padding: 12px 20px;
                font-size: 0.95rem;
            }

            .login-footer {
                margin-top: 20px;
                padding-top: 20px;
            }

            .login-footer p {
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-wrapper">
        <div class="login-illustration">
            <div class="login-illustration-icon">
                <i class="fas fa-utensils"></i>
            </div>
            <h2>UMKM Recommend</h2>
            <p>Temukan makanan UMKM favoritmu dengan rekomendasi pintar berdasarkan selera kamu</p>
        </div>

        <div class="login-container">
            <div class="login-header">
                <h1><i class="fas fa-sign-in-alt"></i> Login</h1>
                <p>Masuk untuk mendapatkan rekomendasi terbaik</p>
            </div>

            <div class="info-box">
                <i class="fas fa-info-circle"></i>
                <strong>User Login</strong> - Masukkan email dan password Anda untuk login
            </div>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>" role="alert">
                    <i class="fas fa-<?php echo $message_type === 'danger' ? 'exclamation-circle' : 'check-circle'; ?>"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           value="<?php echo htmlspecialchars($prefilled_email); ?>" 
                           placeholder="Masukkan email Anda" required>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" 
                           placeholder="Masukkan password Anda" required>
                </div>

                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
            </form>

            <div class="login-footer">
                <p>Belum punya akun? <a href="register.php"><i class="fas fa-user-plus"></i> Daftar di sini</a></p>
                <p><a href="forgot_password.php"><i class="fas fa-question-circle"></i> Lupa password?</a></p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
