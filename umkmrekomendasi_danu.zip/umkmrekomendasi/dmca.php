<?php
require_once 'config/database.php';
require_once 'config/session.php';
$is_logged_in = isLoggedIn();
$page_title = "DMCA Disclaimer";
require_once 'includes/header.php';
?>

<style>
    :root {
        --primary-color: #FF6A00;
        --primary-light: #FFF1E6;
        --primary-dark: #E85D04;
        --dark-color: #1a1a1a;
        --light-bg: #f9fafb;
        --text-color: #6b7280;
        --border-color: #e5e7eb;
    }

    .container-lg {
        max-width: 1400px;
        margin: 0 auto;
        padding: 0 16px;
        box-sizing: border-box;
        width: 100%;
    }

    @media (min-width: 768px) {
        .container-lg { padding: 0 24px; }
    }

    /* DMCA Hero */
    .dmca-hero {
        background: linear-gradient(135deg, #FF6A00 0%, #E85D04 50%, #D9480F 100%);
        color: white;
        padding: 60px 0;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .dmca-hero::before {
        content: '';
        position: absolute;
        width: 300px;
        height: 300px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        top: -100px;
        right: -100px;
    }

    .dmca-hero::after {
        content: '';
        position: absolute;
        width: 250px;
        height: 250px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 50%;
        bottom: -50px;
        left: -50px;
    }

    .dmca-hero-content {
        position: relative;
        z-index: 2;
    }

    .dmca-hero h1 {
        font-size: clamp(2rem, 5vw, 3.2rem);
        font-weight: 800;
        margin-bottom: 12px;
        line-height: 1.1;
        letter-spacing: -0.5px;
    }

    .dmca-hero p {
        font-size: clamp(0.95rem, 2vw, 1.1rem);
        opacity: 0.95;
        max-width: 600px;
        margin: 0 auto;
    }

    /* DMCA Container */
    .dmca-container {
        max-width: 900px;
        margin: 0 auto;
        padding: 60px 16px;
        box-sizing: border-box;
        width: 100%;
    }

    @media (min-width: 768px) {
        .dmca-container { padding: 60px 24px; }
    }

    .dmca-intro {
        text-align: center;
        margin-bottom: 50px;
    }

    .dmca-intro-title {
        font-size: clamp(1.6rem, 4vw, 2.2rem);
        font-weight: 800;
        color: var(--dark-color);
        margin-bottom: 12px;
        letter-spacing: -0.5px;
    }

    .dmca-intro-subtitle {
        font-size: 1rem;
        color: var(--text-color);
        max-width: 500px;
        margin: 0 auto;
        line-height: 1.6;
    }

    /* DMCA Content */
    .dmca-content {
        background: white;
        padding: 30px;
        border-radius: 12px;
        margin-bottom: 20px;
        border: 1px solid var(--border-color);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    }

    .dmca-content:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        border-color: var(--primary-light);
    }

    .dmca-content h3 {
        font-size: 1.1rem;
        font-weight: 700;
        margin-bottom: 16px;
        color: var(--dark-color);
        display: flex;
        align-items: center;
        gap: 12px;
        letter-spacing: -0.3px;
    }

    .dmca-content h3 i {
        color: white;
        font-size: 0.85rem;
        background: var(--primary-color);
        width: 28px;
        height: 28px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 6px;
        box-shadow: 0 3px 10px rgba(255, 106, 0, 0.25);
        flex-shrink: 0;
    }

    .dmca-content p {
        color: var(--text-color);
        line-height: 1.7;
        font-size: 0.95rem;
        margin: 0;
    }

    .dmca-content p + p {
        margin-top: 12px;
    }

    .dmca-content a {
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .dmca-content a:hover {
        text-decoration: underline;
        color: var(--primary-dark);
    }

    .dmca-content ul {
        margin: 12px 0 0 24px;
        padding: 0;
    }

    .dmca-content li {
        color: var(--text-color);
        line-height: 1.7;
        font-size: 0.95rem;
        margin-bottom: 8px;
    }

    /* DMCA CTA */
    .dmca-cta {
        background: linear-gradient(135deg, #FF6A00 0%, #E85D04 100%);
        color: white;
        padding: 50px 30px;
        border-radius: 14px;
        text-align: center;
        margin-top: 60px;
        box-shadow: 0 10px 30px rgba(255, 106, 0, 0.2);
    }

    .dmca-cta h3 {
        font-size: 1.5rem;
        font-weight: 800;
        margin-bottom: 10px;
        letter-spacing: -0.5px;
    }

    .dmca-cta p {
        margin-bottom: 20px;
        opacity: 0.95;
        font-size: 0.95rem;
    }

    .dmca-cta-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        background: white;
        color: var(--primary-color);
        padding: 12px 28px;
        border-radius: 10px;
        border: none;
        font-weight: 700;
        font-size: 0.95rem;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        text-decoration: none;
        font-family: 'Poppins', sans-serif;
    }

    .dmca-cta-btn:hover {
        background: #f3f4f6;
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        color: var(--primary-color);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .dmca-container {
            padding: 40px 0;
        }

        .dmca-hero {
            padding: 40px 0;
        }

        .dmca-hero h1 {
            font-size: 1.8rem;
        }

        .dmca-hero p {
            font-size: 0.9rem;
        }

        .dmca-intro {
            margin-bottom: 30px;
        }

        .dmca-intro-title {
            font-size: 1.4rem;
        }

        .dmca-intro-subtitle {
            font-size: 0.9rem;
        }

        .dmca-content {
            padding: 24px;
        }

        .dmca-content h3 {
            font-size: 1rem;
        }

        .dmca-cta {
            padding: 35px 20px;
            margin-top: 40px;
        }

        .dmca-cta h3 {
            font-size: 1.2rem;
        }

        .dmca-cta p {
            font-size: 0.9rem;
        }
    }

    @media (max-width: 480px) {
        .dmca-hero {
            padding: 30px 0;
        }

        .dmca-hero h1 {
            font-size: 1.5rem;
        }

        .dmca-intro-title {
            font-size: 1.2rem;
        }

        .dmca-content {
            padding: 16px;
        }

        .dmca-content h3 {
            font-size: 0.95rem;
            gap: 8px;
        }

        .dmca-cta {
            padding: 25px 16px;
            margin-top: 30px;
        }

        .dmca-cta h3 {
            font-size: 1rem;
        }

        .dmca-cta p {
            font-size: 0.85rem;
        }

        .dmca-cta-btn {
            padding: 10px 20px;
            font-size: 0.85rem;
        }
    }
</style>

<!-- DMCA Hero Section -->
<section class="dmca-hero">
    <div class="container-lg">
        <div class="dmca-hero-content">
            <h1>DMCA Disclaimer</h1>
            <p>Informasi tentang hak cipta dan kebijakan DMCA kami</p>
        </div>
    </div>
</section>

<!-- DMCA Content -->
<section>
    <div class="container-lg dmca-container">
        <!-- DMCA Intro -->
        <div class="dmca-intro">
            <h2 class="dmca-intro-title">Perlindungan Hak Cipta</h2>
            <p class="dmca-intro-subtitle">BEKOMIN ID menghormati hak kekayaan intelektual dan berkomitmen untuk menangani setiap dugaan pelanggaran hak cipta secara serius sesuai dengan ketentuan hukum yang berlaku.</p>
        </div>

        <!-- DMCA Items -->
        <div class="dmca-content">
            <h3><i class="fas fa-copyright"></i> Penghormatan terhadap Hak Cipta</h3>
            <p>BEKOMIN ID menghormati hak cipta dan hak kekayaan intelektual milik pihak lain serta mengharapkan seluruh pengguna platform untuk melakukan hal yang sama. BEKOMIN ID akan menanggapi pemberitahuan dugaan pelanggaran hak cipta yang disampaikan secara sah dan sesuai dengan prosedur yang berlaku.</p>
        </div>

        <div class="dmca-content">
            <h3><i class="fas fa-exclamation-circle"></i> Melaporkan Pelanggaran Hak Cipta</h3>
            <p>Apabila Anda meyakini bahwa suatu konten yang terdapat pada platform BEKOMIN ID melanggar hak cipta yang Anda miliki atau wakili secara sah, Anda dapat menyampaikan pemberitahuan tertulis melalui halaman kontak BEKOMIN ID.</p>
            <p>Pemberitahuan tersebut sebaiknya memuat informasi berikut:</p>
            <ul>
                <li>Identitas Anda sebagai pemilik hak cipta atau perwakilan yang berwenang</li>
                <li>Deskripsi mengenai karya yang dilindungi hak cipta</li>
                <li>Lokasi atau informasi yang dapat digunakan untuk menemukan konten yang diduga melanggar hak cipta</li>
                <li>Penjelasan mengenai dugaan pelanggaran hak cipta</li>
                <li>Informasi kontak yang dapat dihubungi, seperti nama, alamat, nomor telepon, dan alamat email</li>
                <li>Pernyataan bahwa informasi yang disampaikan adalah benar dan akurat serta Anda memiliki kewenangan untuk mengajukan laporan tersebut</li>
            </ul>
        </div>

        <div class="dmca-content">
            <h3><i class="fas fa-user-tie"></i> Konten Pihak Ketiga</h3>
            <p>Platform BEKOMIN ID dapat menampilkan informasi mengenai produk UMKM, termasuk nama produk, deskripsi, gambar, kategori, dan informasi terkait lainnya yang diberikan oleh pengguna atau pihak terkait.</p>
            <p>Pihak yang mengunggah konten bertanggung jawab atas keakuratan, legalitas, serta hak penggunaan terhadap konten yang mereka berikan. BEKOMIN ID tidak mengklaim kepemilikan atas konten yang diunggah oleh pengguna dan akan menindaklanjuti laporan pelanggaran hak cipta yang valid sesuai dengan prosedur yang berlaku.</p>
        </div>

        <div class="dmca-content">
            <h3><i class="fas fa-user-check"></i> Tanggung Jawab Pengguna</h3>
            <p>Dengan menggunakan platform BEKOMIN ID, pengguna menyatakan bahwa:</p>
            <ul>
                <li>Pengguna memiliki hak atau izin yang diperlukan untuk mengunggah dan membagikan konten yang disediakan</li>
                <li>Konten yang diunggah tidak melanggar hak cipta atau hak kekayaan intelektual pihak lain</li>
                <li>Pengguna bertanggung jawab atas konten yang mereka unggah</li>
                <li>Pengguna bersedia bertanggung jawab atas klaim atau tuntutan yang timbul akibat konten yang mereka unggah apabila terbukti melanggar hak pihak lain</li>
            </ul>
        </div>

        <div class="dmca-content">
            <h3><i class="fas fa-gavel"></i> Prosedur Pengaduan DMCA</h3>
            <p>BEKOMIN ID akan meninjau setiap laporan dugaan pelanggaran hak cipta yang diterima. Apabila laporan tersebut memenuhi persyaratan dan terdapat dasar yang memadai, BEKOMIN ID dapat mengambil tindakan yang sesuai, termasuk membatasi akses atau menghapus konten yang diduga melanggar hak cipta.</p>
            <p>BEKOMIN ID juga dapat mengambil tindakan terhadap akun atau pengguna yang secara berulang kali terbukti melakukan pelanggaran hak cipta.</p>
        </div>

        <div class="dmca-content">
            <h3><i class="fas fa-redo"></i> Counter-Notice</h3>
            <p>Apabila Anda meyakini bahwa suatu konten milik Anda telah dihapus atau dibatasi secara keliru, Anda dapat mengajukan pemberitahuan sanggahan (counter-notice) melalui halaman kontak BEKOMIN ID.</p>
            <p>Setiap pemberitahuan sanggahan akan ditinjau dan ditangani sesuai dengan prosedur serta ketentuan hukum yang berlaku.</p>
        </div>

        <div class="dmca-content">
            <h3><i class="fas fa-envelope"></i> Hubungi Kami</h3>
            <p>Untuk melaporkan dugaan pelanggaran hak cipta, mengajukan counter-notice, atau menyampaikan pertanyaan mengenai kebijakan hak cipta BEKOMIN ID, silakan menghubungi kami melalui halaman <a href="contact.php">Kontak</a> yang tersedia pada platform BEKOMIN ID.</p>
        </div>

        <!-- DMCA CTA -->
        <div class="dmca-cta">
            <h3>Ada Pertanyaan Tentang Hak Cipta?</h3>
            <p>Hubungi tim support kami untuk informasi lebih lanjut tentang kebijakan DMCA kami</p>
            <a href="contact.php" class="dmca-cta-btn">
                <i class="fas fa-envelope"></i>
                Hubungi Kami
            </a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
