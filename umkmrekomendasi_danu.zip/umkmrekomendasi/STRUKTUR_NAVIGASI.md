# STRUKTUR NAVIGASI WEBSITE BEKOMIN ID

## Ringkasan Hubungan Antar Halaman

Berikut adalah hubungan navigasi lengkap antara semua halaman website BEKOMIN ID:

### Hubungan Navigasi (Network Map)

```
Home ↔ Semua Produk
Home ↔ Lihat Rekomendasi
Home ↔ Tentang
Home ↔ Login
Home ↔ Register
Home ↔ Profile (jika login)
Home ↔ Logout (jika login)
Home ↔ Search Results
Home → Product Detail

Login ↔ Register
Login → Home
Login → Semua Produk
Login → Lihat Rekomendasi
Login → Profile
Login → Product Detail → Rating

Register → Login
Register → Home

Semua Produk ↔ Home
Semua Produk ↔ Search Results
Semua Produk → Product Detail
Semua Produk ↔ Category Filter

Product Detail ↔ Semua Produk
Product Detail → Rating
Product Detail → Home
Product Detail → Lihat Rekomendasi

Search Results ↔ Semua Produk
Search Results → Product Detail
Search Results ↔ Category Filter

Lihat Rekomendasi → Product Detail
Lihat Rekomendasi → Home

Profile ↔ Home
Profile → Logout

Tentang ↔ Home
Tentang → Kontak Kami
Tentang → FAQ
Tentang → Ketentuan Penggunaan
Tentang → DMCA

Kontak Kami ↔ Home
Kontak Kami ↔ Tentang

FAQ ↔ Home
FAQ ↔ Tentang

Ketentuan Penggunaan ↔ Home
Ketentuan Penggunaan ↔ Tentang

DMCA ↔ Home
DMCA ↔ Tentang

Forgot Password → Reset Password
Reset Password → Login

Admin Dashboard (jika admin login)
Admin Dashboard → Products Management
Admin Dashboard → Users Management
Admin Dashboard → Logout
```

---

## DAFTAR HALAMAN DAN HUBUNGAN NAVIGASI DETAIL

### 1. HOME (home.php)

**Deskripsi:**
Halaman Home merupakan halaman utama website BEKOMIN ID. Halaman ini menampilkan hero section dengan search bar, promo slider, dan product cards yang dapat diklik untuk melihat detail produk.

**Akses Dari:**
- URL langsung: `/home.php`
- Logo/Brand pada navbar semua halaman
- Tombol Home di sidebar menu
- Link di footer

**Navigasi Keluar (dapat diakses dari Home):**
- ↔ Semua Produk: Via tombol "Semua Produk" atau link di sidebar menu
- ↔ Lihat Rekomendasi: Via tombol "Lihat Rekomendasi" atau link di sidebar menu
- ↔ Tentang: Via tombol di promo section atau link di footer
- ↔ Login: Via tombol "Login" di sidebar (jika belum login)
- ↔ Register: Via tombol "Daftar" atau link di login page
- ↔ Profile: Via sidebar menu "Profil" (hanya jika sudah login)
- ↔ Logout: Via sidebar menu "Logout" (hanya jika sudah login)
- → Search Results: Via form search pada hero section
- → Product Detail: Via klik pada product card

**Komponen Navigasi pada Halaman:**
1. **Navbar:**
   - Logo "BEKOMIN ID" - Link ke home.php
   - Hamburger Menu Button - Buka sidebar navigation
   - Category Dropdown - Filter kategori produk

2. **Sidebar Menu (Off-canvas):**
   - Home - Link ke home.php
   - Semua Produk - Link ke index.php
   - Lihat Rekomendasi - Link ke rekomendasi.php
   - Tentang - Link ke about.php
   - Profil - Link ke profile.php (hanya jika login)
   - Logout - Link ke logout.php (hanya jika login)
   - Login - Link ke login.php (hanya jika tidak login)

3. **Search Section:**
   - Search Input Field - Submit pencarian ke search_results.php
   - Form ID: heroSearchForm

4. **Product Cards:**
   - "Detail" Button - Link ke product_detail.php?id={id}
   - "Rating" Button - Link ke product_detail.php?id={id}#rating

5. **Footer:**
   - Ketentuan Penggunaan - Link ke terms.php
   - Kontak Kami - Link ke contact.php
   - About - Link ke about.php
   - DMCA Disclaimer - Link ke dmca.php
   - FAQ - Link ke faq.php
   - Logo/Brand - Link ke home.php

6. **Back to Top Button:**
   - Scroll ke atas halaman (smooth scroll)

---

### 2. SEMUA PRODUK (index.php)

**Deskripsi:**
Halaman Semua Produk menampilkan katalog lengkap produk UMKM dengan fitur search, category filter, dan product cards yang dapat dilihat detailnya. Halaman ini dapat diakses oleh semua user (login atau tidak).

**Akses Dari:**
- Tombol "Semua Produk" di Home
- Link "Semua Produk" di sidebar menu
- URL: `/index.php`

**Navigasi Keluar:**
- ↔ Home: Via tombol Home di sidebar atau logo brand
- ↔ Search Results: Via search form dengan query filter
- → Product Detail: Via "Detail" atau "Rating" button pada product card
- ↔ Category Filter: Via category buttons untuk filter produk

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **Search Bar:**
   - Form method GET ke index.php
   - Input field dengan placeholder "Cari produk..."
   - Clear button (x) jika ada search query

3. **Category Filter Buttons:**
   - "Semua" - Link ke index.php (reset filter)
   - "Makanan Berat" - Link ke index.php?kategori=Makanan Berat
   - "Jajanan & Street Food" - Link ke index.php?kategori=Jajanan & Street Food
   - "Minuman" - Link ke index.php?kategori=Minuman
   - "Makanan Rumahan" - Link ke index.php?kategori=Makanan Rumahan

4. **Product Card:**
   - Category Badge
   - "Terverifikasi" Badge (jika produk terverifikasi)
   - Product Image - Link ke product_detail.php?id={id}
   - Product Name
   - Product Description
   - Star Rating Display
   - "Detail" Button - Link ke product_detail.php?id={id}
   - "Rating" Button - Link ke product_detail.php?id={id}#rating

5. **Footer:** (sama seperti Home)

---

### 3. DETAIL PRODUK (product_detail.php)

**Deskripsi:**
Halaman Detail Produk menampilkan informasi lengkap tentang satu produk tertentu termasuk deskripsi, gambar, lokasi UMKM, rating dari user, dan form untuk memberikan rating. User dapat melihat rating dari user lain dan memberikan rating baru.

**Akses Dari:**
- "Detail" button dari product card di halaman Home atau Semua Produk
- "Rating" button dari product card
- Direct URL: `/product_detail.php?id={product_id}`
- Link dari Lihat Rekomendasi

**Navigasi Keluar:**
- ↔ Semua Produk: Via tombol back atau sidebar menu
- → Rating Section: Via "Rating" button atau anchor #rating
- → Home: Via tombol Home atau logo brand
- → Lihat Rekomendasi: Via link "Lihat rekomendasi produk serupa"

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **Product Information Section:**
   - Product Name
   - Product Image
   - Product Description
   - Category
   - Location/Address display

3. **Rating Section:**
   - Anchor ID: #rating
   - Display semua rating dari user
   - Form Rating dengan:
     - Star rating input (1-5)
     - Submit button untuk submit rating
   - Rating display untuk user yang sudah login/tidak login

4. **Related Products Section:**
   - Link ke product detail lainnya
   - Link "Lihat rekomendasi produk serupa" → rekomendasi.php

5. **Footer:** (sama seperti Home)

---

### 4. LIHAT REKOMENDASI (rekomendasi.php)

**Deskripsi:**
Halaman Lihat Rekomendasi menampilkan rekomendasi produk berdasarkan Collaborative Filtering algorithm. Halaman ini hanya dapat diakses jika user sudah memberikan minimal 1 rating. Jika tidak ada rating, akan redirect ke Home.

**Akses Dari:**
- Tombol "Lihat Rekomendasi" di Home
- Link "Lihat Rekomendasi" di sidebar menu
- URL: `/rekomendasi.php`

**Navigasi Keluar:**
- → Product Detail: Via klik pada recommendation card
- → Home: Via sidebar menu atau logo brand

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **Recommendation Cards:**
   - Link ke product_detail.php?id={id}
   - Display similar users yang memberikan rating

3. **Similar Users Section:**
   - Display daftar user dengan rating pattern serupa

4. **Footer:** (sama seperti Home)

---

### 5. PENCARIAN (search_results.php)

**Deskripsi:**
Halaman Search Results menampilkan hasil pencarian produk berdasarkan query search yang dikirim dari Home atau halaman lainnya. Halaman ini menggunakan fuzzy matching untuk mencari produk dengan algoritma similarity score.

**Akses Dari:**
- Submit form search dari Home
- Submit form search dari Semua Produk
- Direct URL: `/search_results.php?search={query}&category={optional}`

**Navigasi Keluar:**
- → Product Detail: Via klik pada product card
- ↔ Semua Produk: Via sidebar atau hasil kategorisasi
- ↔ Category Filter: Via category buttons untuk refine search

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **Search Bar:**
   - Form dengan GET method
   - Menampilkan search query yang digunakan
   - Clear/Reset search link

3. **Category Filter Buttons:**
   - Filter hasil berdasarkan kategori
   - Link: search_results.php?search={query}&category={cat}

4. **Product Cards:**
   - "Detail" button → product_detail.php?id={id}
   - "Rating" button → product_detail.php?id={id}#rating

5. **Footer:** (sama seperti Home)

---

### 6. LOGIN (login.php)

**Deskripsi:**
Halaman Login untuk user yang sudah memiliki akun. Form berisi email dan password. Setelah login berhasil, user akan diredirect ke halaman Index atau Admin Dashboard (jika user adalah admin).

**Akses Dari:**
- Tombol "Login" di sidebar (jika belum login)
- Link "Login" di forgot password success page
- Direct URL: `/login.php`
- Jika sudah login dan akses login.php, akan redirect ke index.php

**Navigasi Keluar:**
- ↔ Register: Via link "Daftar di sini" di bawah form
- ↔ Forgot Password: Via link "Lupa password?" di bawah form
- → Home (index.php): Setelah login berhasil (untuk regular user)
- → Admin Dashboard: Setelah login berhasil (untuk admin)
- → Product Detail: Jika login dari product detail page (redirect ke product_detail.php?id={id}#rating)

**Komponen Navigasi pada Halaman:**
1. **Form Elements:**
   - Email input field
   - Password input field
   - Submit button "Login"

2. **Link Navigation:**
   - "Daftar di sini" → register.php
   - "Lupa password?" → forgot_password.php

3. **Ilustrasi Section (Desktop only):**
   - Info text tentang fitur BEKOMIN ID

---

### 7. REGISTER (register.php)

**Deskripsi:**
Halaman Register untuk membuat akun baru. Form berisi nama lengkap, email, password, dan konfirmasi password. Setelah register berhasil, user akan otomatis login dan diredirect ke index.php.

**Akses Dari:**
- Link "Daftar" atau "Daftar di sini" dari Login page
- Tombol "Register" (jika ada)
- Direct URL: `/register.php`
- Jika sudah login dan akses register.php, akan redirect ke index.php

**Navigasi Keluar:**
- ↔ Login: Via link "Login di sini"
- → Home (index.php): Setelah register berhasil (auto login)

**Komponen Navigasi pada Halaman:**
1. **Form Elements:**
   - Name input field
   - Email input field
   - Password input field dengan strength meter
   - Confirm Password input field
   - Submit button "Daftar Sekarang"

2. **Link Navigation:**
   - "Login di sini" → login.php

3. **Ilustrasi Section (Desktop only):**
   - Info text tentang keuntungan bergabung

---

### 8. PROFIL USER (profile.php)

**Deskripsi:**
Halaman Profile menampilkan informasi profil user (nama, email) dan memungkinkan user untuk mengupdate profil atau mengubah password. Halaman ini hanya dapat diakses oleh user yang sudah login.

**Akses Dari:**
- Tombol "Profil" di sidebar menu (hanya jika login)
- Direct URL: `/profile.php`
- Jika tidak login, akan redirect ke login.php

**Navigasi Keluar:**
- ↔ Home: Via sidebar menu atau logo brand
- → Logout: Via "Logout" button atau sidebar menu

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **Profile Form Tabs:**
   - Tab 1: Update Profile
     - Name field
     - Email field
     - Submit button "Update Profile"
   
   - Tab 2: Change Password
     - Old Password field
     - New Password field
     - Confirm Password field
     - Submit button "Change Password"

3. **Logout Option:**
   - "Logout" button atau link di sidebar

4. **Footer:** (sama seperti Home)

---

### 9. LOGOUT (logout.php)

**Deskripsi:**
Halaman Logout melakukan logout dari session user. Setelah logout, user akan diredirect ke home.php. File ini tidak menampilkan UI, hanya melakukan proses logout dan redirect.

**Akses Dari:**
- Link "Logout" di sidebar menu (hanya jika login)
- URL: `/logout.php`

**Navigasi Keluar:**
- → Home: Setelah logout (automatic redirect)

---

### 10. LUPA PASSWORD (forgot_password.php)

**Deskripsi:**
Halaman Forgot Password memungkinkan user untuk mereset password dengan memasukkan email. Sistem akan mengirimkan email reset link ke email user.

**Akses Dari:**
- Link "Lupa password?" di halaman Login
- Direct URL: `/forgot_password.php`

**Navigasi Keluar:**
- ↔ Login: Via link kembali ke login
- → Reset Password: Setelah submit email (via link di email)

**Komponen Navigasi pada Halaman:**
1. **Form Elements:**
   - Email input field
   - Submit button

2. **Link Navigation:**
   - "Kembali ke Login" → login.php

---

### 11. RESET PASSWORD (reset_password.php)

**Deskripsi:**
Halaman Reset Password untuk mengatur password baru setelah user menerima link reset dari email. User perlu memasukkan password baru dan konfirmasi password.

**Akses Dari:**
- Link reset password dari email (dengan token)
- URL: `/reset_password.php?token={reset_token}`

**Navigasi Keluar:**
- → Login: Setelah reset password berhasil

**Komponen Navigasi pada Halaman:**
1. **Form Elements:**
   - New Password field
   - Confirm Password field
   - Submit button

2. **Link Navigation:**
   - "Kembali ke Login" → login.php (setelah sukses)

---

### 12. TENTANG (about.php)

**Deskripsi:**
Halaman Tentang menyediakan informasi tentang website BEKOMIN ID, misi, visi, dan fitur-fitur utama.

**Akses Dari:**
- Tombol "Tentang" di sidebar menu
- Link "About" di footer
- Link "Tentang Kami" di footer quick links
- Direct URL: `/about.php`

**Navigasi Keluar:**
- ↔ Home: Via sidebar menu atau logo brand
- ↔ Kontak Kami: Via tombol atau link di halaman
- ↔ FAQ: Via tombol atau link di halaman
- ↔ Ketentuan Penggunaan: Via tombol atau link di halaman
- ↔ DMCA: Via tombol atau link di halaman

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **About Content:**
   - Hero section dengan info about
   - Link ke related pages

3. **Footer Links:**
   - Ketentuan Penggunaan → terms.php
   - Kontak Kami → contact.php
   - FAQ → faq.php
   - DMCA Disclaimer → dmca.php

---

### 13. KONTAK (contact.php)

**Deskripsi:**
Halaman Kontak memungkinkan user untuk menghubungi tim BEKOMIN ID melalui form contact. Form berisi nama, email, subject, dan message.

**Akses Dari:**
- Link "Kontak Kami" di footer
- Link di halaman About
- Direct URL: `/contact.php`

**Navigasi Keluar:**
- ↔ Home: Via sidebar menu atau logo brand
- ↔ About: Via back link atau sidebar

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **Contact Form:**
   - Name field
   - Email field
   - Subject field
   - Message textarea
   - Submit button

3. **Footer:** (sama seperti Home)

---

### 14. FAQ (faq.php)

**Deskripsi:**
Halaman FAQ (Frequently Asked Questions) menampilkan daftar pertanyaan umum dan jawabannya tentang BEKOMIN ID.

**Akses Dari:**
- Link "FAQ" di footer
- Link di halaman About
- Direct URL: `/faq.php`

**Navigasi Keluar:**
- ↔ Home: Via sidebar menu atau logo brand
- ↔ About: Via back link atau sidebar

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **FAQ Accordion/Expandable Items:**
   - FAQ questions dengan expandable answers

3. **Footer:** (sama seperti Home)

---

### 15. KETENTUAN PENGGUNAAN (terms.php)

**Deskripsi:**
Halaman Ketentuan Penggunaan menampilkan terms and conditions penggunaan website BEKOMIN ID.

**Akses Dari:**
- Link "Ketentuan Penggunaan" di footer
- Link di halaman About
- Direct URL: `/terms.php`

**Navigasi Keluar:**
- ↔ Home: Via sidebar menu atau logo brand
- ↔ About: Via back link atau sidebar

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **Terms Content:**
   - Formatted text dengan sections

3. **Footer:** (sama seperti Home)

---

### 16. DMCA DISCLAIMER (dmca.php)

**Deskripsi:**
Halaman DMCA Disclaimer menampilkan DMCA disclaimer dan informasi copyright.

**Akses Dari:**
- Link "DMCA Disclaimer" di footer
- Link di halaman About
- Direct URL: `/dmca.php`

**Navigasi Keluar:**
- ↔ Home: Via sidebar menu atau logo brand
- ↔ About: Via back link atau sidebar

**Komponen Navigasi pada Halaman:**
1. **Navbar & Sidebar:** (sama seperti Home)

2. **DMCA Content:**
   - Formatted text dengan sections

3. **Footer:** (sama seperti Home)

---

### 17. ADMIN DASHBOARD (khususjier/admin/dashboard.php)

**Deskripsi:**
Halaman Admin Dashboard menampilkan overview statistik website seperti total produk, total user, total rating, dan average rating. Halaman ini hanya dapat diakses oleh admin (user dengan is_admin = 1).

**Akses Dari:**
- Login sebagai admin → auto redirect ke dashboard
- Direct URL: `/khususjier/admin/dashboard.php`
- Jika bukan admin dan akses URL ini, akan redirect ke access_denied.php

**Navigasi Keluar:**
- → Products Management: Via link di sidebar
- → Users Management: Via link di sidebar
- → Logout: Via logout link

**Komponen Navigasi pada Halaman:**
1. **Admin Navbar/Menu:**
   - Logo BEKOMIN ID → dashboard
   - Products → khususjier/admin/products.php
   - Users → khususjier/admin/users.php
   - Menu Management → khususjier/admin/menu.php
   - Logout → logout.php

2. **Dashboard Stats:**
   - Total Products
   - Total Users
   - Total Ratings
   - Average Rating

---

## ALUR NAVIGASI BERDASARKAN USER TYPE

### Alur User Baru (Guest/Tidak Login)

```
Home 
→ Browse Produk (Semua Produk)
→ Search Produk (Search Results)
→ Lihat Detail Produk (Product Detail)
→ Beri Rating (harus login)
  → Register atau Login
    → Profile/Logout
→ Lihat Rekomendasi (harus ada rating)
→ Tentang/Kontak/FAQ/Terms
→ Logout
```

### Alur User Sudah Register & Login

```
Login
→ Home / Index
→ Browse Produk
→ Search Produk
→ Lihat Detail Produk
→ Beri Rating (langsung bisa)
→ Lihat Rekomendasi (jika sudah ada rating)
→ Profile (update info/password)
→ Logout
```

### Alur Admin

```
Login (sebagai admin)
→ Auto redirect ke Admin Dashboard
→ View Statistics
→ Manage Products
→ Manage Users
→ Manage Menu
→ Logout
```

---

## FITUR NAVIGASI KHUSUS

### 1. Sidebar Menu (Off-canvas Navigation)
- Hamburger button untuk buka/tutup
- Menu items dinamis berdasarkan login status
- Smooth animation saat buka/tutup

### 2. Search Functionality
- Search dari Home page
- Search dari Semua Produk page
- Hasil search di Search Results page dengan fuzzy matching
- Category filter di search results

### 3. Category Dropdown
- Di header Home page
- Filter produk berdasarkan kategori
- Update product cards sesuai kategori pilihan

### 4. Product Cards
- Click untuk lihat detail
- Rating display
- Category badge
- Verification badge

### 5. Back to Top Button
- Fixed position di bottom right
- Muncul saat scroll down
- Smooth scroll ke top saat diklik

### 6. Footer Navigation
- Quick links ke info pages
- Copyright dengan link ke home
- Mobile responsive layout

### 7. Breadcrumb / Navigation Trail
- Implicit melalui Back button di browser
- Hamburger menu untuk quick navigation

---

## KESIMPULAN

Struktur navigasi BEKOMIN ID dirancang untuk memberikan pengalaman user yang intuitif dengan:

1. **Navigasi Utama via Sidebar Menu** - Akses cepat ke semua halaman utama
2. **Search & Filter** - Memudahkan mencari produk
3. **Product Cards** - Navigasi ke detail produk
4. **Footer Navigation** - Info pages mudah diakses
5. **Dynamic Menu** - Berbeda untuk user login vs tidak login
6. **Admin Panel** - Terpisah untuk administrative tasks
7. **Responsive Design** - Navigasi optimal di mobile dan desktop

Total halaman yang dapat diakses user: **16 halaman utama** + **Admin section** dengan navigasi yang saling terhubung secara logis dan memudahkan user journey.
