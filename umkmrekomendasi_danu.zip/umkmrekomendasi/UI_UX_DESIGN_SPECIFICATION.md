# UI/UX DESIGN SPECIFICATION - BEKOMIN ID (UMKM RECOMMEND)

## 1. GAMBARAN UMUM WEBSITE

### Tujuan Website
Website BEKOMIN ID adalah platform rekomendasi UMKM makanan berbasis Collaborative Filtering yang membantu pengguna menemukan produk makanan UMKM favorit dengan rekomendasi yang dipersonalisasi berdasarkan rating history mereka.

### Konsep Desain
- **Desain Modern Minimalis**: Interface clean dengan fokus pada user experience
- **Warna-warna Cerah**: Orange dan kombinasi warna warm untuk menciptakan appetite appeal
- **Mobile-First Responsive**: Optimal untuk semua ukuran layar
- **Interaktif & Engaging**: Slider, rating system, search, filter real-time

### Karakter Visual
- Warm dan Welcoming: Menggunakan palette warna orange yang hangat
- Accessibility-Focused: Font yang readable, spacing yang konsisten
- Modern Flat Design: Minimal shadows dan gradients yang subtle
- Call-to-Action yang Jelas: Button dan interactive elements yang menonjol

### Target Pengguna
- Foodie atau pecinta kuliner lokal
- Pengguna mobile (dominan)
- Usia 18-55 tahun
- Lokasi: Bekasi dan sekitarnya
- Tech-savvy enough untuk menggunakan rating system

### Gaya Desain
- **Minimalis dengan accents**: White background dengan orange accent
- **Typography-driven**: Emphasis pada readable font hierarchy
- **Gesture-based**: Swipe slider, tap buttons, scroll navigation
- **Card-based layout**: Product cards, location cards, rating cards

### Kesan yang Ingin Ditampilkan
- **Trustworthy**: Sistem rating yang transparent dan authentic
- **Local Pride**: Menunjukkan support untuk UMKM lokal Bekasi
- **Easy & Fun**: Interface yang mudah digunakan namun menyenangkan
- **Community-Driven**: Menampilkan rating dan feedback dari komunitas

---

## 2. DESIGN SYSTEM

### Color Palette

#### Primary Colors
| Color | HEX | RGB | Penggunaan |
|-------|-----|-----|-----------|
| Primary Orange | #FF6A00 | rgb(255, 106, 0) | Button, links, accents, navbar brand |
| Secondary Orange | #E85D04 | rgb(232, 93, 4) | Hover states, gradients |
| Dark Orange | #D84315 | rgb(216, 67, 21) | Login/register background gradient |

#### Secondary Colors
| Color | HEX | RGB | Penggunaan |
|-------|-----|-----|-----------|
| Accent Green | #1d7e3f | rgb(29, 126, 63) | Header.php primary (override untuk consistency) |
| Light Green | #2d9f52 | rgb(45, 159, 82) | Hover/active states green |
| Red Alert | #ef4444 | rgb(239, 68, 68) | Error, delete button, warning |
| Red Dark | #dc2626 | rgb(220, 38, 38) | Dark red for emphasis |

#### Neutral Colors
| Color | HEX | Penggunaan |
|-------|-----|-----------|
| Dark | #1a1a1a | Text utama, headings |
| Dark | #2d3748 | Text secondary |
| Light Gray | #f9fafb | Background subtle |
| Light Gray | #f3f4f6 | Background divider |
| Light Gray | #e5e7eb | Border color, dividers |
| Light Gray | #eeeeee | Background input disabled |
| Light Gray | #d0d0d0 | Shadow, inactive states |

#### Background Colors
| Color | HEX | Penggunaan |
|-------|-----|-----------|
| Light Orange | #FFF1E6 | Background section, hero light bg |
| Light Orange | #ffe8cc | Alternative light bg |
| Fade Light | #f9fafb | Main background |
| White | #ffffff | Default background |

### Warna Untuk Status
- **Success**: #2d9f52 (Green) - Checkmark, success message
- **Error**: #ef4444 (Red) - Error message, validation error
- **Warning**: #f39c12 (Orange) - Warning message, password strength medium
- **Info**: #3b82f6 (Blue) - Info message, informational icons
- **Verified Badge**: #dc2626 with #fef2f2 background - Produk terverifikasi

### Alasan Penggunaan Warna
1. **Orange (#FF6A00)**: 
   - Mendorong appetite (appetizing color dalam food psychology)
   - Energetic dan welcoming
   - High visibility untuk CTA
   - Memorable brand color

2. **White & Light Gray**:
   - Clean, modern aesthetic
   - Good contrast untuk readability
   - Tidak membanjiri visual

3. **Red Accent**:
   - Untuk error states (universal expectation)
   - Verified badge (mendapat attention untuk produk berkualitas)

4. **Green (header.php)**:
   - Digunakan di header.php dan sebagian komponen
   - Namun home.php dan halaman utama lebih dominant orange
   - Konsistensi warna tergantung on file configuration

---

## 3. TYPOGRAPHY

### Font Families
- **Primary Font**: Inter (sans-serif)
- **Heading Font**: Poppins (bold variant untuk headings)
- **Fallback**: Sans-serif

### Font Sizes & Hierarchy

#### Headings
- **h1**: 2rem / 2.5rem (desktop) | 1.8rem-1.4rem (mobile)
  - Font-weight: 700-800
  - Letter-spacing: -0.5px
  - Usage: Page titles, hero section

- **h2**: 1.8rem-1.5rem | 1.3rem-1rem
  - Font-weight: 700
  - Usage: Section titles, major headings

- **h3**: 1.15rem | 1rem-0.95rem
  - Font-weight: 700
  - Usage: Card titles, subsection headings

- **h4/h5**: 1rem-0.95rem | 0.9rem-0.85rem
  - Font-weight: 600
  - Usage: Form labels, minor headings

#### Body Text
- **Body Large**: 1rem
  - Font-weight: 400-500
  - Line-height: 1.6
  - Usage: Main paragraph text

- **Body Regular**: 0.95rem
  - Font-weight: 400-500
  - Line-height: 1.6
  - Usage: Standard text, descriptions

- **Body Small**: 0.85rem-0.9rem
  - Font-weight: 400-500
  - Color: Light gray
  - Usage: Helper text, captions, footer links

- **Label**: 0.9rem-0.95rem
  - Font-weight: 600
  - Text-transform: uppercase
  - Letter-spacing: 0.5px
  - Usage: Form labels

#### Button Text
- Font-size: 0.9rem-1rem
- Font-weight: 700
- Text-transform: uppercase
- Letter-spacing: 0.5px

### Line Heights
- Headings: 1.2-1.3
- Body text: 1.6
- Labels/captions: 1.3-1.4

### Spacing (Letter-spacing & Word-spacing)
- Headings: -0.3px to -0.5px (tight kerning)
- Body: 0 (normal)
- Labels: 0.5px (spread out)
- Uppercase text: 0.5px-1px

---

## 4. GRID DAN LAYOUT

### Container Sizes
| Breakpoint | Name | Width | Padding | Max-width |
|------------|------|-------|---------|-----------|
| <480px | Mobile | 100% | 12-16px | 100% |
| 480px+ | Mobile Large | 100% | 16px | 100% |
| 768px+ | Tablet Small | 100% | 20px | 100% |
| 992px+ | Tablet Large | 100% | 24px | 100% |
| 1200px+ | Desktop | 100% | 24px | 1400px |

### Margin & Padding System
- **0**: 0px
- **xs**: 4px
- **sm**: 8px
- **md**: 12px
- **lg**: 16px
- **xl**: 20px
- **2xl**: 24px
- **3xl**: 28px
- **4xl**: 32px

### Border Radius
- **None**: 0px
- **sm**: 8px (form inputs, small components)
- **md**: 12px (cards, buttons)
- **lg**: 16px-20px (large cards, modal)
- **pill**: 24px-50px (badges, rounded buttons)

### Shadow System
| Depth | Shadow | Usage |
|-------|--------|-------|
| None | none | Flat elements |
| sm | 0 1px 2px rgba(0,0,0,0.05) | Subtle elevation |
| md | 0 4px 6px rgba(0,0,0,0.07) | Card elevation |
| lg | 0 10px 15px rgba(0,0,0,0.1) | Modal, dropdown |
| xl | 0 20px 40px rgba(255,106,0,0.15) | Hero section, login/register |

### Spacing Rules
- **Between sections**: 20px-32px (mobile) | 40px-60px (desktop)
- **Between cards**: 12px-16px (mobile) | 16px-20px (desktop)
- **Inside cards**: 16px-24px
- **Between form fields**: 16px-22px

### Alignment
- **Horizontal**: Center-aligned for hero, left-aligned for content
- **Vertical**: Top-aligned for lists, center-aligned for hero sections
- **Grid columns**: 1 column (mobile), 2 columns (tablet), 3-4 columns (desktop)

### Product Grid Layout
- **Mobile**: 2 columns (360px width)
- **Tablet Small**: 3 columns (768px width)
- **Tablet Large**: 4 columns (992px width)
- **Desktop**: 4-5 columns (1200px+ width)
- **Gap**: 12px-16px between cards

---

## 5. KOMPONEN UI

### 5.1 BUTTON

#### Primary Button (CTA)
- **Shape**: Rounded rectangle
- **Padding**: 12-14px vertical, 20-24px horizontal
- **Border Radius**: 12px
- **Background**: Linear gradient #FF6A00 → #E85D04
- **Color**: White text
- **Font**: 0.9rem-1rem, weight 700, uppercase, letter-spacing 0.5px
- **Border**: None
- **Shadow**: 0 4px 15px rgba(255, 106, 0, 0.3)
- **Hover**: 
  - Background: #E85D04 or darker gradient
  - Transform: translateY(-3px)
  - Shadow: 0 8px 25px rgba(255, 106, 0, 0.4)
- **Active**: 
  - Transform: translateY(-1px)
  - Shadow: 0 4px 12px rgba(255, 149, 0, 0.3)
- **Icon**: Gap 6px dari text

#### Secondary Button
- **Shape**: Rounded rectangle
- **Background**: Transparent or light gray #f3f4f6
- **Color**: #FF6A00 text
- **Border**: 1-2px solid #FF6A00
- **Hover**: Background light orange #FFF1E6

#### Button States
- **Hover**: Transform -2px to -3px, shadow increase
- **Active**: Transform -1px
- **Focus**: Outline 4px rgba(255, 106, 0, 0.12)
- **Disabled**: Opacity 0.6, pointer-events none

### 5.2 INPUT & FORM ELEMENTS

#### Text Input
- **Style**: Solid border
- **Border**: 2px solid #e5e7eb
- **Border Radius**: 12px
- **Padding**: 12-14px horizontal, 10-12px vertical
- **Font-size**: 0.9rem-0.95rem
- **Focus**:
  - Border color: #FF6A00
  - Box-shadow: 0 0 0 4px rgba(255, 106, 0, 0.12)
  - Background: rgba(255, 106, 0, 0.02)
- **Hover**: Border color #FFF1E6 (softer)
- **Placeholder**: Color #cbd5e1, font-weight 400

#### Label
- **Font-size**: 0.85rem-0.95rem
- **Font-weight**: 600
- **Color**: #2d3748 (dark text)
- **Margin-bottom**: 8-10px
- **Text-transform**: uppercase
- **Letter-spacing**: 0.5px

#### Textarea
- **Same as input text**
- **Min-height**: 80px
- **Resize**: vertical only
- **Line-height**: 1.5

#### Dropdown/Select
- **Styling**: Same as input text
- **Icon**: Chevron down, positioned right
- **Background**: White
- **Hover**: Light gray background #f9fafb

#### Checkbox & Radio
- **Size**: 18px × 18px
- **Border**: 2px solid #e5e7eb
- **Checked**: Background #FF6A00, border #FF6A00
- **Checked Icon**: White checkmark or circle
- **Border Radius**: 4px (checkbox), 50% (radio)

#### Form Validation
- **Error State**:
  - Border color: #ef4444
  - Icon: Red ✕
  - Message: 0.85rem, color #ef4444, margin-top 4px
- **Success State**:
  - Border color: #2d9f52
  - Icon: Green ✓
- **Info Box**: Background #fef2f2 or rgba, border-left 4px #FF6A00

### 5.3 CARD

#### Product Card
- **Layout**: Vertical card
- **Border Radius**: 16px-24px
- **Padding**: 0 (image takes full width)
- **Box-shadow**: 0 6px 16px rgba(0, 0, 0, 0.08)
- **Background**: White
- **Hover**: 
  - Shadow increase: 0 10px 24px rgba(0, 0, 0, 0.12)
  - Transform: translateY(-2px)
- **Structure**:
  ```
  [Category Badge - top left]
  [Product Image 200x160px]
  [Product Body - padding 16px]
    - Verified Badge (if applicable)
    - Product Name (1.15rem, 2 lines max)
    - Description (0.95rem, 2 lines max)
    - Rating (stars + count)
    - Action Buttons (Detail | Rating)
  ```

#### Rating Card (Display only)
- **Layout**: Horizontal
- **Border-left**: 4px solid #1d7e3f (green)
- **Padding**: 14px
- **Background**: #f9fafb
- **Border-radius**: 12px

#### Location Card
- **Layout**: Horizontal with numbered circle
- **Number Circle**: Background #FF6A00, white text, 28px diameter
- **Border-left**: 4px solid #FF6A00
- **Padding**: 14px
- **Background**: #f9fafb
- **Border-radius**: 12px
- **Info**: Name (bold), address (gray), coordinates (small, purple)

### 5.4 BADGE

#### Category Badge
- **Style**: Filled
- **Background**: #FF6A00
- **Color**: White
- **Padding**: 4px 8px
- **Border-radius**: 6px
- **Font-size**: 0.7rem-0.75rem
- **Font-weight**: 600

#### Verified Badge
- **Style**: Filled with icon
- **Background**: rgba(29, 126, 63, 0.15) or #fef2f2
- **Color**: #1d7e3f or #dc2626
- **Padding**: 4px 9px
- **Border-radius**: 14px
- **Font-size**: 0.65rem
- **Icon**: Checkmark, 0.65rem
- **Content**: "Terverifikasi"

#### Status Badge
- **Pending**: Yellow/orange background
- **Active**: Green background
- **Inactive**: Gray background

### 5.5 MODAL / DIALOG

#### Modal Container
- **Position**: Fixed, center
- **Backdrop**: rgba(0, 0, 0, 0.5)
- **Width**: 90% (mobile), max-width 500px
- **Max-height**: 90vh, overflow-y auto
- **Border-radius**: 20px (desktop), 16px (mobile)
- **Background**: White
- **Box-shadow**: 0 4px 20px rgba(0, 0, 0, 0.15)

#### Modal Header
- **Padding**: 20px
- **Border-bottom**: 1px solid #e5e7eb
- **Display**: Flex, space-between
- **Close button**: No border, background none, font 1.5rem, cursor pointer

#### Modal Body
- **Padding**: 24px
- **Content**: Form fields, text, etc

#### Modal Footer
- **Padding**: 16px 24px
- **Border-top**: 1px solid #e5e7eb
- **Display**: Flex, justify-end
- **Gap**: 12px between buttons

### 5.6 NAVBAR

#### Navbar Container
- **Position**: Fixed/sticky
- **Top**: 0
- **Background**: White
- **Box-shadow**: 0 1px 2px rgba(0, 0, 0, 0.05)
- **Padding**: 12px 0
- **Z-index**: 1000
- **Scrolled state**: Box-shadow 0 4px 6px rgba(0, 0, 0, 0.07)

#### Brand Logo
- **Display**: Flex, align-center, gap 8px
- **Font-size**: 1.3rem
- **Font-weight**: 700
- **Color**: Black (#000000)
- **Icon Color**: #E85D04
- **Text**: "BEKOMIN ID"

#### Hamburger Menu
- **Icon**: Font Awesome bars icon
- **Size**: 1.3rem
- **Color**: #2d3748
- **Background**: None
- **Border**: None
- **Cursor**: Pointer
- **Hover**: Color #FF6A00

#### Navigation Links
- **Display**: Hidden on mobile, visible on 1400px+ (or always via sidebar)
- **Font-size**: 0.95rem
- **Font-weight**: 500
- **Color**: #2d3748
- **Hover**: Color #FF6A00
- **Transition**: 0.3s ease

### 5.7 SIDEBAR (OFF-CANVAS)

#### Sidebar Container
- **Position**: Fixed left
- **Width**: 280px
- **Height**: 100vh
- **Background**: White
- **Transform**: translateX(-100%) default, translateX(0) when active
- **Transition**: 0.3s cubic-bezier(0.4, 0, 0.2, 1)
- **Box-shadow**: 2px 0 15px rgba(0, 0, 0, 0.1)
- **Z-index**: 1048
- **Overflow-y**: auto

#### Backdrop
- **Position**: Fixed, full screen
- **Background**: rgba(0, 0, 0, 0.5)
- **Z-index**: 1047
- **Opacity**: 0 (inactive), 1 (active)

#### Sidebar Header
- **Padding**: 16px
- **Border-bottom**: 1px solid #e5e7eb
- **Display**: Flex, justify-between
- **Title Font-size**: 1.2rem, weight 700

#### Navigation Items
- **List style**: None
- **Margin**: 0
- **Padding**: 0
- **Link padding**: 14px 16px
- **Color**: #2d3748
- **Hover**: Background #d4f4dd, color #FF6A00, padding-left 20px
- **Icon**: Color #FF6A00, font-size 1.1rem
- **Border-bottom**: 1px solid #f3f4f6

### 5.8 FOOTER

#### Footer Main
- **Background**: #1a1a1a (dark)
- **Color**: White
- **Padding**: 12px 0
- **Text-align**: Center
- **Border-top**: 1px solid rgba(255, 255, 255, 0.1)
- **Width**: 100%
- **Box-sizing**: border-box

#### Footer Quick Links Section
- **Background**: #f8f9fa
- **Border-top**: 1px solid #e5e5e5
- **Padding**: 20px 24px
- **Width**: 100%

#### Quick Links Title
- **Font-size**: 14px
- **Font-weight**: 900
- **Color**: #1a1a1a
- **Icon**: 14px, bordered circle, center
- **Display**: Flex, align-center, gap 10px

#### Quick Links Grid
- **Display**: Grid, 2 columns (mobile), flex row (desktop)
- **Gap**: 60px
- **Margin-left**: 24px

#### Link Style
- **Font-size**: 11px
- **Font-weight**: 700
- **Color**: #3c4043
- **Hover**: Color #FF6A00
- **Transition**: 0.3s ease
- **Margin**: 0
- **Padding**: 0

### 5.9 BACK TO TOP BUTTON

- **Position**: Fixed, bottom-right
- **Size**: 40px × 40px (mobile), 50px × 50px (desktop)
- **Border-radius**: 50%
- **Background**: Linear gradient #FF6A00 → #E85D04
- **Color**: White
- **Icon**: Chevron up
- **Display**: None (inline-flex when show class)
- **Opacity**: 0 (hidden), 1 (show)
- **Z-index**: 999
- **Hover**: Transform translateY(-6px), shadow increase
- **Active**: Transform translateY(-2px)
- **Transition**: 0.3s cubic-bezier(0.4, 0, 0.2, 1)
- **Animation**: slideInUp 0.3s ease-out

### 5.10 STAR RATING DISPLAY

#### Star Container
- **Display**: Flex, gap 2px
- **Font-size**: 0.9rem (display), 1.5rem (input)
- **Align-items**: Center

#### Individual Star
- **Color**: #D9D9D9 (empty)
- **Color**: #FFC107 (filled)
- **Transition**: 0.2s ease

#### Rating Count Badge
- **Font-size**: 0.65rem
- **Background**: rgba(45, 159, 82, 0.15)
- **Color**: #FF6A00 or primary
- **Padding**: 4px 8px
- **Border-radius**: 14px
- **Font-weight**: 700
- **White-space**: nowrap

### 5.11 SEARCH BAR

#### Search Container
- **Display**: Flex, align-center, gap 8px
- **Padding**: 8px 12px
- **Border-radius**: 20px
- **Background**: White
- **Box-shadow**: 0 4px 12px rgba(0,0,0,0.1)
- **Width**: 100%

#### Search Icon
- **Color**: #FF6A00
- **Font-size**: 0.9rem
- **Flex-shrink**: 0

#### Search Input
- **Border**: None
- **Outline**: None
- **Background**: Transparent
- **Font-size**: 0.9rem
- **Font-family**: Inter
- **Color**: #2d3748
- **Width**: 100%
- **Padding**: 0

#### Search Clear (×)
- **Font-size**: 1rem
- **Color**: #2d3748
- **Cursor**: Pointer
- **Hover**: Color #FF6A00

### 5.12 CATEGORY FILTER BUTTONS

#### Button Group
- **Display**: Flex, flex-wrap
- **Gap**: 8px
- **Padding**: 16px 0

#### Individual Button
- **Padding**: 8px 16px
- **Border-radius**: 18px
- **Border**: 1-2px solid #FF6A00
- **Background**: White (inactive), #FF6A00 (active)
- **Color**: #FF6A00 (inactive), White (active)
- **Font-size**: 0.9rem
- **Font-weight**: 600
- **Cursor**: Pointer
- **Transition**: 0.3s ease
- **Hover**: Background #FFF1E6
- **Active**: Background #FF6A00, color white

### 5.13 ALERT / NOTIFICATION

#### Alert Container
- **Border-radius**: 12px
- **Border**: 2px solid (color-based)
- **Margin-bottom**: 20px
- **Font-size**: 0.9rem
- **Padding**: 14px 16px
- **Display**: Flex, align-center, gap 10px
- **Animation**: slideDown 0.4s ease-out

#### Alert Types
- **Success**: Background #f0fdf4, color #166534, border #bbf7d0
- **Danger**: Background #fef2f2, color #991b1b, border #fecaca
- **Warning**: Background #fffbeb, color #92400e, border #fde68a
- **Info**: Background #eff6ff, color #0c4a6e, border #bfdbfe

#### Alert Icon
- **Font-size**: 1.1rem
- **Flex-shrink**: 0

### 5.14 FORM GROUP

#### Structure
```
[Label]
[Input/Textarea]
[Help Text / Error Message]
[Form Group spacing: margin-bottom 22px]
```

#### Label Styling
- **Font-weight**: 600
- **Color**: #2d3748
- **Margin-bottom**: 10px
- **Display**: Block
- **Font-size**: 0.95rem
- **Text-transform**: uppercase
- **Letter-spacing**: 0.5px

#### Help Text
- **Font-size**: 0.85rem
- **Color**: #999 (gray) or specific color for error
- **Margin-top**: 6px
- **Display**: Block

---

## 6. HALAMAN WEBSITE

### 6.1 HOME (home.php)

#### Fungsi & Tujuan
- Halaman utama yang menampilkan overview platform
- Hero section untuk first-time users
- Showcase produk featured dan promo
- Entry point untuk semua user (login/tidak login)

#### Layout Structure (Top to Bottom)

##### 1. Navbar (Sticky)
- **Components**: Logo (left), Hamburger menu (left), Category dropdown (right)
- **Spacing**: 12px vertical padding
- **Shadow**: Subtle shadow sm

##### 2. Hero Section with Search
- **Background**: Linear gradient #FF6A00 to white
- **Padding**: 8px top, 16px bottom
- **Search Bar**: 
  - Flex container, icon left, input centered
  - Placeholder: "Mau cari makanan UMKM apa hari ini?"
  - Form ID: heroSearchForm
  - Full width responsive

##### 3. Promo Slider Section
- **Title**: "Mengapa Memilih Kami?" (h2, font-size 1.3rem-2rem)
- **Slider Container**: 
  - Autoplay 4s interval
  - Drag/swipe support
  - Dot navigation bottom
  - Transition fade/slide
- **Slide Content**:
  - Mockup website (left)
  - Benefits text (right on desktop, below on mobile)
  - Benefits: Rekomendasi Personal, Rating Authentic, Produk Local UMKM
- **Height**: 250px-350px
- **Border-radius**: 16px

##### 4. Statistics Section
- **Title**: "Dipercaya oleh..." or stats display
- **Grid**: 4 columns (desktop), 2 columns (tablet), 1 column (mobile)
- **Cards**:
  - Icon + Number + Label
  - Example: "281 Pengunjung Unik", "Total 35 Produk"
  - Number size: 1.5rem-2rem, bold
  - Label size: 0.9rem

##### 5. Featured Products Section
- **Title**: "Produk Unggulan" or "Produk Terpopuler"
- **Grid**: 2-4 columns responsive
- **Cards**: Product cards (see section 5.3)
- **Action**: "Lihat Semua" button → index.php

##### 6. CTA Section (Before Footer)
- **Text**: "Temukan produk UMKM favoritmu dengan rekomendasi personal"
- **Button**: "Lihat Rekomendasi" or "Mulai Sekarang"
- **Background**: Light orange #FFF1E6
- **Padding**: 40px 20px
- **Border-radius**: 16px

##### 7. Footer
- Quick links section
- Copyright
- Back to top button

#### Responsive Behavior
- **Mobile**: 1 column products, hero search full width, slider smaller
- **Tablet**: 2-3 column products, hero search with category dropdown
- **Desktop**: 4 column products, category dropdown visible in navbar

#### Animations & Interactions
- **Hero gradient**: Smooth fade to white
- **Slider**: Auto-rotate 4s, swipe gesture enabled
- **Dots navigation**: Click to jump slide, highlights active
- **Product cards**: Hover → shadow increase, translateY(-2px)
- **Back to top**: Appears after scroll 300px, smooth scroll animation

---

### 6.2 SEMUA PRODUK (index.php)

#### Fungsi & Tujuan
- Menampilkan catalog lengkap produk UMKM
- Filter & search functionality
- Browse tanpa login required

#### Layout Structure

##### 1. Header Section
- **Title**: "Semua Produk" (h1)
- **Subtitle**: "Jelajahi koleksi produk UMKM terbaik dan berikan rating Anda"
- **Spacing**: margin-bottom 20px

##### 2. Search Bar
- **Icon**: Search left
- **Input**: Placeholder "Cari produk..."
- **Clear**: X button if query exists
- **Form method**: GET
- **Full width**: Responsive

##### 3. Category Filter
- **Header**: "Kategori" with filter icon
- **Buttons**: Flex wrap, gap 8px
  - "Semua" (active by default)
  - "Makanan Berat"
  - "Jajanan & Street Food"
  - "Minuman"
  - "Makanan Rumahan"
- **Active state**: Background orange, white text

##### 4. Product Grid
- **Grid columns**: Responsive 2-4 columns
- **Cards**: Product cards with:
  - Category badge (top-left)
  - Product image
  - Verified badge (if qualified)
  - Name, description
  - Rating display
  - Detail + Rating buttons
- **Spacing**: 12-16px gap

##### 5. Empty State (if no results)
- **Icon**: Big inbox icon, light gray
- **Message**: "Tidak ada produk ditemukan"
- **Description**: "Coba ubah filter atau cari dengan kata kunci lain"

#### Responsive Behavior
- **Mobile**: 2 columns, search full width, filter buttons wrap
- **Tablet**: 3 columns, filter buttons horizontal scrollable
- **Desktop**: 4 columns, filter buttons full visible

---

### 6.3 DETAIL PRODUK (product_detail.php)

#### Fungsi & Tujuan
- Display lengkap info produk
- Rating system integration
- Location information dengan geolocation

#### Layout Structure

##### 1. Breadcrumb / Back Button
- **Style**: Orange button, left icon
- **Text**: "← Kembali ke Produk"
- **Action**: Navigates back or to index.php
- **Styling**: 
  - Padding: 12px 22px
  - Background: #FF6A00
  - Color: White
  - Border-radius: 18px
  - Shadow: 0 6px 16px rgba(255,106,0,0.25)

##### 2. Product Hero Section
- **Layout**: Flex row (desktop), flex column (mobile)
- **Image**: 
  - Size: 110px × 110px (mobile), larger on desktop
  - Border-radius: 20px
  - Background: #FF6A00 if no image
  - Icon: Box icon if no image
- **Product Info**:
  - Name (h3)
  - Category
  - Rating stars + count
  - Verified badge (if applicable)
  - Location badge

##### 3. Description Section (Card)
- **Title**: "Deskripsi Produk" with icon
- **Content**: Formatted text, white-space pre-wrap
- **Text-align**: Left
- **Font-size**: 0.95rem
- **Line-height**: 1.6
- **Color**: #4b5563

##### 4. Location Section (Card)
- **Title**: "Lokasi UMKM" with icon
- **List**: Location items in grid
- **Each location**:
  - Numbered circle (#FF6A00)
  - Location name (bold)
  - Full address (gray)
  - Coordinates (small, if available)
  - Background: #f9fafb
  - Border-left: 4px #FF6A00
- **Nearest button**: Find nearest location via geolocation

##### 5. Rating Section (Card, ID: #rating)
- **Title**: "Rating & Ulasan"
- **Current user rating display** (if exists)
- **Rating form**:
  - Star input 1-5
  - Submit button
- **All ratings display**:
  - List of ratings from other users
  - Name/Guest label
  - Rating value
  - Limit 10 most recent

#### Responsive Behavior
- **Mobile**: 
  - Image 100px, stacked layout
  - Cards full width
  - Sections 16px padding
- **Tablet**: 
  - Image 110px, side by side
  - Cards 20px padding
- **Desktop**: 
  - Image larger
  - Max-width 1400px container
  - Cards wider

---

### 6.4 LOGIN (login.php)

#### Fungsi & Tujuan
- User authentication
- Prevent duplicate ratings
- Session management

#### Layout Structure

##### Full Screen Layout (Grid 2 columns desktop, 1 mobile)

**Left side (Desktop only, hidden mobile)**:
- **Illustration**: Large utensils icon (#FFF1E6 text with shadow)
- **Heading**: "UMKM Recommend" (h2, white)
- **Description**: Feature description (white text, 1.1rem)
- **Animation**: slideInLeft, float animation

**Right side** (or full screen mobile):
- **Container**: White rounded card
- **Box-shadow**: 0 20px 40px rgba(255, 106, 0, 0.15)
- **Border-radius**: 20px
- **Padding**: 50px (desktop), 30px (mobile)
- **Max-width**: 500px
- **Animation**: slideInRight

##### Right Side Content

###### Header
- **Icon**: Sign-in-alt
- **Title**: "Login" (h1, 1.8rem)
- **Subtitle**: "Masuk untuk mendapatkan rekomendasi terbaik"

###### Info Box
- **Background**: Gradient rgba(255,106,0,0.1)
- **Border-left**: 4px #FF6A00
- **Text**: "User Login - Masukkan email dan password Anda untuk login"
- **Font-size**: 0.9rem

###### Form
- **Email field**:
  - Label: "EMAIL"
  - Input placeholder: "Masukkan email Anda"
  - Type: email
- **Password field**:
  - Label: "PASSWORD"
  - Input placeholder: "Masukkan password Anda"
  - Type: password
- **Form spacing**: margin-bottom 22px

###### Alert (if error)
- **Type**: Danger
- **Display**: Flex, icon + message
- **Animation**: slideDown

###### Login Button
- **Style**: Primary button gradient
- **Full width**: 100%
- **Text**: "LOGIN"
- **Font**: 0.9rem, weight 700, uppercase, spacing 0.5px

###### Footer Links
- **Border-top**: 2px solid #e5e7eb
- **Margin-top**: 28px
- **Padding-top**: 28px
- **Links**:
  - "Daftar di sini" → register.php
  - "Lupa password?" → forgot_password.php
- **Link style**: Color #FF6A00, weight 700, gap 6px icon

#### Responsive Behavior
- **Mobile**: 1 column, no illustration, padding 30px
- **Tablet**: 1 column with illustration below
- **Desktop**: 2 columns side by side

---

### 6.5 REGISTER (register.php)

#### Fungsi & Tujuan
- New user account creation
- Email validation
- Password strength indicator

#### Layout Structure
- **Same as login.php**
- Left illustration hidden on mobile
- Right side contains form

##### Form Fields
1. **Nama Lengkap**:
   - Label: "NAMA LENGKAP"
   - Input placeholder: "Masukkan nama lengkap Anda"
   - Min length: 3 characters

2. **Email**:
   - Label: "EMAIL"
   - Input placeholder: "Masukkan email Anda"
   - Type: email
   - Validation: format check

3. **Password**:
   - Label: "PASSWORD"
   - Input placeholder: "Masukkan password (minimal 6 karakter)"
   - Min length: 6 characters
   - **Strength meter**:
     - Height: 6px
     - Background: #e2e8f0
     - Fill width: 0-100% (5 strength levels)
     - Color progression: Red → Orange → Green
     - Text under bar: "Lemah" / "Sedang" / "Kuat"

4. **Konfirmasi Password**:
   - Label: "KONFIRMASI PASSWORD"
   - Input placeholder: "Ulangi password Anda"
   - Validation: must match password field

##### Register Button
- **Full width**: 100%
- **Style**: Primary gradient
- **Text**: "DAFTAR SEKARANG"
- **Icon**: user-plus

##### Footer
- **Link**: "Login di sini" → login.php

#### Validations
- All fields required
- Name minimum 3 chars
- Password minimum 6 chars
- Password confirmation must match
- Email format valid
- Email not already registered

---

### 6.6 PROFILE (profile.php)

#### Fungsi & Tujuan
- User profile management
- Update personal info
- Change password

#### Layout Structure

##### Header
- **Title**: "Profil" or "Profil Saya"
- **Icon**: User icon

##### Tabs (2 tabs)
1. **Update Profile**:
   - **Name field**: Label "Nama Lengkap", current value displayed
   - **Email field**: Label "Email", read-only or editable
   - **Submit button**: "Update Profile"

2. **Change Password**:
   - **Old Password**: Input field
   - **New Password**: Input field
   - **Confirm Password**: Input field
   - **Submit button**: "Change Password"

##### Alerts
- **Success**: Green alert, "Profil berhasil diperbarui"
- **Error**: Red alert with message

##### Logout Option
- **Button**: "Logout" or link in sidebar

---

### 6.7 SEARCH RESULTS (search_results.php)

#### Fungsi & Tujuan
- Display search results
- Allow filter by category
- Show relevance/match

#### Layout Structure

##### Search Bar
- **Shows current query**: "Hasil pencarian untuk: [query]"
- **Clear link**: Reset search

##### Category Filter
- **Same as index.php**
- Can combine search + category filter

##### Results Grid
- **Same as index.php product grid**
- **Empty state** if no results:
  - Icon: Inbox
  - Message: "Tidak ada produk ditemukan"
  - Suggestion text

---

### 6.8 REKOMENDASI (rekomendasi.php)

#### Fungsi & Tujuan
- Show personalized recommendations
- Collaborative filtering results
- Display similar users

#### Layout Structure

##### Header
- **Title**: "Rekomendasi Produk"
- **Info**: Based on your ratings and similar users' preferences

##### Recommendation Cards
- **Grid**: 2-4 columns
- **Same as product cards**
- **Shows**: Similarity score or explanation

##### Similar Users Section
- **Title**: "Pengguna Serupa" (optional)
- **Display**: List of users with similar rating patterns
- **Info**: Name, similarity percentage

##### If no ratings
- **Message**: "Belum ada rating dari Anda"
- **CTA**: "Berikan rating untuk mendapatkan rekomendasi"

---

### 6.9 ABOUT, FAQ, TERMS, DMCA (Static Pages)

#### Layout Structure

##### Header
- **Title**: Page title (About, FAQ, etc)
- **Icon**: Relevant icon

##### Content Sections
- **Left sidebar** (optional): Navigation menu to sections
- **Main content**: Full-width text content
- **Padding**: 20px-24px

##### FAQ Specific
- **Accordion/Expandable items**:
  - Question (clickable header)
  - Answer (hidden, expands on click)
  - Icon: Chevron down (rotates when expanded)

---

## 7. DASHBOARD ADMIN (khususjier/admin/)

### 7.1 Admin Dashboard (dashboard.php)

#### Layout
- **Sidebar** (left, 250px fixed)
- **Main content** (left margin 250px)

#### Sidebar
- **Background**: Gradient #FF6A00 → #E85D04
- **Brand**: Logo + "UMKM Recommend"
- **Navigation links**:
  - Dashboard (active)
  - Kelola Produk
  - Evaluasi MAE
  - Kelola Pengguna
  - Profil Saya
  - Logout
- **Link style**:
  - Padding: 12px 20px
  - Color: rgba(255,255,255,0.8)
  - Border-left: 3px transparent
  - Hover: Background rgba(255,255,255,0.1), border-left white
  - Active: Background rgba(255,255,255,0.15), border-left white

#### Header Section
- **Title**: "Dashboard" (h1)
- **Subtitle**: "Selamat datang kembali, Admin!"
- **User info** (right): Avatar + Name + "Administrator"

#### Statistics Section
- **Grid**: 4 columns (2 columns mobile)
- **Cards**:
  1. Total Produk
  2. Pengguna Aktif
  3. Total Rating
  4. Rating Rata-rata
- **Card style**:
  - Icon (large, colored)
  - Value (large number)
  - Label
  - Box-shadow

#### Management Menu Section
- **Title**: "Manajemen Sistem"
- **Grid**: 4 columns responsive
- **Cards**:
  - Kelola Produk
  - Evaluasi MAE
  - Kelola Pengguna
  - Profil Admin
- **Card style**:
  - Icon, title, description
  - Hover: shadow increase, color change

---

### 7.2 Kelola Produk (products.php)

#### Layout
- **Sidebar + Main content** (same as dashboard)

#### Header
- **Title**: "Kelola Produk"
- **Subtitle**: "Tambah, edit, atau hapus produk UMKM"

#### Action Bar
- **Search input**: "Cari nama produk..."
- **Add button**: "Tambah Produk Baru" (primary button)

#### Products Table
- **Columns**:
  - ID
  - Gambar (thumbnail)
  - Nama Produk
  - Kategori
  - Lokasi (scrollable preview)
  - Rating (star display)
  - Aksi (Edit | Hapus buttons)
- **Styling**:
  - Header: Light gray background
  - Rows: Hover highlight
  - Thumbnail: 50px × 50px, border-radius 6px
  - Actions: Blue edit, red delete buttons

#### Modal - Tambah/Edit Produk
- **Fields**:
  - Nama Produk
  - Deskripsi (textarea)
  - Kategori (dropdown)
  - Gambar (file upload with preview)
  - Lokasi (dynamic fields):
    - Address
    - Latitude
    - Longitude
    - Add/Remove button
- **Buttons**: Save | Cancel

---

### 7.3 Evaluasi MAE (evaluasi_mae.php)

#### Content
- **Displays** algorithm accuracy
- **MAE calculation** results
- **Metrics**:
  - Mean Absolute Error
  - Precision, Recall
  - User-based recommendations accuracy

---

## 8. RESPONSIVE DESIGN

### Breakpoints

| Screen | Width | Layout |
|--------|-------|--------|
| Mobile | <480px | 1 column, full width, stacked |
| Mobile Large | 480px-767px | 1-2 columns, full padding |
| Tablet Small | 768px-991px | 2-3 columns, medium padding |
| Tablet Large | 992px-1199px | 3-4 columns, medium padding |
| Desktop | 1200px+ | 4-5 columns, max-width 1400px |

### Mobile-First Approach
- **Default**: Mobile optimized
- **Breakpoints**: Add features as screen grows
- **Flexbox/Grid**: Responsive by default

### Touch Targets
- **Minimum**: 44px × 44px
- **Buttons**: 40px-50px minimum height
- **Spacing**: 12px-16px between clickable elements

### Typography Scaling
- **Headings**: Use clamp() for fluid sizing
- **Body**: Base 0.95rem-1rem, scales with screen
- **Mobile**: Reduce padding/margins 20-30%

---

## 9. ANIMASI & TRANSITION

### Page Transitions
- **Fade in**: opacity 0→1, 0.3s ease-out
- **Slide in**: transform translateX/Y, 0.3s ease-out
- **Stagger**: Multiple elements with delay increment (0.1s-0.5s)

### Component Animations

#### Promo Slider
- **Auto-rotate**: 4000ms interval
- **Fade transition**: opacity change
- **Dot navigation**: Highlight active dot

#### Product Cards
- **Hover**: 
  - Shadow: 0.3s ease
  - Transform: translateY(-2px), 0.3s ease
  - Scale: 1.01, optional 0.3s ease

#### Buttons
- **Hover**: 
  - Transform: translateY(-3px), 0.3s ease
  - Shadow increase: 0.3s ease
- **Active**: 
  - Transform: translateY(-1px), 0.1s
  - Shadow decrease: 0.1s

#### Back to Top
- **Slide in**: slideInUp 0.3s ease-out
- **Hover**: Transform -6px, shadow, 0.3s
- **Scroll reveal**: Opacity animation

#### Sidebar
- **Transform**: translateX(-100%) ↔ translateX(0)
- **Duration**: 0.3s cubic-bezier(0.4, 0, 0.2, 1)
- **Backdrop**: Opacity fade-in/out

#### Form Alerts
- **Slide down**: slideDown 0.4s ease-out
- **Disappear**: Fade out after timeout

#### Loading States
- **Spinner**: Rotate animation 1s infinite linear
- **Skeleton**: Pulse animation (opacity 0.5-1) 1.5s ease-in-out infinite

---

## 10. IKON

### Icon Library
- **Provider**: Font Awesome 6.4.0
- **Style**: Solid (default)
- **Format**: \<i class="fas fa-[icon-name]">\</i\>

### Icon Sizes
| Use Case | Size | Font-size |
|----------|------|-----------|
| Navigation | 1.1rem | 1.1rem |
| Button | 0.9-1rem | 1rem |
| Badge | 0.6-0.65rem | 0.6-0.65rem |
| Section title | 0.95rem | 0.95rem |
| Alert | 1.1rem | 1.1rem |
| Input icon | 0.9rem | 0.9rem |

### Common Icons Used
- **Navigation**: fa-home, fa-box, fa-star, fa-info-circle, fa-user, fa-sign-out-alt, fa-sign-in-alt
- **Actions**: fa-search, fa-edit, fa-trash, fa-plus, fa-times, fa-chevron-down, fa-chevron-up
- **Status**: fa-check-circle, fa-exclamation-circle, fa-times-circle, fa-star, fa-star-o
- **Others**: fa-utensils, fa-map-pin, fa-phone, fa-envelope, fa-filter, fa-bars, fa-eye, fa-bars

### Icon Colors
- **Primary**: #FF6A00 (accent icons)
- **Text**: #2d3748 (regular icons)
- **White**: #ffffff (on dark background)
- **Gray**: #999 or #cbd5e1 (inactive/disabled)

---

## 11. GAMBAR & MEDIA

### Product Images
- **Aspect ratio**: 1:1 or 4:3
- **Format**: PNG, JPG
- **Size**: 
  - Display: 200x160px (card), 110x110px (detail hero)
  - Actual: 400x320px or larger (2x resolution)
- **Fallback**: Orange background (#FF6A00) with box icon

### Logo/Branding
- **Format**: SVG or PNG
- **Size**: 1.6rem × auto (navbar)
- **Color**: Orange (#E85D04)

### Backgrounds
- **Hero section**: Linear gradient #FF6A00 → white
- **Login/Register**: Gradient #D84315 → #FF6A00 → #FFB347
- **Admin sidebar**: Gradient #FF6A00 → #E85D04

---

## 12. FORM & VALIDASI

### Form Fields Validation

| Field | Validation | Error Message |
|-------|-----------|---------------|
| Email | Valid email format, not registered | "Format email tidak valid" / "Email sudah terdaftar" |
| Password | Min 6 chars | "Password minimal 6 karakter" |
| Password (confirm) | Must match password | "Password tidak cocok" |
| Name | Min 3 chars | "Nama minimal 3 karakter" |

### Error Display
- **Style**: Red alert box, inline message
- **Position**: Below field or in alert container
- **Icon**: fa-exclamation-circle
- **Animation**: slideDown 0.4s ease-out

### Success Display
- **Style**: Green alert box
- **Icon**: fa-check-circle
- **Animation**: slideDown 0.4s ease-out

---

## 13. KESIMPULAN VISUAL

### Brand Identity
**BEKOMIN ID** adalah platform rekomendasi UMKM yang modern, welcoming, dan accessibility-focused. Design ini menggabungkan:

1. **Warm Color Palette**: Orange (#FF6A00) menciptakan appetite appeal dan energetic feeling
2. **Clean & Minimalist**: White space, minimal shadows, focus on content
3. **User-Centric**: Responsive design, clear CTAs, intuitive navigation
4. **Community-Driven**: Rating display, authentic user feedback, local UMKM support

### Design Principles
- **Consistency**: Sama color, typography, spacing di semua halaman
- **Hierarchy**: Clear visual hierarchy dari heading hingga body text
- **Accessibility**: Enough contrast, readable font, touch-friendly buttons
- **Performance**: Optimized animations, lazy loading for images
- **Responsiveness**: Mobile-first, breakpoints well-tested
- **Engagement**: Interactive elements, smooth transitions, meaningful animations

### Visual Tone
- **Friendly & Approachable**: Warm colors, rounded corners, welcoming CTA
- **Professional & Trustworthy**: Consistent design, clear information hierarchy
- **Modern & Fresh**: Flat design, gradient accents, contemporary typography
- **Local & Supportive**: Highlighting UMKM, authentic ratings, community feedback
