<?php
require_once 'config/database.php';
require_once 'config/session.php';
$is_logged_in = isLoggedIn();
$page_title = "Ketentuan Penggunaan";
require_once 'includes/header.php';
?>

<style>
    :root {
        --primary-color: #FF6A00;
        --primary-light: #FFF1E6;
        --primary-dark: #E85D04;
        --dark-color: #1a1a1a;
        --light-bg: #f9fafb;
        --text-color: #6b7280;
        --border-color: #e5e7eb;
    }

    .container-lg {
        max-width: 1400px;
        margin: 0 auto;
        padding: 0 16px;
        box-sizing: border-box;
        width: 100%;
    }

    @media (min-width: 768px) {
        .container-lg { padding: 0 24px; }
    }

    /* Terms Hero */
    .terms-hero {
        background: linear-gradient(135deg, #FF6A00 0%, #E85D04 50%, #D9480F 100%);
        color: white;
        padding: 60px 0;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .terms-hero::before {
        content: '';
        position: absolute;
        width: 300px;
        height: 300px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        top: -100px;
        right: -100px;
    }

    .terms-hero::after {
        content: '';
        position: absolute;
        width: 250px;
        height: 250px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 50%;
        bottom: -50px;
        left: -50px;
    }

    .terms-hero-content {
        position: relative;
        z-index: 2;
    }

    .terms-hero h1 {
        font-size: clamp(2rem, 5vw, 3.2rem);
        font-weight: 800;
        margin-bottom: 12px;
        line-height: 1.1;
        letter-spacing: -0.5px;
    }

    .terms-hero p {
        font-size: clamp(0.95rem, 2vw, 1.1rem);
        opacity: 0.95;
        max-width: 600px;
        margin: 0 auto;
    }

    /* Terms Container */
    .terms-container {
        max-width: 900px;
        margin: 0 auto;
        padding: 60px 16px;
        box-sizing: border-box;
        width: 100%;
    }

    @media (min-width: 768px) {
        .terms-container { padding: 60px 24px; }
    }

    .terms-intro {
        text-align: center;
        margin-bottom: 50px;
    }

    .terms-intro-title {
        font-size: clamp(1.6rem, 4vw, 2.2rem);
        font-weight: 800;
        color: var(--dark-color);
        margin-bottom: 12px;
        letter-spacing: -0.5px;
    }

    .terms-intro-subtitle {
        font-size: 1rem;
        color: var(--text-color);
        max-width: 500px;
        margin: 0 auto;
        line-height: 1.6;
    }

    /* Terms Content */
    .terms-content {
        background: white;
        padding: 30px;
        border-radius: 12px;
        margin-bottom: 20px;
        border: 1px solid var(--border-color);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    }

    .terms-content:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        border-color: var(--primary-light);
    }

    .terms-content h3 {
        font-size: 1.1rem;
        font-weight: 700;
        margin-bottom: 16px;
        color: var(--dark-color);
        display: flex;
        align-items: center;
        gap: 12px;
        letter-spacing: -0.3px;
    }

    .terms-content h3 i {
        color: white;
        font-size: 0.85rem;
        background: var(--primary-color);
        width: 28px;
        height: 28px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 6px;
        box-shadow: 0 3px 10px rgba(255, 106, 0, 0.25);
        flex-shrink: 0;
    }

    .terms-content p {
        color: var(--text-color);
        line-height: 1.7;
        font-size: 0.95rem;
        margin: 0;
    }

    .terms-content p + p {
        margin-top: 12px;
    }

    .terms-content ul {
        margin: 12px 0 0 24px;
        padding: 0;
    }

    .terms-content li {
        color: var(--text-color);
        line-height: 1.7;
        font-size: 0.95rem;
        margin-bottom: 8px;
    }

    /* Terms CTA */
    .terms-cta {
        background: linear-gradient(135deg, #FF6A00 0%, #E85D04 100%);
        color: white;
        padding: 50px 30px;
        border-radius: 14px;
        text-align: center;
        margin-top: 60px;
        box-shadow: 0 10px 30px rgba(255, 106, 0, 0.2);
    }

    .terms-cta h3 {
        font-size: 1.5rem;
        font-weight: 800;
        margin-bottom: 10px;
        letter-spacing: -0.5px;
    }

    .terms-cta p {
        margin-bottom: 20px;
        opacity: 0.95;
        font-size: 0.95rem;
    }

    .terms-cta-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        background: white;
        color: var(--primary-color);
        padding: 12px 28px;
        border-radius: 10px;
        border: none;
        font-weight: 700;
        font-size: 0.95rem;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        text-decoration: none;
        font-family: 'Poppins', sans-serif;
    }

    .terms-cta-btn:hover {
        background: #f3f4f6;
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        color: var(--primary-color);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .terms-container {
            padding: 40px 0;
        }

        .terms-hero {
            padding: 40px 0;
        }

        .terms-hero h1 {
            font-size: 1.8rem;
        }

        .terms-hero p {
            font-size: 0.9rem;
        }

        .terms-intro {
            margin-bottom: 30px;
        }

        .terms-intro-title {
            font-size: 1.4rem;
        }

        .terms-intro-subtitle {
            font-size: 0.9rem;
        }

        .terms-content {
            padding: 24px;
        }

        .terms-content h3 {
            font-size: 1rem;
        }

        .terms-cta {
            padding: 35px 20px;
            margin-top: 40px;
        }

        .terms-cta h3 {
            font-size: 1.2rem;
        }

        .terms-cta p {
            font-size: 0.9rem;
        }
    }

    @media (max-width: 480px) {
        .terms-hero {
            padding: 30px 0;
        }

        .terms-hero h1 {
            font-size: 1.5rem;
        }

        .terms-intro-title {
            font-size: 1.2rem;
        }

        .terms-content {
            padding: 16px;
        }

        .terms-content h3 {
            font-size: 0.95rem;
            gap: 8px;
        }

        .terms-cta {
            padding: 25px 16px;
            margin-top: 30px;
        }

        .terms-cta h3 {
            font-size: 1rem;
        }

        .terms-cta p {
            font-size: 0.85rem;
        }

        .terms-cta-btn {
            padding: 10px 20px;
            font-size: 0.85rem;
        }
    }
</style>

<!-- Terms Hero Section -->
<section class="terms-hero">
    <div class="container-lg">
        <div class="terms-hero-content">
            <h1>Ketentuan Penggunaan</h1>
            <p>Harap membaca ketentuan penggunaan ini dengan cermat sebelum menggunakan platform kami</p>
        </div>
    </div>
</section>

<!-- Terms Content -->
<section>
    <div class="container-lg terms-container">
        <!-- Terms Intro -->
        <div class="terms-intro">
            <h2 class="terms-intro-title">Penting untuk Diketahui</h2>
            <p class="terms-intro-subtitle">Dengan mengakses dan menggunakan BEKOMIN ID, pengguna dianggap telah membaca, memahami, dan menyetujui ketentuan penggunaan yang berlaku pada platform ini.</p>
        </div>

        <!-- Terms Items -->
        <div class="terms-content">
            <h3><i class="fas fa-check-circle"></i> Penerimaan Ketentuan</h3>
            <p>Dengan mengakses dan menggunakan BEKOMIN ID, Anda menyetujui ketentuan penggunaan yang tercantum pada halaman ini. Jika Anda tidak menyetujui ketentuan yang berlaku, Anda disarankan untuk tidak menggunakan layanan dan fitur yang tersedia pada BEKOMIN ID.</p>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-book-open"></i> Penggunaan Layanan</h3>
            <p>BEKOMIN ID disediakan untuk membantu pengguna menemukan dan memperoleh rekomendasi produk UMKM berdasarkan informasi produk, lokasi, serta data rating yang tersedia pada sistem.</p>
            <p>Pengguna wajib menggunakan platform secara wajar dan tidak diperkenankan untuk:</p>
            <ul>
                <li>Menggunakan BEKOMIN ID untuk tujuan yang melanggar hukum atau peraturan yang berlaku</li>
                <li>Menggunakan data atau informasi yang tersedia pada platform untuk tujuan yang merugikan pihak lain</li>
                <li>Mencoba memperoleh akses tanpa izin terhadap sistem, server, database, atau bagian lain dari platform</li>
                <li>Mengganggu, merusak, atau menghambat kinerja sistem</li>
                <li>Melakukan tindakan yang dapat merugikan BEKOMIN ID, pengguna lain, maupun pihak UMKM yang terdaftar pada platform</li>
            </ul>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-user-check"></i> Akun Pengguna</h3>
            <p>Apabila pengguna memiliki akun pada BEKOMIN ID, pengguna bertanggung jawab untuk menjaga keamanan informasi akun dan tidak memberikan informasi login kepada pihak lain.</p>
            <p>Setiap aktivitas yang dilakukan melalui akun pengguna menjadi tanggung jawab pengguna yang bersangkutan.</p>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-pencil-alt"></i> Informasi Produk dan UMKM</h3>
            <p>Informasi produk, deskripsi, kategori, lokasi, serta informasi UMKM yang ditampilkan pada BEKOMIN ID digunakan untuk membantu pengguna dalam menemukan produk yang tersedia.</p>
            <p>Informasi tersebut dapat berasal dari data yang dikelola oleh administrator sistem. BEKOMIN ID berupaya menjaga informasi yang ditampilkan tetap sesuai dengan data yang tersedia, namun tidak menjamin bahwa seluruh informasi selalu bebas dari kesalahan atau perubahan.</p>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-star"></i> Rating dan Review</h3>
            <p>Pengguna yang memberikan rating atau ulasan pada produk wajib memberikan penilaian secara wajar dan sesuai dengan pengalaman atau pengetahuan yang sebenarnya.</p>
            <p>Rating pengguna dapat digunakan sebagai data dalam proses sistem rekomendasi User-Based Collaborative Filtering pada BEKOMIN ID.</p>
            <p>Pengguna tidak diperkenankan memberikan rating atau ulasan yang sengaja dibuat untuk memanipulasi hasil rekomendasi, merugikan pihak lain, atau memberikan informasi yang menyesatkan.</p>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-exclamation-triangle"></i> Sistem Rekomendasi</h3>
            <p>BEKOMIN ID menggunakan metode User-Based Collaborative Filtering untuk menghasilkan rekomendasi produk berdasarkan pola rating dan tingkat kemiripan preferensi antar pengguna.</p>
            <p>Hasil rekomendasi merupakan hasil perhitungan sistem berdasarkan data yang tersedia dan tidak dapat dianggap sebagai jaminan bahwa produk yang direkomendasikan pasti sesuai dengan kebutuhan atau pilihan pengguna.</p>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-shield-alt"></i> Penafian</h3>
            <p>BEKOMIN ID disediakan sebagaimana adanya untuk membantu pengguna dalam menemukan informasi dan rekomendasi produk UMKM.</p>
            <p>BEKOMIN ID tidak menjamin bahwa platform akan selalu tersedia tanpa gangguan, bebas dari kesalahan, atau selalu menghasilkan rekomendasi yang sesuai dengan kebutuhan setiap pengguna.</p>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-refresh"></i> Batasan Tanggung Jawab</h3>
            <p>BEKOMIN ID berupaya menyediakan informasi dan layanan sistem rekomendasi dengan sebaik mungkin. Namun, pengguna tetap bertanggung jawab atas keputusan yang dibuat berdasarkan informasi, rating, maupun rekomendasi yang diperoleh melalui platform.</p>
            <p>BEKOMIN ID tidak bertanggung jawab atas kerugian yang timbul akibat keputusan pengguna dalam menggunakan informasi atau rekomendasi yang tersedia pada platform, sepanjang diperbolehkan berdasarkan ketentuan hukum yang berlaku.</p>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-ban"></i> Perubahan Ketentuan</h3>
            <p>BEKOMIN ID dapat melakukan perubahan atau pembaruan terhadap ketentuan penggunaan apabila diperlukan untuk menyesuaikan dengan perkembangan sistem, layanan, maupun ketentuan yang berlaku.</p>
            <p>Perubahan ketentuan akan ditampilkan pada halaman ini dan mulai berlaku setelah diperbarui.</p>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-gavel"></i> Penghentian atau Pembatasan Akses</h3>
            <p>BEKOMIN ID dapat membatasi atau menghentikan akses pengguna apabila ditemukan penggunaan platform yang melanggar ketentuan penggunaan, mengganggu sistem, atau merugikan pengguna maupun pihak lain.</p>
        </div>

        <div class="terms-content">
            <h3><i class="fas fa-scales"></i> Hukum yang Berlaku</h3>
            <p>Ketentuan penggunaan BEKOMIN ID ditafsirkan berdasarkan hukum yang berlaku di wilayah Negara Kesatuan Republik Indonesia.</p>
            <p>Setiap permasalahan yang berkaitan dengan penggunaan platform akan diselesaikan terlebih dahulu secara baik sesuai dengan ketentuan yang berlaku.</p>
        </div>

        <!-- Terms CTA -->
        <div class="terms-cta">
            <h3>Setuju dengan Ketentuan Kami?</h3>
            <p>Temukan produk UMKM berkualitas dan dapatkan rekomendasi berdasarkan preferensi Anda</p>
            <a href="home.php" class="terms-cta-btn">
                <i class="fas fa-arrow-right"></i>
                Kembali ke Home
            </a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
