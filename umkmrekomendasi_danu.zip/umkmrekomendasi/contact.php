<?php
require_once 'config/database.php';
require_once 'config/session.php';
$is_logged_in = isLoggedIn();
$page_title = "Kontak Kami";
require_once 'includes/header.php';

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email = isset($_POST['email']) ? trim(strtolower($_POST['email'])) : '';
    $subject = isset($_POST['subject']) ? trim($_POST['subject']) : '';
    $message_text = isset($_POST['message']) ? trim($_POST['message']) : '';
    
    if (empty($name) || empty($email) || empty($subject) || empty($message_text)) {
        $message = 'Semua field harus diisi';
        $message_type = 'danger';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Format email tidak valid';
        $message_type = 'danger';
    } else {
        $message = 'Terima kasih atas pesan Anda. Kami akan merespons segera.';
        $message_type = 'success';
    }
}
?>

<style>
    :root {
        --primary-color: #FF6A00;
        --primary-light: #FFF1E6;
        --primary-dark: #E85D04;
        --dark-color: #1a1a1a;
        --light-bg: #f9fafb;
        --text-color: #6b7280;
        --border-color: #e5e7eb;
    }

    .container-lg {
        max-width: 1400px;
        margin: 0 auto;
        padding: 0 16px;
        box-sizing: border-box;
        width: 100%;
    }

    @media (min-width: 768px) {
        .container-lg { padding: 0 24px; }
    }

    /* Contact Hero */
    .contact-hero {
        background: linear-gradient(135deg, #FF6A00 0%, #E85D04 50%, #D9480F 100%);
        color: white;
        padding: 60px 0;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .contact-hero::before {
        content: '';
        position: absolute;
        width: 300px;
        height: 300px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        top: -100px;
        right: -100px;
    }

    .contact-hero::after {
        content: '';
        position: absolute;
        width: 250px;
        height: 250px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 50%;
        bottom: -50px;
        left: -50px;
    }

    .contact-hero-content {
        position: relative;
        z-index: 2;
    }

    .contact-hero h1 {
        font-size: clamp(2rem, 5vw, 3.2rem);
        font-weight: 800;
        margin-bottom: 12px;
        line-height: 1.1;
        letter-spacing: -0.5px;
    }

    .contact-hero p {
        font-size: clamp(0.95rem, 2vw, 1.1rem);
        opacity: 0.95;
        max-width: 600px;
        margin: 0 auto;
    }

    /* Contact Container */
    .contact-container {
        max-width: 900px;
        margin: 0 auto;
        padding: 60px 16px;
        box-sizing: border-box;
        width: 100%;
    }

    @media (min-width: 768px) {
        .contact-container { padding: 60px 24px; }
    }

    .contact-intro {
        text-align: center;
        margin-bottom: 50px;
    }

    .contact-intro-title {
        font-size: clamp(1.6rem, 4vw, 2.2rem);
        font-weight: 800;
        color: var(--dark-color);
        margin-bottom: 12px;
        letter-spacing: -0.5px;
    }

    .contact-intro-subtitle {
        font-size: 1rem;
        color: var(--text-color);
        max-width: 500px;
        margin: 0 auto;
        line-height: 1.6;
    }

    /* Contact Item */
    .contact-item {
        background: white;
        padding: 30px;
        border-radius: 12px;
        margin-bottom: 12px;
        border: 1px solid var(--border-color);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        display: flex;
        gap: 16px;
        align-items: flex-start;
    }

    .contact-item:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        border-color: var(--primary-light);
    }

    .contact-item-icon {
        font-size: 1.2rem;
        color: white;
        background: var(--primary-color);
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 10px;
        flex-shrink: 0;
        box-shadow: 0 3px 10px rgba(255, 106, 0, 0.25);
    }

    .contact-item-content h3 {
        font-size: 1rem;
        font-weight: 700;
        color: var(--dark-color);
        margin: 0 0 4px 0;
    }

    .contact-item-content p {
        font-size: 0.95rem;
        color: var(--text-color);
        line-height: 1.6;
        margin: 0;
    }

    .contact-item-content a {
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 600;
        transition: all 0.3s ease;
    }

    .contact-item-content a:hover {
        text-decoration: underline;
        color: var(--primary-dark);
    }

    /* Contact Form */
    .contact-form {
        background: white;
        padding: 30px;
        border-radius: 12px;
        border: 1px solid var(--border-color);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        margin-top: 20px;
    }

    .contact-form h3 {
        font-size: 1.3rem;
        font-weight: 800;
        color: var(--dark-color);
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 12px;
        letter-spacing: -0.5px;
    }

    .contact-form h3 i {
        color: white;
        font-size: 0.95rem;
        background: var(--primary-color);
        width: 32px;
        height: 32px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 8px;
        box-shadow: 0 3px 10px rgba(255, 106, 0, 0.25);
        flex-shrink: 0;
    }

    .form-group {
        margin-bottom: 20px;
    }

    .form-label {
        display: block;
        font-weight: 600;
        color: var(--dark-color);
        margin-bottom: 8px;
        font-size: 0.95rem;
    }

    .form-control {
        width: 100%;
        padding: 12px 16px;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        font-size: 0.95rem;
        font-family: 'Poppins', sans-serif;
        transition: all 0.3s;
    }

    .form-control:focus {
        outline: none;
        border-color: var(--primary-color);
        box-shadow: 0 0 0 3px rgba(255, 106, 0, 0.1);
    }

    textarea.form-control {
        resize: vertical;
        min-height: 120px;
    }

    .btn-submit {
        background: var(--primary-color);
        color: white;
        padding: 12px 32px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.3s;
        font-size: 1rem;
        width: 100%;
        font-family: 'Poppins', sans-serif;
    }

    .btn-submit:hover {
        background: var(--primary-dark);
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(255, 106, 0, 0.3);
    }

    .alert {
        padding: 16px;
        border-radius: 8px;
        margin-bottom: 24px;
        font-weight: 500;
    }

    .alert-success {
        background: #ffe8cc;
        color: #FF6A00;
        border: 1px solid #ffd4a8;
    }

    .alert-danger {
        background: #fef2f2;
        color: #991b1b;
        border: 1px solid #fecaca;
    }

    /* Contact CTA */
    .contact-cta {
        background: linear-gradient(135deg, #FF6A00 0%, #E85D04 100%);
        color: white;
        padding: 50px 30px;
        border-radius: 14px;
        text-align: center;
        margin-top: 60px;
        box-shadow: 0 10px 30px rgba(255, 106, 0, 0.2);
    }

    .contact-cta h3 {
        font-size: 1.5rem;
        font-weight: 800;
        margin-bottom: 10px;
        letter-spacing: -0.5px;
    }

    .contact-cta p {
        margin-bottom: 20px;
        opacity: 0.95;
        font-size: 0.95rem;
    }

    .contact-cta-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        background: white;
        color: var(--primary-color);
        padding: 12px 28px;
        border-radius: 10px;
        border: none;
        font-weight: 700;
        font-size: 0.95rem;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        text-decoration: none;
        font-family: 'Poppins', sans-serif;
    }

    .contact-cta-btn:hover {
        background: #f3f4f6;
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        color: var(--primary-color);
    }

    /* Responsive */
    @media (max-width: 768px) {
        .contact-container {
            padding: 40px 0;
        }

        .contact-hero {
            padding: 40px 0;
        }

        .contact-hero h1 {
            font-size: 1.8rem;
        }

        .contact-hero p {
            font-size: 0.9rem;
        }

        .contact-intro {
            margin-bottom: 30px;
        }

        .contact-intro-title {
            font-size: 1.4rem;
        }

        .contact-intro-subtitle {
            font-size: 0.9rem;
        }

        .contact-item {
            padding: 24px;
        }

        .contact-form {
            padding: 24px;
        }

        .contact-form h3 {
            font-size: 1.1rem;
            gap: 10px;
        }

        .contact-form h3 i {
            font-size: 0.85rem;
            width: 28px;
            height: 28px;
            border-radius: 6px;
        }

        .contact-cta {
            padding: 35px 20px;
            margin-top: 40px;
        }

        .contact-cta h3 {
            font-size: 1.2rem;
        }

        .contact-cta p {
            font-size: 0.9rem;
        }
    }

    @media (max-width: 480px) {
        .contact-hero {
            padding: 30px 0;
        }

        .contact-hero h1 {
            font-size: 1.5rem;
        }

        .contact-intro-title {
            font-size: 1.2rem;
        }

        .contact-item {
            padding: 16px;
        }

        .contact-form {
            padding: 16px;
        }

        .contact-form h3 {
            font-size: 1rem;
        }

        .contact-cta {
            padding: 25px 16px;
            margin-top: 30px;
        }

        .contact-cta h3 {
            font-size: 1rem;
        }

        .contact-cta p {
            font-size: 0.85rem;
        }

        .contact-cta-btn {
            padding: 10px 20px;
            font-size: 0.85rem;
        }
    }
</style>

<!-- Contact Hero Section -->
<section class="contact-hero">
    <div class="container-lg">
        <div class="contact-hero-content">
            <h1>Kontak Kami</h1>
            <p>Hubungi kami untuk pertanyaan, saran, atau bantuan apapun</p>
        </div>
    </div>
</section>

<!-- Contact Content -->
<section>
    <div class="container-lg contact-container">
        <!-- Contact Intro -->
        <div class="contact-intro">
            <h2 class="contact-intro-title">Kami Siap Membantu</h2>
            <p class="contact-intro-subtitle">Hubungi tim kami melalui berbagai cara. Kami akan merespons pertanyaan Anda dalam waktu 24 jam.</p>
        </div>

        <!-- Contact Items -->
        <div class="contact-item">
            <div class="contact-item-icon">
                <i class="fas fa-map-marker-alt"></i>
            </div>
            <div class="contact-item-content">
                <h3>Alamat</h3>
                <p>Bekasi Utara, Jawa Barat, Indonesia</p>
            </div>
        </div>

        <div class="contact-item">
            <div class="contact-item-icon">
                <i class="fas fa-envelope"></i>
            </div>
            <div class="contact-item-content">
                <h3>Email</h3>
                <p><a href="mailto:info@umkmrecommend.id">info@umkmrecommend.id</a></p>
            </div>
        </div>

        <div class="contact-item">
            <div class="contact-item-icon">
                <i class="fas fa-clock"></i>
            </div>
            <div class="contact-item-content">
                <h3>Jam Operasional</h3>
                <p>Senin - Jumat: 09:00 - 17:00 WIB<br>Sabtu - Minggu: Tutup</p>
            </div>
        </div>

        <!-- Contact Form -->
        <div class="contact-form">
            <h3>
                <i class="fas fa-paper-plane"></i>
                Kirim Pesan Kepada Kami
            </h3>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="name" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Masukkan nama Anda" required>
                </div>

                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="Masukkan email Anda" required>
                </div>

                <div class="form-group">
                    <label for="subject" class="form-label">Subjek</label>
                    <input type="text" class="form-control" id="subject" name="subject" placeholder="Masukkan subjek pesan" required>
                </div>

                <div class="form-group">
                    <label for="message" class="form-label">Pesan</label>
                    <textarea class="form-control" id="message" name="message" placeholder="Ketikkan pesan Anda di sini..." required></textarea>
                </div>

                <button type="submit" class="btn-submit">
                    <i class="fas fa-paper-plane"></i> Kirim Pesan
                </button>
            </form>
        </div>

        <!-- Contact CTA -->
        <div class="contact-cta">
            <h3>Pertanyaan Umum?</h3>
            <p>Kunjungi halaman FAQ kami untuk menemukan jawaban atas pertanyaan-pertanyaan umum</p>
            <a href="faq.php" class="contact-cta-btn">
                <i class="fas fa-question-circle"></i>
                Baca FAQ
            </a>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>

</content>
