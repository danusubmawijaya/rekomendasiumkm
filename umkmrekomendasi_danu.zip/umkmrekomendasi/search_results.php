<?php
// Enable error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once 'config/database.php';
require_once 'config/session.php';

$page_title = "Hasil Pencarian";
require_once 'includes/header.php';

// Initialize variables
$searchQuery = isset($_GET['search']) ? trim($_GET['search']) : '';
$categoryFilter = isset($_GET['category']) ? trim($_GET['category']) : '';
$products = [];
$categories = [];
$error_message = '';

// Fungsi similarityScore (Levenshtein-like)
function similarityScore($str1, $str2) {
    $str1 = strtolower($str1);
    $str2 = strtolower($str2);
    
    if ($str1 === $str2) return 100;
    
    $len1 = strlen($str1);
    $len2 = strlen($str2);
    $maxLen = max($len1, $len2);
    
    if ($maxLen == 0) return 100;
    
    $distance = levenshtein($str1, $str2);
    return max(0, 100 - ($distance / $maxLen) * 100);
}

// Fungsi untuk mencari partial match di dalam string
function partialMatch($haystack, $needle) {
    $needle = strtolower($needle);
    $haystack = strtolower($haystack);
    
    // Split needle into words
    $words = explode(' ', $needle);
    $score = 0;
    $matched_words = 0;
    
    foreach ($words as $word) {
        if (!empty($word)) {
            if (strpos($haystack, $word) !== false) {
                $matched_words++;
                $score += 50; // Berat untuk word match
            } else {
                // Try fuzzy match
                $parts = explode(' ', $haystack);
                $best_similarity = 0;
                foreach ($parts as $part) {
                    $sim = similarityScore($word, $part);
                    if ($sim > $best_similarity) {
                        $best_similarity = $sim;
                    }
                }
                if ($best_similarity >= 70) {
                    $matched_words++;
                    $score += $best_similarity;
                }
            }
        }
    }
    
    // Return score jika setidaknya 1 word cocok
    return $matched_words > 0 ? min(100, ($score / max(count($words), 1))) : 0;
}

// Validasi database connection
if (!$conn) {
    $error_message = "Koneksi database gagal";
} else {
    try {
        // Escape input untuk safety
        $search_escaped = $conn->real_escape_string($searchQuery);
        $category_escaped = $conn->real_escape_string($categoryFilter);
        
        // Build WHERE clause - hanya untuk category jika ada
        $where_clause = "";
        if (!empty($categoryFilter)) {
            $where_clause = "WHERE p.kategori = '$category_escaped'";
        }
        
        // Query untuk semua produk (atau filtered by category)
        $query = "
            SELECT 
                p.id,
                p.nama_produk,
                p.deskripsi,
                p.kategori,
                p.gambar,
                COALESCE(AVG(r.rating), 0) as avg_rating,
                COUNT(r.id) as rating_count
            FROM products p
            LEFT JOIN ratings r ON p.id = r.product_id
            $where_clause
            GROUP BY p.id
            LIMIT 500
        ";
        
        $result = $conn->query($query);
        
        if (!$result) {
            $error_message = "Database query failed: " . $conn->error;
        } else {
            $all_products = [];
            while ($row = $result->fetch_assoc()) {
                $row['avg_rating'] = floatval($row['avg_rating']);
                $row['rating_count'] = intval($row['rating_count']);
                $all_products[] = $row;
            }
            
            // Apply Fuzzy Search jika ada query
            if (!empty($searchQuery)) {
                // Calculate fuzzy match scores
                foreach ($all_products as &$product) {
                    $name_score = partialMatch($product['nama_produk'], $searchQuery);
                    $desc_score = partialMatch($product['deskripsi'], $searchQuery);
                    $product['fuzzy_score'] = max($name_score, $desc_score);
                }
                
                // Filter products dengan score >= 50 (50% similarity)
                $products = array_filter($all_products, function($p) {
                    return $p['fuzzy_score'] >= 50;
                });
                
                // Sort by fuzzy score first, then by rating
                usort($products, function($a, $b) {
                    if ($a['fuzzy_score'] != $b['fuzzy_score']) {
                        return $b['fuzzy_score'] - $a['fuzzy_score'];
                    }
                    if ($a['rating_count'] != $b['rating_count']) {
                        return $b['rating_count'] - $a['rating_count'];
                    }
                    return $b['avg_rating'] - $a['avg_rating'];
                });
                
                // Re-index array
                $products = array_values($products);
            } else {
                // Jika hanya filter category, sort by rating
                usort($all_products, function($a, $b) {
                    if ($a['rating_count'] != $b['rating_count']) {
                        return $b['rating_count'] - $a['rating_count'];
                    }
                    return $b['avg_rating'] - $a['avg_rating'];
                });
                $products = $all_products;
            }
        }
        
        // Query untuk kategori
        $query_cat = "SELECT DISTINCT kategori FROM products WHERE kategori IS NOT NULL AND kategori != '' ORDER BY kategori ASC";
        $result_cat = $conn->query($query_cat);
        
        if ($result_cat) {
            while ($row = $result_cat->fetch_assoc()) {
                if (!empty($row['kategori'])) {
                    $categories[] = $row['kategori'];
                }
            }
        }
        
    } catch (Exception $e) {
        $error_message = "Error: " . $e->getMessage();
        error_log("Search Error: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?> - UMKM Recommend</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6A00;
            --primary-light: #FFF1E6;
            --primary-dark: #E85D04;
            --dark-color: #1a1a1a;
            --light-bg: #f9fafb;
            --text-color: #6b7280;
            --border-color: #e5e7eb;
        }

        body {
            font-family: 'Poppins', 'Inter', sans-serif;
            color: var(--dark-color);
            background: #fff;
        }

        .container-lg {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 16px;
        }

        @media (min-width: 768px) {
            .container-lg { padding: 0 24px; }
        }

        /* Search Header Section */
        .search-header-section {
            background: linear-gradient(135deg, #FF6A00 0%, #E85D04 50%, #D9480F 100%);
            color: white;
            padding: 60px 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .search-header-section::before {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -100px;
            right: -100px;
        }

        .search-header-section::after {
            content: '';
            position: absolute;
            width: 250px;
            height: 250px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 50%;
            bottom: -50px;
            left: -50px;
        }

        .search-header-content {
            position: relative;
            z-index: 2;
        }

        .search-header-section h1 {
            font-size: clamp(2rem, 5vw, 3.2rem);
            font-weight: 800;
            margin-bottom: 12px;
            line-height: 1.1;
            letter-spacing: -0.5px;
        }

        .search-header-section p {
            font-size: clamp(0.95rem, 2vw, 1.1rem);
            opacity: 0.95;
            max-width: 600px;
            margin: 0 auto;
        }

        .search-results-info {
            display: inline-block;
            background: rgba(255, 255, 255, 0.15);
            padding: 8px 16px;
            border-radius: 20px;
            margin-top: 16px;
            font-size: 0.95rem;
            backdrop-filter: blur(5px);
        }

        /* Search Page Container */
        .search-page-wrapper {
            max-width: 1400px;
            margin: 0 auto;
            padding: 60px 0;
        }

        .breadcrumb-link {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #FF6A00;
            text-decoration: none;
            font-weight: 600;
            font-size: 0.95rem;
            transition: all 0.2s ease;
            margin-bottom: 30px;
        }

        .breadcrumb-link:hover {
            gap: 12px;
            color: #E85D04;
        }

        .category-filter-bar {
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.07);
            margin-bottom: 40px;
            border: 1px solid #e5e7eb;
        }

        .category-filter-title {
            font-size: 0.9rem;
            font-weight: 700;
            color: #718096;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 12px;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .category-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .category-btn {
            padding: 8px 16px;
            border-radius: 20px;
            border: 1px solid #e5e7eb;
            background: white;
            color: #2d3748;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
            cursor: pointer;
            transition: all 0.2s ease;
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .category-btn:hover {
            border-color: #FF6A00;
            color: #FF6A00;
            background: #FFF1E6;
        }

        .category-btn.active {
            background: #FF6A00;
            color: white;
            border-color: #FF6A00;
            box-shadow: 0 4px 12px rgba(255, 106, 0, 0.3);
        }

        .products-section-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: #1a1a1a;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .products-section-title i {
            color: #FF6A00;
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .product-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid #e5e7eb;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            display: flex;
            flex-direction: column;
            height: 100%;
        }

        .product-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 20px 35px rgba(0, 0, 0, 0.15);
            border-color: #FFF1E6;
        }

        .product-image-wrapper {
            width: 100%;
            aspect-ratio: 16 / 9;
            background: linear-gradient(135deg, #FF6A00 0%, #E85D04 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
        }

        .product-image-wrapper img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .product-card:hover .product-image-wrapper img {
            transform: scale(1.08);
        }

        .product-category-badge {
            position: absolute;
            top: 8px;
            right: 8px;
            background: #FF6A00;
            color: white;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            box-shadow: 0 2px 8px rgba(255, 106, 0, 0.2);
        }

        .product-info {
            padding: 12px;
            display: flex;
            flex-direction: column;
            flex: 1;
            gap: 8px;
        }

        .product-name {
            font-weight: 700;
            font-size: 0.95rem;
            line-height: 1.3;
            color: #1a1a1a;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .product-rating {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 0.8rem;
        }

        .rating-stars {
            color: #f59e0b;
            display: flex;
            gap: 2px;
        }

        .rating-value {
            font-weight: 600;
            color: #1a1a1a;
        }

        .rating-count {
            color: #718096;
            font-size: 0.75rem;
        }

        .product-actions {
            display: flex;
            gap: 8px;
            margin-top: auto;
            padding-top: 8px;
            border-top: 1px solid #e5e7eb;
        }

        .btn-product-action {
            flex: 1;
            padding: 8px 10px;
            border-radius: 8px;
            border: none;
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 4px;
            font-family: 'Poppins', sans-serif;
            min-height: 32px;
        }

        .btn-detail {
            background: #7c3aed;
            color: white;
        }

        .btn-detail:hover {
            background: #6d28d9;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(124, 58, 237, 0.3);
        }

        .btn-rating {
            background: #FF6A00;
            color: white;
        }

        .btn-rating:hover {
            background: #E85D04;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 106, 0, 0.3);
        }

        .empty-state-container {
            grid-column: 1 / -1;
            text-align: center;
            padding: 80px 20px;
            background: #f9fafb;
            border-radius: 12px;
        }

        .empty-state-icon {
            font-size: 4rem;
            color: #cbd5e1;
            margin-bottom: 16px;
            display: block;
        }

        .empty-state-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: #1a1a1a;
            margin-bottom: 8px;
        }

        .empty-state-text {
            color: #718096;
            font-size: 1rem;
            margin-bottom: 20px;
        }

        .empty-state-hint {
            color: #9ca3af;
            font-size: 0.9rem;
            margin-bottom: 16px;
        }

        .btn-back-home {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #FF6A00;
            color: white;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.2s ease;
        }

        .btn-back-home:hover {
            background: #E85D04;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(255, 106, 0, 0.3);
        }

        .error-alert {
            background: #fee2e2;
            border: 1px solid #fca5a5;
            color: #991b1b;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 500;
        }

        .error-alert i {
            font-size: 1.2rem;
        }

        .back-to-top {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            background: #FF6A00;
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 999;
            transition: all 0.3s ease;
        }

        .back-to-top.show {
            display: flex;
        }

        .back-to-top:hover {
            background: #E85D04;
            transform: translateY(-3px);
        }

        /* Responsive Breakpoints - Match about.php */
        @media (max-width: 768px) {
            .search-header-section {
                padding: 40px 0;
            }

            .search-page-wrapper {
                padding: 40px 0;
            }

            .products-grid {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
                gap: 16px;
            }

            .btn-product-action {
                padding: 7px 8px;
                font-size: 0.8rem;
                min-height: 30px;
            }

            .btn-product-action span {
                display: none;
            }
        }

        @media (max-width: 480px) {
            .search-header-section {
                padding: 30px 0;
            }

            .search-page-wrapper {
                padding: 30px 0;
            }

            .products-grid {
                grid-template-columns: 1fr;
                gap: 12px;
            }

            .empty-state-container {
                padding: 60px 16px;
            }
        }
    </style>
</head>
<body>
    <!-- Search Header -->
    <section class="search-header-section">
        <div class="container-lg">
            <div class="search-header-content">
                <h1>
                    <?php 
                        if (!empty($searchQuery)) {
                            echo '<i class="fas fa-search"></i> ' . htmlspecialchars($searchQuery);
                        } else {
                            echo '<i class="fas fa-filter"></i> ' . htmlspecialchars($categoryFilter);
                        }
                    ?>
                </h1>
                <p>Temukan produk UMKM terbaik sesuai pencarian Anda</p>
                <div class="search-results-info">
                    <i class="fas fa-check-circle"></i>
                    <?php echo count($products) . ' produk ditemukan'; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <div class="search-page-wrapper">
        <div class="container-lg">
            <!-- Breadcrumb -->
            <a href="home.php" class="breadcrumb-link">
                <i class="fas fa-arrow-left"></i>
                Kembali ke Home
            </a>

            <!-- Error Message -->
            <?php if (!empty($error_message)): ?>
                <div class="error-alert">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <!-- Category Filter Bar -->
            <div class="category-filter-bar">
                <span class="category-filter-title">
                    <i class="fas fa-tag"></i> Filter Kategori
                </span>
                <div class="category-buttons">
                    <a href="search_results.php" class="category-btn <?php echo empty($categoryFilter) ? 'active' : ''; ?>">
                        <i class="fas fa-list"></i> Semua
                    </a>
                    <?php foreach ($categories as $cat): ?>
                        <a href="search_results.php?category=<?php echo urlencode($cat); ?>" 
                           class="category-btn <?php echo ($categoryFilter === $cat) ? 'active' : ''; ?>">
                            <i class="fas fa-tag"></i> <?php echo htmlspecialchars($cat); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Products Section -->
            <?php if (count($products) > 0): ?>
                <h2 class="products-section-title">
                    <i class="fas fa-boxes"></i>
                    Produk Yang Sesuai
                </h2>
                <div class="products-grid">
                    <?php foreach ($products as $product): ?>
                        <div class="product-card">
                            <div class="product-image-wrapper">
                                <img src="<?php echo !empty($product['gambar']) ? htmlspecialchars($product['gambar']) : 'https://via.placeholder.com/300x200?text=No+Image'; ?>" 
                                     alt="<?php echo htmlspecialchars($product['nama_produk']); ?>"
                                     onerror="this.src='https://via.placeholder.com/300x200?text=No+Image'">
                                <span class="product-category-badge"><?php echo htmlspecialchars($product['kategori'] ?? 'Umum'); ?></span>
                            </div>
                            <div class="product-info">
                                <h3 class="product-name"><?php echo htmlspecialchars($product['nama_produk']); ?></h3>
                                <div class="product-rating">
                                    <div class="rating-stars">
                                        <?php 
                                            $rating = (int)$product['avg_rating'];
                                            for ($i = 0; $i < 5; $i++) {
                                                if ($i < $rating) {
                                                    echo '<i class="fas fa-star"></i>';
                                                } else {
                                                    echo '<i class="fas fa-star" style="color: #d1d5db;"></i>';
                                                }
                                            }
                                        ?>
                                    </div>
                                    <span class="rating-value"><?php echo number_format($product['avg_rating'], 1); ?></span>
                                    <span class="rating-count">(<?php echo intval($product['rating_count']); ?>)</span>
                                </div>
                                <div class="product-actions">
                                    <a href="product_detail.php?id=<?php echo $product['id']; ?>" class="btn-product-action btn-detail">
                                        <i class="fas fa-eye"></i>
                                        <span>Detail</span>
                                    </a>
                                    <a href="product_detail.php?id=<?php echo $product['id']; ?>#rating" class="btn-product-action btn-rating">
                                        <i class="fas fa-star"></i>
                                        <span>Rating</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="products-grid">
                    <div class="empty-state-container">
                        <div class="empty-state-icon">
                            <i class="fas fa-search"></i>
                        </div>
                        <h2 class="empty-state-title">Produk Tidak Ditemukan</h2>
                        <p class="empty-state-text">Maaf, kami tidak menemukan produk yang sesuai dengan pencarian Anda</p>
                        <p class="empty-state-hint">Coba gunakan kata kunci lain atau pilih kategori berbeda</p>
                        <a href="home.php" class="btn-back-home">
                            <i class="fas fa-arrow-left"></i>
                            Kembali ke Home
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>

    <button class="back-to-top" id="backToTopBtn">
        <i class="fas fa-arrow-up"></i>
    </button>

    <script>
        // Back to top button
        const backToTopBtn = document.getElementById('backToTopBtn');
        
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        });
        
        backToTopBtn.addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    </script>
</body>
</html>
