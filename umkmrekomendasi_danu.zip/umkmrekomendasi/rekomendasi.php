<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once BASE_PATH . '/classes/CollaborativeFiltering.php';
require_once BASE_PATH . '/classes/Product.php';

// Check if AJAX request
$is_ajax = isset($_GET['ajax']) && $_GET['ajax'] === '1';

// Guest juga bisa akses rekomendasi, tapi butuh minimal 1 rating
// Hanya redirect jika tidak ada identity sama sekali
$identity = getCurrentIdentity();
if (!$identity) {
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['error' => 'No identity found', 'recommendations' => []]);
        exit();
    }
    header("Location: home.php");
    exit();
}

$TOP_K_NEIGHBORS = 10;
$TOP_N_RECOMMENDATIONS = 5;

$cf = new CollaborativeFiltering($conn);
$cf->setSimilarityThreshold(0.1);
$product = new Product($conn);

// Build identity key untuk CF
if ($identity['type'] === 'user') {
    $identity_key = "user:" . $identity['id'];
} else {
    $identity_key = "guest:" . $identity['id'];
}

// Hitung rating dari identity ini
$rating_count = 0;

if ($identity['type'] === 'user') {
    $check_rating_query = "SELECT COUNT(*) as total FROM ratings WHERE user_id = " . intval($identity['id']);
} else {
    // Guest: user_id harus NULL
    $check_rating_query = "SELECT COUNT(*) as total FROM ratings WHERE user_id IS NULL AND guest_id = '" . $conn->real_escape_string($identity['id']) . "'";
}

$rating_result = $conn->query($check_rating_query);

if ($rating_result) {
    $rating_data = $rating_result->fetch_assoc();
    $rating_count = isset($rating_data['total']) ? intval($rating_data['total']) : 0;
}

$recommendations = [];
$similar_users = [];

if ($rating_count > 0) {
    try {
        $similar_users = $cf->getSimilarUsers($identity_key, $TOP_K_NEIGHBORS);
        $recommendations = $cf->getRecommendations($identity_key, $TOP_N_RECOMMENDATIONS);
    } catch (Exception $e) {
        error_log("CF Error: " . $e->getMessage());
        $recommendations = [];
        $similar_users = [];
    }
}

// If AJAX request, return JSON
if ($is_ajax) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'recommendations' => $recommendations,
        'rating_count' => $rating_count,
        'identity_key' => $identity_key
    ]);
    exit();
}
?>
<?php require_once 'includes/header.php'; ?>

<link rel="stylesheet" href="css/global.css">
<link rel="stylesheet" href="css/home.css">

<style>
:root {
    --primary-color: #1d7e3f;
    --secondary-color: #2d9f52;
    --accent-color: #ff6b35;
    --dark-color: #1a1a1a;
    --border-color: #e5e7eb;
    --light-bg: #f9fafb;
}

.reko-container {
    padding: 20px 16px;
    max-width: 1200px;
    margin: 0 auto;
}

.reko-header {
    margin-bottom: 32px;
}

.reko-header h1 {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--dark-color);
    margin-bottom: 8px;
}

.reko-header p {
    color: #6b7280;
    font-size: 0.95rem;
    margin: 0;
}

.reko-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
    margin-bottom: 40px;
}

@media (min-width: 640px) {
    .reko-grid {
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
    }
}

@media (min-width: 1024px) {
    .reko-grid {
        grid-template-columns: repeat(4, 1fr);
    }
}

.product-card {
    background: white;
    border-radius: 12px;
    overflow: hidden;
    border: 1px solid var(--border-color);
    transition: all 0.3s;
    display: flex;
    flex-direction: column;
}

.product-card:hover {
    border-color: var(--primary-color);
    box-shadow: 0 12px 32px rgba(29, 126, 63, 0.15);
    transform: translateY(-4px);
}

.product-img-wrapper {
    position: relative;
    width: 100%;
    padding-bottom: 100%;
    background: var(--light-bg);
    overflow: hidden;
}

.product-img-wrapper img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.product-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    background: linear-gradient(135deg, var(--accent-color), #f7931e);
    color: white;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 700;
}

.product-body {
    padding: 16px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.product-name {
    font-weight: 700;
    color: var(--dark-color);
    margin-bottom: 8px;
    font-size: 1rem;
    line-height: 1.4;
}

.product-desc {
    font-size: 0.85rem;
    color: #6b7280;
    margin-bottom: 12px;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.product-rating {
    margin-bottom: 12px;
}

.stars {
    display: flex;
    gap: 4px;
    margin-bottom: 6px;
    color: #fbbf24;
    font-size: 0.9rem;
}

.rating-text {
    font-size: 0.85rem;
    color: #6b7280;
}

.prediction-box {
    background: rgba(255, 107, 53, 0.08);
    padding: 12px;
    border-radius: 8px;
    border-left: 3px solid var(--accent-color);
    margin-bottom: 12px;
    text-align: center;
    font-size: 0.9rem;
    color: var(--accent-color);
    font-weight: 700;
}

.location-box {
    background: #f0f9ff;
    padding: 10px;
    border-radius: 6px;
    margin-bottom: 12px;
    font-size: 0.8rem;
    color: var(--primary-color);
    font-weight: 600;
}

.btn-detail {
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: 8px;
    padding: 12px;
    font-weight: 600;
    font-size: 0.9rem;
    cursor: pointer;
    transition: all 0.3s;
    text-decoration: none;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    margin-top: auto;
}

.btn-detail:hover {
    background: var(--secondary-color);
    color: white;
    transform: translateY(-2px);
}

.empty-state {
    text-align: center;
    padding: 48px 24px;
    background: white;
    border-radius: 12px;
    border: 2px dashed var(--border-color);
}

.empty-icon {
    font-size: 3.5rem;
    color: #d1d5db;
    margin-bottom: 16px;
}

.empty-text {
    font-size: 1.1rem;
    font-weight: 600;
    color: var(--dark-color);
    margin-bottom: 8px;
}

.empty-desc {
    font-size: 0.95rem;
    color: #6b7280;
    margin-bottom: 24px;
    line-height: 1.6;
}

.btn-primary {
    background: var(--primary-color);
    color: white;
    border: none;
    padding: 12px 28px;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    transition: all 0.3s;
}

.btn-primary:hover {
    background: var(--secondary-color);
    color: white;
}

.section-title {
    font-size: 1.4rem;
    font-weight: 700;
    color: var(--dark-color);
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.how-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 16px;
    margin-bottom: 40px;
}

@media (min-width: 768px) {
    .how-grid {
        grid-template-columns: repeat(3, 1fr);
    }
}

.how-card {
    background: white;
    padding: 20px;
    border-radius: 12px;
    border: 1px solid var(--border-color);
    text-align: center;
    transition: all 0.3s;
}

.how-card:hover {
    border-color: var(--primary-color);
    box-shadow: 0 8px 24px rgba(29, 126, 63, 0.12);
}

.how-icon {
    font-size: 2.5rem;
    color: var(--primary-color);
    margin-bottom: 16px;
}

.how-card h5 {
    font-weight: 700;
    color: var(--dark-color);
    margin-bottom: 10px;
    font-size: 1rem;
}

.how-card p {
    color: #6b7280;
    font-size: 0.9rem;
    line-height: 1.6;
    margin-bottom: 12px;
}

.btn-sm {
    background: var(--primary-color);
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 0.8rem;
    font-weight: 600;
    cursor: pointer;
}

.btn-sm:hover {
    background: var(--secondary-color);
}

@media (max-width: 640px) {
    .reko-header h1 {
        font-size: 1.5rem;
    }
    
    .section-title {
        font-size: 1.2rem;
    }
}
</style>

<div class="reko-container">
    <div class="reko-header">
        <h1><i class="fas fa-sparkles"></i> Rekomendasi untuk Kamu</h1>
        <p>Produk pilihan khusus berdasarkan preferensi Anda</p>
    </div>

    <div style="margin-bottom: 40px;">
        <h2 class="section-title"><i class="fas fa-cog"></i> Bagaimana Cara Kerjanya?</h2>
        <div class="how-grid">
            <div class="how-card">
                <div class="how-icon"><i class="fas fa-users"></i></div>
                <h5>Cosine Similarity</h5>
                <p>Menghitung kemiripan preferensi pengguna berdasarkan rating.</p>
                <button class="btn-sm" data-bs-toggle="modal" data-bs-target="#modalCosineSimilarity">Lihat Rumus</button>
            </div>
            <div class="how-card">
                <div class="how-icon"><i class="fas fa-calculator"></i></div>
                <h5>Prediksi Rating</h5>
                <p>Memperkirakan nilai rating produk berdasarkan preferensi mirip.</p>
                <button class="btn-sm" data-bs-toggle="modal" data-bs-target="#modalPrediksiRating">Lihat Rumus</button>
            </div>
            <div class="how-card">
                <div class="how-icon"><i class="fas fa-star"></i></div>
                <h5>Top-N Recommendation</h5>
                <p>Menampilkan produk dengan nilai prediksi tertinggi.</p>
                <button class="btn-sm" data-bs-toggle="modal" data-bs-target="#modalTopNRecommendation">Lihat Proses</button>
            </div>
        </div>
    </div>

    <?php if (empty($recommendations)): ?>
        <div class="empty-state">
            <div class="empty-icon"><i class="fas fa-inbox"></i></div>
            <p class="empty-text">Belum ada rekomendasi</p>
            <p class="empty-desc">Sistem membutuhkan data rating dari pengguna lain yang memiliki preferensi serupa.</p>
            <a href="index.php" class="btn-primary"><i class="fas fa-star"></i>Berikan Rating Sekarang</a>
        </div>
    <?php else: ?>
        <h2 class="section-title"><i class="fas fa-fire"></i> Pilihan Terbaik untuk Kamu</h2>
        
        <div class="reko-grid">
            <?php foreach ($recommendations as $rec): ?>
                <div class="product-card">
                    <div class="product-img-wrapper">
                        <?php if ($rec['gambar']): ?>
                            <img src="<?php echo htmlspecialchars($rec['gambar']); ?>" alt="<?php echo htmlspecialchars($rec['nama_produk']); ?>" onerror="this.parentNode.innerHTML='<div style=\'width: 100%; height: 100%; display: flex; align-items: center; justify-content: center;\'><i class=\'fas fa-box\' style=\'font-size: 2rem; color: #d1d5db;\'></i></div>'">
                        <?php else: ?>
                            <div style="width: 100%; height: 100%; display: flex; align-items: center; justify-content: center;"><i class="fas fa-box" style="font-size: 2rem; color: #d1d5db;"></i></div>
                        <?php endif; ?>
                        <div class="product-badge"><i class="fas fa-check"></i> Rekomendasi</div>
                    </div>
                    
                    <div class="product-body">
                        <h5 class="product-name"><?php echo htmlspecialchars($rec['nama_produk']); ?></h5>
                        <p class="product-desc"><?php echo htmlspecialchars($rec['deskripsi']); ?></p>
                        
                        <div class="product-rating">
                            <div class="stars">
                                <?php 
                                $rating_val = round($rec['avg_rating'] ?? 0);
                                for ($i = 0; $i < 5; $i++): 
                                ?>
                                    <i class="<?php echo $i < $rating_val ? 'fas' : 'far'; ?> fa-star"></i>
                                <?php endfor; ?>
                            </div>
                            <div class="rating-text">
                                <?php if (isset($rec['avg_rating']) && $rec['avg_rating']): ?>
                                    <?php echo number_format($rec['avg_rating'], 1); ?> (<?php echo isset($rec['rating_count']) ? $rec['rating_count'] : 0; ?> rating)
                                <?php else: ?>
                                    Belum ada rating
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="prediction-box">
                            <i class="fas fa-chart-line"></i> Prediksi: <?php echo isset($rec['score']) ? number_format($rec['score'], 2) : '0.00'; ?>
                        </div>

                        <?php 
                        $locations = $rec['locations'] ?? '';
                        if (!empty($locations)): 
                            $locs = explode('|', $locations);
                        ?>
                            <div class="location-box">
                                <i class="fas fa-map-pin"></i> <?php echo htmlspecialchars($locs[0]); ?>
                                <?php if (count($locs) > 1): ?>
                                    +<?php echo count($locs) - 1; ?> lokasi
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <a href="product_detail.php?id=<?php echo $rec['id']; ?>" class="btn-detail">
                            <i class="fas fa-arrow-right"></i> Lihat Detail
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if (!empty($similar_users)): ?>
            <div style="margin-top: 40px;">
                <h2 class="section-title"><i class="fas fa-users"></i> Similar Users</h2>
                <div class="reko-grid" style="grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));">
                    <?php foreach ($similar_users as $sim_identity => $similarity): ?>
                        <?php 
                        // Parse identity key: "user:123" or "guest:xxx"
                        $sim_parts = explode(':', $sim_identity);
                        $sim_type = $sim_parts[0] ?? '';
                        $sim_id = $sim_parts[1] ?? '';
                        $user = ['name' => 'Unknown'];
                        
                        if ($sim_type === 'user' && is_numeric($sim_id)) {
                            $query = "SELECT name FROM users WHERE id = " . intval($sim_id);
                            $result = $conn->query($query);
                            if ($result) {
                                $user = $result->fetch_assoc();
                                if (!$user) $user = ['name' => 'Unknown User'];
                            }
                        } else {
                            $user = ['name' => 'Guest #' . substr($sim_id, 0, 8)];
                        }
                        ?>
                        <div style="background: white; padding: 18px; border-radius: 12px; border: 1px solid var(--border-color); text-align: center;">
                            <div style="width: 50px; height: 50px; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 700; font-size: 1.2rem; margin: 0 auto 12px;">
                                <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
                            </div>
                            <h6 style="margin: 0 0 6px 0; font-weight: 600; color: var(--dark-color); font-size: 0.9rem;"><?php echo htmlspecialchars($user['name']); ?></h6>
                            <div style="height: 6px; background: #f0f0f0; border-radius: 3px; margin-bottom: 10px; overflow: hidden;">
                                <div style="width: <?php echo $similarity * 100; ?>%; height: 100%; background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));"></div>
                            </div>
                            <small style="color: var(--primary-color); font-weight: 600; font-size: 0.8rem;"><?php echo number_format($similarity * 100, 0); ?>%</small>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<!-- Modals -->
<div class="modal fade" id="modalCosineSimilarity" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="border-radius: 12px; border: none; box-shadow: 0 10px 40px rgba(0,0,0,0.15);">
            <div class="modal-header" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; border: none; border-radius: 12px 12px 0 0;">
                <h5 class="modal-title" style="font-weight: 700;">Cosine Similarity</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" style="padding: 24px;">
                <h6 style="color: var(--dark-color); font-weight: 600; margin-bottom: 12px;">Penjelasan:</h6>
                <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">Metode ini menghitung tingkat kemiripan antara pengguna berdasarkan rating produk.</p>
                
                <h6 style="color: var(--dark-color); font-weight: 600; margin-bottom: 12px;">Rumus:</h6>
                <div style="background: #f8f9fa; padding: 16px; border-radius: 8px; overflow-x: auto; margin-bottom: 20px;">
                    <div style="text-align: center; font-family: 'Courier New', monospace; color: var(--dark-color); line-height: 1.8;">
                        <div>Sim(u,v) = Σ(r(u,i) × r(v,i))</div>
                        <div style="border-top: 2px solid var(--primary-color); margin: 8px 0; padding-top: 8px;">√Σ(r(u,i)²) × √Σ(r(v,i)²)</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalPrediksiRating" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="border-radius: 12px; border: none; box-shadow: 0 10px 40px rgba(0,0,0,0.15);">
            <div class="modal-header" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; border: none; border-radius: 12px 12px 0 0;">
                <h5 class="modal-title" style="font-weight: 700;">Prediksi Rating</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" style="padding: 24px;">
                <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">Prediksi rating dihitung dari rata-rata tertimbang rating pengguna yang mirip.</p>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalTopNRecommendation" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content" style="border-radius: 12px; border: none; box-shadow: 0 10px 40px rgba(0,0,0,0.15);">
            <div class="modal-header" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; border: none; border-radius: 12px 12px 0 0;">
                <h5 class="modal-title" style="font-weight: 700;">Top-N Recommendation</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" style="padding: 24px;">
                <p style="color: #666; line-height: 1.6;">Sistem menampilkan N produk dengan predicted rating tertinggi yang belum pernah dinilai pengguna.</p>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
