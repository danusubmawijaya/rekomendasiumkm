# UI Documentation - BEKOMIN ID UMKM Recommendation Platform

## HOME

# Home Page

**Purpose:**
Landing page with hero section, search bar, promo slider, featured products, and statistics showcasing the platform.

**Navigation/Menu:**
- Navbar (sticky): Logo, hamburger menu button, category dropdown
- Sidebar menu: Home, Semua Produk, Lihat Rekomendasi, Tentang, Profil (if logged in), Logout (if logged in), Login (if not logged in)
- Search form with hero section
- Product card links to detail page
- Footer with quick links and brand

**Components:**
- Sticky navbar with logo and hamburger button
- Hero section with gradient background and search bar
- Promo slider with autoplay and dot navigation
- Statistics cards displaying platform metrics
- Product grid with featured items
- CTA section with action button
- Back to top button (appears on scroll)
- Footer with quick links

**Input Fields:**
- Search input field (placeholder: "Mau cari makanan UMKM apa hari ini?")

**Actions:**
- Search products via hero search form
- Browse featured products
- Click product cards to view details
- Click category dropdown to filter
- Click back to top button to scroll to top
- Click footer links to navigate

**Output:**
- Featured products displayed in responsive grid
- Statistics showing visitor count and product count
- Promo slider with platform benefits
- Navigation options visible in header and sidebar

---

## AUTHENTICATION

# Login Page

**Purpose:**
User authentication page for account login with email and password.

**Navigation/Menu:**
- No navbar on this page
- Left side illustration (desktop only)
- Back to login link if coming from forgot password
- Links to Register and Forgot Password pages

**Components:**
- Illustration section (left side on desktop)
- White card form container
- Email input field
- Password input field
- Error/success alert box
- Login button
- Footer links section

**Input Fields:**
- Email field (type: email, placeholder: "Masukkan email Anda")
- Password field (type: password, placeholder: "Masukkan password Anda")

**Actions:**
- Submit login form with email and password
- Click "Daftar di sini" link to go to register page
- Click "Lupa password?" link to go to forgot password page

**Output:**
- Success: Redirects to index.php (user) or admin dashboard (admin)
- Error: Display error alert message
- Display success message if coming from successful password reset

---

# Register Page

**Purpose:**
New user account creation page with form validation and password strength indicator.

**Navigation/Menu:**
- No navbar on this page
- Left side illustration (desktop only)
- Link to login page
- Links to privacy documents

**Components:**
- Illustration section (left side on desktop)
- White card form container
- Name input field
- Email input field
- Password input field with strength meter
- Confirm password input field
- Error/success alert box
- Register button
- Footer link to login

**Input Fields:**
- Name field (type: text, placeholder: "Masukkan nama lengkap Anda", min: 3 chars)
- Email field (type: email, placeholder: "Masukkan email Anda")
- Password field (type: password, placeholder: "Masukkan password (minimal 6 karakter)", min: 6 chars)
- Password strength meter (visual indicator below password)
- Confirm password field (type: password, placeholder: "Ulangi password Anda")

**Actions:**
- Submit registration form
- Click "Login di sini" link to go to login page
- Watch password strength meter update as user types

**Output:**
- Strength meter displays: Weak (red), Medium (orange), Strong (green)
- Success: Auto login and redirect to index.php
- Error: Display validation error messages
- Display duplicate email error if email exists

---

# Forgot Password Page

**Purpose:**
Allow users to reset password by entering email address to receive reset link.

**Navigation/Menu:**
- Back to login link
- Card form container

**Components:**
- Email input field
- Submit button
- Success/error alert message
- Information text about password reset process

**Input Fields:**
- Email field (type: email, placeholder: "Masukkan email terdaftar Anda")

**Actions:**
- Submit email to request password reset
- Receive confirmation message with reset link sent to email
- Click link in email to go to reset password page

**Output:**
- Success message: "Email reset password telah dikirim ke [email]"
- Error message if email not found or other issues

---

# Reset Password Page

**Purpose:**
Allow users to set new password using token from email reset link.

**Navigation/Menu:**
- Redirect to login if no valid token
- Back to login link

**Components:**
- New password input field
- Confirm password input field
- Reset button
- Success/error alert message
- Form validation messages

**Input Fields:**
- New password field (type: password, placeholder: "Masukkan password baru", min: 6 chars)
- Confirm password field (type: password, placeholder: "Ulangi password baru")

**Actions:**
- Submit new password
- Form validates password match and length
- Redirect to login on success

**Output:**
- Success: "Password berhasil direset, silakan login"
- Error: "Token tidak valid atau sudah expired"
- Validation errors if passwords don't match

---

## USER PAGES

# Semua Produk (All Products)

**Purpose:**
Display complete product catalog with search, filtering, and browsing functionality.

**Navigation/Menu:**
- Navbar (sticky): Logo, hamburger menu, category dropdown
- Sidebar: Navigation links
- Search bar at top with clear button
- Category filter buttons: Semua, Makanan Berat, Jajanan & Street Food, Minuman, Makanan Rumahan
- Product card links
- Footer with quick links

**Components:**
- Search bar with search icon and clear button
- Category filter button group
- Product grid (responsive 2-4 columns)
- Product cards with image, name, description, rating, buttons
- Empty state message if no results
- Back to top button
- Footer

**Input Fields:**
- Search input (placeholder: "Cari produk...")

**Actions:**
- Search by keyword (GET parameter)
- Filter by category button
- Click product detail button to view full details
- Click product rating button to view/add rating
- Clear search query

**Output:**
- Product grid showing filtered results
- Display total product count
- Empty state if no products match search/filter
- Category active state highlights

---

# Product Detail

**Purpose:**
Display complete product information including description, locations, ratings, and allow users to add ratings.

**Navigation/Menu:**
- Back button at top (orange button with arrow)
- Navbar: Logo, hamburger menu
- Sidebar: Navigation
- Footer: Quick links

**Components:**
- Back button
- Product hero section: image, name, category, rating, verified badge, location
- Description card with formatted text
- Locations card with list of UMKM locations
- Location items with: numbered circle, name, address, coordinates
- Nearest location button with geolocation
- Ratings section with heading
- User current rating display (if exists)
- Rating form with star input and submit button
- Rating list showing recent ratings
- Footer

**Input Fields:**
- Star rating selector (1-5 stars clickable)
- Comment field (optional, if supported)

**Actions:**
- Click back button to return to previous page
- Click location item to view on map (if supported)
- Click nearest location button to find closest UMKM
- Click on star to set rating
- Submit rating form
- View other users' ratings
- Edit or delete own rating (if user is logged in)

**Output:**
- Product image and all details displayed
- List of all locations where product is available
- Display ratings from all users with name/timestamp
- User's own rating highlighted if exists
- Location address and map coordinates shown

---

# Search Results

**Purpose:**
Display search results for product query with category filter refinement.

**Navigation/Menu:**
- Navbar: Logo, hamburger menu, category dropdown
- Sidebar: Navigation
- Search query display with clear button
- Category filter buttons
- Product card links
- Footer

**Components:**
- Search query display: "Hasil pencarian untuk: [query]"
- Search bar for new search
- Category filter buttons
- Product grid with results
- Empty state if no matches
- Result count display
- Back to top button
- Footer

**Input Fields:**
- Search bar with current query and clear option

**Actions:**
- Click search clear to reset search
- Filter results by category
- Click product detail button
- Click product rating button
- New search via search bar

**Output:**
- Products matching search query displayed
- Result count shown
- Empty state if no matches found
- Filter buttons show availability per category

---

# Recommendations Page (Lihat Rekomendasi)

**Purpose:**
Display personalized product recommendations based on collaborative filtering algorithm using user's rating history.

**Navigation/Menu:**
- Navbar: Logo, hamburger menu
- Sidebar: Navigation
- Back to home link (if applicable)
- Footer: Quick links

**Components:**
- Page title: "Rekomendasi Untuk Anda"
- Subtitle explaining recommendation source
- Product grid with recommendation cards
- Similar user information section
- Message if insufficient ratings to generate recommendations
- Product rating/similarity score display
- Footer

**Input Fields:**
None

**Actions:**
- Click product card to view details
- Add additional ratings to improve recommendations
- Refresh page to get updated recommendations

**Output:**
- List of recommended products based on user ratings
- Similarity score shown
- Products sorted by recommendation score
- Message if no recommendations available yet
- Similar users who share rating patterns

---

# Profile Page

**Purpose:**
Display and manage user profile information, including name, email, and password change.

**Navigation/Menu:**
- Navbar: Logo, hamburger menu
- Sidebar: Navigation with profile link highlighted
- Tabs: Update Profile, Change Password
- Logout button/link
- Footer: Quick links

**Components:**
- Page title: "Profil"
- Tab navigation: "Update Profile", "Change Password"
- Profile form in tab 1
- Password change form in tab 2
- Success/error alert messages
- Logout button
- Footer

**Input Fields:**

Tab 1 - Update Profile:
- Name field (current value pre-filled)
- Email field (read-only or editable)

Tab 2 - Change Password:
- Old password field
- New password field
- Confirm password field

**Actions:**
- Edit name field
- Submit update profile form
- Enter old password
- Enter new password and confirm
- Submit password change form
- Click logout button

**Output:**
- Current profile information displayed
- Success message: "Profil berhasil diperbarui"
- Error message if update fails
- Password change success message
- Email verification alert (if applicable)

---

## INFORMATION PAGES

# About Page (Tentang)

**Purpose:**
Display information about BEKOMIN ID platform, mission, vision, and features.

**Navigation/Menu:**
- Navbar: Logo, hamburger menu
- Sidebar: Navigation
- Links to related pages: Kontak, FAQ, Terms, DMCA
- Footer: Quick links

**Components:**
- Page title with icon
- About description section
- Mission statement
- Vision statement
- Key features list with icons
- Links to related pages (cards or buttons)
- Footer

**Input Fields:**
None

**Actions:**
- Click links to related pages (Kontak, FAQ, Terms, DMCA)
- Click back via sidebar or navbar logo
- Scroll through content

**Output:**
- Platform information displayed
- Features highlighted
- Related page links shown as cards or section links

---

# Contact Page (Kontak)

**Purpose:**
Allow users to submit contact form to reach BEKOMIN ID team.

**Navigation/Menu:**
- Navbar: Logo, hamburger menu
- Sidebar: Navigation
- Back link
- Footer: Quick links

**Components:**
- Contact form
- Name input field
- Email input field
- Subject input field
- Message textarea
- Submit button
- Success/error message alert
- Contact information display (if any)

**Input Fields:**
- Name field (type: text, placeholder: "Masukkan nama Anda")
- Email field (type: email, placeholder: "Masukkan email Anda")
- Subject field (type: text, placeholder: "Masukkan subjek")
- Message field (type: textarea, placeholder: "Masukkan pesan Anda", rows: 6)

**Actions:**
- Fill in contact form
- Submit form
- Form validates all required fields
- Receive success confirmation

**Output:**
- Success message: "Pesan Anda telah terkirim, kami akan menghubungi Anda segera"
- Error message if form submission fails
- Form clears on successful submission

---

# FAQ Page

**Purpose:**
Display frequently asked questions and answers about BEKOMIN ID platform.

**Navigation/Menu:**
- Navbar: Logo, hamburger menu
- Sidebar: Navigation
- Footer: Quick links

**Components:**
- Page title: "FAQ (Frequently Asked Questions)"
- Accordion/expandable list of FAQ items
- Each FAQ item: question and answer
- Search/filter for FAQ (optional)
- Footer

**Input Fields:**
- Optional search field to filter FAQs

**Actions:**
- Click FAQ item to expand/collapse answer
- Search FAQ items (if search available)
- Scroll through FAQ list

**Output:**
- FAQ questions displayed
- Answers shown when expanded
- Expandable indicators visible
- All questions visible in list

---

# Terms & Conditions Page (Ketentuan Penggunaan)

**Purpose:**
Display website terms of service and conditions of use.

**Navigation/Menu:**
- Navbar: Logo, hamburger menu
- Sidebar: Navigation
- Footer: Quick links

**Components:**
- Page title: "Ketentuan Penggunaan"
- Formatted text with sections
- Headings for each section
- Footer

**Input Fields:**
None

**Actions:**
- Read terms document
- Scroll through content
- Navigate via sidebar or navbar

**Output:**
- Terms and conditions displayed with sections
- Text formatted for readability
- Sections clearly delineated

---

# DMCA Disclaimer Page

**Purpose:**
Display DMCA disclaimer and copyright information.

**Navigation/Menu:**
- Navbar: Logo, hamburger menu
- Sidebar: Navigation
- Footer: Quick links

**Components:**
- Page title: "DMCA Disclaimer"
- Formatted text sections
- Copyright information
- Contact information for DMCA claims
- Footer

**Input Fields:**
None

**Actions:**
- Read disclaimer
- Scroll through content
- Navigate via sidebar or navbar

**Output:**
- DMCA information displayed
- Copyright notice shown
- Contact procedure for DMCA claims

---

## ADMIN PAGES

# Admin Dashboard

**Purpose:**
Display overview statistics and management options for admin users.

**Navigation/Menu:**
- Admin header: Logo, hamburger menu (if needed)
- Admin sidebar: Dashboard, Products, Users, Menu Management
- Logout link

**Components:**
- Page title: "Dashboard" or "Admin Dashboard"
- Statistics cards displaying:
  - Total Products
  - Total Users
  - Total Ratings
  - Average Rating
- Charts or graphs showing platform metrics (optional)
- Quick action buttons
- Footer (optional)

**Input Fields:**
None

**Actions:**
- View statistics
- Click Products link to manage products
- Click Users link to manage users
- Click Menu Management to manage categories
- Click Logout to exit admin panel

**Output:**
- Statistics displayed in cards
- Numbers showing: product count, user count, rating count, average rating
- Charts showing trends (if implemented)
- Admin navigation options visible

---

# Admin Products Management

**Purpose:**
Manage all products: create, read, update, delete, verify products.

**Navigation/Menu:**
- Admin header: Logo
- Admin sidebar: Dashboard, Products (active), Users, Menu Management
- Products table with sorting
- Logout link

**Components:**
- Page title: "Manage Products"
- Add new product button
- Products table with columns:
  - Product ID
  - Name
  - Category
  - Description (truncated)
  - Verified status
  - Actions
- Action buttons per row: View, Edit, Delete, Verify
- Pagination for products list
- Search/filter bar (optional)
- Edit modal/form overlay
- Delete confirmation modal

**Input Fields:**

For Add/Edit Product:
- Product name field
- Category dropdown
- Description textarea
- Product image upload
- Verified checkbox
- Submit button

**Actions:**
- Click Add Product button to open form
- Fill product details
- Click Edit to modify product
- Click Delete to remove product
- Click Verify to mark product verified
- Click View to see product details
- Pagination: Click to go to next/previous page
- Search to filter products

**Output:**
- Products listed in table format
- Product details displayed: name, category, description (preview)
- Verified badge visible
- Success/error messages after actions
- Product count displayed
- Pagination indicators shown

---

# Admin Users Management

**Purpose:**
Manage user accounts: view, edit, delete users, manage admin status.

**Navigation/Menu:**
- Admin header: Logo
- Admin sidebar: Dashboard, Products, Users (active), Menu Management
- Users table with sorting
- Logout link

**Components:**
- Page title: "Manage Users"
- Add new user button (optional)
- Users table with columns:
  - User ID
  - Name
  - Email
  - Registration Date
  - Is Admin
  - Actions
- Action buttons per row: View, Edit, Delete, Toggle Admin
- Pagination for users list
- Search/filter bar (optional)
- Edit modal/form overlay
- Delete confirmation modal

**Input Fields:**

For Edit User:
- Name field
- Email field
- Admin checkbox (toggle)
- Submit button

**Actions:**
- Click user row to view details
- Click Edit to modify user
- Click Delete to remove user
- Click Toggle Admin to change admin status
- Pagination: Navigate pages
- Search to filter users

**Output:**
- Users listed in table
- User details: name, email, registration date
- Admin status displayed as badge/toggle
- Success/error messages
- User count displayed
- Pagination indicators

---

# Admin Menu Management

**Purpose:**
Manage product categories/menu items for filtering and organization.

**Navigation/Menu:**
- Admin header: Logo
- Admin sidebar: Dashboard, Products, Users, Menu Management (active)
- Menu table
- Logout link

**Components:**
- Page title: "Manage Menu/Categories"
- Add new category button
- Menu/Category table with columns:
  - ID
  - Category Name
  - Icon (if applicable)
  - Status
  - Actions
- Action buttons per row: Edit, Delete
- Add/Edit form modal
- Delete confirmation modal
- Success/error messages

**Input Fields:**

For Add/Edit Category:
- Category name field
- Category description field (optional)
- Category icon upload (optional)
- Status dropdown
- Submit button

**Actions:**
- Click Add Category button
- Fill category details
- Click Edit to modify category
- Click Delete to remove category
- Toggle status if applicable

**Output:**
- Categories listed in table
- Category details displayed
- Status indicators shown
- Success/error messages
- Add category form displayed as modal

---

# Admin Profile Page

**Purpose:**
Allow admin to view and edit their own profile and password.

**Navigation/Menu:**
- Admin header: Logo
- Admin sidebar: Dashboard, Products, Users, Menu Management
- Tabs or sections for profile and password
- Logout link

**Components:**
- Page title: "Admin Profile"
- Tabs: Profile, Change Password
- Admin profile form
- Password change form
- Success/error messages
- Back button or close option

**Input Fields:**

Tab 1 - Profile:
- Name field (pre-filled)
- Email field (read-only or editable)
- Submit button

Tab 2 - Change Password:
- Current password field
- New password field
- Confirm password field
- Submit button

**Actions:**
- View admin information
- Edit admin name
- Change admin password
- Submit forms
- Receive confirmation messages

**Output:**
- Admin profile information displayed
- Success message: "Profil berhasil diperbarui"
- Password change confirmation
- Error messages if validation fails

---

# Admin Location Management (Auto Geocode Locations)

**Purpose:**
Bulk add and auto-geocode product locations using geolocation APIs.

**Navigation/Menu:**
- Admin header: Logo
- Admin sidebar with management options
- Back link to dashboard
- Logout link

**Components:**
- Page title: "Bulk Add Locations"
- Bulk import file upload
- Instructions text
- File format requirements
- Upload button
- Progress indicator
- Results table or messages
- Success/error notifications

**Input Fields:**
- File upload field (accepts CSV or similar format)
- Process button

**Actions:**
- Upload location file
- Process bulk import
- Auto-geocode locations using coordinates or address
- View import results
- Handle errors and retries

**Output:**
- Import progress displayed
- Success count shown
- Error count with details
- Successfully imported locations listed
- Failed locations with error reasons

---

# Admin Evaluation Page (MAE Evaluation)

**Purpose:**
Display mean absolute error evaluation metrics for recommendation algorithm accuracy.

**Navigation/Menu:**
- Admin header: Logo
- Admin sidebar
- Back to dashboard link
- Logout link

**Components:**
- Page title: "Evaluasi MAE (Mean Absolute Error)"
- Statistics section showing:
  - MAE value
  - RMSE (if applicable)
  - Algorithm accuracy percentage
- Graph/chart of prediction errors
- Detailed evaluation results table
- Filters: date range, algorithm version
- Export/download results option (optional)

**Input Fields:**
- Date range picker (optional)
- Algorithm filter dropdown (optional)

**Actions:**
- View evaluation metrics
- Filter by date or algorithm
- Export results
- Navigate back to dashboard

**Output:**
- MAE metrics displayed
- Graphs showing accuracy trends
- Detailed evaluation data in table
- Interpretation of results
- Recommendations for improvement

---

# Admin Detailed Evaluation Page

**Purpose:**
Display detailed breakdown of evaluation metrics with per-user or per-product analysis.

**Navigation/Menu:**
- Admin header
- Admin sidebar
- Back to evaluation link
- Logout link

**Components:**
- Page title: "Detail Evaluasi"
- Evaluation summary cards
- Detailed results table with columns:
  - User ID / Product ID
  - Predicted Rating
  - Actual Rating
  - Error
  - Percentage Error
- Charts and visualizations
- Filters for analysis
- Export options (optional)

**Input Fields:**
- Filter dropdowns or search fields
- Date range selectors
- Metric selection dropdown

**Actions:**
- View detailed evaluation data
- Filter results by various criteria
- Sort table by columns
- Export evaluation report
- Navigate to related pages

**Output:**
- Detailed metrics displayed in table
- Visual charts and graphs
- Statistics summary
- Per-user/product analysis
- Export file generated if requested

---

## SHARED COMPONENTS

# Navbar (All Pages)

**Purpose:**
Primary navigation header present on all public pages.

**Navigation/Menu:**
- Logo (brand) - links to home
- Hamburger menu button - opens sidebar
- Category dropdown (on some pages)
- User name/dropdown (if logged in)

**Components:**
- Fixed/sticky navbar container
- Logo/brand name
- Hamburger menu icon button
- Category dropdown select
- Right side: User info or login button

**Input Fields:**
- Category dropdown for filtering (on product pages)

**Actions:**
- Click logo to go to home
- Click hamburger to open sidebar
- Click category dropdown to filter
- Click user dropdown for options (if logged in)

**Output:**
- Navigation options visible
- Active page highlighted
- User status displayed

---

# Sidebar Menu (All Pages)

**Purpose:**
Off-canvas navigation menu for all pages with dynamic links based on login status.

**Navigation/Menu:**
- Close button (X)
- Menu items (dynamic based on login status)
- Icons and text for each item

**Components:**
- Off-canvas sidebar container
- Close button
- Menu item list with icons
- Separator lines between items
- Backdrop/overlay (if applicable)

**Input Fields:**
None

**Actions:**
- Click menu items to navigate
- Click close button to dismiss sidebar
- Click backdrop to close sidebar
- Scroll menu if needed

**Output:**
- Sidebar slides in from left
- All menu items visible
- Active item highlighted
- Sidebar closes when item clicked or close button pressed

**Menu Items (Logged In User):**
- Home
- Semua Produk
- Lihat Rekomendasi
- Tentang
- Profil
- Logout

**Menu Items (Not Logged In):**
- Home
- Semua Produk
- Tentang
- Login
- Register

---

# Footer (All Pages)

**Purpose:**
Footer section present on all pages with quick links and copyright information.

**Navigation/Menu:**
- Quick links section
- Copyright and brand info
- Back to top button

**Components:**
- Quick links bar with sections:
  - About section: Tentang Kami, Kontak, FAQ
  - Legal section: Ketentuan Penggunaan, DMCA
- Copyright notice
- Brand name
- Back to top button (floating)

**Input Fields:**
None

**Actions:**
- Click quick links to navigate
- Click brand to return to home
- Click back to top button to scroll to top

**Output:**
- Footer links displayed horizontally or in grid
- Copyright notice visible
- Icons and text for sections
- Back to top button visible at bottom right

---

# Product Card (Semua Produk, Home, Search Results, Recommendations)

**Purpose:**
Display product preview with image, name, rating, and action buttons.

**Navigation/Menu:**
- Detail button - links to product detail page
- Rating button - links to product detail page #rating

**Components:**
- Product image (top)
- Category badge (top-left)
- Verified badge (if applicable)
- Product name
- Product description (truncated)
- Star rating display
- Rating count
- Action buttons: Detail, Rating

**Input Fields:**
None

**Actions:**
- Click product image to view details
- Click Detail button to go to product detail page
- Click Rating button to view/add ratings
- Hover for effects (shadow, elevation)

**Output:**
- Product information displayed in card
- Image shown with fallback color if missing
- Category clearly indicated
- Rating and count visible
- Buttons ready for interaction

---

# Alert/Notification Messages

**Purpose:**
Display success, error, warning, or info messages to users.

**Navigation/Menu:**
None (standalone)

**Components:**
- Alert container with border
- Alert icon based on type
- Message text
- Close button (optional)

**Input Fields:**
None

**Actions:**
- Dismiss alert by clicking close button
- Auto-dismiss after timeout (optional)

**Output:**

Success Alert:
- Background: Light green
- Border: Green
- Icon: Checkmark
- Text: Success message

Error Alert:
- Background: Light red
- Border: Red
- Icon: X or alert
- Text: Error message

Warning Alert:
- Background: Light orange/yellow
- Border: Orange/yellow
- Icon: Warning
- Text: Warning message

Info Alert:
- Background: Light blue
- Border: Blue
- Icon: Info
- Text: Information message

---

# Modal/Dialog (Edit Forms, Confirmations)

**Purpose:**
Display forms, confirmations, and additional content in overlay modals.

**Navigation/Menu:**
- Close button (X)
- Buttons: Cancel, Save/Submit/Delete

**Components:**
- Modal backdrop (semi-transparent overlay)
- Modal container (centered white card)
- Modal header with title
- Close button (X)
- Modal body with content/form
- Modal footer with buttons

**Input Fields:**
- Varies based on form (product edit, user edit, etc.)

**Actions:**
- Click outside modal to close (if allowed)
- Click X button to close
- Click Cancel button to close
- Fill form and click Save/Submit
- Click Delete/Confirm for action confirmation

**Output:**
- Modal displayed centered on screen
- Content clearly visible
- Form validation errors if applicable
- Success/error message after submission

---

# Star Rating Display

**Purpose:**
Display product or review ratings using star visualization.

**Navigation/Menu:**
None

**Components:**
- 5 star icons arranged horizontally
- Filled stars for rating
- Empty stars for remaining
- Rating count badge

**Input Fields:**
None (display only, unless in product detail for input)

**Actions:**
- Display current rating (read-only on cards)
- Interactive on product detail page (click stars to rate)

**Output:**
- Stars filled to rating value (1-5)
- Count shown: "4.5 (25 ratings)"
- Visual clarity on product quality

---

# Search Bar Component

**Purpose:**
Allow users to search for products or content.

**Navigation/Menu:**
None

**Components:**
- Search icon (left)
- Input field
- Clear button (X) if query exists
- Submit button (implicit on enter)

**Input Fields:**
- Search query input (type: text)

**Actions:**
- Type search query
- Click search icon to submit
- Click X to clear search
- Press Enter to submit
- Form submits via GET method

**Output:**
- Search redirects to search_results.php with query parameter
- Results displayed on search results page

---

# Category Filter Buttons

**Purpose:**
Allow users to filter products by category on index, search, and product pages.

**Navigation/Menu:**
None

**Components:**
- Button group with flex layout
- Individual category buttons
- Active state styling on current selection

**Input Fields:**
None

**Actions:**
- Click category button to filter
- Button links to page with category parameter
- "Semua" button resets filter

**Output:**
- Selected category button highlighted (orange background, white text)
- Other buttons show orange border, white background
- Product grid updates to show filtered results

---

