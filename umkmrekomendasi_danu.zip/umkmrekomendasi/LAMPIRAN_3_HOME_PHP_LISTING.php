<?php
// ============================================================================
// LAMPIRAN 3 – LISTING PROGRAM SKRIPSI
// home.php - Kode Inti Halaman Home
// ============================================================================

// 1. INISIALISASI
require_once 'config/database.php';
require_once 'config/session.php';
require_once BASE_PATH . '/classes/Product.php';

// 2. TRACKING PENGUNJUNG DENGAN DEVICE ID
$visitor_ip = $_SERVER['REMOTE_ADDR'];
$today = date('Y-m-d');

$device_id = isset($_COOKIE['device_id']) 
    ? $_COOKIE['device_id'] 
    : hash('sha256', $_SERVER['HTTP_USER_AGENT'] . $visitor_ip . time() . rand(1000, 9999));

if (!isset($_COOKIE['device_id'])) {
    setcookie('device_id', $device_id, time() + (365 * 24 * 60 * 60), '/');
}

$check_query = "SELECT id FROM app_visitors WHERE device_id = ? AND visit_date = ?";
$stmt = $conn->prepare($check_query);
$stmt->bind_param("ss", $device_id, $today);
$stmt->execute();

if ($stmt->get_result()->num_rows == 0) {
    $user_id_visitor = isLoggedIn() ? intval($_SESSION['user_id']) : NULL;
    $insert_query = "INSERT INTO app_visitors (device_id, visitor_ip, visit_date, count, user_id, page_visited) 
                     VALUES (?, ?, ?, 1, ?, 'home.php') ON DUPLICATE KEY UPDATE count=count+1";
    $stmt = $conn->prepare($insert_query);
    $stmt->bind_param("sssi", $device_id, $visitor_ip, $today, $user_id_visitor);
    $stmt->execute();
}

// 3. HANDLE AJAX REQUEST
if (isset($_GET['ajax']) && $_GET['ajax'] === 'stats') {
    header('Content-Type: application/json');
    echo json_encode(['total_products' => 0, 'total_app_visitors' => 0, 
                     'overall_avg_rating' => 0, 'timestamp' => time()]);
    exit();
}

// 4. AMBIL KATEGORI PRODUK
$sql_categories = "SELECT DISTINCT kategori FROM products 
                   WHERE kategori IS NOT NULL AND kategori != '' ORDER BY kategori ASC";
$result_categories = $conn->query($sql_categories);
$categories_from_db = [];

if ($result_categories) {
    while ($row = $result_categories->fetch_assoc()) {
        if (!empty($row['kategori'])) {
            $categories_from_db[] = $row['kategori'];
        }
    }
}

if (!in_array('Makanan Rumahan', $categories_from_db)) {
    $categories_from_db[] = 'Makanan Rumahan';
    sort($categories_from_db);
}

// 5. CEK STATUS LOGIN USER
$is_logged_in = isLoggedIn();
$user_id = $is_logged_in ? getCurrentUserId() : 0;

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UMKM Recommend - Temukan Makanan UMKM Favoritmu</title>
</head>
<body>
    <!-- Navbar dengan Kategori -->
    <nav class="navbar-home">
        <?php foreach ($categories_from_db as $category): ?>
            <div data-category="<?php echo htmlspecialchars($category); ?>">
                <?php echo htmlspecialchars($category); ?>
            </div>
        <?php endforeach; ?>
        
        <!-- Menu Login/Logout -->
        <?php if ($is_logged_in): ?>
            <a href="profile.php">Profil</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>
    </nav>

    <!-- Section Produk -->
    <section id="produk">
        <div id="productGrid"></div>
    </section>

    <!-- Section Rekomendasi -->
    <section id="rekomendasi">
        <div id="recommendationGrid"></div>
    </section>

    <script src="js/home.js"></script>
</body>
</html>
