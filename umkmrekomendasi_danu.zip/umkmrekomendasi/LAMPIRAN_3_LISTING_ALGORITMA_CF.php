<?php
/**
 * LISTING PROGRAM LAMPIRAN 3
 * Algoritma User-Based Collaborative Filtering
 * Menampilkan kode inti perhitungan: Cosine Similarity, Prediksi Rating, MAE, LOOCV
 */

class CollaborativeFiltering {
    
    // ===== 1. COSINE SIMILARITY =====
    // Baris 1-20: Menghitung kemiripan antar user berdasarkan common products
    public function cosineSimilarity($identity1, $identity2, $all_ratings) {
        $ratings1 = $all_ratings[$identity1] ?? [];
        $ratings2 = $all_ratings[$identity2] ?? [];
        
        $common = array_intersect_key($ratings1, $ratings2);
        if (empty($common)) return 0;
        
        $dot = $mag1 = $mag2 = 0;
        foreach ($common as $pid => $r1) {
            $r2 = $ratings2[$pid];
            $dot += $r1 * $r2;
            $mag1 += $r1 * $r1;
            $mag2 += $r2 * $r2;
        }
        
        $mag1 = sqrt($mag1);
        $mag2 = sqrt($mag2);
        
        return ($mag1 > 0 && $mag2 > 0) ? $dot / ($mag1 * $mag2) : 0;
    }
    
    // ===== 2. PREDIKSI RATING =====
    // Baris 21-33: Memprediksi rating produk berdasarkan user mirip
    // Rumus: P(u,i) = Σ(Sim(u,v) × r(v,i)) / Σ|Sim(u,v)|
    private function predictRating($identity, $product_id, $similar_users, $all_ratings) {
        $num = $den = 0;
        
        foreach ($similar_users as $sim_identity => $similarity) {
            if (isset($all_ratings[$sim_identity][$product_id])) {
                $rating = $all_ratings[$sim_identity][$product_id];
                $num += $similarity * $rating;
                $den += abs($similarity);
            }
        }
        
        return ($den > 0) ? $num / $den : 0;
    }
    
    // ===== 3. MAE - MEAN ABSOLUTE ERROR =====
    // Baris 34-56: Evaluasi dengan LOOCV dan perhitungan MAE
    // Rumus: MAE = (1/n) × Σ|p_i - r_i|
    public function calculateMAE() {
        $all_ratings = $this->loadAllRatings();
        $errors = [];
        
        foreach ($all_ratings as $identity => $products) {
            foreach ($products as $product_id => $actual_rating) {
                unset($all_ratings[$identity][$product_id]); // Remove untuk LOOCV
                
                $similar_users = $this->getSimilarUsers($identity, 10, $all_ratings);
                if (!empty($similar_users)) {
                    $predicted = $this->predictRating($identity, $product_id, $similar_users, $all_ratings);
                    if ($predicted > 0) {
                        $errors[] = abs($predicted - $actual_rating);
                    }
                }
                
                $all_ratings[$identity][$product_id] = $actual_rating; // Restore
            }
        }
        
        return count($errors) > 0 ? array_sum($errors) / count($errors) : 0;
    }
    
    // ===== 4. LOOCV - Leave-One-Out Cross Validation =====
    // Baris 57-68: Prosedur validasi menghindari data leakage
    // Setiap iterasi: 1) Ambil 1 rating, 2) Hapus sementara, 
    // 3) Hitung similarity, 4) Prediksi, 5) Hitung error, 6) Restore
    private function loadAllRatings() {
        $query = "SELECT user_id, guest_id, product_id, rating FROM ratings 
                  WHERE (user_id > 0) OR (user_id = 0 AND guest_id IS NOT NULL)";
        $result = $this->conn->query($query);
        
        $all_ratings = [];
        while ($row = $result->fetch_assoc()) {
            $key = ($row['user_id'] > 0) ? "user:" . $row['user_id'] : "guest:" . $row['guest_id'];
            $all_ratings[$key][$row['product_id']] = $row['rating'];
        }
        return $all_ratings;
    }
    
    public function getSimilarUsers($identity, $limit = 5, $all_ratings = null) {
        if ($all_ratings === null) $all_ratings = $this->loadAllRatings();
        if (!isset($all_ratings[$identity])) return [];
        
        $similarities = [];
        foreach ($all_ratings as $other => $products) {
            if ($other !== $identity) {
                $sim = $this->cosineSimilarity($identity, $other, $all_ratings);
                if ($sim > 0.1) $similarities[$other] = $sim;
            }
        }
        arsort($similarities);
        return array_slice($similarities, 0, $limit, true);
    }
}
?>

/* PENJELASAN KOMPONEN ALGORITMA */

// Baris 1-20: COSINE SIMILARITY
// Menghitung kemiripan dua user berdasarkan produk yang sama-sama di-rating
// Input: identity1, identity2, all_ratings (cache data rating)
// Output: nilai similarity 0-1 (0=tidak mirip, 1=sangat mirip)
// Rumus: Sim(u,v) = Σ(r_u,i × r_v,i) / (√Σr_u,i² × √Σr_v,i²)

// Baris 21-33: PREDIKSI RATING
// Memprediksi rating user untuk produk yang belum di-rated
// Input: identity (user), product_id, similar_users (dengan similarity score), all_ratings
// Output: predicted rating value
// Rumus: P(u,i) = Σ(Sim(u,v) × r(v,i)) / Σ|Sim(u,v)|
// Proses: Jumlah (similarity × rating dari similar user) dibagi jumlah similarity

// Baris 34-56: MAE (MEAN ABSOLUTE ERROR)
// Mengevaluasi akurasi prediksi dengan membandingkan prediksi vs actual rating
// Rumus: MAE = (1/n) × Σ|p_i - r_i|
// p_i = predicted rating, r_i = actual rating, n = jumlah prediksi valid
// MAE lebih rendah = prediksi lebih akurat

// Baris 57-68: LOOCV (Leave-One-Out Cross Validation)
// Prosedur untuk menghindari data leakage dalam evaluasi:
// 1. Ambil satu rating dari database (menjadi test set)
// 2. Hapus rating tersebut sementara dari cache training set
// 3. Hitung similar users menggunakan training set yang sudah dikurangi
// 4. Prediksi rating menggunakan similar users dan training set
// 5. Hitung error: |predicted - actual|
// 6. Restore rating ke cache
// 7. Lanjutkan ke rating berikutnya
// Manfaat: Setiap rating diuji dengan data training yang tidak mengandung data test tersebut
