<?php
// Database Configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'umkmbeka_umkm_rekomendasi');
define('DB_PASS', '8SO3=Rfh]8c7ZkX%');
define('DB_NAME', 'umkmbeka_umkm_rekomendasi');

// Define base path for the application
if (!defined('BASE_PATH')) {
    define('BASE_PATH', dirname(__DIR__));
}

// Create connection with error suppression to prevent header issues
$conn = @new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    // Log error but don't die immediately to avoid partial header output
    error_log("Database Connection Error: " . $conn->connect_error);
    
    // Set a flag so we can handle this gracefully
    $GLOBALS['db_connection_error'] = true;
    $GLOBALS['db_error_message'] = $conn->connect_error;
    
    // Only die if not in header-sensitive operations
    if (!headers_sent()) {
        http_response_code(500);
        die("Database connection failed. Please try again later.");
    }
} else {
    // Set charset
    $conn->set_charset("utf8mb4");
}

// Polyfill untuk get_result() di PHP versi lama
// Gunakan store_result() + bind_result() untuk kompatibilitas
if (!function_exists('stmt_get_result')) {
    function stmt_get_result($stmt) {
        if (method_exists($stmt, 'get_result')) {
            return $stmt->get_result();
        }
        // Untuk versi lama, return statement sendiri
        // Classes yang memanggil ini harus gunakan store_result() + fetch()
        return null;
    }
}

// Helper function untuk load class files
if (!function_exists('loadClass')) {
    function loadClass($classname) {
        $file = BASE_PATH . '/classes/' . $classname . '.php';
        if (file_exists($file)) {
            require_once $file;
            return true;
        }
        trigger_error("Class file not found: $file", E_USER_WARNING);
        return false;
    }
}

/**
 * Helper function untuk mendapatkan jumlah baris dari statement
 * Kompatibel dengan PHP versi lama yang tidak punya get_result()
 */
if (!function_exists('stmt_get_row_count')) {
    function stmt_get_row_count($stmt) {
        if (method_exists($stmt, 'get_result')) {
            $result = $stmt->get_result();
            return $result ? $result->num_rows : 0;
        }
        // Fallback untuk PHP lama
        $stmt->store_result();
        return $stmt->num_rows;
    }
}

/**
 * Helper function untuk fetch associative array dari statement
 * Kompatibel dengan PHP versi lama
 */
if (!function_exists('stmt_fetch_assoc')) {
    function stmt_fetch_assoc($stmt) {
        if (method_exists($stmt, 'get_result')) {
            $result = $stmt->get_result();
            return $result ? $result->fetch_assoc() : null;
        }
        
        // Fallback untuk PHP lama - gunakan store_result + bind_result
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $meta = $stmt->result_metadata();
            $fields = [];
            $result = [];
            
            while ($field = $meta->fetch_field()) {
                $fields[] = $field->name;
            }
            
            // Create array of references for bind_result
            $values = array_fill(0, count($fields), null);
            $bind_params = [];
            foreach ($values as &$value) {
                $bind_params[] = &$value;
            }
            
            call_user_func_array([$stmt, 'bind_result'], $bind_params);
            
            if ($stmt->fetch()) {
                for ($i = 0; $i < count($fields); $i++) {
                    $result[$fields[$i]] = $values[$i];
                }
                return $result;
            }
        }
        return null;
    }
}
?>
