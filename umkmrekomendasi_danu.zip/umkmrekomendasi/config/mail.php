<?php
/**
 * Email Configuration - Menggunakan PHP mail()
 */

define('MAIL_FROM', 'noreply@umkmrekomendasi.com');
define('MAIL_FROM_NAME', 'UMKM Recommend');

/**
 * Send email menggunakan PHP mail()
 */
function sendEmail($to, $subject, $body, $isHtml = false) {
    error_log("=== SEND EMAIL ===");
    error_log("TO: $to");
    error_log("SUBJECT: $subject");
    
    $headers = "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM . ">\r\n";
    $headers .= "Reply-To: " . MAIL_FROM . "\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    
    if ($isHtml) {
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    } else {
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    }
    
    $headers .= "Content-Transfer-Encoding: 8bit\r\n";
    $headers .= "X-Mailer: UMKM Recommend System\r\n";
    
    $result = @mail($to, $subject, $body, $headers);
    
    if ($result) {
        error_log("✓ EMAIL SENT SUCCESS");
        return true;
    } else {
        error_log("✗ EMAIL SEND FAILED");
        return false;
    }
}
?>
