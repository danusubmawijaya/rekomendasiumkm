<?php
// Session Management
// Set session configuration BEFORE starting session
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);

// Start session hanya jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Initialize Guest ID if not exists
if (!isset($_COOKIE['guest_id']) && !isset($_SESSION['user_id'])) {
    initializeGuestId();
}

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && intval($_SESSION['is_admin']) == 1;
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

function redirectIfNotAdmin() {
    if (!isAdmin()) {
        header("Location: ../access_denied.php");
        exit();
    }
}

function getCurrentUserId() {
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    $userId = $_SESSION['user_id'];
    // Ensure user_id is numeric
    return is_numeric($userId) ? intval($userId) : null;
}

function getGuestId() {
    // Cek cookie dulu
    if (isset($_COOKIE['guest_id']) && !empty($_COOKIE['guest_id'])) {
        $guestId = sanitizeGuestId($_COOKIE['guest_id']);
        if ($guestId) {
            return $guestId;
        }
    }
    
    // Jika cookie tidak valid atau kosong, generate guest ID baru
    initializeGuestId();
    
    // Return guest ID dari cookie yang baru di-set
    if (isset($_COOKIE['guest_id']) && !empty($_COOKIE['guest_id'])) {
        $guestId = sanitizeGuestId($_COOKIE['guest_id']);
        if ($guestId) {
            return $guestId;
        }
    }
    
    // Fallback: generate UUID dan kembalikan langsung (jika setcookie gagal)
    $fallback_id = generateUUIDv4();
    error_log("WARNING: getGuestId fallback - generated new UUID: $fallback_id");
    return $fallback_id;
}

/**
 * Sanitize and validate guest ID format (UUID v4)
 * More lenient validation to handle edge cases
 */
function sanitizeGuestId($guestId) {
    // Must be string
    if (!is_string($guestId)) {
        return null;
    }
    
    // Trim whitespace
    $guestId = trim($guestId);
    
    // Check if empty
    if (empty($guestId)) {
        return null;
    }
    
    // Check UUID v4 format (strict)
    if (preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/', strtolower($guestId))) {
        return strtolower($guestId);
    }
    
    // Check looser format (for backward compatibility or edge cases)
    if (preg_match('/^[0-9a-f\-]{35,37}$/i', $guestId)) {
        error_log("WARNING: Guest ID format is non-standard but usable: $guestId");
        return strtolower($guestId);
    }
    
    // Invalid format
    error_log("WARNING: Invalid guest ID format: $guestId");
    return null;
}

/**
 * Get current identity (user_id if logged in, guest_id if not)
 * Returns array: ['type' => 'user'|'guest', 'id' => value]
 */
function getCurrentIdentity() {
    if (isLoggedIn()) {
        $userId = getCurrentUserId();
        if ($userId !== null) {
            return [
                'type' => 'user',
                'id' => $userId
            ];
        }
    }
    
    $guest_id = getGuestId();
    if ($guest_id) {
        return [
            'type' => 'guest',
            'id' => $guest_id
        ];
    }
    
    return null;
}

/**
 * Initialize Guest ID dengan UUID v4
 */
function initializeGuestId() {
    if (!isset($_COOKIE['guest_id'])) {
        $guest_id = generateUUIDv4();
        
        // Determine if HTTPS is enabled (strict type checking)
        $isSecure = false;
        if (isset($_SERVER['HTTPS'])) {
            $https = $_SERVER['HTTPS'];
            $isSecure = ($https === 'on' || $https === '1' || $https === true);
        }
        
        // Calculate cookie expiry time - ensure it's integer
        $expireTime = (int)(time() + (365 * 24 * 60 * 60));
        
        // Set cookie dengan durasi 365 hari
        setcookie(
            'guest_id',
            $guest_id,
            $expireTime,
            '/',
            '',
            $isSecure,
            true   // HttpOnly
        );
        
        // Juga set di superglobal untuk immediate use
        $_COOKIE['guest_id'] = $guest_id;
    }
}

/**
 * Generate UUID v4
 */
function generateUUIDv4() {
    $bytes = random_bytes(16);
    
    // Set version (4) dan variant (RFC 4122)
    $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
    $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
    
    return implode('-', [
        bin2hex(substr($bytes, 0, 4)),
        bin2hex(substr($bytes, 4, 2)),
        bin2hex(substr($bytes, 6, 2)),
        bin2hex(substr($bytes, 8, 2)),
        bin2hex(substr($bytes, 10, 6))
    ]);
}

function logout() {
    $_SESSION = [];
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
    header("Location: home.php");
    exit();
}
?>
