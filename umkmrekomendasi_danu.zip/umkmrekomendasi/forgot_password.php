<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require_once 'config/mail.php';
require_once 'config/database.php';
require_once 'classes/User.php';

$message = '';
$message_type = '';
$show_form = true;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = isset($_POST['email']) ? trim(strtolower($_POST['email'])) : '';
    
    error_log("=== FORGOT PASSWORD DEBUG ===");
    error_log("POST email: " . $email);
    
    // Strict email validation
    if (empty($email)) {
        $message = 'Email harus diisi';
        $message_type = 'danger';
        error_log("ERROR: Email kosong");
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Format email tidak valid';
        $message_type = 'danger';
        error_log("ERROR: Format email tidak valid - email: " . $email);
    } elseif (!preg_match('/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/', $email)) {
        $message = 'Format email tidak valid';
        $message_type = 'danger';
        error_log("ERROR: Email regex tidak valid - email: " . $email);
    } else {
        
        $user = new User($conn);
        $user_data = $user->getUserByEmail($email);
        
        error_log("User data dari DB: " . print_r($user_data, true));
        
        if (!$user_data) {
            $message = 'Email tidak terdaftar di sistem';
            $message_type = 'danger';
            error_log("EMAIL NOT FOUND: " . $email);
        } else {
            error_log("EMAIL FOUND: " . $email . " | User ID: " . $user_data['id'] . " | Name: " . $user_data['name']);
            
            $token = $user->generatePasswordResetToken($user_data['id']);
            error_log("Token generated: " . ($token ? "YES - " . substr($token, 0, 10) . "..." : "NO"));
            
            if ($token) {
                $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
                $domain = $_SERVER['HTTP_HOST'];
                $domain = preg_replace('#/.*#', '', $domain);
                $base_path = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
                if ($base_path === '/') $base_path = '';
                
                $reset_link = $protocol . $domain . $base_path . "/reset_password.php?token=" . urlencode($token);
                $to = $email;
                $subject = "UMKM Recommend - Reset Password Anda";
                
                $email_body = "Halo " . htmlspecialchars($user_data['name']) . ",\n\n";
                $email_body .= "Kami menerima permintaan untuk mereset password akun Anda.\n\n";
                $email_body .= "Klik link ini untuk reset password:\n";
                $email_body .= $reset_link . "\n\n";
                $email_body .= "Link ini berlaku selama 1 jam.\n\n";
                $email_body .= "Jika tidak Anda yang meminta, abaikan email ini.\n\n";
                $email_body .= "Regards,\nUMKM Recommend Team";
                
                error_log("Attempting to send email to: " . $to);
                error_log("Reset link: " . $reset_link);
                
                // Langsung tampilkan link reset tanpa kirim email
                $message = '✓ Link reset password:<br><br>';
                $message .= '<a href="' . htmlspecialchars($reset_link) . '" target="_blank" class="btn btn-primary" style="display: inline-block; padding: 10px 20px; background: #1d7e3f; color: white; text-decoration: none; border-radius: 6px; font-weight: bold;">KLIK DI SINI UNTUK RESET PASSWORD</a><br><br>';
                $message .= 'Atau copy link ini ke browser:<br>';
                $message .= '<code style="background: #f0f0f0; padding: 10px; display: block; margin-top: 10px; word-break: break-all;">' . htmlspecialchars($reset_link) . '</code>';
                $message_type = 'success';
                $show_form = false;
                error_log("Reset link ditampilkan untuk: " . $to);
            } else {
                $message = 'Terjadi kesalahan. Silakan coba lagi.';
                $message_type = 'danger';
                error_log("TOKEN GENERATION FAILED");
            }
        }
    }
    error_log("=== END DEBUG ===");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lupa Password - UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #FF6A00;
            --secondary-color: #E85D04;
        }
        body {
            font-family: 'Inter', 'Poppins', sans-serif;
            background: linear-gradient(135deg, #D84315 0%, #FF6A00 50%, #FFB347 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }
        .forgot-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 40px;
            width: 100%;
            max-width: 450px;
        }
        .forgot-header h1 {
            font-size: 1.6rem;
            font-weight: 700;
            color: #1a1a1a;
            margin-bottom: 8px;
        }
        .forgot-header p {
            color: #6b7280;
            font-size: 0.95rem;
        }
        .form-control {
            border-radius: 6px;
            border: 1px solid #e5e7eb;
            padding: 10px 14px;
            margin-bottom: 18px;
        }
        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(29, 126, 63, 0.1);
        }
        .btn-submit {
            background: var(--primary-color);
            border: none;
            color: white;
            padding: 10px 20px;
            font-weight: 600;
            border-radius: 6px;
            width: 100%;
            cursor: pointer;
        }
        .btn-submit:hover {
            background: var(--secondary-color);
            color: white;
        }
        .alert {
            border-radius: 6px;
            padding: 12px 14px;
            margin-bottom: 18px;
        }
        .alert-success {
            background: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
        }
        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }
        .login-footer {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }
        .login-footer a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 700;
        }
    </style>
</head>
<body>
    <div class="forgot-container">
        <div class="forgot-header">
            <h1><i class="fas fa-lock"></i> Lupa Password?</h1>
            <p>Masukkan email Anda untuk menerima link reset password</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>" role="alert">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if ($show_form): ?>
            <form method="POST" action="">
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="Masukkan email Anda" required autofocus>
                </div>

                <button type="submit" class="btn-submit">
                    <i class="fas fa-paper-plane"></i> Kirim Link Reset
                </button>
            </form>
        <?php endif; ?>

        <div class="login-footer">
            <p>Ingat password Anda? <a href="login.php">Kembali ke Login</a></p>
            <p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
