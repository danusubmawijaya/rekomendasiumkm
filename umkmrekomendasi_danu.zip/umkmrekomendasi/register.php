<?php
ini_set('display_errors', 1);
ini_set('log_errors', 1);
error_reporting(E_ALL);

// Start session hanya jika belum dimulai
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    $email = isset($_POST['email']) ? trim(strtolower($_POST['email'])) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $password_confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    
    if (empty($name) || empty($email) || empty($password) || empty($password_confirm)) {
        $message = 'Semua field harus diisi';
        $message_type = 'danger';
    } elseif (strlen($name) < 3) {
        $message = 'Nama minimal 3 karakter';
        $message_type = 'danger';
    } elseif (strlen($password) < 6) {
        $message = 'Password minimal harus 6 karakter';
        $message_type = 'danger';
    } elseif ($password !== $password_confirm) {
        $message = 'Password tidak cocok';
        $message_type = 'danger';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = 'Format email tidak valid';
        $message_type = 'danger';
    } elseif (!preg_match('/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/', $email)) {
        $message = 'Format email tidak valid - harus memiliki domain yang benar';
        $message_type = 'danger';
    } else {
        require_once 'config/database.php';
        require_once 'config/session.php';
        
        // Check if email exists - simple query
        $query = "SELECT id FROM users WHERE email = '" . $conn->real_escape_string($email) . "'";
        $result = $conn->query($query);
        
        if (!$result) {
            $message = 'Terjadi kesalahan sistem: ' . $conn->error;
            $message_type = 'danger';
        } elseif ($result->num_rows > 0) {
            $message = 'Email sudah terdaftar';
            $message_type = 'danger';
        } else {
            // Insert new user - simpan plain text password
            // (sama seperti yang sudah bisa di-verify di login)
            
            // Gunakan prepared statement
            $stmt = $conn->prepare("INSERT INTO users (name, email, password, is_admin) VALUES (?, ?, ?, 0)");
            if (!$stmt) {
                $message = 'Database error: ' . $conn->error;
                $message_type = 'danger';
            } else {
                $stmt->bind_param("sss", $name, $email, $password);
                
                if ($stmt->execute()) {
                    $stmt->close();
                    
                    // Immediately login user untuk migrasi guest ratings
                    require_once 'config/session.php';
                    $new_user_id = $conn->insert_id;
                    
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = $new_user_id;
                    $_SESSION['user_name'] = $name;
                    $_SESSION['user_email'] = $email;
                    $_SESSION['is_admin'] = 0;
                    
                    // MIGRATE: Pindahkan guest ratings ke akun baru ini
                    $guest_id = isset($_COOKIE['guest_id']) ? $_COOKIE['guest_id'] : null;
                    if ($guest_id) {
                        try {
                            $conn->begin_transaction();
                            
                            $migrate_stmt = $conn->prepare("
                                UPDATE ratings 
                                SET user_id = ?, guest_id = NULL
                                WHERE guest_id = ? 
                                AND user_id IS NULL
                                AND product_id NOT IN (
                                    SELECT product_id FROM ratings WHERE user_id = ?
                                )
                            ");
                            
                            $migrate_stmt->bind_param("isi", $new_user_id, $guest_id, $new_user_id);
                            $migrate_stmt->execute();
                            $migrate_stmt->close();
                            
                            $conn->commit();
                        } catch (Exception $e) {
                            $conn->rollback();
                            error_log("Guest migration error during registration: " . $e->getMessage());
                        }
                    }
                    
                    // Redirect ke index dengan user baru
                    header("Location: index.php");
                    exit();
                } else {
                    $message = 'Registrasi gagal: ' . $conn->error;
                    $message_type = 'danger';
                    $stmt->close();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6A00;
            --primary-light: #FFF1E6;
            --primary-lighter: #FFF1E6;
            --secondary-color: #E85D04;
            --dark-color: #1a1a1a;
            --text-color: #2d3748;
            --border-color: #e5e7eb;
            --light-bg: #f9fafb;
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.07);
            --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
            --shadow-xl: 0 20px 40px rgba(255, 106, 0, 0.15);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', 'Inter', sans-serif;
            background: linear-gradient(135deg, #D84315 0%, #FF6A00 50%, #FFB347 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            position: relative;
            overflow: hidden;
        }

        body::before {
            content: '';
            position: absolute;
            width: 400px;
            height: 400px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -100px;
            left: -100px;
            z-index: 0;
            animation: float 6s ease-in-out infinite;
        }

        body::after {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 50%;
            bottom: -50px;
            right: -50px;
            z-index: 0;
            animation: float 8s ease-in-out infinite reverse;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(30px); }
        }

        .register-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            align-items: center;
            max-width: 1200px;
            width: 100%;
            position: relative;
            z-index: 1;
        }

        .register-illustration {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
            animation: slideInLeft 0.8s ease-out;
        }

        @keyframes slideInLeft {
            from {
                opacity: 0;
                transform: translateX(-50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .register-illustration-icon {
            font-size: 6rem;
            margin-bottom: 32px;
            opacity: 0.95;
            animation: float 4s ease-in-out infinite;
            filter: drop-shadow(0 10px 20px rgba(0, 0, 0, 0.2));
        }

        .register-illustration h2 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 16px;
            letter-spacing: -1px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
        }

        .register-illustration p {
            font-size: 1.1rem;
            opacity: 0.95;
            line-height: 1.8;
            max-width: 350px;
            text-shadow: 0 1px 5px rgba(0, 0, 0, 0.1);
        }

        .register-container {
            background: white;
            border-radius: 20px;
            box-shadow: var(--shadow-xl);
            padding: 50px;
            width: 100%;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            animation: slideInRight 0.8s ease-out;
            max-height: 90vh;
            overflow-y: auto;
        }

        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(50px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .register-header {
            margin-bottom: 32px;
        }

        .register-header h1 {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 10px;
            letter-spacing: -0.5px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .register-header h1 i {
            color: var(--primary-color);
            font-size: 1.6rem;
        }

        .register-header p {
            color: #64748b;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .form-group {
            margin-bottom: 22px;
            position: relative;
        }

        .form-label {
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 10px;
            display: block;
            font-size: 0.95rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .form-control {
            border-radius: 12px;
            border: 2px solid var(--border-color);
            padding: 14px 18px;
            font-size: 0.95rem;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-family: 'Poppins', sans-serif;
            width: 100%;
            background: white;
            color: var(--text-color);
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(29, 126, 63, 0.12);
            outline: none;
            background: rgba(29, 126, 63, 0.02);
        }

        .form-control:hover {
            border-color: var(--primary-light);
        }

        .form-control::placeholder {
            color: #cbd5e1;
        }

        .password-strength {
            margin-top: 10px;
            font-size: 0.85rem;
        }

        .strength-bar {
            height: 6px;
            background: #e2e8f0;
            border-radius: 3px;
            overflow: hidden;
            margin-top: 8px;
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .strength-bar-fill {
            height: 100%;
            width: 0%;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border-radius: 3px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
        }

        .btn-register {
            background: var(--primary-color);
            border: none;
            color: white;
            padding: 14px 24px;
            font-weight: 700;
            border-radius: 12px;
            width: 100%;
            font-size: 1rem;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            margin-top: 8px;
            font-family: 'Poppins', sans-serif;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            box-shadow: 0 4px 15px rgba(255, 106, 0, 0.3);
            position: relative;
            overflow: hidden;
        }

        .btn-register:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(255, 106, 0, 0.4);
            background: var(--secondary-color);
        }

        .btn-register:active {
            transform: translateY(-1px);
        }

        .alert {
            border-radius: 12px;
            border: 2px solid;
            margin-bottom: 20px;
            font-size: 0.9rem;
            padding: 14px 16px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.4s ease-out;
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .alert-danger {
            background: #fef2f2;
            color: #991b1b;
            border-color: #fecaca;
        }

        .alert-success {
            background: #f0fdf4;
            color: #166534;
            border-color: #bbf7d0;
        }

        .alert i {
            font-size: 1.1rem;
            flex-shrink: 0;
        }

        .info-box {
            background: linear-gradient(135deg, rgba(255, 106, 0, 0.1) 0%, rgba(232, 93, 4, 0.08) 100%);
            border-left: 4px solid var(--primary-color);
            padding: 16px 18px;
            border-radius: 12px;
            margin-bottom: 24px;
            font-size: 0.9rem;
            color: #D84315;
            font-weight: 500;
            backdrop-filter: blur(5px);
        }

        .info-box i {
            margin-right: 10px;
            font-size: 1rem;
            color: var(--primary-color);
        }

        .info-box a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 700;
            transition: all 0.3s;
        }

        .info-box a:hover {
            text-decoration: underline;
            color: var(--secondary-color);
        }

        .register-footer {
            text-align: center;
            margin-top: 28px;
            padding-top: 28px;
            border-top: 2px solid var(--border-color);
        }

        .register-footer p {
            color: #64748b;
            font-size: 0.9rem;
            margin: 8px 0;
            font-weight: 500;
        }

        .register-footer a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 700;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .register-footer a:hover {
            color: var(--primary-dark);
            transform: translateX(2px);
        }

        .divider {
            text-align: center;
            margin: 20px 0;
            color: #cbd5e1;
            font-size: 0.85rem;
            font-weight: 500;
        }

        @media (max-width: 992px) {
            .register-wrapper {
                grid-template-columns: 1fr;
                gap: 40px;
            }

            .register-illustration {
                display: none;
            }

            .register-container {
                padding: 40px 30px;
            }

            .register-header h1 {
                font-size: 1.6rem;
            }
        }

        @media (max-width: 640px) {
            body {
                padding: 16px;
            }

            .register-container {
                padding: 30px 20px;
                border-radius: 16px;
                max-height: none;
            }

            .register-header h1 {
                font-size: 1.4rem;
            }

            .register-header p {
                font-size: 0.9rem;
            }

            .form-group {
                margin-bottom: 18px;
            }

            .form-label {
                font-size: 0.85rem;
            }

            .form-control {
                padding: 12px 16px;
                font-size: 0.9rem;
                border-radius: 10px;
            }

            .btn-register {
                padding: 12px 20px;
                font-size: 0.95rem;
            }

            .register-footer {
                margin-top: 20px;
                padding-top: 20px;
            }

            .register-footer p {
                font-size: 0.85rem;
            }

            .divider {
                margin: 16px 0;
            }
        }
    </style>
</head>
<body>
    <div class="register-wrapper">
        <div class="register-illustration">
            <div class="register-illustration-icon">
                <i class="fas fa-user-plus"></i>
            </div>
            <h2>Bergabunglah dengan Kami</h2>
            <p>Daftar sekarang dan temukan makanan UMKM favorit dengan rekomendasi personal</p>
        </div>

        <div class="register-container">
            <div class="register-header">
                <h1><i class="fas fa-user-plus"></i> Daftar Akun</h1>
                <p>Buat akun baru untuk memulai</p>
            </div>

            <div class="info-box">
                <i class="fas fa-info-circle"></i>
                <strong>Pengguna Baru</strong> - Daftar sekarang dan bergabunglah dengan komunitas UMKM Recommend
            </div>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>" role="alert">
                    <i class="fas fa-<?php echo $message_type === 'danger' ? 'exclamation-circle' : 'check-circle'; ?>"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label for="name" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="name" name="name" 
                           placeholder="Masukkan nama lengkap Anda" required>
                </div>

                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" 
                           placeholder="Masukkan email Anda" required>
                </div>

                <div class="form-group">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" 
                           placeholder="Masukkan password (minimal 6 karakter)" required>
                    <div class="password-strength">
                        <div class="strength-bar">
                            <div class="strength-bar-fill" id="strengthBar"></div>
                        </div>
                        <small id="strengthText" style="color: #999;"></small>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password_confirm" class="form-label">Konfirmasi Password</label>
                    <input type="password" class="form-control" id="password_confirm" name="password_confirm" 
                           placeholder="Ulangi password Anda" required>
                </div>

                <button type="submit" class="btn-register">
                    <i class="fas fa-user-plus"></i> Daftar Sekarang
                </button>
            </form>

            <div class="register-footer">
                <p>Sudah punya akun? <a href="login.php"><i class="fas fa-sign-in-alt"></i> Login di sini</a></p>
            </div>
        </div>
    </div>

    <script>
        const passwordInput = document.getElementById('password');
        const strengthBar = document.getElementById('strengthBar');
        const strengthText = document.getElementById('strengthText');

        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            let text = '';
            let color = '';

            if (password.length >= 6) strength++;
            if (password.length >= 10) strength++;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
            if (/[0-9]/.test(password)) strength++;
            if (/[^a-zA-Z0-9]/.test(password)) strength++;

            if (strength === 0) {
                text = '';
                color = '#e8e8e8';
            } else if (strength <= 2) {
                text = 'Lemah';
                color = '#e74c3c';
            } else if (strength <= 3) {
                text = 'Sedang';
                color = '#f39c12';
            } else {
                text = 'Kuat';
                color = '#27ae60';
            }

            strengthBar.style.width = (strength * 20) + '%';
            strengthBar.style.backgroundColor = color;
            strengthText.textContent = text;
            strengthText.style.color = color;
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
