<?php
// Ensure database connection is loaded
if (!isset($GLOBALS['conn'])) {
    require_once dirname(__DIR__) . '/config/database.php';
}

class Product {
    private $conn;
    private $upload_dir;
    
    public function __construct($connection) {
        $this->conn = $connection;
        $this->upload_dir = dirname(__DIR__) . '/uploads/produk/';
        $this->createUploadDir();
    }
    
    private function createUploadDir() {
        if (!is_dir($this->upload_dir)) {
            mkdir($this->upload_dir, 0755, true);
        }
    }
    
    public function getAllProducts() {
        $query = "SELECT DISTINCT p.id, p.nama_produk, p.deskripsi, p.gambar, p.kategori, p.lokasi, p.created_at,
                  (SELECT AVG(rating) FROM ratings WHERE product_id = p.id) as avg_rating,
                  (SELECT COUNT(*) FROM ratings WHERE product_id = p.id) as rating_count
                  FROM products p
                  ORDER BY p.id ASC";
        
        $result = $this->conn->query($query);
        if (!$result) {
            return [];
        }
        
        $products = [];
        while ($row = $result->fetch_assoc()) {
            // Fetch locations from product_locations table
            $locations_query = "SELECT id, lokasi, latitude, longitude FROM product_locations WHERE product_id = " . intval($row['id']) . " ORDER BY created_at ASC";
            $locations_result = $this->conn->query($locations_query);
            $locations = [];
            if ($locations_result) {
                while ($loc_row = $locations_result->fetch_assoc()) {
                    $locations[] = $loc_row;
                }
            }
            $row['locations'] = $locations;
            $products[] = $row;
        }
        
        return $products;
    }
    
    public function getProductLocations($product_id) {
        $query = "SELECT id, lokasi, latitude, longitude FROM product_locations WHERE product_id = $product_id ORDER BY id ASC";
        
        $result = $this->conn->query($query);
        $locations = [];
        
        if (!$result) {
            error_log("Query error: " . $this->conn->error);
            return $locations;
        }
        
        while ($row = $result->fetch_assoc()) {
            $locations[] = $row;
        }
        
        return $locations;
    }
    
    /**
     * Hitung jarak antara dua titik GPS menggunakan Haversine Formula
     * @param float $lat1 Latitude user
     * @param float $lon1 Longitude user
     * @param float $lat2 Latitude UMKM
     * @param float $lon2 Longitude UMKM
     * @return float Jarak dalam kilometer
     */
    public function calculateDistance($lat1, $lon1, $lat2, $lon2) {
        $earth_radius = 6371; // Radius bumi dalam km
        
        $lat1_rad = deg2rad($lat1);
        $lon1_rad = deg2rad($lon1);
        $lat2_rad = deg2rad($lat2);
        $lon2_rad = deg2rad($lon2);
        
        $dlat = $lat2_rad - $lat1_rad;
        $dlon = $lon2_rad - $lon1_rad;
        
        $a = sin($dlat / 2) * sin($dlat / 2) + 
             cos($lat1_rad) * cos($lat2_rad) * sin($dlon / 2) * sin($dlon / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        
        return round($earth_radius * $c, 2); // Distance in km, rounded to 2 decimals
    }
    
    /**
     * Auto-geocode alamat ke koordinat menggunakan Nominatim API
     * @param string $address Alamat untuk di-geocode
     * @return array|null Array dengan 'latitude' dan 'longitude' atau null jika gagal
     */
    public function geocodeAddress($address) {
        // Fungsi ini akan dinonaktifkan karena geocoding service dihapus
        // Disarankan untuk input koordinat secara manual
        return null;
    }
    
    /**
     * Auto-fill koordinat untuk lokasi yang belum memiliki koordinat
     * @param int $product_id ID produk
     * @return array Hasil update
     */
    public function autoFillCoordinates($product_id) {
        $locations = $this->getProductLocations($product_id);
        $updated = 0;
        $failed = 0;
        
        foreach ($locations as $location) {
            // Skip jika sudah memiliki koordinat
            if (!empty($location['latitude']) && !empty($location['longitude'])) {
                continue;
            }
            
            // Try geocode alamat
            $coords = $this->geocodeAddress($location['lokasi']);
            
            if ($coords) {
                $location_id = intval($location['id']);
                $lat = floatval($coords['latitude']);
                $lon = floatval($coords['longitude']);
                $alamat_lengkap = $this->conn->real_escape_string($location['lokasi']);
                
                $update_query = "UPDATE product_locations 
                                 SET latitude = $lat, longitude = $lon, alamat_lengkap = '$alamat_lengkap'
                                 WHERE id = $location_id";
                
                if ($this->conn->query($update_query)) {
                    $updated++;
                } else {
                    $failed++;
                }
            } else {
                $failed++;
            }
            
            // Rate limiting - jangan terlalu cepat query API
            usleep(1000000); // 1 detik delay
        }
        
        return [
            'success' => true,
            'updated' => $updated,
            'failed' => $failed,
            'total' => count($locations)
        ];
    }
    
    /**
     * Cari lokasi terdekat dari sebuah produk
     * @param int $product_id ID produk
     * @param float $user_lat User latitude
     * @param float $user_lon User longitude
     * @return array Lokasi dengan jarak dari user
     */
    public function getNearestLocations($product_id, $user_lat, $user_lon) {
        $locations = $this->getProductLocations($product_id);
        
        if (empty($locations)) {
            return [];
        }
        
        // Filter hanya lokasi yang memiliki koordinat
        $locations_with_coords = array_filter($locations, function($loc) {
            return !empty($loc['latitude']) && !empty($loc['longitude']);
        });
        
        // Hitung jarak untuk setiap lokasi
        $locations_with_distance = [];
        foreach ($locations_with_coords as $location) {
            $distance = $this->calculateDistance(
                $user_lat, 
                $user_lon, 
                $location['latitude'], 
                $location['longitude']
            );
            $location['distance'] = $distance;
            $locations_with_distance[] = $location;
        }
        
        // Sort berdasarkan jarak
        usort($locations_with_distance, function($a, $b) {
            return $a['distance'] - $b['distance'];
        });
        
        return $locations_with_distance;
    }
    
    /**
     * Cari N lokasi terdekat
     * @param int $product_id ID produk
     * @param float $user_lat User latitude
     * @param float $user_lon User longitude
     * @param int $limit Jumlah lokasi yang dicari
     * @return array N lokasi terdekat
     */
    public function getTopNearestLocations($product_id, $user_lat, $user_lon, $limit = 3) {
        $all_nearest = $this->getNearestLocations($product_id, $user_lat, $user_lon);
        return array_slice($all_nearest, 0, $limit);
    }
    
    public function addProductLocation($product_id, $lokasi, $latitude = null, $longitude = null) {
        $lokasi = trim($lokasi);
        
        if (empty($lokasi)) {
            return ['success' => false, 'message' => 'Lokasi tidak boleh kosong'];
        }
        
        $lokasi_escaped = $this->conn->real_escape_string($lokasi);
        $lat = null;
        $lng = null;
        $message = '';
        
        // Jika latitude dan longitude diberikan manual, gunakan itu
        if (!empty($latitude) && !empty($longitude)) {
            $latitude = trim($latitude);
            $longitude = trim($longitude);
            // Validasi bahwa keduanya adalah angka valid
            if (is_numeric($latitude) && is_numeric($longitude)) {
                $lat = floatval($latitude);
                $lng = floatval($longitude);
                
                // Validasi range koordinat (latitude: -90 to 90, longitude: -180 to 180)
                if ($lat >= -90 && $lat <= 90 && $lng >= -180 && $lng <= 180) {
                    $query = "INSERT INTO product_locations (product_id, lokasi, latitude, longitude) VALUES ($product_id, '$lokasi_escaped', $lat, $lng)";
                    $message = 'Lokasi berhasil ditambahkan dengan koordinat manual';
                } else {
                    return ['success' => false, 'message' => 'Koordinat tidak valid (latitude: -90~90, longitude: -180~180)'];
                }
            } else {
                return ['success' => false, 'message' => 'Format koordinat tidak valid. Harus berupa angka.'];
            }
        } else {
            // Geocoding otomatis jika tidak ada koordinat manual
            $coords = $this->geocodeAddress($lokasi);
            if ($coords) {
                $lat = floatval($coords['latitude']);
                $lng = floatval($coords['longitude']);
                $query = "INSERT INTO product_locations (product_id, lokasi, latitude, longitude) VALUES ($product_id, '$lokasi_escaped', $lat, $lng)";
                $message = 'Lokasi berhasil ditambahkan dengan koordinat otomatis';
            } else {
                // Simpan tanpa koordinat jika geocoding gagal
                $query = "INSERT INTO product_locations (product_id, lokasi) VALUES ($product_id, '$lokasi_escaped')";
                $message = 'Lokasi berhasil ditambahkan (koordinat tidak ditemukan, bisa ditambah manual nanti)';
            }
        }
        
        if ($this->conn->query($query)) {
            return [
                'success' => true, 
                'message' => $message,
                'id' => $this->conn->insert_id,
                'latitude' => $lat,
                'longitude' => $lng
            ];
        } else {
            return ['success' => false, 'message' => 'Gagal menyimpan lokasi ke database: ' . $this->conn->error];
        }
    }
    
    public function deleteProductLocation($location_id) {
        $query = "DELETE FROM product_locations WHERE id = $location_id";
        
        if ($this->conn->query($query)) {
            return ['success' => true, 'message' => 'Lokasi berhasil dihapus'];
        } else {
            return ['success' => false, 'message' => 'Gagal menghapus lokasi'];
        }
    }
    
    public function updateProductLocations($product_id, $locations, $latitudes = [], $longitudes = []) {
        // Array untuk menyimpan error
        $errors = [];
        $inserted = 0;
        
        // Convert indexed arrays ke sequential
        $filtered_locations = [];
        $filtered_latitudes = [];
        $filtered_longitudes = [];
        
        // Jika $locations adalah array dengan key numerik, iterasi dengan key
        foreach ($locations as $index => $lokasi) {
            $lokasi_trimmed = trim((string)$lokasi);
            if (!empty($lokasi_trimmed)) {
                $filtered_locations[] = $lokasi_trimmed;
                $filtered_latitudes[] = isset($latitudes[$index]) ? trim((string)$latitudes[$index]) : '';
                $filtered_longitudes[] = isset($longitudes[$index]) ? trim((string)$longitudes[$index]) : '';
            }
        }
        
        // Jika tidak ada lokasi baru yang valid, kembalikan dengan success=false dan jangan hapus data
        if (empty($filtered_locations)) {
            return [
                'success' => false,
                'message' => 'Tidak ada lokasi yang diisi. Data lokasi lama tetap disimpan.',
                'errors' => ['Lokasi tidak boleh kosong'],
                'inserted' => 0,
                'total_attempted' => 0
            ];
        }
        
        // Validasi dan persiapan semua lokasi terlebih dahulu
        $valid_locations = [];
        $failed_geocoding = [];
        
        foreach ($filtered_locations as $idx => $lokasi_trimmed) {
            $lat = $filtered_latitudes[$idx] ?? '';
            $lng = $filtered_longitudes[$idx] ?? '';
            
            // Jika manual latitude dan longitude diberikan, gunakan itu
            if (!empty($lat) || !empty($lng)) {
                // Jika salah satu ada, keduanya harus ada dan valid
                if (!empty($lat) && !empty($lng)) {
                    if (is_numeric($lat) && is_numeric($lng)) {
                        $lat_float = floatval($lat);
                        $lng_float = floatval($lng);
                        
                        // Validasi range koordinat (latitude: -90 to 90, longitude: -180 to 180)
                        if ($lat_float >= -90 && $lat_float <= 90 && $lng_float >= -180 && $lng_float <= 180) {
                            $valid_locations[] = [
                                'lokasi' => $lokasi_trimmed,
                                'latitude' => $lat_float,
                                'longitude' => $lng_float,
                                'source' => 'manual'
                            ];
                        } else {
                            $errors[] = "Koordinat tidak valid untuk '" . substr($lokasi_trimmed, 0, 30) . "' (latitude: -90~90, longitude: -180~180)";
                            continue;
                        }
                    } else {
                        $errors[] = "Format koordinat salah untuk '" . substr($lokasi_trimmed, 0, 30) . "'";
                        continue;
                    }
                } else {
                    $errors[] = "Latitude dan longitude harus diisi bersama untuk '" . substr($lokasi_trimmed, 0, 30) . "'";
                    continue;
                }
            } else {
                // Coba geocode otomatis jika tidak ada koordinat manual
                $coords = $this->geocodeAddress($lokasi_trimmed);
                
                if ($coords && !empty($coords['latitude']) && !empty($coords['longitude'])) {
                    $valid_locations[] = [
                        'lokasi' => $lokasi_trimmed,
                        'latitude' => floatval($coords['latitude']),
                        'longitude' => floatval($coords['longitude']),
                        'source' => 'geocoding'
                    ];
                } else {
                    // Simpan tanpa koordinat
                    $valid_locations[] = [
                        'lokasi' => $lokasi_trimmed,
                        'latitude' => null,
                        'longitude' => null,
                        'source' => 'none'
                    ];
                    $failed_geocoding[] = "Alamat '" . substr($lokasi_trimmed, 0, 30) . "' disimpan tanpa koordinat (geocoding gagal)";
                }
            }
        }
        
        // Jika tidak ada lokasi yang valid sekalipun, return error
        if (empty($valid_locations)) {
            return [
                'success' => false,
                'message' => 'Tidak ada lokasi yang bisa disimpan.',
                'errors' => $errors,
                'inserted' => 0,
                'total_attempted' => count($filtered_locations)
            ];
        }
        
        // HANYA HAPUS LOKASI LAMA JIKA ADA LOKASI BARU YANG VALID
        $delete_query = "DELETE FROM product_locations WHERE product_id = $product_id";
        if (!$this->conn->query($delete_query)) {
            return [
                'success' => false,
                'message' => 'Gagal menghapus lokasi lama: ' . $this->conn->error,
                'errors' => $errors
            ];
        }
        
        // Tambahkan lokasi baru
        foreach ($valid_locations as $loc) {
            $lokasi_escaped = $this->conn->real_escape_string($loc['lokasi']);
            
            if ($loc['latitude'] !== null && $loc['longitude'] !== null) {
                $insert_query = "INSERT INTO product_locations (product_id, lokasi, latitude, longitude) 
                                 VALUES ($product_id, '$lokasi_escaped', {$loc['latitude']}, {$loc['longitude']})";
            } else {
                // Simpan tanpa koordinat
                $insert_query = "INSERT INTO product_locations (product_id, lokasi) 
                                 VALUES ($product_id, '$lokasi_escaped')";
            }
            
            if ($this->conn->query($insert_query)) {
                $inserted++;
            } else {
                $errors[] = "Gagal menyimpan lokasi '" . substr($loc['lokasi'], 0, 30) . "': " . $this->conn->error;
            }
        }
        
        // Merge failed geocoding into errors untuk info
        $errors = array_merge($errors, $failed_geocoding);
        
        $message = "Berhasil menyimpan $inserted lokasi";
        if (!empty($failed_geocoding)) {
            $message .= ". ⚠ " . count($failed_geocoding) . " alamat disimpan tanpa koordinat (coba lagi nanti)";
        }
        if (!empty($errors) && count($errors) > count($failed_geocoding)) {
            $message .= ". ❌ " . (count($errors) - count($failed_geocoding)) . " alamat gagal disimpan";
        }
        
        return [
            'success' => true,
            'message' => $message,
            'inserted' => $inserted,
            'errors' => $errors,
            'total_attempted' => count($filtered_locations)
        ];
    }
    
    public function getProductsByCategory($category) {
        $category = $this->conn->real_escape_string($category);
        $query = "SELECT DISTINCT p.id, p.nama_produk, p.deskripsi, p.gambar, p.kategori, p.lokasi, p.created_at,
                  (SELECT AVG(rating) FROM ratings WHERE product_id = p.id) as avg_rating,
                  (SELECT COUNT(*) FROM ratings WHERE product_id = p.id) as rating_count
                  FROM products p 
                  WHERE p.kategori = '$category'
                  ORDER BY p.id ASC";
        
        $result = $this->conn->query($query);
        $products = [];
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
        }
        
        return $products;
    }
    
    public function getAllCategories() {
        $default_categories = ['Jajanan & Street Food', 'Makanan Berat', 'Makanan Rumahan', 'Minuman'];
        
        $query = "SELECT DISTINCT kategori FROM products ORDER BY kategori ASC";
        $result = $this->conn->query($query);
        $db_categories = [];
        
        while ($row = $result->fetch_assoc()) {
            $db_categories[] = $row['kategori'];
        }
        
        $categories = array_unique(array_merge($db_categories, $default_categories));
        sort($categories);
        
        return $categories;
    }
    
    public function searchProducts($search_query) {
        $search_term = '%' . $this->conn->real_escape_string($search_query) . '%';
        $query = "SELECT DISTINCT p.id, p.nama_produk, p.deskripsi, p.gambar, p.kategori, p.lokasi, p.created_at,
                  (SELECT AVG(rating) FROM ratings WHERE product_id = p.id) as avg_rating,
                  (SELECT COUNT(*) FROM ratings WHERE product_id = p.id) as rating_count
                  FROM products p 
                  WHERE p.nama_produk LIKE '$search_term' OR p.deskripsi LIKE '$search_term' 
                  ORDER BY p.id ASC";
        
        $result = $this->conn->query($query);
        $products = [];
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
        }
        
        return $products;
    }
    
    public function getProductById($product_id) {
        $query = "SELECT p.id, p.nama_produk, p.deskripsi, p.gambar, p.kategori, p.lokasi, p.created_at,
                  (SELECT AVG(rating) FROM ratings WHERE product_id = p.id) as avg_rating,
                  (SELECT COUNT(*) FROM ratings WHERE product_id = p.id) as rating_count
                  FROM products p 
                  WHERE p.id = $product_id";
        
        $result = $this->conn->query($query);
        
        if ($result && $result->num_rows > 0) {
            $product = $result->fetch_assoc();
            // Fetch locations from product_locations table
            $locations_query = "SELECT id, lokasi, latitude, longitude FROM product_locations WHERE product_id = " . intval($product_id) . " ORDER BY created_at ASC";
            $locations_result = $this->conn->query($locations_query);
            $locations = [];
            if ($locations_result) {
                while ($loc_row = $locations_result->fetch_assoc()) {
                    $locations[] = $loc_row;
                }
            }
            $product['locations'] = $locations;
            return $product;
        }
        return null;
    }
    
    public function addProduct($nama_produk, $deskripsi, $gambar = null, $kategori = 'Lainnya', $locations = [], $latitudes = [], $longitudes = []) {
        $nama_produk = $this->conn->real_escape_string($nama_produk);
        $deskripsi = $this->conn->real_escape_string($deskripsi);
        $gambar = $this->conn->real_escape_string($gambar ?? '');
        $kategori = $this->conn->real_escape_string($kategori);
        
        $query = "INSERT INTO products (nama_produk, deskripsi, gambar, kategori) 
                  VALUES ('$nama_produk', '$deskripsi', '$gambar', '$kategori')";
        
        if ($this->conn->query($query)) {
            $product_id = $this->conn->insert_id;
            
            // Convert indexed arrays ke sequential untuk consistency
            $processed_locations = [];
            $processed_latitudes = [];
            $processed_longitudes = [];
            
            foreach ($locations as $idx => $lokasi) {
                $lokasi_trimmed = trim($lokasi);
                if (!empty($lokasi_trimmed)) {
                    $processed_locations[] = $lokasi_trimmed;
                    $processed_latitudes[] = isset($latitudes[$idx]) ? trim($latitudes[$idx]) : '';
                    $processed_longitudes[] = isset($longitudes[$idx]) ? trim($longitudes[$idx]) : '';
                }
            }
            
            // Tambahkan lokasi dengan geocoding (optional)
            $location_errors = [];
            $location_count = 0;
            $failed_geocoding_count = 0;
            
            if (is_array($processed_locations) && !empty($processed_locations)) {
                foreach ($processed_locations as $index => $lokasi_trimmed) {
                    $lat = $processed_latitudes[$index] ?? '';
                    $lng = $processed_longitudes[$index] ?? '';
                    
                    $result = $this->addProductLocation($product_id, $lokasi_trimmed, $lat, $lng);
                    if ($result['success']) {
                        $location_count++;
                        if (!$result['latitude'] || !$result['longitude']) {
                            $failed_geocoding_count++;
                        }
                    } else {
                        $location_errors[] = $result['message'];
                    }
                }
            }
            
            $message = 'Produk berhasil ditambahkan';
            if ($location_count > 0) {
                $message .= " dengan $location_count lokasi";
                if ($failed_geocoding_count > 0) {
                    $message .= " ($failed_geocoding_count tanpa koordinat)";
                }
            }
            if (!empty($location_errors)) {
                $message .= '. Namun beberapa lokasi gagal: ' . implode('; ', array_slice($location_errors, 0, 2));
            }
            
            return [
                'success' => true,
                'message' => $message,
                'id' => $product_id,
                'location_errors' => $location_errors
            ];
        } else {
            return ['success' => false, 'message' => 'Gagal menambahkan produk: ' . $this->conn->error];
        }
    }
    
    public function updateProduct($product_id, $nama_produk, $deskripsi, $gambar = null, $kategori = 'Lainnya', $locations = [], $latitudes = [], $longitudes = []) {
        if ($gambar === null) {
            $current = $this->getProductById($product_id);
            $gambar = $current['gambar'] ?? null;
        }
        
        $nama_produk = $this->conn->real_escape_string($nama_produk);
        $deskripsi = $this->conn->real_escape_string($deskripsi);
        $gambar = $this->conn->real_escape_string($gambar ?? '');
        $kategori = $this->conn->real_escape_string($kategori);
        
        $query = "UPDATE products SET nama_produk = '$nama_produk', deskripsi = '$deskripsi', 
                  gambar = '$gambar', kategori = '$kategori' 
                  WHERE id = $product_id";
        
        if ($this->conn->query($query)) {
            // Update lokasi hanya jika ada location yang dikirim
            $location_result = ['success' => true, 'message' => '', 'errors' => []];
            if (is_array($locations) && !empty($locations)) {
                $location_result = $this->updateProductLocations($product_id, $locations, $latitudes, $longitudes);
            }
            
            $message = 'Produk berhasil diperbarui';
            if (!$location_result['success']) {
                $message = $location_result['message'];
            } elseif (!empty($location_result['errors'])) {
                $message .= '. Peringatan: ' . implode('; ', array_slice($location_result['errors'], 0, 2));
            }
            
            return [
                'success' => true,
                'message' => $message,
                'location_info' => $location_result
            ];
        } else {
            return ['success' => false, 'message' => 'Gagal memperbarui produk: ' . $this->conn->error];
        }
    }
    
    public function deleteProduct($product_id) {
        $product = $this->getProductById($product_id);
        if ($product && $product['gambar']) {
            $this->deleteImage($product['gambar']);
        }
        
        $query = "DELETE FROM ratings WHERE product_id = $product_id";
        $this->conn->query($query);
        
        $query = "DELETE FROM products WHERE id = $product_id";
        
        if ($this->conn->query($query)) {
            return ['success' => true, 'message' => 'Produk berhasil dihapus'];
        } else {
            return ['success' => false, 'message' => 'Gagal menghapus produk'];
        }
    }
    
    public function uploadImage($file) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'Gagal upload file'];
        }

        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($file['type'], $allowed_types)) {
            return ['success' => false, 'message' => 'Tipe file tidak didukung. Gunakan JPG, PNG, GIF, atau WebP'];
        }

        $max_size = 5 * 1024 * 1024;
        if ($file['size'] > $max_size) {
            return ['success' => false, 'message' => 'Ukuran file terlalu besar (max 5MB)'];
        }

        $temp_upload = $file['tmp_name'];

        try {
            // STEP 1: Load image
            $image = null;
            switch ($file['type']) {
                case 'image/jpeg':
                    $image = @imagecreatefromjpeg($temp_upload);
                    break;
                case 'image/png':
                    $image = @imagecreatefrompng($temp_upload);
                    break;
                case 'image/gif':
                    $image = @imagecreatefromgif($temp_upload);
                    break;
                case 'image/webp':
                    $image = @imagecreatefromwebp($temp_upload);
                    break;
            }

            if (!$image) {
                throw new Exception("Gagal membaca file gambar. Pastikan file tidak rusak");
            }

            // STEP 2: Resize jika terlalu besar
            $original_width = imagesx($image);
            $original_height = imagesy($image);
            $max_width = 800;
            $max_height = 800;
            $ratio = min($max_width / $original_width, $max_height / $original_height);
            
            if ($ratio < 1) {
                $new_width = (int)($original_width * $ratio);
                $new_height = (int)($original_height * $ratio);
                
                $resized_image = imagecreatetruecolor($new_width, $new_height);
                
                // Preserve transparency untuk PNG dan GIF
                if ($file['type'] === 'image/png' || $file['type'] === 'image/gif') {
                    $transparent_color = imagecolorallocatealpha($resized_image, 255, 255, 255, 127);
                    imagefill($resized_image, 0, 0, $transparent_color);
                    imagesavealpha($resized_image, true);
                }
                
                imagecopyresampled($resized_image, $image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);
                imagedestroy($image);
                $image = $resized_image;
            }

            // STEP 3: Generate filename
            $filename = time() . '_' . uniqid() . '.jpg'; // Always save as JPG for better compression
            $filepath = $this->upload_dir . $filename;
            $web_path = 'uploads/produk/' . $filename;

            // STEP 4: Compress sampai <= 100KB dengan LOOP YANG PASTI SELESAI
            $target_size = 100 * 1024; // 100KB
            $quality = 90; // Start tinggi
            $compressed = false;
            $attempts = 0;
            $max_attempts = 15; // Max attempts
            
            while ($attempts < $max_attempts && !$compressed) {
                $attempts++;
                
                // Clear any buffered output
                while (ob_get_level() > 0) {
                    ob_end_clean();
                }
                
                // Save as JPEG dengan quality ini
                if (!imagejpeg($image, $filepath, $quality)) {
                    throw new Exception("Failed to save image at attempt $attempts");
                }
                
                if (!file_exists($filepath)) {
                    throw new Exception("File was not saved at $filepath");
                }
                
                $file_size = filesize($filepath);
                
                // Check ukuran
                if ($file_size <= $target_size) {
                    // Berhasil! Ukuran sudah OK
                    $compressed = true;
                    error_log("✓ Image compressed: " . basename($file['name']) . " → " . number_format($file_size, 0) . " bytes (Quality: $quality, Attempts: $attempts)");
                } else if ($quality <= 20) {
                    // Quality sudah minimum, gunakan file ini
                    $compressed = true;
                    error_log("⚠ Image saved at minimum quality: " . basename($file['name']) . " → " . number_format($file_size, 0) . " bytes");
                } else {
                    // Reduce quality dan try again
                    $quality -= 6;
                    unlink($filepath); // Hapus file lama sebelum retry
                }
            }

            imagedestroy($image);

            if ($compressed && file_exists($filepath)) {
                $final_size = filesize($filepath);
                return ['success' => true, 'filepath' => $web_path, 'size' => $final_size];
            } else {
                if (file_exists($filepath)) {
                    unlink($filepath);
                }
                throw new Exception("Could not compress image to target size after $attempts attempts");
            }

        } catch (Exception $e) {
            // Cleanup
            if (isset($image) && is_resource($image)) {
                imagedestroy($image);
            }
            if (isset($filepath) && file_exists($filepath)) {
                unlink($filepath);
            }
            error_log("❌ Image upload error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Gagal memproses gambar: ' . $e->getMessage()];
        }
    }

    public function deleteImage($filepath) {
        $fs_path = '../' . $filepath;
        if ($filepath && file_exists($fs_path)) {
            return unlink($fs_path);
        }
        return true;
    }
}
?>
