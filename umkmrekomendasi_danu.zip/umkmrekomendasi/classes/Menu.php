<?php
// Ensure database connection is loaded
if (!isset($GLOBALS['conn'])) {
    require_once dirname(__DIR__) . '/config/database.php';
}

class Menu {
    private $conn;
    private $table = 'menu';
    private $categories_table = 'menu_categories';
    private $upload_dir;

    public function __construct($conn) {
        $this->conn = $conn;
        $this->upload_dir = dirname(__DIR__) . '/uploads/menu/';
        $this->createUploadDir();
    }

    private function createUploadDir() {
        if (!is_dir($this->upload_dir)) {
            mkdir($this->upload_dir, 0755, true);
        }
    }

    // Get all menu items with category info
    public function getAllMenu() {
        $query = "SELECT m.*, mc.nama_kategori 
                 FROM {$this->table} m
                 LEFT JOIN {$this->categories_table} mc ON m.kategori_id = mc.id
                 ORDER BY mc.nama_kategori, m.nama_menu";
        
        $result = $this->conn->query($query);
        if (!$result) return [];
        
        $items = [];
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
        return $items;
    }

    // Get menu by ID
    public function getMenuById($id) {
        $id = $this->conn->real_escape_string($id);
        $query = "SELECT m.*, mc.nama_kategori 
                 FROM {$this->table} m
                 LEFT JOIN {$this->categories_table} mc ON m.kategori_id = mc.id
                 WHERE m.id = '{$id}'";
        
        $result = $this->conn->query($query);
        if (!$result) return null;
        return $result->fetch_assoc();
    }

    // Get all categories
    public function getCategories() {
        $query = "SELECT * FROM {$this->categories_table} ORDER BY nama_kategori";
        $result = $this->conn->query($query);
        if (!$result) return [];
        
        $categories = [];
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }
        return $categories;
    }

    // Add new menu
    public function addMenu($nama_menu, $deskripsi, $harga, $kategori_id, $gambar = null) {
        $nama_menu = $this->conn->real_escape_string($nama_menu);
        $deskripsi = $this->conn->real_escape_string($deskripsi);
        $harga = $this->conn->real_escape_string($harga);
        $kategori_id = $this->conn->real_escape_string($kategori_id);
        $gambar = $gambar ? $this->conn->real_escape_string($gambar) : 'NULL';
        
        $query = "INSERT INTO {$this->table} (nama_menu, deskripsi, harga, kategori_id, gambar) 
                 VALUES ('{$nama_menu}', '{$deskripsi}', '{$harga}', '{$kategori_id}', {$gambar})";
        
        if ($this->conn->query($query)) {
            return ['success' => true, 'message' => 'Menu berhasil ditambahkan', 'id' => $this->conn->insert_id];
        } else {
            return ['success' => false, 'message' => 'Error: ' . $this->conn->error];
        }
    }

    // Update menu
    public function updateMenu($id, $nama_menu, $deskripsi, $harga, $kategori_id, $gambar = null) {
        $currentMenu = $this->getMenuById($id);
        
        if (!$currentMenu) {
            return ['success' => false, 'message' => 'Menu tidak ditemukan'];
        }

        if ($gambar === null) {
            $gambar = $currentMenu['gambar'];
        }

        $id = $this->conn->real_escape_string($id);
        $nama_menu = $this->conn->real_escape_string($nama_menu);
        $deskripsi = $this->conn->real_escape_string($deskripsi);
        $harga = $this->conn->real_escape_string($harga);
        $kategori_id = $this->conn->real_escape_string($kategori_id);
        $gambar = $this->conn->real_escape_string($gambar);

        $query = "UPDATE {$this->table} 
                 SET nama_menu = '{$nama_menu}', deskripsi = '{$deskripsi}', harga = '{$harga}', kategori_id = '{$kategori_id}', gambar = '{$gambar}'
                 WHERE id = '{$id}'";
        
        if ($this->conn->query($query)) {
            return ['success' => true, 'message' => 'Menu berhasil diperbarui'];
        } else {
            return ['success' => false, 'message' => 'Error: ' . $this->conn->error];
        }
    }

    // Delete menu
    public function deleteMenu($id) {
        $menu = $this->getMenuById($id);
        
        if (!$menu) {
            return ['success' => false, 'message' => 'Menu tidak ditemukan'];
        }

        // Delete image if exists
        if ($menu['gambar'] && file_exists($menu['gambar'])) {
            unlink($menu['gambar']);
        }

        $id = $this->conn->real_escape_string($id);
        $query = "DELETE FROM {$this->table} WHERE id = '{$id}'";
        
        if ($this->conn->query($query)) {
            return ['success' => true, 'message' => 'Menu berhasil dihapus'];
        } else {
            return ['success' => false, 'message' => 'Error: ' . $this->conn->error];
        }
    }

    // Handle file upload dengan compression otomatis ke 100KB
    public function uploadImage($file) {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'message' => 'Gagal upload file'];
        }

        $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
        if (!in_array($file['type'], $allowed_types)) {
            return ['success' => false, 'message' => 'Tipe file tidak didukung. Gunakan JPG, PNG, GIF, atau WebP'];
        }

        $max_size = 5 * 1024 * 1024; // 5MB
        if ($file['size'] > $max_size) {
            return ['success' => false, 'message' => 'Ukuran file terlalu besar (max 5MB)'];
        }

        $temp_upload = $file['tmp_name'];

        try {
            // STEP 1: Load image
            $image = null;
            switch ($file['type']) {
                case 'image/jpeg':
                    $image = @imagecreatefromjpeg($temp_upload);
                    break;
                case 'image/png':
                    $image = @imagecreatefrompng($temp_upload);
                    break;
                case 'image/gif':
                    $image = @imagecreatefromgif($temp_upload);
                    break;
                case 'image/webp':
                    $image = @imagecreatefromwebp($temp_upload);
                    break;
            }

            if (!$image) {
                throw new Exception("Gagal membaca file gambar. Pastikan file tidak rusak");
            }

            // STEP 2: Resize jika terlalu besar
            $original_width = imagesx($image);
            $original_height = imagesy($image);
            $max_width = 800;
            $max_height = 800;
            $ratio = min($max_width / $original_width, $max_height / $original_height);
            
            if ($ratio < 1) {
                $new_width = (int)($original_width * $ratio);
                $new_height = (int)($original_height * $ratio);
                
                $resized_image = imagecreatetruecolor($new_width, $new_height);
                
                // Preserve transparency untuk PNG dan GIF
                if ($file['type'] === 'image/png' || $file['type'] === 'image/gif') {
                    $transparent_color = imagecolorallocatealpha($resized_image, 255, 255, 255, 127);
                    imagefill($resized_image, 0, 0, $transparent_color);
                    imagesavealpha($resized_image, true);
                }
                
                imagecopyresampled($resized_image, $image, 0, 0, 0, 0, $new_width, $new_height, $original_width, $original_height);
                imagedestroy($image);
                $image = $resized_image;
            }

            // STEP 3: Generate filename (Always save as JPG)
            $filename = time() . '_' . uniqid() . '.jpg';
            $filepath = $this->upload_dir . $filename;
            $web_path = 'uploads/menu/' . $filename;

            // STEP 4: Compress sampai <= 100KB
            $target_size = 100 * 1024; // 100KB
            $quality = 90; // Start tinggi
            $compressed = false;
            $attempts = 0;
            $max_attempts = 15;
            
            while ($attempts < $max_attempts && !$compressed) {
                $attempts++;
                
                // Clear any buffered output
                while (ob_get_level() > 0) {
                    ob_end_clean();
                }
                
                // Save as JPEG
                if (!imagejpeg($image, $filepath, $quality)) {
                    throw new Exception("Failed to save image at attempt $attempts");
                }
                
                if (!file_exists($filepath)) {
                    throw new Exception("File was not saved at $filepath");
                }
                
                $file_size = filesize($filepath);
                
                // Check ukuran
                if ($file_size <= $target_size) {
                    $compressed = true;
                    error_log("✓ Menu image compressed: " . basename($file['name']) . " → " . number_format($file_size, 0) . " bytes (Quality: $quality, Attempts: $attempts)");
                } else if ($quality <= 20) {
                    $compressed = true;
                    error_log("⚠ Menu image saved at minimum quality: " . basename($file['name']) . " → " . number_format($file_size, 0) . " bytes");
                } else {
                    $quality -= 6;
                    unlink($filepath);
                }
            }

            imagedestroy($image);

            if ($compressed && file_exists($filepath)) {
                $final_size = filesize($filepath);
                return ['success' => true, 'filepath' => $web_path, 'size' => $final_size];
            } else {
                if (file_exists($filepath)) {
                    unlink($filepath);
                }
                throw new Exception("Could not compress image to target size after $attempts attempts");
            }

        } catch (Exception $e) {
            // Cleanup
            if (isset($image) && is_resource($image)) {
                imagedestroy($image);
            }
            if (isset($filepath) && file_exists($filepath)) {
                unlink($filepath);
            }
            error_log("❌ Menu image upload error: " . $e->getMessage());
            return ['success' => false, 'message' => 'Gagal memproses gambar: ' . $e->getMessage()];
        }
    }

    // Delete image
    public function deleteImage($filepath) {
        // filepath dari DB berupa web path, konversi ke filesystem path
        $fs_path = '../' . $filepath;
        if ($filepath && file_exists($fs_path)) {
            return unlink($fs_path);
        }
        return true;
    }

    // Add category
    public function addCategory($nama_kategori, $deskripsi = '') {
        $nama_kategori = $this->conn->real_escape_string($nama_kategori);
        $deskripsi = $this->conn->real_escape_string($deskripsi);
        
        $query = "INSERT INTO {$this->categories_table} (nama_kategori, deskripsi) 
                 VALUES ('{$nama_kategori}', '{$deskripsi}')";
        
        if ($this->conn->query($query)) {
            return ['success' => true, 'message' => 'Kategori berhasil ditambahkan', 'id' => $this->conn->insert_id];
        } else {
            return ['success' => false, 'message' => 'Error: ' . $this->conn->error];
        }
    }

    // Update category
    public function updateCategory($id, $nama_kategori, $deskripsi = '') {
        $id = $this->conn->real_escape_string($id);
        $nama_kategori = $this->conn->real_escape_string($nama_kategori);
        $deskripsi = $this->conn->real_escape_string($deskripsi);
        
        $query = "UPDATE {$this->categories_table} 
                 SET nama_kategori = '{$nama_kategori}', deskripsi = '{$deskripsi}'
                 WHERE id = '{$id}'";
        
        if ($this->conn->query($query)) {
            return ['success' => true, 'message' => 'Kategori berhasil diperbarui'];
        } else {
            return ['success' => false, 'message' => 'Error: ' . $this->conn->error];
        }
    }

    // Delete category
    public function deleteCategory($id) {
        // Check if category has menu items
        $id_escaped = $this->conn->real_escape_string($id);
        $query = "SELECT COUNT(*) as count FROM {$this->table} WHERE kategori_id = '{$id_escaped}'";
        $result = $this->conn->query($query);
        $result_row = $result->fetch_assoc();

        if ($result_row['count'] > 0) {
            return ['success' => false, 'message' => 'Tidak bisa menghapus kategori yang memiliki menu'];
        }

        $query = "DELETE FROM {$this->categories_table} WHERE id = '{$id_escaped}'";
        
        if ($this->conn->query($query)) {
            return ['success' => true, 'message' => 'Kategori berhasil dihapus'];
        } else {
            return ['success' => false, 'message' => 'Error: ' . $this->conn->error];
        }
    }

    // Get menu by category
    public function getMenuByCategory($kategori_id) {
        $kategori_id = $this->conn->real_escape_string($kategori_id);
        $query = "SELECT m.*, mc.nama_kategori 
                 FROM {$this->table} m
                 LEFT JOIN {$this->categories_table} mc ON m.kategori_id = mc.id
                 WHERE m.kategori_id = '{$kategori_id}'
                 ORDER BY m.nama_menu";
        
        $result = $this->conn->query($query);
        if (!$result) return [];
        
        $menus = [];
        while ($row = $result->fetch_assoc()) {
            $menus[] = $row;
        }
        return $menus;
    }
}
?>
