<?php
// Ensure database connection is loaded
if (!isset($GLOBALS['conn'])) {
    require_once dirname(__DIR__) . '/config/database.php';
}

class CollaborativeFiltering {
    private $conn;
    private $similarity_threshold = 0.1; // Threshold minimum similarity
    private $debug_log = [];
    private $loocv_iterations = []; // Store detailed LOOCV iterations
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
    
    /**
     * Set similarity threshold
     */
    public function setSimilarityThreshold($threshold) {
        $this->similarity_threshold = $threshold;
    }
    
    /**
     * Hitung Cosine Similarity antara dua identity (user atau guest)
     * Rumus: Sim(u,v) = Σ(r_u,i × r_v,i) / (√Σr_u,i² × √Σr_v,i²)
     * 
     * @param string $identity1 Identity key pertama (user:{id} atau guest:{id})
     * @param string $identity2 Identity key kedua
     * @param array $all_ratings Rating dari semua identity (cache)
     * @return float Nilai similarity (0-1)
     */
    public function cosineSimilarity($identity1, $identity2, $all_ratings) {
        $ratings1 = isset($all_ratings[$identity1]) ? $all_ratings[$identity1] : [];
        $ratings2 = isset($all_ratings[$identity2]) ? $all_ratings[$identity2] : [];
        
        $common_products = array_intersect_key($ratings1, $ratings2);
        
        if (empty($common_products)) {
            return 0;
        }
        
        $dot_product = 0;
        $magnitude1 = 0;
        $magnitude2 = 0;
        
        foreach ($common_products as $product_id => $rating1) {
            $rating2 = $ratings2[$product_id];
            $dot_product += $rating1 * $rating2;
            $magnitude1 += $rating1 * $rating1;
            $magnitude2 += $rating2 * $rating2;
        }
        
        $magnitude1 = sqrt($magnitude1);
        $magnitude2 = sqrt($magnitude2);
        
        if ($magnitude1 == 0 || $magnitude2 == 0) {
            return 0;
        }
        
        return $dot_product / ($magnitude1 * $magnitude2);
    }
    
    /**
     * Load semua rating dari database ke memory (optimasi query)
     * Menggunakan identity abstraction untuk support user dan guest
     * @return array Rating dalam format [identity_key => [product_id => rating]]
     *         dimana identity_key = "user:{user_id}" atau "guest:{guest_id}"
     */
    private function loadAllRatings() {
        // Query semua rating (user dan guest)
        // User ratings: user_id > 0
        // Guest ratings: user_id IS NULL AND guest_id IS NOT NULL
        $query = "SELECT user_id, guest_id, product_id, rating FROM ratings 
                  WHERE (user_id > 0) OR (user_id IS NULL AND guest_id IS NOT NULL AND guest_id != '')
                  ORDER BY user_id, guest_id, product_id";
        $result = $this->conn->query($query);
        
        if (!$result) return [];
        
        $all_ratings = [];
        while ($row = $result->fetch_assoc()) {
            // Tentukan identity key
            if ($row['user_id'] > 0) {
                $identity_key = "user:" . intval($row['user_id']);
            } else if ($row['user_id'] === null && !empty($row['guest_id'])) {
                // Guest: user_id IS NULL
                $identity_key = "guest:" . $row['guest_id'];
            } else {
                // Skip invalid ratings
                continue;
            }
            
            $product_id = intval($row['product_id']);
            $rating = intval($row['rating']);
            
            if (!isset($all_ratings[$identity_key])) {
                $all_ratings[$identity_key] = [];
            }
            $all_ratings[$identity_key][$product_id] = $rating;
        }
        
        return $all_ratings;
    }
    
    /**
     * Dapatkan user yang mirip dengan user tertentu
     * Support identity abstraction (user:{id} atau guest:{id})
     * @param string $identity Identity key dari current user (user:{id} atau guest:{id})
     * @param int $limit Jumlah similar user
     * @param array $all_ratings Cache rating dari semua user
     * @return array Similar users dengan similarity score
     */
    public function getSimilarUsers($identity, $limit = 5, $all_ratings = null) {
        if ($all_ratings === null) {
            $all_ratings = $this->loadAllRatings();
        }
        
        if (!isset($all_ratings[$identity])) {
            return [];
        }
        
        $similarities = [];
        
        // Bandingkan dengan semua identity lain dalam cache
        foreach ($all_ratings as $other_identity => $products) {
            if ($other_identity === $identity) {
                continue;
            }
            
            $similarity = $this->cosineSimilarity($identity, $other_identity, $all_ratings);
            
            if ($similarity > $this->similarity_threshold) {
                $similarities[$other_identity] = $similarity;
            }
        }
        
        arsort($similarities);
        return array_slice($similarities, 0, $limit, true);
    }
    
    /**
     * Prediksi rating untuk produk tertentu menggunakan User-Based CF
     * Rumus: P(u,i) = Σ(Sim(u,v) × r(v,i)) / Σ|Sim(u,v)|
     * 
     * @param string $identity Identity key dari current user (user:{id} atau guest:{id})
     * @param int $product_id Produk yang akan diprediksi
     * @param array $similar_identities Identity yang mirip dengan similarity score
     * @param array $all_ratings Cache rating dari semua identity
     * @return float Predicted rating (0 jika tidak bisa diprediksi)
     */
    private function predictRating($identity, $product_id, $similar_identities, $all_ratings) {
        $numerator = 0;      // Σ(Sim(u,v) × r(v,i))
        $denominator = 0;    // Σ|Sim(u,v)|
        
        foreach ($similar_identities as $similar_identity => $similarity) {
            // Ambil rating produk ini dari identity mirip
            if (isset($all_ratings[$similar_identity][$product_id])) {
                $rating = $all_ratings[$similar_identity][$product_id];
                $numerator += $similarity * $rating;
                $denominator += abs($similarity);
            }
        }
        
        // Hindari pembagian dengan nol
        if ($denominator == 0) {
            return 0;
        }
        
        return $numerator / $denominator;
    }
    
    /**
     * Dapatkan rekomendasi produk untuk user/guest
     * Menggunakan User-Based Collaborative Filtering dengan Cosine Similarity
     * Support identity abstraction
     * @param string $identity Identity key (user:{id} atau guest:{id})
     * @param int $limit Jumlah rekomendasi
     */
    public function getRecommendations($identity, $limit = 5) {
        // Load semua rating ke memory
        $all_ratings = $this->loadAllRatings();
        
        // Ambil produk yang sudah di-rating oleh identity ini
        $rated_products = isset($all_ratings[$identity]) ? array_keys($all_ratings[$identity]) : [];
        
        // Dapatkan identities yang mirip
        $similar_users = $this->getSimilarUsers($identity, 10, $all_ratings);
        
        if (empty($similar_users)) {
            return [];
        }
        
        // Dapatkan semua produk yang belum di-rating
        $query = "SELECT id FROM products ORDER BY id";
        $result = $this->conn->query($query);
        
        if (!$result) return [];
        
        $candidate_products = [];
        while ($row = $result->fetch_assoc()) {
            if (!in_array($row['id'], $rated_products)) {
                $candidate_products[] = $row['id'];
            }
        }
        
        // Hitung predicted rating untuk setiap produk
        $product_predictions = [];
        
        foreach ($candidate_products as $product_id) {
            $predicted_rating = $this->predictRating($identity, $product_id, $similar_users, $all_ratings);
            
            if ($predicted_rating > 0) {
                $product_predictions[$product_id] = $predicted_rating;
            }
        }
        
        // Sort by predicted rating descending
        arsort($product_predictions);
        
        // Ambil top N produk
        $recommended_product_ids = array_slice(array_keys($product_predictions), 0, $limit);
        
        // Ambil detail produk dengan rating info
        $recommendations = [];
        
        if (!empty($recommended_product_ids)) {
            // Sanitasi product IDs untuk keamanan
            $safe_ids = array_map(function($id) { return intval($id); }, $recommended_product_ids);
            $ids_str = implode(',', $safe_ids);
            
            if (!empty($ids_str)) {
                $query = "SELECT p.*, 
                          AVG(r.rating) as avg_rating, 
                          COUNT(r.id) as rating_count 
                          FROM products p 
                          LEFT JOIN ratings r ON p.id = r.product_id 
                          WHERE p.id IN ({$ids_str})
                          GROUP BY p.id";
                
                $result = $this->conn->query($query);
                
                if ($result) {
                    while ($row = $result->fetch_assoc()) {
                        $row['score'] = isset($product_predictions[$row['id']]) ? floatval($product_predictions[$row['id']]) : 0;
                        $row['avg_rating'] = isset($row['avg_rating']) && $row['avg_rating'] ? floatval($row['avg_rating']) : 0;
                        $row['rating_count'] = isset($row['rating_count']) ? intval($row['rating_count']) : 0;
                        $recommendations[] = $row;
                    }
                }
            }
        }
        
        return $recommendations;
    }
    
    /**
     * Evaluasi Mean Absolute Error (MAE) - Menghindari Data Leakage
     * Untuk setiap rating yang diuji, rating tersebut dihapus sementara dari cache
     * sebelum menghitung similarity dan predicted rating.
     * 
     * Prosedur:
     * 1. Ambil satu data rating (user_id, product_id, actual_rating)
     * 2. Hapus sementara rating tersebut dari cache
     * 3. Hitung similar users tanpa rating yang sedang diuji
     * 4. Hitung predicted rating: P(u,i) = Σ(Sim(u,v) × r(v,i)) / Σ|Sim(u,v)|
     * 5. Hitung error: |Predicted Rating - Actual Rating|
     * 6. Kembalikan rating ke cache
     * 7. Lanjutkan ke rating berikutnya
     * 
     * Rumus MAE: MAE = (1/n) × Σ|p_i - r_i|
     * p_i = predicted rating, r_i = actual rating, n = total rating
     */
    public function calculateMAE() {
        // Reset iterations array
        $this->loocv_iterations = [];
        
        // Load semua rating dari database ke memory
        $all_ratings = $this->loadAllRatings();
        $all_errors = [];
        $iteration_count = 0;
        
        // Iterasi setiap rating untuk evaluasi
        foreach ($all_ratings as $identity_key => $products) {
            foreach ($products as $product_id => $actual_rating) {
                $iteration_count++;
                
                // STEP 1: Simpan rating yang sedang diuji
                $test_rating = $actual_rating;
                
                // STEP 2: Hapus sementara rating dari cache untuk menghindari data leakage
                unset($all_ratings[$identity_key][$product_id]);
                
                // STEP 3: Hitung similar users menggunakan dataset yang sudah dikurangi
                $similar_users = $this->getSimilarUsers($identity_key, 10, $all_ratings);
                
                // Initialize iteration data
                $iteration_data = [
                    'iteration' => $iteration_count,
                    'identity_key' => $identity_key,
                    'product_id' => $product_id,
                    'actual_rating' => round($test_rating, 3),
                    'predicted_rating' => 0,
                    'absolute_error' => 0,
                    'status' => 'Tidak Diprediksi',
                    'product_name' => '',
                    'user_id' => 0,
                    'guest_id' => ''
                ];
                
                // Parse identity_key to extract user_id and guest_id
                if (strpos($identity_key, 'user:') === 0) {
                    $iteration_data['user_id'] = intval(substr($identity_key, 5));
                } else if (strpos($identity_key, 'guest:') === 0) {
                    $iteration_data['guest_id'] = substr($identity_key, 6);
                }
                
                // Jika tidak ada similar user, skip rating ini dengan status "Tidak Diprediksi"
                if (empty($similar_users)) {
                    // Kembalikan rating ke cache sebelum lanjut
                    $all_ratings[$identity_key][$product_id] = $test_rating;
                    
                    // Parse identity_key to extract user_id and guest_id
                    if (strpos($identity_key, 'user:') === 0) {
                        $iteration_data['user_id'] = intval(substr($identity_key, 5));
                    } else if (strpos($identity_key, 'guest:') === 0) {
                        $iteration_data['guest_id'] = substr($identity_key, 6);
                    }
                    
                    // Store iteration data
                    $this->loocv_iterations[] = $iteration_data;
                    continue;
                }
                
                // STEP 4: Hitung predicted rating menggunakan dataset tanpa rating yang diuji
                $predicted_rating = $this->predictRating($identity_key, $product_id, $similar_users, $all_ratings);
                
                // STEP 5: Hitung absolute error jika ada prediksi
                if ($predicted_rating > 0) {
                    $error = abs($predicted_rating - $test_rating);
                    $all_errors[] = $error;
                    
                    $iteration_data['predicted_rating'] = round($predicted_rating, 3);
                    $iteration_data['absolute_error'] = round($error, 3);
                    $iteration_data['status'] = 'Valid';
                } else {
                    $iteration_data['status'] = 'Tidak Diprediksi';
                }
                
                // STEP 6: Kembalikan rating ke cache untuk evaluasi rating berikutnya
                $all_ratings[$identity_key][$product_id] = $test_rating;
                
                // Store iteration data
                $this->loocv_iterations[] = $iteration_data;
            }
        }
        
        // STEP 7: Hitung MAE akhir
        if (empty($all_errors)) {
            return 0;
        }
        
        return array_sum($all_errors) / count($all_errors);
    }
    
    /**
     * Get LOOCV iterations details
     * Returns array of all LOOCV iterations with data
     * Memastikan return value adalah array yang proper (tidak berubah menjadi object saat serialisasi)
     */
    public function getLOOCVIterations() {
        // Validasi bahwa loocv_iterations adalah array
        if (!is_array($this->loocv_iterations)) {
            return [];
        }
        
        // Load product names for all iterations
        if (!empty($this->loocv_iterations)) {
            $product_ids = array_unique(array_column($this->loocv_iterations, 'product_id'));
            
            if (!empty($product_ids)) {
                $safe_ids = array_map(function($id) { return intval($id); }, $product_ids);
                $ids_str = implode(',', $safe_ids);
                
                if (!empty($ids_str)) {
                    $query = "SELECT id, nama_produk as name FROM products WHERE id IN ({$ids_str})";
                    $result = $this->conn->query($query);
                    
                    $product_names = [];
                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            $product_names[$row['id']] = $row['name'];
                        }
                    }
                    
                    // Add product names to iterations and ensure user_id/guest_id are set
                    foreach ($this->loocv_iterations as &$iteration) {
                        if (isset($product_names[$iteration['product_id']])) {
                            $iteration['product_name'] = $product_names[$iteration['product_id']];
                        }
                        
                        // Ensure user_id and guest_id are properly set from identity_key if missing
                        if (empty($iteration['user_id']) && empty($iteration['guest_id']) && isset($iteration['identity_key'])) {
                            if (strpos($iteration['identity_key'], 'user:') === 0) {
                                $iteration['user_id'] = intval(substr($iteration['identity_key'], 5));
                            } else if (strpos($iteration['identity_key'], 'guest:') === 0) {
                                $iteration['guest_id'] = substr($iteration['identity_key'], 6);
                            }
                        }
                    }
                }
            }
        }
        
        // Ensure we return a proper array, not object
        // Convert back to indexed array to prevent serialization issues
        $result = array_values($this->loocv_iterations);
        
        return $result;
    }
    
    /**
     * Get LOOCV summary statistics
     * Menghitung ringkasan dari loocv_iterations dengan validasi tipe data
     */
    public function getLOOCVSummary() {
        // Validasi bahwa loocv_iterations adalah array
        if (!is_array($this->loocv_iterations)) {
            return [
                'total_ratings' => 0,
                'total_iterations' => 0,
                'successful_predictions' => 0,
                'failed_predictions' => 0,
                'total_absolute_error' => 0,
                'mae' => 0
            ];
        }
        
        $iterations = $this->loocv_iterations;
        
        $total_ratings = count($iterations);
        $successful_predictions = 0;
        $failed_predictions = 0;
        $total_absolute_error = 0;
        
        foreach ($iterations as $iteration) {
            // Validasi struktur data iterasi
            if (!is_array($iteration)) {
                continue;
            }
            
            if (isset($iteration['status']) && $iteration['status'] === 'Valid') {
                $successful_predictions++;
                $total_absolute_error += isset($iteration['absolute_error']) ? floatval($iteration['absolute_error']) : 0;
            } else {
                $failed_predictions++;
            }
        }
        
        // MAE harus dibagi dengan jumlah successful_predictions, bukan total_ratings
        // Sesuai dengan rumus MAE = sum(|predicted - actual|) / count(predictions)
        $mae = $successful_predictions > 0 ? $total_absolute_error / $successful_predictions : 0;
        
        return [
            'total_ratings' => $total_ratings,
            'total_iterations' => $total_ratings,
            'successful_predictions' => $successful_predictions,
            'failed_predictions' => $failed_predictions,
            'total_absolute_error' => round($total_absolute_error, 3),
            'mae' => round($mae, 4)
        ];
    }
    
    /**
     * Debug function untuk menampilkan detail perhitungan
     * Menampilkan similar users, similarity scores, numerator, denominator, predicted rating
     * Digunakan untuk validasi perhitungan saat sidang skripsi
     */
    public function getDebugInfo($user_id, $product_id) {
        $all_ratings = $this->loadAllRatings();
        $rated_products = isset($all_ratings[$user_id]) ? array_keys($all_ratings[$user_id]) : [];
        
        // Hanya debug untuk produk yang belum di-rating
        if (in_array($product_id, $rated_products)) {
            return ['error' => 'Product sudah di-rating oleh user ini'];
        }
        
        // Ambil similar users
        $similar_users = $this->getSimilarUsers($user_id, 10, $all_ratings);
        
        if (empty($similar_users)) {
            return ['error' => 'Tidak ada similar user ditemukan'];
        }
        
        // Debug info
        $debug = [
            'user_id' => $user_id,
            'product_id' => $product_id,
            'similar_users' => $similar_users,
            'threshold' => $this->similarity_threshold,
            'details' => []
        ];
        
        // Detail untuk setiap similar user
        $numerator = 0;
        $denominator = 0;
        
        foreach ($similar_users as $similar_user_id => $similarity) {
            $similarity_score = $similarity;
            $rating = isset($all_ratings[$similar_user_id][$product_id]) ? $all_ratings[$similar_user_id][$product_id] : null;
            
            if ($rating !== null) {
                $weighted = $similarity_score * $rating;
                $numerator += $weighted;
                $denominator += abs($similarity_score);
                
                $debug['details'][] = [
                    'similar_user_id' => $similar_user_id,
                    'similarity' => round($similarity_score, 4),
                    'rating' => $rating,
                    'similarity_x_rating' => round($weighted, 4)
                ];
            }
        }
        
        $predicted_rating = ($denominator > 0) ? $numerator / $denominator : 0;
        
        $debug['numerator'] = round($numerator, 4);
        $debug['denominator'] = round($denominator, 4);
        $debug['predicted_rating'] = round($predicted_rating, 4);
        
        return $debug;
    }
}
?>
