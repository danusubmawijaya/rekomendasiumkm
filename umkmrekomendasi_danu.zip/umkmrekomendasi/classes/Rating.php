<?php
// Ensure database connection is loaded
if (!isset($GLOBALS['conn'])) {
    require_once dirname(__DIR__) . '/config/database.php';
}

class Rating {
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
    
    /**
     * Helper method untuk kompatibilitas PHP versi lama
     * Check row count dari statement
     */
    private function getRowCount($stmt) {
        $stmt->store_result();
        return $stmt->num_rows;
    }
    
    /**
     * Add or update rating for user or guest
     * 
     * FIXED BUGS:
     * - Guest dapat rating berulang untuk produk yang sama (UPDATE rating)
     * - Tidak ada duplicate entry error karena kita UPDATE bukan INSERT
     * - Kompatibel dengan foreign key constraints
     * 
     * @param mixed $user_id - User ID (int) or null for guest
     * @param int $product_id
     * @param int $rating
     * @param mixed $guest_id - Guest ID (string) or null for logged in user
     */
    public function addRating($user_id, $product_id, $rating, $guest_id = null) {
        // Validasi rating
        $user_id = $user_id ? intval($user_id) : null;
        $product_id = intval($product_id);
        $rating = intval($rating);
        
        if ($rating < 1 || $rating > 5) {
            return ['success' => false, 'message' => 'Rating harus antara 1-5'];
        }
        
        // Pastikan ada user_id atau guest_id
        if (!$user_id && !$guest_id) {
            return ['success' => false, 'message' => 'Identitas pengguna tidak valid'];
        }
        
        try {
            // Cek apakah sudah ada rating sebelumnya dengan STRICT CHECK
            if ($user_id) {
                // USER TERDAFTAR: Cek rating berdasarkan user_id
                $check_stmt = $this->conn->prepare("SELECT id, rating FROM ratings WHERE user_id = ? AND product_id = ? LIMIT 1");
                if (!$check_stmt) {
                    throw new Exception("Prepare failed: " . $this->conn->error);
                }
                $check_stmt->bind_param("ii", $user_id, $product_id);
                if (!$check_stmt->execute()) {
                    throw new Exception("Execute failed: " . $this->conn->error);
                }
                $check_stmt->store_result();
                $existing_rating = null;
                
                if ($check_stmt->num_rows > 0) {
                    // Support untuk PHP lama yang tidak punya get_result()
                    if (method_exists($check_stmt, 'get_result')) {
                        $check_result = $check_stmt->get_result();
                        if ($check_result) {
                            $existing_rating = $check_result->fetch_assoc();
                        }
                    } else {
                        // Fallback untuk PHP lama
                        $meta = $check_stmt->result_metadata();
                        $fields = [];
                        while ($field = $meta->fetch_field()) {
                            $fields[] = $field->name;
                        }
                        $values = array_fill(0, count($fields), null);
                        $bind_params = [];
                        foreach ($values as &$value) {
                            $bind_params[] = &$value;
                        }
                        call_user_func_array([$check_stmt, 'bind_result'], $bind_params);
                        if ($check_stmt->fetch()) {
                            $existing_rating = [];
                            for ($i = 0; $i < count($fields); $i++) {
                                $existing_rating[$fields[$i]] = $values[$i];
                            }
                        }
                    }
                    
                    if ($existing_rating) {
                        error_log("DEBUG: User rating exists - ID: " . $existing_rating['id'] . ", Current: " . $existing_rating['rating'] . ", New: $rating");
                    }
                }
                $check_stmt->close();
                
                if ($existing_rating) {
                    // Rating sudah ada, lakukan UPDATE
                    $update_stmt = $this->conn->prepare("UPDATE ratings SET rating = ?, updated_at = NOW() WHERE user_id = ? AND product_id = ?");
                    if (!$update_stmt) {
                        throw new Exception("Prepare failed: " . $this->conn->error);
                    }
                    $update_stmt->bind_param("iii", $rating, $user_id, $product_id);
                    
                    if ($update_stmt->execute()) {
                        $update_stmt->close();
                        return ['success' => true, 'message' => 'Rating berhasil diperbarui'];
                    } else {
                        $error = $this->conn->error;
                        $update_stmt->close();
                        return ['success' => false, 'message' => 'Gagal memperbarui rating: ' . $error];
                    }
                }
                
                // Rating belum ada, lakukan INSERT
                $insert_stmt = $this->conn->prepare("INSERT INTO ratings (user_id, product_id, rating, guest_id) VALUES (?, ?, ?, NULL)");
                if (!$insert_stmt) {
                    throw new Exception("Prepare failed: " . $this->conn->error);
                }
                $insert_stmt->bind_param("iii", $user_id, $product_id, $rating);
                
                if ($insert_stmt->execute()) {
                    $insert_stmt->close();
                    error_log("DEBUG: User rating inserted successfully");
                    return ['success' => true, 'message' => 'Rating berhasil disimpan'];
                } else {
                    $error = $this->conn->error;
                    $insert_stmt->close();
                    error_log("DEBUG: Insert failed - " . $error);
                    return ['success' => false, 'message' => 'Gagal menyimpan rating: ' . $error];
                }
            } else {
                // GUEST: Cek rating berdasarkan guest_id + user_id=NULL
                $check_stmt = $this->conn->prepare("SELECT id, rating FROM ratings WHERE user_id IS NULL AND guest_id = ? AND product_id = ? LIMIT 1");
                if (!$check_stmt) {
                    throw new Exception("Prepare failed: " . $this->conn->error);
                }
                $check_stmt->bind_param("si", $guest_id, $product_id);
                if (!$check_stmt->execute()) {
                    throw new Exception("Execute failed: " . $this->conn->error);
                }
                $check_stmt->store_result();
                $existing_rating = null;
                
                if ($check_stmt->num_rows > 0) {
                    // Support untuk PHP lama yang tidak punya get_result()
                    if (method_exists($check_stmt, 'get_result')) {
                        $check_result = $check_stmt->get_result();
                        if ($check_result) {
                            $existing_rating = $check_result->fetch_assoc();
                        }
                    } else {
                        // Fallback untuk PHP lama
                        $meta = $check_stmt->result_metadata();
                        $fields = [];
                        while ($field = $meta->fetch_field()) {
                            $fields[] = $field->name;
                        }
                        $values = array_fill(0, count($fields), null);
                        $bind_params = [];
                        foreach ($values as &$value) {
                            $bind_params[] = &$value;
                        }
                        call_user_func_array([$check_stmt, 'bind_result'], $bind_params);
                        if ($check_stmt->fetch()) {
                            $existing_rating = [];
                            for ($i = 0; $i < count($fields); $i++) {
                                $existing_rating[$fields[$i]] = $values[$i];
                            }
                        }
                    }
                    
                    if ($existing_rating) {
                        error_log("DEBUG: Guest rating exists - ID: " . $existing_rating['id'] . ", Current: " . $existing_rating['rating'] . ", New: $rating");
                    }
                }
                $check_stmt->close();
                
                if ($existing_rating) {
                    // Rating sudah ada, lakukan UPDATE
                    $update_stmt = $this->conn->prepare("UPDATE ratings SET rating = ?, updated_at = NOW() WHERE user_id IS NULL AND guest_id = ? AND product_id = ?");
                    if (!$update_stmt) {
                        throw new Exception("Prepare failed: " . $this->conn->error);
                    }
                    $update_stmt->bind_param("isi", $rating, $guest_id, $product_id);
                    
                    if ($update_stmt->execute()) {
                        $update_stmt->close();
                        return ['success' => true, 'message' => 'Rating berhasil diperbarui'];
                    } else {
                        $error = $this->conn->error;
                        $update_stmt->close();
                        return ['success' => false, 'message' => 'Gagal memperbarui rating: ' . $error];
                    }
                }
                
                // Rating belum ada, lakukan INSERT dengan user_id = NULL
                $insert_stmt = $this->conn->prepare("INSERT INTO ratings (user_id, guest_id, product_id, rating) VALUES (NULL, ?, ?, ?)");
                if (!$insert_stmt) {
                    throw new Exception("Prepare failed: " . $this->conn->error);
                }
                $insert_stmt->bind_param("sii", $guest_id, $product_id, $rating);
                
                if ($insert_stmt->execute()) {
                    $insert_stmt->close();
                    error_log("DEBUG: Guest rating inserted successfully");
                    return ['success' => true, 'message' => 'Rating berhasil disimpan'];
                } else {
                    $error = $this->conn->error;
                    $insert_stmt->close();
                    error_log("DEBUG: Guest insert failed - " . $error);
                    return ['success' => false, 'message' => 'Gagal menyimpan rating: ' . $error];
                }
            }
        } catch (Exception $e) {
            error_log("DEBUG: Exception in addRating - " . $e->getMessage());
            return ['success' => false, 'message' => 'Error: ' . $e->getMessage()];
        }
    }
    
    /**
     * Rate product (one time only)
     * Prevents duplicate rating untuk same (user/guest, product) combination
     */
    public function rateProduct($user_id, $product_id, $rating, $guest_id = null) {
        // FIXED: Delegasikan ke addRating yang sudah benar
        return $this->addRating($user_id, $product_id, $rating, $guest_id);
    }
    
    public function getUserRating($user_id = null, $product_id = null, $guest_id = null) {
        $product_id = intval($product_id);
        
        if ($user_id) {
            $user_id = intval($user_id);
            $stmt = $this->conn->prepare("SELECT * FROM ratings WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("ii", $user_id, $product_id);
        } else if ($guest_id) {
            $stmt = $this->conn->prepare("SELECT * FROM ratings WHERE user_id IS NULL AND guest_id = ? AND product_id = ?");
            $stmt->bind_param("si", $guest_id, $product_id);
        } else {
            return null;
        }
        
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $meta = $stmt->result_metadata();
            $fields = [];
            
            while ($field = $meta->fetch_field()) {
                $fields[] = $field->name;
            }
            
            $row = [];
            $bind_vars = [];
            foreach ($fields as $field) {
                $bind_vars[$field] = null;
            }
            
            $bind_params = [];
            foreach ($fields as $field) {
                $bind_params[] = &$bind_vars[$field];
            }
            
            call_user_func_array([$stmt, 'bind_result'], $bind_params);
            
            if ($stmt->fetch()) {
                foreach ($fields as $field) {
                    $row[$field] = $bind_vars[$field];
                }
                $stmt->close();
                return $row;
            }
        }
        
        $stmt->close();
        return null;
    }
    
    /**
     * Delete user/guest rating for specific product
     */
    public function deleteRating($user_id = null, $product_id = null, $guest_id = null) {
        $product_id = intval($product_id);
        
        if ($user_id && intval($user_id) > 0) {
            $user_id = intval($user_id);
            $stmt = $this->conn->prepare("DELETE FROM ratings WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("ii", $user_id, $product_id);
        } else if ($guest_id) {
            $stmt = $this->conn->prepare("DELETE FROM ratings WHERE user_id IS NULL AND guest_id = ? AND product_id = ?");
            $stmt->bind_param("si", $guest_id, $product_id);
        } else {
            return ['success' => false, 'message' => 'Identitas pengguna tidak valid'];
        }
        
        if ($stmt->execute()) {
            $stmt->close();
            return ['success' => true, 'message' => 'Rating berhasil dihapus'];
        } else {
            $error = $this->conn->error;
            $stmt->close();
            return ['success' => false, 'message' => 'Gagal menghapus rating: ' . $error];
        }
    }
}
?>