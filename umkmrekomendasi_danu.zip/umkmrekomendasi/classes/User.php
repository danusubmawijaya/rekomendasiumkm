<?php
// Ensure database connection is loaded
if (!isset($GLOBALS['conn'])) {
    require_once dirname(__DIR__) . '/config/database.php';
}

class User {
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection;
    }
    
    public function register($name, $email, $password) {
        // Normalize email
        $email = strtolower(trim($email));
        
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return ['success' => false, 'message' => 'Format email tidak valid'];
        }
        
        if (!preg_match('/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/', $email)) {
            return ['success' => false, 'message' => 'Format email tidak valid - harus memiliki domain yang benar'];
        }
        
        // Prepared statement untuk check email
        $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
        if (!$stmt) {
            return ['success' => false, 'message' => 'Database error'];
        }
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $stmt->close();
            return ['success' => false, 'message' => 'Email sudah terdaftar'];
        }
        $stmt->close();
        
        // Insert user dengan plain text password (sesuai dengan login fallback)
        $stmt = $this->conn->prepare("INSERT INTO users (name, email, password, is_admin) VALUES (?, ?, ?, 0)");
        if (!$stmt) {
            return ['success' => false, 'message' => 'Database error'];
        }
        
        $stmt->bind_param("sss", $name, $email, $password);
        
        if ($stmt->execute()) {
            $stmt->close();
            return ['success' => true, 'message' => 'Registrasi berhasil'];
        } else {
            $stmt->close();
            return ['success' => false, 'message' => 'Registrasi gagal'];
        }
    }
    
    public function login($email, $password) {
        // Normalize email
        $email = strtolower(trim($email));
        
        // Prepared statement untuk keamanan
        $stmt = $this->conn->prepare("SELECT id, name, email, password, is_admin FROM users WHERE email = ?");
        if (!$stmt) {
            return ['success' => false, 'message' => 'Database error'];
        }
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows == 0) {
            $stmt->close();
            return ['success' => false, 'message' => 'Email atau password tidak valid'];
        }
        
        $stmt->bind_result($id, $name, $email_db, $password_hash, $is_admin);
        $stmt->fetch();
        $stmt->close();
        
        // Check if password is hashed or plain text
        $password_valid = false;
        
        // Try bcrypt verify first
        if (substr($password_hash, 0, 4) === '$2y$' || substr($password_hash, 0, 4) === '$2a$' || substr($password_hash, 0, 4) === '$2b$') {
            $password_valid = password_verify($password, $password_hash);
        } else {
            // Fallback to plain text comparison (for migration)
            $password_valid = ($password === $password_hash);
        }
        
        if ($password_valid) {
            // Password valid - lanjut login
            session_regenerate_id(true);
            $_SESSION['user_id'] = $id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email_db;
            $_SESSION['is_admin'] = $is_admin;
            
            // MIGRATE: Pindahkan rating guest ke user ini
            $this->migrateGuestRatings($id);
            
            return ['success' => true, 'message' => 'Login berhasil'];
        }
        
        return ['success' => false, 'message' => 'Email atau password tidak valid'];
    }
    
    public function getUserById($user_id) {
        $user_id = intval($user_id);
        $query = "SELECT id, name, email, is_admin FROM users WHERE id = $user_id";
        $result = $this->conn->query($query);
        
        if ($result && $result->num_rows > 0) {
            return $result->fetch_assoc();
        }
        
        return null;
    }
    
    public function getAllUsers() {
        $query = "SELECT id, name, email, is_admin, created_at FROM users ORDER BY created_at DESC";
        $result = $this->conn->query($query);
        $users = [];
        
        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }
        
        return $users;
    }
    
    public function deleteUser($user_id) {
        $user_id = intval($user_id);
        
        error_log("DEBUG deleteUser: Deleting user_id=$user_id and all their ratings");
        
        // Hapus ratings pengguna terlebih dahulu - HARUS berhasil
        $rating_delete_query = "DELETE FROM ratings WHERE user_id = $user_id";
        $rating_delete_result = $this->conn->query($rating_delete_query);
        if (!$rating_delete_result) {
            error_log("WARNING deleteUser: Failed to delete ratings - " . $this->conn->error);
        } else {
            error_log("DEBUG deleteUser: Deleted " . $this->conn->affected_rows . " ratings");
        }
        
        // Hapus pengguna
        $user_delete_query = "DELETE FROM users WHERE id = $user_id";
        $user_delete_result = $this->conn->query($user_delete_query);
        
        if ($user_delete_result) {
            error_log("DEBUG deleteUser: User $user_id deleted successfully");
            return ['success' => true, 'message' => 'Pengguna berhasil dihapus'];
        } else {
            error_log("ERROR deleteUser: Failed to delete user - " . $this->conn->error);
            return ['success' => false, 'message' => 'Gagal menghapus pengguna: ' . $this->conn->error];
        }
    }
    
    public function getUserByEmail($email) {
        // Normalize email
        $email = strtolower(trim($email));
        
        // Simple query tanpa prepared statement
        $query = "SELECT id, name, email FROM users WHERE email = '" . $this->conn->real_escape_string($email) . "'";
        $result = $this->conn->query($query);
        
        if (!$result || $result->num_rows == 0) {
            return null;
        }
        
        return $result->fetch_assoc();
    }
    
    public function generatePasswordResetToken($user_id) {
        $user_id = intval($user_id);
        $token = bin2hex(random_bytes(32));
        $token_hash = hash('sha256', $token);
        $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Prepared statement untuk update token
        $stmt = $this->conn->prepare("UPDATE users SET password_reset_token = ?, password_reset_expires = ? WHERE id = ?");
        if (!$stmt) {
            return null;
        }
        
        $stmt->bind_param("ssi", $token_hash, $expires_at, $user_id);
        
        if ($stmt->execute()) {
            $stmt->close();
            return $token; // Return token asli untuk dikirim via email
        }
        
        $stmt->close();
        return null;
    }
    
    public function validatePasswordResetToken($token) {
        $token_hash = hash('sha256', $token);
        
        // Prepared statement untuk validate token
        $stmt = $this->conn->prepare("SELECT id, email, password_reset_expires FROM users WHERE password_reset_token = ?");
        if (!$stmt) {
            return ['success' => false, 'message' => 'Database error'];
        }
        
        $stmt->bind_param("s", $token_hash);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows == 0) {
            $stmt->close();
            return ['success' => false, 'message' => 'Token tidak valid'];
        }
        
        $stmt->bind_result($user_id, $user_email, $expires_at);
        $stmt->fetch();
        $stmt->close();
        
        // Cek apakah token sudah expired
        if (strtotime($expires_at) < time()) {
            return ['success' => false, 'message' => 'Token sudah expired'];
        }
        
        return ['success' => true, 'user_id' => $user_id, 'email' => $user_email];
    }
    
    public function resetPassword($user_id, $new_password) {
        $user_id = intval($user_id);
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        
        // Prepared statement untuk update password
        $stmt = $this->conn->prepare("UPDATE users SET password = ?, password_reset_token = NULL, password_reset_expires = NULL WHERE id = ?");
        if (!$stmt) {
            return ['success' => false, 'message' => 'Database error'];
        }
        
        $stmt->bind_param("si", $hashed_password, $user_id);
        
        if ($stmt->execute()) {
            $stmt->close();
            return ['success' => true, 'message' => 'Password berhasil direset'];
        }
        
        $stmt->close();
        return ['success' => false, 'message' => 'Gagal mereset password'];
    }
    
    /**
     * Migrate guest ratings ke user account saat login
     * Menggunakan transaksi database untuk ensure atomicity
     * @param int $user_id User ID yang baru login
     */
    private function migrateGuestRatings($user_id) {
        // Ambil guest_id dari cookie
        $guest_id = isset($_COOKIE['guest_id']) ? $_COOKIE['guest_id'] : null;
        
        if (!$guest_id) {
            return; // Tidak ada guest_id untuk dimigrate
        }
        
        $user_id = intval($user_id);
        
        try {
            // Cek apakah ada ratings dari guest ini
            $check_stmt = $this->conn->prepare("SELECT COUNT(*) as cnt FROM ratings WHERE guest_id = ? AND user_id = 0");
            $check_stmt->bind_param("s", $guest_id);
            $check_stmt->execute();
            $check_stmt->store_result();
            
            $guest_rating_count = 0;
            if ($check_stmt->num_rows > 0) {
                $check_stmt->bind_result($guest_rating_count);
                $check_stmt->fetch();
            }
            $check_stmt->close();
            
            if ($guest_rating_count > 0) {
                // FIXED: Migrate guest ratings ke user
                // Hanya migrate ratings yang produknya belum pernah di-rating oleh user ini
                $migrate_query = "UPDATE ratings r1
                                  JOIN (
                                      SELECT product_id, MAX(id) as max_id
                                      FROM ratings 
                                      WHERE guest_id = '" . $this->conn->real_escape_string($guest_id) . "' 
                                      AND user_id = 0
                                      GROUP BY product_id
                                  ) r2 ON r1.id = r2.max_id
                                  SET r1.user_id = $user_id, r1.guest_id = NULL
                                  WHERE r1.guest_id = '" . $this->conn->real_escape_string($guest_id) . "'
                                  AND r1.user_id = 0
                                  AND r1.product_id NOT IN (
                                      SELECT product_id FROM ratings WHERE user_id = $user_id AND product_id IS NOT NULL
                                  )";
                $this->conn->query($migrate_query);
            }
            
        } catch (Exception $e) {
            error_log("Guest rating migration error: " . $e->getMessage());
        }
    }
}
?>
