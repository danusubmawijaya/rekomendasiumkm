<?php
require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/session.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isAdmin()) {
    header("Location: ../../access_denied.php");
    exit();
}

$user_id = getCurrentUserId();
$message = '';
$message_type = '';

// Fetch admin data
$user = ['id' => $user_id, 'name' => '', 'email' => ''];
$query = "SELECT id, name, email FROM users WHERE id = ?";
$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id_result, $name, $email);
            $stmt->fetch();
            $user = ['id' => $user_id_result, 'name' => $name, 'email' => $email];
        }
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'update_profile') {
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        
        if (empty($name) || empty($email)) {
            $message = 'Nama dan email tidak boleh kosong';
            $message_type = 'danger';
        } else {
            $check_query = "SELECT id FROM users WHERE email = ? AND id != ?";
            $check_stmt = $conn->prepare($check_query);
            $email_exists = false;
            
            if ($check_stmt) {
                $check_stmt->bind_param("si", $email, $user_id);
                if ($check_stmt->execute()) {
                    $check_stmt->store_result();
                    $email_exists = $check_stmt->num_rows > 0;
                }
                $check_stmt->close();
            }
            
            if ($email_exists) {
                $message = 'Email sudah digunakan oleh akun lain';
                $message_type = 'danger';
            } else {
                $update_query = "UPDATE users SET name = ?, email = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_query);
                
                if ($update_stmt) {
                    $update_stmt->bind_param("ssi", $name, $email, $user_id);
                    
                    if ($update_stmt->execute()) {
                        $_SESSION['user_name'] = $name;
                        $_SESSION['user_email'] = $email;
                        $user['name'] = $name;
                        $user['email'] = $email;
                        $message = 'Profil berhasil diperbarui';
                        $message_type = 'success';
                    } else {
                        $message = 'Gagal memperbarui profil';
                        $message_type = 'danger';
                    }
                    $update_stmt->close();
                } else {
                    $message = 'Error saat memperbarui profil';
                    $message_type = 'danger';
                }
            }
        }
    } elseif ($action == 'update_password') {
        $old_password = $_POST['old_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
            $message = 'Semua field password harus diisi';
            $message_type = 'danger';
        } elseif ($new_password !== $confirm_password) {
            $message = 'Password baru tidak cocok';
            $message_type = 'danger';
        } elseif (strlen($new_password) < 6) {
            $message = 'Password minimal 6 karakter';
            $message_type = 'danger';
        } else {
            $pass_query = "SELECT password FROM users WHERE id = ?";
            $pass_stmt = $conn->prepare($pass_query);
            $current_password = null;
            $password_valid = false;
            
            if ($pass_stmt) {
                $pass_stmt->bind_param("i", $user_id);
                if ($pass_stmt->execute()) {
                    $pass_stmt->store_result();
                    if ($pass_stmt->num_rows > 0) {
                        $pass_stmt->bind_result($current_password);
                        $pass_stmt->fetch();
                        $password_valid = password_verify($old_password, $current_password);
                    }
                }
                $pass_stmt->close();
            }
            
            if (!$password_valid) {
                $message = 'Password lama salah';
                $message_type = 'danger';
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                $update_pass_query = "UPDATE users SET password = ? WHERE id = ?";
                $update_pass_stmt = $conn->prepare($update_pass_query);
                
                if ($update_pass_stmt) {
                    $update_pass_stmt->bind_param("si", $hashed_password, $user_id);
                    
                    if ($update_pass_stmt->execute()) {
                        $message = 'Password berhasil diubah';
                        $message_type = 'success';
                    } else {
                        $message = 'Gagal mengubah password';
                        $message_type = 'danger';
                    }
                    $update_pass_stmt->close();
                } else {
                    $message = 'Error saat mengubah password';
                    $message_type = 'danger';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Admin - UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../../css/admin.css" rel="stylesheet">
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-leaf"></i> UMKM Recommend
        </div>
        <a href="dashboard.php" class="nav-link-admin">
            <i class="fas fa-chart-line"></i> <span>Dashboard</span>
        </a>
        <a href="products.php" class="nav-link-admin">
            <i class="fas fa-box"></i> <span>Kelola Produk</span>
        </a>
        <a href="evaluasi_mae.php" class="nav-link-admin">
            <i class="fas fa-chart-bar"></i> <span>Evaluasi MAE</span>
        </a>
        <a href="users.php" class="nav-link-admin">
            <i class="fas fa-users"></i> <span>Kelola Pengguna</span>
        </a>
        <hr style="border-color: rgba(255,255,255,0.2); margin: 20px 0;">
        <a href="profile.php" class="nav-link-admin active">
            <i class="fas fa-user-cog"></i> <span>Profil Saya</span>
        </a>
        <a href="../../logout.php" class="nav-link-admin">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="dashboard-header">
            <div>
                <h1 class="dashboard-title"><i class="fas fa-user-cog"></i> Profil Admin</h1>
                <p style="color: #999; margin: 5px 0 0 0;">Kelola informasi akun dan keamanan Anda</p>
            </div>
        </div>

        <?php if ($message): ?>
        <div class="alert alert-<?php echo ($message_type === 'success' ? 'success' : 'danger'); ?> alert-dismissible fade show" role="alert" style="margin-bottom: 24px;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <i class="fas fa-<?php echo ($message_type === 'success' ? 'check-circle' : 'exclamation-circle'); ?>"></i>
                <span><?php echo htmlspecialchars($message); ?></span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 24px;">
            <!-- Profile Card -->
            <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden;">
                <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(34, 139, 34, 0.05), rgba(45, 80, 22, 0.05));">
                    <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                        <i class="fas fa-user-circle" style="color: var(--primary-color); margin-right: 10px;"></i>
                        Data Profil Admin
                    </h2>
                </div>
                <div style="padding: 24px;">
                    <form method="POST">
                        <input type="hidden" name="action" value="update_profile">
                        
                        <div style="margin-bottom: 16px;">
                            <label style="display: block; font-weight: 600; margin-bottom: 8px; color: var(--dark-color);">Nama Lengkap</label>
                            <input type="text" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit; transition: all 0.3s;">
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; font-weight: 600; margin-bottom: 8px; color: var(--dark-color);">Email</label>
                            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit; transition: all 0.3s;">
                        </div>
                        
                        <button type="submit" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 10px 24px; border-radius: 8px; font-weight: 600; border: none; background: var(--primary-color); color: white; cursor: pointer; transition: all 0.3s;">
                            <i class="fas fa-save"></i> Simpan Perubahan
                        </button>
                    </form>
                </div>
            </div>

            <!-- Password Card -->
            <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden;">
                <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(34, 139, 34, 0.05), rgba(45, 80, 22, 0.05));">
                    <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                        <i class="fas fa-lock" style="color: var(--primary-color); margin-right: 10px;"></i>
                        Ubah Password
                    </h2>
                </div>
                <div style="padding: 24px;">
                    <form method="POST">
                        <input type="hidden" name="action" value="update_password">
                        
                        <div style="margin-bottom: 16px;">
                            <label style="display: block; font-weight: 600; margin-bottom: 8px; color: var(--dark-color);">Password Lama</label>
                            <input type="password" name="old_password" required style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit; transition: all 0.3s;">
                        </div>
                        
                        <div style="margin-bottom: 16px;">
                            <label style="display: block; font-weight: 600; margin-bottom: 8px; color: var(--dark-color);">Password Baru</label>
                            <input type="password" name="new_password" required style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit; transition: all 0.3s;">
                            <small style="display: block; color: #999; margin-top: 6px;">Minimal 6 karakter</small>
                        </div>
                        
                        <div style="margin-bottom: 20px;">
                            <label style="display: block; font-weight: 600; margin-bottom: 8px; color: var(--dark-color);">Konfirmasi Password Baru</label>
                            <input type="password" name="confirm_password" required style="width: 100%; padding: 10px 12px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit; transition: all 0.3s;">
                        </div>
                        
                        <button type="submit" style="width: 100%; display: flex; align-items: center; justify-content: center; gap: 8px; padding: 10px 24px; border-radius: 8px; font-weight: 600; border: none; background: var(--primary-color); color: white; cursor: pointer; transition: all 0.3s;">
                            <i class="fas fa-key"></i> Ubah Password
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('show');
                sidebarOverlay.classList.toggle('active');
            });

            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('active');
            });

            const navLinks = document.querySelectorAll('.nav-link-admin');
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                });
            });

            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>
