<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/config/session.php';

// Hanya admin yang bisa akses
if (!isset($_SESSION['user_id']) || $_SESSION['is_admin'] != 1) {
    header("Location: ../login.php");
    exit();
}

echo "<!DOCTYPE html>";
echo "<html>";
echo "<head>";
echo "<meta charset='UTF-8'>";
echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
echo "<title>Fix Product Context Locations</title>";
echo "<link rel='stylesheet' href='../css/admin.css'>";
echo "<style>";
echo "body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }";
echo ".container { max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; }";
echo ".success { background: #d4edda; border: 1px solid #c3e6cb; color: #155724; padding: 15px; margin: 10px 0; border-radius: 4px; }";
echo ".error { background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 15px; margin: 10px 0; border-radius: 4px; }";
echo ".info { background: #d1ecf1; border: 1px solid #bee5eb; color: #0c5460; padding: 15px; margin: 10px 0; border-radius: 4px; }";
echo ".warning { background: #fff3cd; border: 1px solid #ffeaa7; color: #856404; padding: 15px; margin: 10px 0; border-radius: 4px; }";
echo "table { width: 100%; border-collapse: collapse; margin: 20px 0; }";
echo "th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }";
echo "th { background: #f8f9fa; font-weight: bold; }";
echo "tr:hover { background: #f9f9f9; }";
echo "h1 { color: #333; margin-bottom: 20px; }";
echo "h2 { color: #555; margin-top: 30px; margin-bottom: 15px; border-bottom: 2px solid #007bff; padding-bottom: 10px; }";
echo ".step { background: #f8f9fa; padding: 15px; margin: 15px 0; border-left: 4px solid #007bff; border-radius: 4px; }";
echo ".step-title { font-weight: bold; color: #007bff; margin-bottom: 10px; }";
echo ".back-link { display: inline-block; margin: 20px 0; color: #007bff; text-decoration: none; }";
echo ".back-link:hover { text-decoration: underline; }";
echo "</style>";
echo "</head>";
echo "<body>";
echo "<div class='container'>";

try {
    echo "<h1>🔧 Fix: Pastikan Lokasi Produk Sesuai Konteks</h1>";
    
    // STEP 1: Verifikasi struktur tabel
    echo "<h2>Step 1: Verifikasi Struktur Database</h2>";
    
    $check_columns = $conn->query("
        SELECT COLUMN_NAME, COLUMN_TYPE, IS_NULLABLE
        FROM INFORMATION_SCHEMA.COLUMNS 
        WHERE TABLE_NAME = 'product_locations' AND TABLE_SCHEMA = 'umkm_rekomendasi'
    ");
    
    if (!$check_columns) {
        throw new Exception("Error checking columns: " . $conn->error);
    }
    
    $columns_found = [];
    while ($row = $check_columns->fetch_assoc()) {
        $columns_found[$row['COLUMN_NAME']] = $row['COLUMN_TYPE'];
    }
    
    $required_columns = [
        'id' => true,
        'product_id' => true,
        'lokasi' => true,
        'latitude' => true,
        'longitude' => true,
        'alamat_lengkap' => true
    ];
    
    $all_columns_ok = true;
    echo "<table>";
    echo "<tr><th>Kolom</th><th>Tipe</th><th>Status</th></tr>";
    foreach ($required_columns as $col => $required) {
        if (isset($columns_found[$col])) {
            echo "<tr><td>$col</td><td>" . $columns_found[$col] . "</td><td><span style='color: green;'>✓ Ada</span></td></tr>";
        } else {
            echo "<tr><td>$col</td><td>-</td><td><span style='color: red;'>✗ Tidak ada</span></td></tr>";
            $all_columns_ok = false;
        }
    }
    echo "</table>";
    
    if (!$all_columns_ok) {
        echo "<div class='warning'>";
        echo "<strong>⚠️ Peringatan:</strong> Beberapa kolom tidak ditemukan. Jalankan migration terlebih dahulu.";
        echo "</div>";
    } else {
        echo "<div class='success'>";
        echo "✓ Semua kolom yang diperlukan sudah ada";
        echo "</div>";
    }
    
    // STEP 2: Lengkapi alamat_lengkap yang kosong
    echo "<h2>Step 2: Lengkapi Alamat Lengkap</h2>";
    
    $update_count = 0;
    
    // Array mapping lokasi -> alamat lengkap
    // CATATAN: Sudah tidak dipakai lagi karena data sudah termigrai ke product_locations
    $alamat_mapping = [
        // Data seeding lama - tidak perlu lagi dipetakan
        // Sekarang semuanya harus dari tabel product_locations
    ];
    
    foreach ($alamat_mapping as $lokasi => $alamat) {
        $lokasi_escaped = $conn->real_escape_string($lokasi);
        $alamat_escaped = $conn->real_escape_string($alamat);
        
        $sql = "UPDATE product_locations 
                SET alamat_lengkap = '$alamat_escaped'
                WHERE lokasi = '$lokasi_escaped' AND (alamat_lengkap IS NULL OR alamat_lengkap = '')";
        
        if ($conn->query($sql)) {
            $update_count += $conn->affected_rows;
        }
    }
    
    echo "<div class='step'>";
    echo "<div class='step-title'>Hasil Update Alamat Lengkap</div>";
    echo "Baris yang diupdate: <strong>$update_count</strong>";
    echo "</div>";
    
    // STEP 3: Verifikasi data duplikasi
    echo "<h2>Step 3: Verifikasi Duplikasi Lokasi per Produk</h2>";
    
    $duplicate_check = $conn->query("
        SELECT p.id, p.nama_produk, COUNT(pl.id) as jumlah_lokasi, 
               COUNT(DISTINCT pl.lokasi) as lokasi_unik
        FROM products p
        LEFT JOIN product_locations pl ON p.id = pl.product_id
        GROUP BY p.id
        HAVING jumlah_lokasi > 0
        ORDER BY p.id
    ");
    
    if (!$duplicate_check) {
        throw new Exception("Error checking duplicates: " . $conn->error);
    }
    
    $has_duplicates = false;
    echo "<table>";
    echo "<tr><th>ID</th><th>Nama Produk</th><th>Total Lokasi</th><th>Lokasi Unik</th><th>Status</th></tr>";
    
    while ($row = $duplicate_check->fetch_assoc()) {
        $status = ($row['jumlah_lokasi'] == $row['lokasi_unik']) ? 
                  "<span style='color: green;'>✓ OK</span>" : 
                  "<span style='color: orange;'>⚠️ Ada Duplikasi</span>";
        
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['nama_produk']) . "</td>";
        echo "<td>" . $row['jumlah_lokasi'] . "</td>";
        echo "<td>" . $row['lokasi_unik'] . "</td>";
        echo "<td>" . $status . "</td>";
        echo "</tr>";
        
        if ($row['jumlah_lokasi'] != $row['lokasi_unik']) {
            $has_duplicates = true;
        }
    }
    echo "</table>";
    
    // STEP 4: Cek produk tanpa lokasi
    echo "<h2>Step 4: Produk Tanpa Lokasi</h2>";
    
    $no_location = $conn->query("
        SELECT p.id, p.nama_produk, p.kategori
        FROM products p
        LEFT JOIN product_locations pl ON p.id = pl.product_id
        WHERE pl.id IS NULL
        ORDER BY p.id
    ");
    
    if (!$no_location) {
        throw new Exception("Error checking no location: " . $conn->error);
    }
    
    $no_location_count = $no_location->num_rows;
    
    if ($no_location_count > 0) {
        echo "<div class='warning'>";
        echo "<strong>⚠️ Perhatian:</strong> Ada " . $no_location_count . " produk tanpa lokasi penjual:";
        echo "</div>";
        
        echo "<table>";
        echo "<tr><th>ID</th><th>Nama Produk</th><th>Kategori</th></tr>";
        while ($row = $no_location->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . htmlspecialchars($row['nama_produk']) . "</td>";
            echo "<td>" . htmlspecialchars($row['kategori']) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div class='success'>";
        echo "✓ Semua produk memiliki minimal satu lokasi penjual";
        echo "</div>";
    }
    
    // STEP 5: Sampel data lokasi produk
    echo "<h2>Step 5: Sampel Data Lokasi Produk (10 terakhir)</h2>";
    
    $sample = $conn->query("
        SELECT pl.id, p.nama_produk, pl.lokasi, pl.alamat_lengkap, 
               pl.latitude, pl.longitude
        FROM product_locations pl
        INNER JOIN products p ON pl.product_id = p.id
        ORDER BY pl.id DESC
        LIMIT 10
    ");
    
    if (!$sample) {
        throw new Exception("Error fetching sample: " . $conn->error);
    }
    
    echo "<table>";
    echo "<tr><th>ID</th><th>Produk</th><th>Lokasi</th><th>Alamat Lengkap</th><th>Koordinat</th></tr>";
    while ($row = $sample->fetch_assoc()) {
        $coord = ($row['latitude'] && $row['longitude']) ? 
                 number_format($row['latitude'], 4) . ", " . number_format($row['longitude'], 4) : 
                 "<span style='color: orange;'>-</span>";
        
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['nama_produk']) . "</td>";
        echo "<td>" . htmlspecialchars($row['lokasi']) . "</td>";
        echo "<td>" . htmlspecialchars($row['alamat_lengkap'] ?? '-') . "</td>";
        echo "<td>" . $coord . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    // FINAL SUMMARY
    echo "<h2>✅ Ringkasan Perbaikan</h2>";
    echo "<div class='success'>";
    echo "<ul>";
    echo "<li>✓ Struktur database terverifikasi</li>";
    echo "<li>✓ Alamat lengkap dilengkapi (" . $update_count . " baris)</li>";
    echo "<li>✓ Verifikasi duplikasi lokasi: " . ($has_duplicates ? "Ada duplikasi ditemukan" : "Tidak ada duplikasi") . "</li>";
    echo "<li>✓ Produk tanpa lokasi: " . $no_location_count . " produk</li>";
    echo "</ul>";
    echo "</div>";
    
    echo "<a href='../product_detail.php?id=1' class='back-link'>← Lihat Detail Produk untuk Verifikasi</a>";
    
} catch (Exception $e) {
    echo "<div class='error'>";
    echo "<strong>❌ Error:</strong> " . htmlspecialchars($e->getMessage());
    echo "</div>";
}

echo "</div>";
echo "</body>";
echo "</html>";
?>
