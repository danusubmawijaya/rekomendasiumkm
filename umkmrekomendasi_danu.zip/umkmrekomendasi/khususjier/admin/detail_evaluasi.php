<?php
require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/session.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isAdmin()) {
    header("Location: ../../access_denied.php");
    exit();
}

// Get last evaluation from session
$loocv_iterations = isset($_SESSION['last_mae_evaluation']['loocv_iterations']) ? $_SESSION['last_mae_evaluation']['loocv_iterations'] : [];
$loocv_summary = isset($_SESSION['last_mae_evaluation']['loocv_summary']) ? $_SESSION['last_mae_evaluation']['loocv_summary'] : [];
$evaluation_timestamp = isset($_SESSION['last_mae_evaluation']['timestamp']) ? $_SESSION['last_mae_evaluation']['timestamp'] : null;

// Pre-load user names cache
$user_names_cache = [];
if (!empty($loocv_iterations)) {
    $user_ids = array_unique(array_filter(array_column($loocv_iterations, 'user_id')));
    if (!empty($user_ids)) {
        $safe_ids = array_map('intval', $user_ids);
        $ids_str = implode(',', $safe_ids);
        if (!empty($ids_str)) {
            $query = "SELECT id, name FROM users WHERE id IN ({$ids_str})";
            $result = $conn->query($query);
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    if ($row && isset($row['id']) && isset($row['name'])) {
                        $user_names_cache[$row['id']] = $row['name'];
                    }
                }
            }
        }
    }
}

// Validasi data
if (!is_array($loocv_iterations) || empty($loocv_iterations)) {
    $error_message = "Tidak ada data evaluasi MAE yang tersedia. Silahkan jalankan evaluasi MAE terlebih dahulu di halaman Evaluasi MAE.";
    $loocv_iterations = [];
    $loocv_summary = [
        'total_ratings' => 0,
        'total_iterations' => 0,
        'successful_predictions' => 0,
        'failed_predictions' => 0,
        'total_absolute_error' => 0,
        'mae' => 0
    ];
}

// Ensure loocv_summary has all required keys
if (!is_array($loocv_summary)) {
    $loocv_summary = [];
}

$required_summary_keys = ['total_ratings', 'total_iterations', 'successful_predictions', 'failed_predictions', 'total_absolute_error', 'mae'];
foreach ($required_summary_keys as $key) {
    if (!isset($loocv_summary[$key])) {
        $loocv_summary[$key] = 0;
    }
}

// Handle export requests
$export_type = isset($_GET['export']) ? $_GET['export'] : '';

// Helper function to get user identifier (name or guest ID)
function getUserIdentifier($user_id, $guest_id, $conn) {
    // If user_id is 0 or null and guest_id exists, show guest_id
    if (empty($user_id) || $user_id == 0) {
        if (!empty($guest_id)) {
            return "G#" . substr($guest_id, 0, 8);
        }
        return 'Unknown';
    }
    
    // Try to get user name from database
    $query = "SELECT name FROM users WHERE id = ?";
    $stmt = $conn->prepare($query);
    if ($stmt) {
        $stmt->bind_param("i", $user_id);
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                return "U#" . $user_id . " (" . htmlspecialchars($row['name']) . ")";
            }
        }
        $stmt->close();
    }
    
    // If user not found in database, show as unknown user
    return "U#" . $user_id;
}

if ($export_type === 'excel') {
    header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
    header('Content-Disposition: attachment; filename="detail_evaluasi_mae_' . date('Y-m-d_H-i-s') . '.xls"');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    header('Pragma: no-cache');
    header('Expires: 0');
    
    echo "No\tIterasi\tUserID/Guest ID\tProduct ID\tNama Produk\tRating Aktual\tRating Prediksi\tAbsolute Error\tStatus\n";
    
    if (is_array($loocv_iterations) && !empty($loocv_iterations)) {
        foreach ($loocv_iterations as $index => $iteration) {
            if (is_array($iteration)) {
                echo ($index + 1) . "\t";
                echo (isset($iteration['iteration']) ? $iteration['iteration'] : '') . "\t";
                $user_id = isset($iteration['user_id']) ? $iteration['user_id'] : 0;
                $guest_id = isset($iteration['guest_id']) ? $iteration['guest_id'] : '';
                echo getUserIdentifier($user_id, $guest_id, $conn) . "\t";
                echo (isset($iteration['product_id']) ? $iteration['product_id'] : '') . "\t";
                echo (isset($iteration['product_name']) ? $iteration['product_name'] : '') . "\t";
                echo (isset($iteration['actual_rating']) ? $iteration['actual_rating'] : '') . "\t";
                echo (isset($iteration['predicted_rating']) ? $iteration['predicted_rating'] : '') . "\t";
                echo (isset($iteration['absolute_error']) ? $iteration['absolute_error'] : '') . "\t";
                echo (isset($iteration['status']) ? $iteration['status'] : '') . "\n";
            }
        }
    }
    
    echo "\n\nRINGKASAN:\n";
    echo "Jumlah Rating:\t" . $loocv_summary['total_ratings'] . "\n";
    echo "Iterasi LOOCV:\t" . $loocv_summary['total_iterations'] . "\n";
    echo "Prediksi Berhasil:\t" . $loocv_summary['successful_predictions'] . "\n";
    echo "Prediksi Gagal:\t" . $loocv_summary['failed_predictions'] . "\n";
    echo "Total Absolute Error:\t" . $loocv_summary['total_absolute_error'] . "\n";
    echo "MAE:\t" . $loocv_summary['mae'] . "\n";
    
    exit;
}

if ($export_type === 'pdf') {
    // Redirect ke halaman export PDF
    header('Location: export_pdf.php?autoprint=1');
    exit;
}

// Pagination settings
$items_per_page = 20;
$current_page = isset($_GET['page']) && is_numeric($_GET['page']) ? intval($_GET['page']) : 1;
$total_items = count($loocv_iterations);
$total_pages = ceil($total_items / $items_per_page);

if ($current_page < 1) $current_page = 1;
if ($current_page > $total_pages && $total_pages > 0) $current_page = $total_pages;

$start_index = ($current_page - 1) * $items_per_page;
$end_index = $start_index + $items_per_page;

// Filter dan sorting
$filtered_iterations = $loocv_iterations;

// Filter berdasarkan status
if (isset($_GET['status_filter']) && $_GET['status_filter'] !== '') {
    $status_filter = $_GET['status_filter'];
    $filtered_iterations = array_filter($loocv_iterations, function($item) use ($status_filter) {
        return isset($item['status']) && $item['status'] === $status_filter;
    });
}

// Filter berdasarkan user ID
if (isset($_GET['user_filter']) && $_GET['user_filter'] !== '') {
    $user_filter = intval($_GET['user_filter']);
    $filtered_iterations = array_filter($filtered_iterations, function($item) use ($user_filter) {
        return isset($item['user_id']) && $item['user_id'] === $user_filter;
    });
}

// Filter berdasarkan product ID
if (isset($_GET['product_filter']) && $_GET['product_filter'] !== '') {
    $product_filter = intval($_GET['product_filter']);
    $filtered_iterations = array_filter($filtered_iterations, function($item) use ($product_filter) {
        return isset($item['product_id']) && $item['product_id'] === $product_filter;
    });
}

// Sorting
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'status_valid_first';

switch ($sort_by) {
    case 'status_valid_first':
        // Default: Valid semua di atas, Tidak Diprediksi di bawah
        uasort($filtered_iterations, function($a, $b) {
            $a_status = isset($a['status']) ? $a['status'] : '';
            $b_status = isset($b['status']) ? $b['status'] : '';
            
            // Valid comes first
            if ($a_status === 'Valid' && $b_status !== 'Valid') {
                return -1;
            }
            if ($a_status !== 'Valid' && $b_status === 'Valid') {
                return 1;
            }
            // If same status, maintain order
            return 0;
        });
        break;
    case 'iteration':
        uasort($filtered_iterations, function($a, $b) {
            $a_val = isset($a['iteration']) ? $a['iteration'] : 0;
            $b_val = isset($b['iteration']) ? $b['iteration'] : 0;
            return $a_val - $b_val;
        });
        break;
    case 'user':
        uasort($filtered_iterations, function($a, $b) {
            $a_val = isset($a['user_id']) ? $a['user_id'] : 0;
            $b_val = isset($b['user_id']) ? $b['user_id'] : 0;
            return $a_val - $b_val;
        });
        break;
    case 'product':
        uasort($filtered_iterations, function($a, $b) {
            $a_val = isset($a['product_id']) ? $a['product_id'] : 0;
            $b_val = isset($b['product_id']) ? $b['product_id'] : 0;
            return $a_val - $b_val;
        });
        break;
    case 'error_desc':
        uasort($filtered_iterations, function($a, $b) {
            $a_val = isset($a['absolute_error']) ? $a['absolute_error'] : 0;
            $b_val = isset($b['absolute_error']) ? $b['absolute_error'] : 0;
            return $b_val - $a_val;
        });
        break;
    case 'error_asc':
        uasort($filtered_iterations, function($a, $b) {
            $a_val = isset($a['absolute_error']) ? $a['absolute_error'] : 0;
            $b_val = isset($b['absolute_error']) ? $b['absolute_error'] : 0;
            return $a_val - $b_val;
        });
        break;
}

// Prepare paginated data
$paginated_iterations = array_slice($filtered_iterations, $start_index, $items_per_page, true);

// Calculate error distribution for chart
$error_distribution = [
    '0-0.5' => 0,
    '0.5-1' => 0,
    '1-1.5' => 0,
    '1.5-2' => 0,
    '>2' => 0
];

if (is_array($loocv_iterations) && !empty($loocv_iterations)) {
    foreach ($loocv_iterations as $iteration) {
        if (is_array($iteration) && isset($iteration['absolute_error']) && $iteration['status'] === 'Valid') {
            $error = floatval($iteration['absolute_error']);
            if ($error <= 0.5) {
                $error_distribution['0-0.5']++;
            } elseif ($error <= 1) {
                $error_distribution['0.5-1']++;
            } elseif ($error <= 1.5) {
                $error_distribution['1-1.5']++;
            } elseif ($error <= 2) {
                $error_distribution['1.5-2']++;
            } else {
                $error_distribution['>2']++;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Evaluasi MAE - Admin UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../../css/admin.css" rel="stylesheet">
    <script>
        window.MathJax = {
            tex: {
                inlineMath: [['$', '$'], ['\\(', '\\)']],
                displayMath: [['$$', '$$'], ['\\[', '\\]']]
            },
            svg: {
                fontCache: 'global'
            }
        };
    </script>
    <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
    <style>
        .table-custom {
            font-size: 0.9rem;
        }
        .table-custom thead th {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            font-weight: 600;
            border: none;
            padding: 12px 8px;
        }
        .table-custom tbody tr:hover {
            background-color: #f5f5f5;
        }
        .badge-valid {
            background-color: #16a34a;
            color: white;
        }
        .badge-invalid {
            background-color: #f59e0b;
            color: white;
        }
        .chart-container {
            position: relative;
            height: 400px;
            margin-bottom: 20px;
        }
        .filter-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            padding: 20px;
            margin-bottom: 20px;
        }
        .summary-box {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            padding: 20px;
            margin-bottom: 20px;
            border-left: 5px solid var(--primary-color);
        }
        .summary-item {
            display: inline-block;
            margin-right: 40px;
            margin-bottom: 15px;
        }
        .summary-item-label {
            color: #999;
            font-size: 0.85rem;
            font-weight: 600;
            text-transform: uppercase;
        }
        .summary-item-value {
            color: var(--primary-color);
            font-size: 1.5rem;
            font-weight: 700;
            margin-top: 5px;
        }
        .pagination-custom {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 20px;
        }
        .pagination-custom a, .pagination-custom span {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: var(--primary-color);
        }
        .pagination-custom a:hover {
            background-color: var(--primary-color);
            color: white;
        }
        .pagination-custom .active {
            background-color: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }
        .sidebar-toggle {
            display: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 16px;
            border-radius: 8px;
            cursor: pointer;
            z-index: 999;
        }
        @media (max-width: 768px) {
            .sidebar-toggle {
                display: block;
            }
            .sidebar {
                width: 200px;
            }
            .main-content {
                margin-left: 0;
            }
        }
        .export-button {
            display: inline-block;
            margin-right: 10px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar Overlay untuk Mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-leaf"></i> UMKM Recommend
        </div>
        <a href="dashboard.php" class="nav-link-admin">
            <i class="fas fa-chart-line"></i> <span>Dashboard</span>
        </a>
        <a href="products.php" class="nav-link-admin">
            <i class="fas fa-box"></i> <span>Kelola Produk</span>
        </a>
        <a href="evaluasi_mae.php" class="nav-link-admin">
            <i class="fas fa-chart-bar"></i> <span>Evaluasi MAE</span>
        </a>
        <a href="users.php" class="nav-link-admin">
            <i class="fas fa-users"></i> <span>Kelola Pengguna</span>
        </a>
        <hr style="border-color: rgba(255,255,255,0.2); margin: 20px 0;">
        <a href="profile.php" class="nav-link-admin">
            <i class="fas fa-user-cog"></i> <span>Profil Saya</span>
        </a>
        <a href="../../logout.php" class="nav-link-admin">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="dashboard-header">
            <div>
                <h1 class="dashboard-title"><i class="fas fa-magnifying-glass"></i> Detail Evaluasi MAE</h1>
                <p style="color: #999; margin: 5px 0 0 0;">Lihat hasil Leave-One-Out Cross Validation</p>
            </div>
        </div>

        <!-- Error message -->
        <?php if (isset($error_message)): ?>
        <div style="background: #fee; border: 2px solid #f88; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
            <p style="margin: 0; color: #c00;">
                <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($error_message); ?>
            </p>
        </div>
        <?php endif; ?>

        <!-- Evaluation Timestamp -->
        <?php if ($evaluation_timestamp): ?>
        <div style="background: #f0f7ff; border: 2px solid #2196f3; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
            <p style="margin: 0 0 12px 0; color: #1565c0; font-weight: 600;">
                <i class="fas fa-info-circle"></i> Informasi Evaluasi
            </p>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px;">
                <div>
                    <p style="margin: 0; font-size: 0.85rem; color: #999;">Tanggal</p>
                    <p style="margin: 4px 0 0 0; font-weight: 600; color: #1565c0;"><?php echo isset($evaluation_timestamp['date']) ? htmlspecialchars($evaluation_timestamp['date']) : '-'; ?></p>
                </div>
                <div>
                    <p style="margin: 0; font-size: 0.85rem; color: #999;">Waktu</p>
                    <p style="margin: 4px 0 0 0; font-weight: 600; color: #1565c0;"><?php echo isset($evaluation_timestamp['time']) ? htmlspecialchars($evaluation_timestamp['time']) : '-'; ?></p>
                </div>
                <div>
                    <p style="margin: 0; font-size: 0.85rem; color: #999;">Durasi</p>
                    <p style="margin: 4px 0 0 0; font-weight: 600; color: #1565c0;"><?php echo isset($evaluation_timestamp['duration']) ? $evaluation_timestamp['duration'] . ' detik' : '-'; ?></p>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Grafik Distribusi Error -->
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 24px;">
            <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(34, 139, 34, 0.05), rgba(45, 80, 22, 0.05));">
                <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                    <i class="fas fa-chart-bar" style="color: var(--primary-color); margin-right: 10px;"></i>
                    Grafik Distribusi Error
                </h2>
            </div>
            <div style="padding: 24px;">
                <div class="chart-container">
                    <canvas id="errorChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Export Buttons -->
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; padding: 20px; margin-bottom: 24px;">
            <h3 style="margin: 0 0 16px 0; font-size: 1.1rem; font-weight: 600; color: var(--dark-color);">
                <i class="fas fa-download" style="color: var(--primary-color); margin-right: 8px;"></i>
                Export Data
            </h3>
            <a href="?export=excel" class="btn export-button" style="background: linear-gradient(135deg, #27ae60, #229954); color: white; padding: 10px 20px; border: none; border-radius: 8px; font-weight: 600; text-decoration: none;">
                <i class="fas fa-file-excel"></i> Export Excel
            </a>
            <a href="?export=pdf" class="btn export-button" style="background: linear-gradient(135deg, #c0392b, #a93226); color: white; padding: 10px 20px; border: none; border-radius: 8px; font-weight: 600; text-decoration: none;">
                <i class="fas fa-file-pdf"></i> Export PDF
            </a>
            <button onclick="window.print()" class="btn export-button" style="background: linear-gradient(135deg, #3498db, #2980b9); color: white; padding: 10px 20px; border: none; border-radius: 8px; font-weight: 600; cursor: pointer;">
                <i class="fas fa-print"></i> Print
            </button>
        </div>
        <!-- Filter Section -->
        <div class="filter-card">
            <h3 style="margin: 0 0 16px 0; font-size: 1.1rem; font-weight: 600; color: var(--dark-color);">
                <i class="fas fa-filter" style="color: var(--primary-color); margin-right: 8px;"></i>
                Filter & Sorting
            </h3>
            <form method="GET" action="" style="margin: 0;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: 16px;">
                    <div>
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; color: #666;">
                            <i class="fas fa-user"></i> Filter User ID
                        </label>
                        <input type="number" name="user_filter" class="form-control" placeholder="Masukkan User ID" value="<?php echo isset($_GET['user_filter']) ? htmlspecialchars($_GET['user_filter']) : ''; ?>">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; color: #666;">
                            <i class="fas fa-box"></i> Filter Product ID
                        </label>
                        <input type="number" name="product_filter" class="form-control" placeholder="Masukkan Product ID" value="<?php echo isset($_GET['product_filter']) ? htmlspecialchars($_GET['product_filter']) : ''; ?>">
                    </div>
                    <div>
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; color: #666;">
                            <i class="fas fa-check-circle"></i> Filter Status
                        </label>
                        <select name="status_filter" class="form-control">
                            <option value="">-- Semua Status --</option>
                            <option value="Valid" <?php echo isset($_GET['status_filter']) && $_GET['status_filter'] === 'Valid' ? 'selected' : ''; ?>>Valid</option>
                            <option value="Tidak Diprediksi" <?php echo isset($_GET['status_filter']) && $_GET['status_filter'] === 'Tidak Diprediksi' ? 'selected' : ''; ?>>Tidak Diprediksi</option>
                        </select>
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-bottom: 16px;">
                    <div>
                        <label style="display: block; margin-bottom: 6px; font-weight: 500; color: #666;">
                            <i class="fas fa-sort"></i> Sorting
                        </label>
                        <select name="sort_by" class="form-control">
                            <option value="status_valid_first" <?php echo (!isset($_GET['sort_by']) || $_GET['sort_by'] === 'status_valid_first') ? 'selected' : ''; ?>>Valid Dulu (↑ Default)</option>
                            <option value="iteration" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] === 'iteration' ? 'selected' : ''; ?>>Iterasi (↑)</option>
                            <option value="user" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] === 'user' ? 'selected' : ''; ?>>User ID (↑)</option>
                            <option value="product" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] === 'product' ? 'selected' : ''; ?>>Product ID (↑)</option>
                            <option value="error_asc" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] === 'error_asc' ? 'selected' : ''; ?>>Error (Terkecil)</option>
                            <option value="error_desc" <?php echo isset($_GET['sort_by']) && $_GET['sort_by'] === 'error_desc' ? 'selected' : ''; ?>>Error (Terbesar)</option>
                        </select>
                    </div>
                    <div style="display: flex; align-items: flex-end; gap: 8px;">
                        <button type="submit" class="btn" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; padding: 8px 20px; border: none; border-radius: 8px; font-weight: 600; flex: 1;">
                            <i class="fas fa-search"></i> Terapkan Filter
                        </button>
                        <a href="detail_evaluasi.php" class="btn" style="background: #999; color: white; padding: 8px 20px; border: none; border-radius: 8px; font-weight: 600; text-decoration: none;">
                            <i class="fas fa-redo"></i> Reset
                        </a>
                    </div>
                </div>
            </form>
        </div>

        <!-- Table Section -->
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 24px;">
            <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(34, 139, 34, 0.05), rgba(45, 80, 22, 0.05));">
                <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                    <i class="fas fa-table" style="color: var(--primary-color); margin-right: 10px;"></i>
                    Tabel Detail LOOCV
                </h2>
            </div>
            <div style="padding: 20px; overflow-x: auto;">
                <?php if (empty($loocv_iterations)): ?>
                <div style="text-align: center; padding: 40px 20px;">
                    <p style="color: #999; font-size: 1.1rem;">
                        <i class="fas fa-info-circle"></i> Tidak ada data evaluasi tersedia
                    </p>
                </div>
                <?php else: ?>
                <table class="table table-custom" style="margin: 0;">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Iterasi</th>
                            <th>UserID/Guest ID</th>
                            <th>Product ID</th>
                            <th>Nama Produk</th>
                            <th>Rating Aktual</th>
                            <th>Rating Prediksi</th>
                            <th>Absolute Error</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                        <?php 
                        if (is_array($paginated_iterations) && !empty($paginated_iterations)) {
                            $row_counter = $start_index + 1;
                            foreach ($paginated_iterations as $index => $iteration) {
                                if (is_array($iteration)) {
                        ?>
                        <tr>
                            <td><?php echo $row_counter++; ?></td>
                            <td><?php echo isset($iteration['iteration']) ? htmlspecialchars($iteration['iteration']) : '-'; ?></td>
                            <td>
                                <?php 
                                // Extract from identity_key first, then fallback to user_id/guest_id
                                $identity_key = isset($iteration['identity_key']) ? $iteration['identity_key'] : '';
                                $user_id = isset($iteration['user_id']) ? intval($iteration['user_id']) : 0;
                                $guest_id = isset($iteration['guest_id']) ? $iteration['guest_id'] : '';
                                
                                // Priority: use user_id/guest_id first, then parse from identity_key
                                if ($user_id > 0) {
                                    if (isset($user_names_cache[$user_id])) {
                                        echo "U#" . $user_id . " (" . htmlspecialchars($user_names_cache[$user_id]) . ")";
                                    } else {
                                        echo "U#" . $user_id;
                                    }
                                } else if (!empty($guest_id)) {
                                    echo "G#" . substr($guest_id, 0, 8);
                                } else if (!empty($identity_key) && strpos($identity_key, 'user:') === 0) {
                                    // Fallback: parse from identity_key
                                    $parsed_user_id = intval(substr($identity_key, 5));
                                    if (isset($user_names_cache[$parsed_user_id])) {
                                        echo "U#" . $parsed_user_id . " (" . htmlspecialchars($user_names_cache[$parsed_user_id]) . ")";
                                    } else {
                                        echo "U#" . $parsed_user_id;
                                    }
                                } else if (!empty($identity_key) && strpos($identity_key, 'guest:') === 0) {
                                    // Fallback: parse from identity_key
                                    $parsed_guest_id = substr($identity_key, 6);
                                    echo "G#" . substr($parsed_guest_id, 0, 8);
                                } else {
                                    echo 'Unknown';
                                }
                                ?>
                            </td>
                            <td><?php echo isset($iteration['product_id']) ? htmlspecialchars($iteration['product_id']) : '-'; ?></td>
                            <td><?php echo isset($iteration['product_name']) ? htmlspecialchars($iteration['product_name']) : '-'; ?></td>
                            <td><?php echo isset($iteration['actual_rating']) ? htmlspecialchars($iteration['actual_rating']) : '-'; ?></td>
                            <td><?php echo isset($iteration['predicted_rating']) ? (floatval($iteration['predicted_rating']) > 0 ? htmlspecialchars($iteration['predicted_rating']) : '-') : '-'; ?></td>
                            <td><?php echo isset($iteration['absolute_error']) ? (floatval($iteration['absolute_error']) > 0 ? htmlspecialchars($iteration['absolute_error']) : '-') : '-'; ?></td>
                            <td>
                                <?php if (isset($iteration['status'])): ?>
                                    <?php if ($iteration['status'] === 'Valid'): ?>
                                        <span class="badge badge-valid"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($iteration['status']); ?></span>
                                    <?php else: ?>
                                        <span class="badge badge-invalid"><i class="fas fa-times-circle"></i> <?php echo htmlspecialchars($iteration['status']); ?></span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span>-</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php 
                                }
                            }
                        }
                        ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <div class="pagination-custom">
                    <?php
                    // Build query params preserving filters
                    $filter_params = [];
                    if (isset($_GET['user_filter']) && $_GET['user_filter'] !== '') {
                        $filter_params['user_filter'] = $_GET['user_filter'];
                    }
                    if (isset($_GET['product_filter']) && $_GET['product_filter'] !== '') {
                        $filter_params['product_filter'] = $_GET['product_filter'];
                    }
                    if (isset($_GET['status_filter']) && $_GET['status_filter'] !== '') {
                        $filter_params['status_filter'] = $_GET['status_filter'];
                    }
                    if (isset($_GET['sort_by']) && $_GET['sort_by'] !== '') {
                        $filter_params['sort_by'] = $_GET['sort_by'];
                    }

                    if ($current_page > 1) {
                        $p1_params = array_merge($filter_params, ['page' => 1]);
                        echo '<a href="?' . http_build_query($p1_params) . '"><i class="fas fa-step-backward"></i></a>';
                        $p_params = array_merge($filter_params, ['page' => ($current_page - 1)]);
                        echo '<a href="?' . http_build_query($p_params) . '"><i class="fas fa-chevron-left"></i></a>';
                    }
                    
                    for ($i = max(1, $current_page - 2); $i <= min($total_pages, $current_page + 2); $i++) {
                        if ($i === $current_page) {
                            echo '<span class="active">' . $i . '</span>';
                        } else {
                            $page_params = array_merge($filter_params, ['page' => $i]);
                            echo '<a href="?' . http_build_query($page_params) . '">' . $i . '</a>';
                        }
                    }
                    
                    if ($current_page < $total_pages) {
                        $pnext_params = array_merge($filter_params, ['page' => ($current_page + 1)]);
                        echo '<a href="?' . http_build_query($pnext_params) . '"><i class="fas fa-chevron-right"></i></a>';
                        $plast_params = array_merge($filter_params, ['page' => $total_pages]);
                        echo '<a href="?' . http_build_query($plast_params) . '"><i class="fas fa-step-forward"></i></a>';
                    }
                    ?>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <!-- Summary Section -->
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 24px;">
            <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(34, 139, 34, 0.05), rgba(45, 80, 22, 0.05));">
                <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                    <i class="fas fa-chart-pie" style="color: var(--primary-color); margin-right: 10px;"></i>
                    Ringkasan Evaluasi
                </h2>
            </div>
            <div style="padding: 24px;">
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 20px;">
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #228B22; text-align: center;">
                        <p style="color: #666; font-size: 0.9rem; margin-bottom: 8px; font-weight: 500;">
                            <i class="fas fa-list-ol"></i> Jumlah Rating
                        </p>
                        <p style="margin: 0; font-size: 2rem; font-weight: 700; color: #228B22;">
                            <?php echo isset($loocv_summary['total_ratings']) ? htmlspecialchars($loocv_summary['total_ratings']) : '0'; ?>
                        </p>
                    </div>
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #3b82f6; text-align: center;">
                        <p style="color: #666; font-size: 0.9rem; margin-bottom: 8px; font-weight: 500;">
                            <i class="fas fa-sync-alt"></i> Iterasi LOOCV
                        </p>
                        <p style="margin: 0; font-size: 2rem; font-weight: 700; color: #3b82f6;">
                            <?php echo isset($loocv_summary['total_iterations']) ? htmlspecialchars($loocv_summary['total_iterations']) : '0'; ?>
                        </p>
                    </div>
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #16a34a; text-align: center;">
                        <p style="color: #666; font-size: 0.9rem; margin-bottom: 8px; font-weight: 500;">
                            <i class="fas fa-check"></i> Prediksi Berhasil
                        </p>
                        <p style="margin: 0; font-size: 2rem; font-weight: 700; color: #16a34a;">
                            <?php echo isset($loocv_summary['successful_predictions']) ? htmlspecialchars($loocv_summary['successful_predictions']) : '0'; ?>
                        </p>
                    </div>
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #f59e0b; text-align: center;">
                        <p style="color: #666; font-size: 0.9rem; margin-bottom: 8px; font-weight: 500;">
                            <i class="fas fa-times"></i> Prediksi Gagal
                        </p>
                        <p style="margin: 0; font-size: 2rem; font-weight: 700; color: #f59e0b;">
                            <?php echo isset($loocv_summary['failed_predictions']) ? htmlspecialchars($loocv_summary['failed_predictions']) : '0'; ?>
                        </p>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; border-left: 4px solid #8b5cf6; text-align: center;">
                        <p style="color: #666; font-size: 0.9rem; margin-bottom: 8px; font-weight: 500;">
                            <i class="fas fa-calculator"></i> Total Absolute Error
                        </p>
                        <p style="margin: 0; font-size: 2rem; font-weight: 700; color: #8b5cf6;">
                            <?php echo isset($loocv_summary['total_absolute_error']) ? htmlspecialchars(number_format(floatval($loocv_summary['total_absolute_error']), 3)) : '0.000'; ?>
                        </p>
                    </div>
                    <div style="background: #e8f5e9; padding: 20px; border-radius: 8px; border-left: 4px solid #228B22; text-align: center;">
                        <p style="color: #1b5e20; font-size: 0.9rem; margin-bottom: 8px; font-weight: 500;">
                            <i class="fas fa-ruler"></i> Mean Absolute Error (MAE)
                        </p>
                        <p style="margin: 0; font-size: 2rem; font-weight: 700; color: #228B22;">
                            <?php echo isset($loocv_summary['mae']) ? htmlspecialchars(number_format(floatval($loocv_summary['mae']), 4)) : '0.0000'; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- MAE Formula Section -->
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 24px;">
            <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(34, 139, 34, 0.05), rgba(45, 80, 22, 0.05));">
                <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                    <i class="fas fa-formula" style="color: var(--primary-color); margin-right: 10px;"></i>
                    Proses Perhitungan MAE
                </h2>
            </div>
            <div style="padding: 24px;">
                <div style="background: #e8f5e9; border: 2px solid #4caf50; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
                    <p style="margin: 0 0 12px 0; color: #1b5e20; font-weight: 600;">
                        <i class="fas fa-check-circle"></i> Rumus Mean Absolute Error (MAE):
                    </p>
                    <div style="background: white; padding: 16px; border-radius: 6px; overflow-x: auto;">
                        <div style="margin: 0; color: #1b5e20; font-size: 0.95rem; text-align: center; line-height: 2;">
                            $$\text{MAE}=\frac{1}{n}\sum_{i=1}^{n}|P_i-R_i|$$
                        </div>
                    </div>
                </div>

                <div style="background: #f0f7ff; border: 2px solid #2196f3; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
                    <p style="margin: 0 0 12px 0; color: #1565c0; font-weight: 600;">
                        <i class="fas fa-info-circle"></i> Penjelasan Variabel:
                    </p>
                    <ul style="margin: 0; color: #1565c0; padding-left: 20px;">
                        <li><em>p<sub>i</sub></em> = Rating yang diprediksi menggunakan User-Based Collaborative Filtering dengan Cosine Similarity</li>
                        <li><em>r<sub>i</sub></em> = Rating aktual dari database</li>
                        <li><em>n</em> = Jumlah total rating yang dievaluasi dalam Leave-One-Out Cross Validation</li>
                        <li>|p<sub>i</sub> - r<sub>i</sub>| = Nilai absolut dari selisih prediksi dan aktual</li>
                    </ul>
                </div>

                <div style="background: #fff8e1; border: 2px solid #fbc02d; border-radius: 8px; padding: 16px;">
                    <p style="margin: 0 0 12px 0; color: #f57f17; font-weight: 600;">
                        <i class="fas fa-calculator"></i> Perhitungan Akhir:
                    </p>
                    <div style="background: white; padding: 16px; border-radius: 6px; overflow-x: auto;">
                        <p style="margin: 0; color: #f57f17; font-size: 0.95rem; text-align: center; line-height: 2;">
                            MAE = <?php echo isset($loocv_summary['total_absolute_error']) ? htmlspecialchars(number_format(floatval($loocv_summary['total_absolute_error']), 3)) : '0.000'; ?> / <?php echo isset($loocv_summary['total_iterations']) ? htmlspecialchars($loocv_summary['total_iterations']) : '0'; ?> = <strong><?php echo isset($loocv_summary['mae']) ? htmlspecialchars(number_format(floatval($loocv_summary['mae']), 4)) : '0.0000'; ?></strong>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Back Button -->
        <div style="margin-bottom: 40px;">
            <a href="evaluasi_mae.php" class="btn" style="background: linear-gradient(135deg, #666, #444); color: white; padding: 10px 20px; border: none; border-radius: 8px; font-weight: 600; text-decoration: none; display: inline-block;">
                <i class="fas fa-arrow-left"></i> Kembali ke Evaluasi MAE
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Render MathJax setelah halaman selesai dimuat
        if (window.MathJax) {
            MathJax.typesetPromise().catch(err => console.log(err));
        }

        // Mobile Menu Toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('show');
                sidebarOverlay.classList.toggle('active');
            });

            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('active');
            });

            const navLinks = document.querySelectorAll('.nav-link-admin');
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                });
            });

            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                }
            });
        }

        // Chart.js - Error Distribution Chart
        const ctx = document.getElementById('errorChart');
        if (ctx) {
            const errorData = {
                labels: ['0 - 0.5', '0.5 - 1', '1 - 1.5', '1.5 - 2', '> 2'],
                datasets: [{
                    label: 'Jumlah Data',
                    data: [
                        <?php echo htmlspecialchars($error_distribution['0-0.5']); ?>,
                        <?php echo htmlspecialchars($error_distribution['0.5-1']); ?>,
                        <?php echo htmlspecialchars($error_distribution['1-1.5']); ?>,
                        <?php echo htmlspecialchars($error_distribution['1.5-2']); ?>,
                        <?php echo htmlspecialchars($error_distribution['>2']); ?>
                    ],
                    backgroundColor: [
                        '#16a34a',
                        '#3b82f6',
                        '#f59e0b',
                        '#ef4444',
                        '#8b5cf6'
                    ],
                    borderColor: [
                        '#15803d',
                        '#1d4ed8',
                        '#d97706',
                        '#dc2626',
                        '#7c3aed'
                    ],
                    borderWidth: 2
                }]
            };

            new Chart(ctx, {
                type: 'bar',
                data: errorData,
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                stepSize: 1
                            },
                            title: {
                                display: true,
                                text: 'Jumlah Data'
                            }
                        },
                        x: {
                            title: {
                                display: true,
                                text: 'Range Absolute Error'
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Distribusi Error LOOCV'
                        }
                    }
                }
            });
        }
    </script>

    <style>
        @media print {
            .sidebar, .sidebar-toggle, .filter-card, .export-button, .btn {
                display: none !important;
            }
            .main-content {
                margin-left: 0 !important;
            }
            body {
                background: white !important;
            }
        }
    </style>
</body>
</html>
