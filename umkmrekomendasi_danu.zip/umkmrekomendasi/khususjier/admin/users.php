<?php
require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/session.php';
require_once dirname(dirname(__DIR__)) . '/classes/User.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isAdmin()) {
    header("Location: ../../access_denied.php");
    exit();
}

$user = new User($conn);
$users = $user->getAllUsers();

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'delete') {
        $user_id = $_POST['user_id'] ?? 0;
        
        if ($user_id == $_SESSION['user_id']) {
            $message = 'Anda tidak dapat menghapus akun sendiri';
            $message_type = 'danger';
        } else {
            $result = $user->deleteUser($user_id);
            $message = $result['message'];
            $message_type = $result['success'] ? 'success' : 'danger';
            
            if ($result['success']) {
                $users = $user->getAllUsers();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pengguna - Admin UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../../css/admin.css" rel="stylesheet">
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar Overlay untuk Mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-leaf"></i> UMKM Recommend
        </div>
        <a href="dashboard.php" class="nav-link-admin">
            <i class="fas fa-chart-line"></i> <span>Dashboard</span>
        </a>
        <a href="products.php" class="nav-link-admin">
            <i class="fas fa-box"></i> <span>Kelola Produk</span>
        </a>
        <a href="evaluasi_mae.php" class="nav-link-admin">
            <i class="fas fa-chart-bar"></i> <span>Evaluasi MAE</span>
        </a>
        <a href="users.php" class="nav-link-admin active">
            <i class="fas fa-users"></i> <span>Kelola Pengguna</span>
        </a>
        <hr style="border-color: rgba(255,255,255,0.2); margin: 20px 0;">
        <a href="profile.php" class="nav-link-admin">
            <i class="fas fa-user-cog"></i> <span>Profil Saya</span>
        </a>
        <a href="../../logout.php" class="nav-link-admin">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="dashboard-header">
            <div>
                <h1 class="dashboard-title"><i class="fas fa-users"></i> Kelola Pengguna</h1>
                <p style="color: #999; margin: 5px 0 0 0;">Lihat dan kelola pengguna terdaftar</p>
            </div>
        </div>

        <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert" style="margin-bottom: 24px;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <i class="fas fa-<?php echo ($message_type === 'success' ? 'check-circle' : 'exclamation-circle'); ?>"></i>
                <span><?php echo htmlspecialchars($message); ?></span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Users Table -->
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden;">
            <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(34, 139, 34, 0.05), rgba(45, 80, 22, 0.05));">
                <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                    <i class="fas fa-list" style="color: var(--primary-color); margin-right: 10px;"></i>
                    Daftar Pengguna Terdaftar
                </h2>
            </div>
            <div style="padding: 24px; overflow-x: auto;">
                <?php if (count($users) > 0): ?>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead style="background: #f8f9fa;">
                        <tr>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">No</th>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">Nama Lengkap</th>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">Email</th>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">Role</th>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">Terdaftar</th>
                            <th style="padding: 12px; text-align: center; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; foreach ($users as $u): ?>
                        <tr style="border-bottom: 1px solid var(--border-color); transition: background-color 0.3s;">
                            <td style="padding: 12px; color: var(--text-color);"><?php echo $no++; ?></td>
                            <td style="padding: 12px; color: var(--text-color); font-weight: 500;"><?php echo htmlspecialchars($u['name']); ?></td>
                            <td style="padding: 12px; color: #666;"><?php echo htmlspecialchars($u['email']); ?></td>
                            <td style="padding: 12px;">
                                <?php if ($u['is_admin'] == 1): ?>
                                    <span style="background: #fee2e2; color: #991b1b; padding: 4px 8px; border-radius: 4px; font-size: 0.85rem; font-weight: 600;">
                                        <i class="fas fa-shield"></i> Admin
                                    </span>
                                <?php else: ?>
                                    <span style="background: #f0f0f0; color: #666; padding: 4px 8px; border-radius: 4px; font-size: 0.85rem; font-weight: 600;">
                                        <i class="fas fa-user"></i> User
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td style="padding: 12px; color: #666;"><?php echo date('d M Y', strtotime($u['created_at'])); ?></td>
                            <td style="padding: 12px; text-align: center;">
                                <?php if ($u['id'] != $_SESSION['user_id']): ?>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Yakin ingin menghapus pengguna ini? Tindakan ini tidak dapat dibatalkan.');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="user_id" value="<?php echo $u['id']; ?>">
                                        <button type="submit" class="btn-action" style="background: #ef4444; color: white; padding: 6px 12px; border-radius: 4px; font-size: 0.85rem; border: none; cursor: pointer; transition: all 0.3s;">
                                            <i class="fas fa-trash"></i> Hapus
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span style="color: #999; font-size: 0.85rem; font-weight: 600;">
                                        <i class="fas fa-lock"></i> Akun Anda
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <p style="color: #999; text-align: center; padding: 40px 0;">Belum ada pengguna terdaftar</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('show');
                sidebarOverlay.classList.toggle('active');
            });

            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('active');
            });

            const navLinks = document.querySelectorAll('.nav-link-admin');
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                });
            });

            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>
