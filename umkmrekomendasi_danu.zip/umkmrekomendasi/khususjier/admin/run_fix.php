<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

require_once 'config/database.php';

echo "<h2>PERBAIKAN PRODUK - MULAI</h2>";

try {
    // STEP 1: Add columns
    $sqls = [
        "ALTER TABLE product_locations ADD COLUMN IF NOT EXISTS latitude DECIMAL(10, 8)",
        "ALTER TABLE product_locations ADD COLUMN IF NOT EXISTS longitude DECIMAL(11, 8)",
        "ALTER TABLE product_locations ADD COLUMN IF NOT EXISTS alamat_lengkap TEXT"
    ];
    
    foreach ($sqls as $sql) {
        if (!$conn->query($sql)) {
            echo "Error: " . $conn->error . "<br>";
        }
    }
    echo "✓ Kolom ditambahkan<br>";
    
    // STEP 2: Fix Nasi Uduk Bekasi
    $conn->query("DELETE FROM product_locations WHERE product_id = 1");
    
    $locations_nasi_uduk = [
        [1, 'Nasi Uduk - Jl. Merdeka', -6.2349, 107.0102, 'Jl. Merdeka No. 123, Bekasi Barat, Jawa Barat 17141'],
        [1, 'Nasi Uduk - Pasar Sentral', -6.1816, 107.1025, 'Pasar Sentral, Bekasi Timur, Jawa Barat 17112'],
        [1, 'Nasi Uduk - Warung Pinggir', -6.1934, 107.1520, 'Jl. Raya Kaliabang, Bekasi Utara, Jawa Barat 17125']
    ];
    
    foreach ($locations_nasi_uduk as $loc) {
        $sql = "INSERT INTO product_locations (product_id, lokasi, latitude, longitude, alamat_lengkap) VALUES ({$loc[0]}, '{$loc[1]}', {$loc[2]}, {$loc[3]}, '{$loc[4]}')";
        $conn->query($sql);
    }
    echo "✓ Nasi Uduk Bekasi: 3 lokasi ditambahkan<br>";
    
    // STEP 3: Fix Nasi Goreng NBA/UNA
    $conn->query("UPDATE products SET nama_produk = 'Nasi Goreng Perwira' WHERE nama_produk LIKE '%NBA%'");
    
    $result = $conn->query("SELECT id FROM products WHERE nama_produk = 'Nasi Goreng Perwira' LIMIT 1");
    $product = $result->fetch_assoc();
    $ng_id = $product['id'] ?? 2;
    
    $conn->query("DELETE FROM product_locations WHERE product_id = {$ng_id}");
    
    $locations_nasi_goreng = [
        [$ng_id, 'Nasi Goreng Perwira', -6.2015, 106.9952, 'Jl. KH. Muchtar Tabrani No.14, Perwira, Kec. Bekasi Utara, Kota Bekasi, Jawa Barat 17143'],
        [$ng_id, 'Warung Nasi - Kaliabang', -6.1885, 106.9930, 'Jl. Raya Kaliabang Tengah, Kaliabang Tengah, Kec. Bekasi Utara, Jawa Barat 17125'],
        [$ng_id, 'Warung Nasi - Harapan Jaya', -6.1935, 106.9985, 'Harapan Jaya, Kec. Bekasi Utara, Kota Bekasi, Jawa Barat 17124']
    ];
    
    foreach ($locations_nasi_goreng as $loc) {
        $sql = "INSERT INTO product_locations (product_id, lokasi, latitude, longitude, alamat_lengkap) VALUES ({$loc[0]}, '{$loc[1]}', {$loc[2]}, {$loc[3]}, '{$loc[4]}')";
        $conn->query($sql);
    }
    echo "✓ Nasi Goreng Perwira: 3 lokasi ditambahkan<br>";
    
    // STEP 4: Fix Nasi Uduk Betawi Ibu Hj. Adah
    $result = $conn->query("SELECT id FROM products WHERE nama_produk = 'Nasi Uduk Betawi Ibu Hj. Adah' LIMIT 1");
    $product = $result->fetch_assoc();
    $nuba_id = $product['id'] ?? 3;
    
    $conn->query("DELETE FROM product_locations WHERE product_id = {$nuba_id}");
    
    $locations_nuba = [
        [$nuba_id, 'Nasi Uduk Betawi Ibu Hj. Adah - Perwira', -6.1820, 106.9880, 'Jl. Ujung Harapan No.35, Perwira, Bekasi, Jawa Barat'],
        [$nuba_id, 'Warung Nasi - Kaliabang', -6.1885, 106.9930, 'Jl. Raya Kaliabang Tengah, Kaliabang Tengah, Bekasi Utara, Jawa Barat 17125'],
        [$nuba_id, 'Rumah Makan - Harapan Jaya', -6.1930, 106.9990, 'Area Harapan Jaya, Kec. Bekasi Utara, Kota Bekasi, Jawa Barat 17124']
    ];
    
    foreach ($locations_nuba as $loc) {
        $sql = "INSERT INTO product_locations (product_id, lokasi, latitude, longitude, alamat_lengkap) VALUES ({$loc[0]}, '{$loc[1]}', {$loc[2]}, {$loc[3]}, '{$loc[4]}')";
        $conn->query($sql);
    }
    echo "✓ Nasi Uduk Betawi Ibu Hj. Adah: 3 lokasi ditambahkan<br>";
    
    // STEP 5: Update all missing coordinates
    $conn->query("UPDATE product_locations SET 
        latitude = COALESCE(latitude, -6.19),
        longitude = COALESCE(longitude, 106.99),
        alamat_lengkap = COALESCE(NULLIF(alamat_lengkap, ''), CONCAT(lokasi, ', Bekasi Utara, Jawa Barat'))
        WHERE latitude IS NULL OR longitude IS NULL");
    
    echo "✓ Semua lokasi diupdate dengan koordinat<br>";
    echo "<h3>✓ PERBAIKAN SELESAI!</h3>";
    echo "Akses detail produk untuk test button 'Lokasi Terdekat'";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage();
}
?>
