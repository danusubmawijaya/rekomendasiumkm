<?php
// Fix Product Locations - Admin Script
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('memory_limit', '256M');
set_time_limit(300);

require_once dirname(__DIR__) . '/config/database.php';

// Allow direct access for migration (no session check)

echo "<!DOCTYPE html>
<html>
<head>
    <meta charset='UTF-8'>
    <title>Perbaiki Lokasi Produk</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
        .container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; }
        .status { margin: 20px 0; padding: 15px; border-radius: 4px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .warning { background: #fff3cd; color: #856404; border: 1px solid #ffeaa7; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #007bff; color: white; }
        tr:hover { background: #f5f5f5; }
        .btn { padding: 10px 20px; margin: 10px 0; border: none; border-radius: 4px; cursor: pointer; }
        .btn-primary { background: #007bff; color: white; }
        .btn-primary:hover { background: #0056b3; }
    </style>
</head>
<body>
<div class='container'>
    <h1>🔧 Perbaiki Lokasi Produk - Fix Product Locations</h1>
    <p>Script ini akan memperbaiki semua produk yang tidak memiliki titik lokasi terdekat, detail lokasi, dan koordinat GPS.</p>
    
    <hr>";

try {
    // STEP 1: Tambah kolom jika belum ada
    echo "<div class='status warning'><strong>Step 1:</strong> Menambah kolom latitude, longitude, alamat_lengkap...</div>";
    
    $sqls = [
        "ALTER TABLE product_locations ADD COLUMN IF NOT EXISTS latitude DECIMAL(10, 8) NULL",
        "ALTER TABLE product_locations ADD COLUMN IF NOT EXISTS longitude DECIMAL(11, 8) NULL",
        "ALTER TABLE product_locations ADD COLUMN IF NOT EXISTS alamat_lengkap TEXT NULL"
    ];
    
    foreach ($sqls as $sql) {
        if (!$conn->query($sql)) {
            throw new Exception("Error: " . $conn->error);
        }
    }
    
    echo "<div class='status success'>✓ Kolom ditambahkan berhasil</div>";
    
    // STEP 2: Perbaiki Nasi Uduk Bekasi
    echo "<div class='status warning'><strong>Step 2:</strong> Perbaiki 'Nasi Uduk Bekasi' - tambah 3 lokasi...</div>";
    
    $conn->query("DELETE FROM product_locations WHERE product_id = 1");
    
    $locations_nasi_uduk = [
        ['Nasi Uduk - Jl. Merdeka', -6.2349, 107.0102, 'Jl. Merdeka No. 123, Bekasi Barat, Jawa Barat 17141'],
        ['Nasi Uduk - Pasar Sentral', -6.1816, 107.1025, 'Pasar Sentral, Bekasi Timur, Jawa Barat 17112'],
        ['Nasi Uduk - Warung Pinggir', -6.1934, 107.1520, 'Jl. Raya Kaliabang, Bekasi Utara, Jawa Barat 17125']
    ];
    
    $inserted = 0;
    foreach ($locations_nasi_uduk as $loc) {
        $lokasi = $loc[0];
        $lat = $loc[1];
        $lng = $loc[2];
        $alamat = $loc[3];
        
        $stmt = $conn->prepare("INSERT INTO product_locations (product_id, lokasi, latitude, longitude, alamat_lengkap) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("isdds", $product_id, $lokasi, $lat, $lng, $alamat);
        $product_id = 1;
        if ($stmt->execute()) {
            $inserted++;
        }
        $stmt->close();
    }
    
    echo "<div class='status success'>✓ Berhasil menambah {$inserted} lokasi untuk Nasi Uduk Bekasi</div>";
    
    // STEP 3: Perbaiki Nasi Goreng NBA/UNA -> Nasi Goreng Perwira
    echo "<div class='status warning'><strong>Step 3:</strong> Ubah 'Nasi Goreng NBA/UNA' → 'Nasi Goreng Perwira'...</div>";
    
    $conn->query("UPDATE products SET nama_produk = 'Nasi Goreng Perwira' WHERE nama_produk LIKE '%NBA/UNA%'");
    
    $result = $conn->query("SELECT id FROM products WHERE nama_produk = 'Nasi Goreng Perwira' LIMIT 1");
    $product = $result->fetch_assoc();
    $ng_id = $product['id'] ?? null;
    
    if ($ng_id) {
        $conn->query("DELETE FROM product_locations WHERE product_id = {$ng_id}");
        
        $locations_nasi_goreng = [
            ['Nasi Goreng Perwira', -6.2015, 106.9952, 'Jl. KH. Muchtar Tabrani No.14, Perwira, Kec. Bekasi Utara, Kota Bekasi, Jawa Barat 17143'],
            ['Warung Nasi - Kaliabang', -6.1885, 106.9930, 'Jl. Raya Kaliabang Tengah, Kaliabang Tengah, Kec. Bekasi Utara, Jawa Barat 17125'],
            ['Warung Nasi - Harapan Jaya', -6.1935, 106.9985, 'Harapan Jaya, Kec. Bekasi Utara, Kota Bekasi, Jawa Barat 17124']
        ];
        
        $inserted = 0;
        foreach ($locations_nasi_goreng as $loc) {
            $lokasi = $loc[0];
            $lat = $loc[1];
            $lng = $loc[2];
            $alamat = $loc[3];
            
            $stmt = $conn->prepare("INSERT INTO product_locations (product_id, lokasi, latitude, longitude, alamat_lengkap) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("isdds", $ng_id, $lokasi, $lat, $lng, $alamat);
            if ($stmt->execute()) {
                $inserted++;
            }
            $stmt->close();
        }
        
        echo "<div class='status success'>✓ Nama diubah dan {$inserted} lokasi ditambahkan untuk Nasi Goreng Perwira</div>";
    }
    
    // STEP 4: Perbaiki Nasi Uduk Betawi Ibu Hj. Adah
    echo "<div class='status warning'><strong>Step 4:</strong> Perbaiki 'Nasi Uduk Betawi Ibu Hj. Adah'...</div>";
    
    $result = $conn->query("SELECT id FROM products WHERE nama_produk = 'Nasi Uduk Betawi Ibu Hj. Adah' LIMIT 1");
    $product = $result->fetch_assoc();
    $nuba_id = $product['id'] ?? null;
    
    if ($nuba_id) {
        $conn->query("DELETE FROM product_locations WHERE product_id = {$nuba_id}");
        
        $locations_nuba = [
            ['Nasi Uduk Betawi Ibu Hj. Adah - Perwira', -6.1820, 106.9880, 'Jl. Ujung Harapan No.35, Perwira, Bekasi, Jawa Barat'],
            ['Warung Nasi - Kaliabang', -6.1885, 106.9930, 'Jl. Raya Kaliabang Tengah, Kaliabang Tengah, Bekasi Utara, Jawa Barat 17125'],
            ['Rumah Makan - Harapan Jaya', -6.1930, 106.9990, 'Area Harapan Jaya, Kec. Bekasi Utara, Kota Bekasi, Jawa Barat 17124']
        ];
        
        $inserted = 0;
        foreach ($locations_nuba as $loc) {
            $lokasi = $loc[0];
            $lat = $loc[1];
            $lng = $loc[2];
            $alamat = $loc[3];
            
            $stmt = $conn->prepare("INSERT INTO product_locations (product_id, lokasi, latitude, longitude, alamat_lengkap) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("isdds", $nuba_id, $lokasi, $lat, $lng, $alamat);
            if ($stmt->execute()) {
                $inserted++;
            }
            $stmt->close();
        }
        
        echo "<div class='status success'>✓ {$inserted} lokasi ditambahkan untuk Nasi Uduk Betawi Ibu Hj. Adah</div>";
    }
    
    // STEP 5: Update semua lokasi yang belum punya koordinat
    echo "<div class='status warning'><strong>Step 5:</strong> Update lokasi tanpa koordinat dengan default Bekasi Utara...</div>";
    
    $conn->query("UPDATE product_locations SET 
        latitude = COALESCE(latitude, -6.19),
        longitude = COALESCE(longitude, 106.99),
        alamat_lengkap = COALESCE(NULLIF(alamat_lengkap, ''), CONCAT(lokasi, ', Bekasi Utara, Jawa Barat'))
        WHERE latitude IS NULL OR longitude IS NULL OR alamat_lengkap IS NULL OR alamat_lengkap = ''");
    
    echo "<div class='status success'>✓ Semua lokasi diperbarui dengan koordinat</div>";
    
    // STEP 6: Tampilkan hasil
    echo "<div class='status warning'><strong>Step 6:</strong> Hasil Perbaikan...</div>";
    
    $result = $conn->query("SELECT 
        p.id,
        p.nama_produk,
        COUNT(pl.id) as jumlah_lokasi,
        GROUP_CONCAT(pl.lokasi SEPARATOR ' | ') as lokasi_list
    FROM products p
    LEFT JOIN product_locations pl ON p.id = pl.product_id
    WHERE p.nama_produk IN ('Nasi Uduk Bekasi', 'Nasi Goreng Perwira', 'Nasi Uduk Betawi Ibu Hj. Adah')
    GROUP BY p.id, p.nama_produk
    ORDER BY p.id");
    
    echo "<table>
    <tr>
        <th>ID</th>
        <th>Nama Produk</th>
        <th>Jumlah Lokasi</th>
        <th>Lokasi</th>
    </tr>";
    
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['nama_produk']}</td>
            <td>{$row['jumlah_lokasi']}</td>
            <td>" . substr($row['lokasi_list'], 0, 100) . "...</td>
        </tr>";
    }
    
    echo "</table>";
    
    // STEP 7: Tampilkan detail lengkap
    echo "<h2>Detail Lokasi Lengkap:</h2>";
    
    $result = $conn->query("SELECT 
        p.id,
        p.nama_produk,
        pl.lokasi,
        pl.latitude,
        pl.longitude,
        pl.alamat_lengkap
    FROM products p
    LEFT JOIN product_locations pl ON p.id = pl.product_id
    WHERE p.nama_produk IN ('Nasi Uduk Bekasi', 'Nasi Goreng Perwira', 'Nasi Uduk Betawi Ibu Hj. Adah')
    ORDER BY p.id, pl.id");
    
    echo "<table>
    <tr>
        <th>ID Produk</th>
        <th>Produk</th>
        <th>Lokasi</th>
        <th>Lat</th>
        <th>Lng</th>
        <th>Alamat Lengkap</th>
    </tr>";
    
    while ($row = $result->fetch_assoc()) {
        $alamat = substr($row['alamat_lengkap'], 0, 50);
        echo "<tr>
            <td>{$row['id']}</td>
            <td>{$row['nama_produk']}</td>
            <td>{$row['lokasi']}</td>
            <td>{$row['latitude']}</td>
            <td>{$row['longitude']}</td>
            <td>{$alamat}...</td>
        </tr>";
    }
    
    echo "</table>";
    
    echo "<div class='status success'>
        <strong>✓ Perbaikan Selesai!</strong><br>
        • Semua produk sekarang memiliki minimum 3 lokasi<br>
        • Semua lokasi memiliki koordinat GPS<br>
        • Nama produk NBA/UNA sudah diganti menjadi Nasi Goreng Perwira<br>
        • Sistem siap menampilkan 'Lokasi Terdekat' dengan akurat
    </div>";
    
    echo "<a href='dashboard.php'><button class='btn btn-primary'>← Kembali ke Dashboard</button></a>";

} catch (Exception $e) {
    echo "<div class='status error'>
        <strong>❌ Error:</strong> " . htmlspecialchars($e->getMessage()) . "
    </div>";
}

?>
</div>
</body>
</html>
