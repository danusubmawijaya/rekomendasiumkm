<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/session.php';
require_once dirname(dirname(__DIR__)) . '/classes/Product.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isAdmin()) {
    header("Location: ../../access_denied.php");
    exit();
}

$product = new Product($conn);
$products = $product->getAllProducts();
$categories = $product->getAllCategories();

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'add') {
        $nama_produk = $_POST['nama_produk'] ?? '';
        $deskripsi = $_POST['deskripsi'] ?? '';
        $kategori = $_POST['kategori'] ?? 'Lainnya';
        $locations = $_POST['lokasi'] ?? [];
        $latitudes = $_POST['latitude'] ?? [];
        $longitudes = $_POST['longitude'] ?? [];
        
        $gambar = null;
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $upload_result = $product->uploadImage($_FILES['gambar']);
            if (!$upload_result['success']) {
                $message = $upload_result['message'];
                $message_type = 'danger';
            } else {
                $gambar = $upload_result['filepath'];
            }
        }
        
        if (!$message) {
            $result = $product->addProduct($nama_produk, $deskripsi, $gambar, $kategori, $locations, $latitudes, $longitudes);
            
            $message = $result['message'];
            $message_type = $result['success'] ? 'success' : 'danger';
            
            // Log semua lokasi yang dikirim untuk debugging
            error_log("Total locations received: " . count($locations));
            
            if (!empty($result['location_errors'])) {
                $message .= '<br><small style="margin-top: 8px; display: block;">';
                foreach (array_slice($result['location_errors'], 0, 3) as $err) {
                    $message .= '• ' . htmlspecialchars($err) . '<br>';
                }
                if (count($result['location_errors']) > 3) {
                    $message .= '• ' . (count($result['location_errors']) - 3) . ' alamat lain juga gagal';
                }
                $message .= '</small>';
            }
            
            if ($result['success']) {
                $products = $product->getAllProducts();
            }
        }
    } elseif ($action == 'update') {
        $product_id = $_POST['product_id'] ?? 0;
        $nama_produk = $_POST['nama_produk'] ?? '';
        $deskripsi = $_POST['deskripsi'] ?? '';
        $kategori = $_POST['kategori'] ?? 'Lainnya';
        $locations = $_POST['lokasi'] ?? [];
        $latitudes = $_POST['latitude'] ?? [];
        $longitudes = $_POST['longitude'] ?? [];
        $location_ids = $_POST['location_id'] ?? [];
        
        $current_product = $product->getProductById($product_id);
        $gambar = $current_product['gambar'];
        
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $upload_result = $product->uploadImage($_FILES['gambar']);
            if (!$upload_result['success']) {
                $message = $upload_result['message'];
                $message_type = 'danger';
            } else {
                if ($gambar) {
                    $product->deleteImage($gambar);
                }
                $gambar = $upload_result['filepath'];
            }
        }
        
        if (!$message) {
            $update_query = "UPDATE products SET nama_produk = ?, deskripsi = ?, gambar = ?, kategori = ? WHERE id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param("ssssi", $nama_produk, $deskripsi, $gambar, $kategori, $product_id);
            
            // Log semua lokasi yang dikirim untuk debugging
            error_log("Total locations received for update: " . count($locations));
            
            if ($stmt->execute()) {
                $updated_ids = [];
                
                // Proses setiap lokasi (update atau insert baru)
                foreach ($locations as $idx => $lokasi) {
                    $lokasi_trimmed = trim($lokasi);
                    
                    if (empty($lokasi_trimmed)) continue;
                    
                    $loc_id = isset($location_ids[$idx]) ? intval($location_ids[$idx]) : 0;
                    $lat = isset($latitudes[$idx]) ? trim($latitudes[$idx]) : '';
                    $lng = isset($longitudes[$idx]) ? trim($longitudes[$idx]) : '';
                    
                    if ($loc_id > 0) {
                        // Update lokasi yang sudah ada
                        $updated_ids[] = $loc_id;
                        
                        if (!empty($lat) && !empty($lng) && is_numeric($lat) && is_numeric($lng)) {
                            $lat_f = floatval($lat);
                            $lng_f = floatval($lng);
                            $update_loc_query = "UPDATE product_locations SET lokasi = ?, latitude = ?, longitude = ? WHERE id = ? AND product_id = ?";
                            $stmt_loc = $conn->prepare($update_loc_query);
                            $stmt_loc->bind_param("sddii", $lokasi_trimmed, $lat_f, $lng_f, $loc_id, $product_id);
                            $stmt_loc->execute();
                            $stmt_loc->close();
                        } else {
                            $update_loc_query = "UPDATE product_locations SET lokasi = ? WHERE id = ? AND product_id = ?";
                            $stmt_loc = $conn->prepare($update_loc_query);
                            $stmt_loc->bind_param("sii", $lokasi_trimmed, $loc_id, $product_id);
                            $stmt_loc->execute();
                            $stmt_loc->close();
                        }
                    } else {
                        // Tambah lokasi baru
                        if (!empty($lat) && !empty($lng) && is_numeric($lat) && is_numeric($lng)) {
                            $lat_f = floatval($lat);
                            $lng_f = floatval($lng);
                            $insert_query = "INSERT INTO product_locations (product_id, lokasi, latitude, longitude) VALUES (?, ?, ?, ?)";
                            $stmt_loc = $conn->prepare($insert_query);
                            $stmt_loc->bind_param("isdd", $product_id, $lokasi_trimmed, $lat_f, $lng_f);
                            $stmt_loc->execute();
                            $new_id = $stmt_loc->insert_id;
                            $updated_ids[] = $new_id; // Tambahkan ID baru ke daftar
                            $stmt_loc->close();
                        } else {
                            $insert_query = "INSERT INTO product_locations (product_id, lokasi) VALUES (?, ?)";
                            $stmt_loc = $conn->prepare($insert_query);
                            $stmt_loc->bind_param("is", $product_id, $lokasi_trimmed);
                            $stmt_loc->execute();
                            $new_id = $stmt_loc->insert_id;
                            $updated_ids[] = $new_id; // Tambahkan ID baru ke daftar
                            $stmt_loc->close();
                        }
                    }
                }
                
                // Hapus lokasi lama yang tidak ada di list baru
                if (!empty($updated_ids)) {
                    $id_list = implode(',', $updated_ids);
                    $delete_old_query = "DELETE FROM product_locations WHERE product_id = ? AND id NOT IN ($id_list)";
                    $stmt_del = $conn->prepare($delete_old_query);
                    $stmt_del->bind_param("i", $product_id);
                    $stmt_del->execute();
                    $stmt_del->close();
                } else {
                    // Jika tidak ada lokasi sama sekali, hapus semua lokasi lama
                    $delete_all_query = "DELETE FROM product_locations WHERE product_id = ?";
                    $stmt_del = $conn->prepare($delete_all_query);
                    $stmt_del->bind_param("i", $product_id);
                    $stmt_del->execute();
                    $stmt_del->close();
                }
                
                $message = '✓ Produk dan lokasi berhasil diperbarui';
                $message_type = 'success';
                $products = $product->getAllProducts();
            } else {
                $message = 'Gagal memperbarui produk: ' . $stmt->error;
                $message_type = 'danger';
            }
            $stmt->close();
        }
    } elseif ($action == 'delete') {
        $product_id = $_POST['product_id'] ?? 0;
        
        $result = $product->deleteProduct($product_id);
        $message = $result['message'];
        $message_type = $result['success'] ? 'success' : 'danger';
        
        if ($result['success']) {
            $products = $product->getAllProducts();
        }
    }
}

$edit_product = null;
if (isset($_GET['edit'])) {
    $edit_id = $_GET['edit'];
    $edit_product = $product->getProductById($edit_id);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Produk - Admin UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../../css/admin.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6A00;
            --secondary-color: #E85D04;
            --dark-color: #2d2d2d;
            --light-color: #FFF1E6;
            --text-color: #1f2937;
            --border-color: #F97316;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
        }

        .sidebar {
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            padding: 20px 0;
            position: fixed;
            left: 0;
            width: 250px;
            color: white;
            overflow-y: auto;
        }

        .sidebar-brand {
            padding: 20px;
            text-align: center;
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 30px;
            border-bottom: 2px solid rgba(255,255,255,0.2);
        }

        .nav-link-admin {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .nav-link-admin:hover {
            background-color: rgba(255,255,255,0.1);
            color: white;
            border-left-color: white;
        }

        .nav-link-admin.active {
            background-color: rgba(255,255,255,0.15);
            color: white;
            border-left-color: white;
        }

        .main-content {
            margin-left: 250px;
            padding: 30px;
        }

        .page-header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--border-color);
        }

        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark-color);
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--border-color);
        }

        .dashboard-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark-color);
            margin: 0;
        }

        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .card {
            border: 1px solid var(--border-color);
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-radius: 12px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--dark-color));
        }

        .btn-action {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 0.85rem;
            margin-right: 6px;
            transition: all 0.3s;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table thead {
            background: #f8f9fa;
        }

        table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: var(--dark-color);
            border-bottom: 2px solid var(--border-color);
        }

        table td {
            padding: 12px;
            color: var(--text-color);
            border-bottom: 1px solid var(--border-color);
        }

        table tbody tr:hover {
            background-color: #f0f8f0;
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 1050;
            align-items: center;
            justify-content: center;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            background: white;
            border-radius: 12px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
        }

        .modal-header {
            padding: 20px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-body {
            padding: 24px;
        }

        .modal-footer {
            padding: 16px 24px;
            border-top: 1px solid var(--border-color);
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--dark-color);
        }

        .form-control {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: inherit;
            font-size: 0.95rem;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(34, 139, 34, 0.1);
        }

        textarea.form-control {
            resize: vertical;
            min-height: 80px;
        }

        .location-field {
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 8px;
        }

        .location-field input {
            display: block;
            width: 100%;
            margin-bottom: 8px;
        }

        .location-coords {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
            margin-bottom: 8px;
        }

        .location-coords input {
            display: block;
            width: 100%;
        }

        .btn-remove-location {
            padding: 6px 10px;
            background: #ef4444;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            width: 100%;
            justify-self: end;
        }

        .btn-remove-location:hover {
            background: #dc2626;
        }

        .btn-add-location {
            padding: 4px 8px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            font-weight: 600;
            margin-left: 8px;
        }

        .btn-add-location:hover {
            background: var(--secondary-color);
        }

        .img-preview {
            max-width: 100%;
            height: auto;
            margin-top: 12px;
            border-radius: 8px;
            display: none;
        }

        .help-text {
            display: block;
            color: #999;
            margin-top: 6px;
            font-size: 0.85rem;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .main-content {
                margin-left: 200px;
                padding: 20px;
            }

            .dashboard-title {
                font-size: 1.5rem;
            }
        }

        /* Search Styles */
        .table-hidden {
            display: none;
        }

        .table-visible {
            display: table-row;
        }

        .search-highlight {
            background-color: #fffacd;
        }

        .search-empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .search-empty-state i {
            font-size: 3rem;
            color: #ddd;
            margin-bottom: 16px;
        }

        .search-empty-state h3 {
            color: #666;
            font-size: 1.1rem;
            margin-bottom: 8px;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .main-content {
                margin-left: 200px;
                padding: 20px;
            }

            .dashboard-title {
                font-size: 1.5rem;
            }

            /* Stack search and button vertically on smaller screens */
            #searchProducts {
                min-width: 100%;
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                width: 150px;
                padding: 10px 0;
            }

            .main-content {
                margin-left: 150px;
                padding: 15px;
            }

            .nav-link-admin {
                padding: 10px 15px;
                font-size: 0.85rem;
            }

            #searchProducts {
                min-width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-leaf"></i> UMKM Recommend
        </div>
        <a href="dashboard.php" class="nav-link-admin">
            <i class="fas fa-chart-line"></i> <span>Dashboard</span>
        </a>
        <a href="products.php" class="nav-link-admin active">
            <i class="fas fa-box"></i> <span>Kelola Produk</span>
        </a>
        <a href="evaluasi_mae.php" class="nav-link-admin">
            <i class="fas fa-chart-bar"></i> <span>Evaluasi MAE</span>
        </a>
        <a href="users.php" class="nav-link-admin">
            <i class="fas fa-users"></i> <span>Kelola Pengguna</span>
        </a>
        <hr style="border-color: rgba(255,255,255,0.2); margin: 20px 0;">
        <a href="profile.php" class="nav-link-admin">
            <i class="fas fa-user-cog"></i> <span>Profil Saya</span>
        </a>
        <a href="../../logout.php" class="nav-link-admin">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="dashboard-header">
            <div>
                <h1 class="dashboard-title"><i class="fas fa-box"></i> Kelola Produk</h1>
                <p style="color: #999; margin: 5px 0 0 0;">Tambah, edit, atau hapus produk UMKM</p>
            </div>
        </div>

        <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert" style="margin-bottom: 24px;">
            <div style="display: flex; align-items: flex-start; gap: 8px;">
                <i class="fas fa-<?php echo ($message_type === 'success' ? 'check-circle' : ($message_type === 'warning' ? 'exclamation-triangle' : 'exclamation-circle')); ?>" style="margin-top: 2px;"></i>
                <span><?php echo $message; ?></span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Add Button & Search -->
        <div style="margin-bottom: 24px; display: flex; gap: 12px; align-items: center; flex-wrap: wrap;">
            <button onclick="openAddProductModal()" class="btn btn-primary" style="padding: 10px 24px; border: none; border-radius: 8px; font-weight: 600; transition: all 0.3s; cursor: pointer;">
                <i class="fas fa-plus"></i> Tambah Produk Baru
            </button>
            <div style="position: relative; flex: 1; min-width: 250px;">
                <input 
                    type="text" 
                    id="searchProducts" 
                    placeholder="Cari nama produk..." 
                    class="form-control" 
                    style="padding-left: 40px; border-radius: 8px; border: 2px solid var(--border-color); transition: all 0.3s;"
                    onkeyup="searchProductTable()"
                    onfocus="this.style.borderColor = 'var(--primary-color)'; this.style.boxShadow = '0 0 0 3px rgba(34, 139, 34, 0.1)';"
                    onblur="this.style.borderColor = 'var(--border-color)'; this.style.boxShadow = 'none';"
                >
                <i class="fas fa-search" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: var(--primary-color); font-size: 1rem;"></i>
                <span id="searchResultCount" style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); font-size: 0.85rem; color: #999; display: none;"></span>
            </div>
        </div>

        <!-- Products Table -->
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden;">
            <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(34, 139, 34, 0.05), rgba(45, 80, 22, 0.05));">
                <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                    <i class="fas fa-list" style="color: var(--primary-color); margin-right: 10px;"></i>
                    Daftar Produk
                </h2>
            </div>
            <div style="padding: 24px; overflow-x: auto;">
                <?php if (count($products) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Gambar</th>
                            <th>Nama Produk</th>
                            <th>Kategori</th>
                            <th>Lokasi</th>
                            <th>Rating</th>
                            <th style="text-align: center;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $prod): ?>
                        <tr>
                            <td><?php echo $prod['id']; ?></td>
                            <td>
                                <?php if ($prod['gambar'] && file_exists('../../' . $prod['gambar'])): ?>
                                    <img src="../../<?php echo htmlspecialchars($prod['gambar']); ?>" alt="<?php echo htmlspecialchars($prod['nama_produk']); ?>" 
                                         style="max-width: 50px; height: 50px; object-fit: cover; border-radius: 6px;">
                                <?php else: ?>
                                    <span style="background: #e0e0e0; padding: 4px 8px; border-radius: 4px; font-size: 0.85rem; color: #999;">Tidak ada</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-weight: 500;"><?php echo htmlspecialchars($prod['nama_produk']); ?></td>
                            <td><?php echo htmlspecialchars($prod['kategori'] ?? 'Lainnya'); ?></td>
                            <td>
                                <?php if (!empty($prod['locations'])): ?>
                                    <div style="max-width: 250px; overflow-y: auto; max-height: 80px; border: 1px solid #ddd; border-radius: 4px; padding: 4px;">
                                        <?php foreach ($prod['locations'] as $loc): ?>
                                            <div style="font-size: 0.75rem; color: #333; padding: 4px 0; border-bottom: 1px solid #f0f0f0;">
                                                <div style="font-weight: 600; color: #1a1a1a;">• <?php echo htmlspecialchars(substr($loc['lokasi'], 0, 40)); ?><?php if(strlen($loc['lokasi']) > 40) echo '...'; ?></div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php else: ?>
                                    <span style="color: #999; font-size: 0.85rem;">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (isset($prod['avg_rating']) && $prod['avg_rating']): ?>
                                    <span style="background: #e8f5e9; color: #1b5e20; padding: 4px 8px; border-radius: 4px; font-size: 0.85rem; font-weight: 600;">
                                        ★ <?php echo number_format($prod['avg_rating'], 1); ?>
                                    </span>
                                <?php else: ?>
                                    <span style="background: #f0f0f0; color: #999; padding: 4px 8px; border-radius: 4px; font-size: 0.85rem;">Belum ada</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center;">
                                <a href="?edit=<?php echo $prod['id']; ?>" class="btn-action" style="background: #3b82f6; color: white;">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Yakin ingin menghapus produk ini?');">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="product_id" value="<?php echo $prod['id']; ?>">
                                    <button type="submit" class="btn-action" style="background: #ef4444; color: white; border: none; cursor: pointer;">
                                        <i class="fas fa-trash"></i> Hapus
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else: ?>
                <p style="color: #999; text-align: center; padding: 40px 0;">Belum ada produk. <a href="#" onclick="openAddProductModal()" style="color: var(--primary-color); text-decoration: none; font-weight: 600;">Tambah sekarang</a></p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal Tambah Produk -->
    <div id="addProductModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">Tambah Produk Baru</h2>
                <button onclick="closeAddProductModal()" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #999;">×</button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="form-group">
                        <label class="form-label">Nama Produk *</label>
                        <input type="text" name="nama_produk" class="form-control" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Deskripsi *</label>
                        <textarea name="deskripsi" class="form-control" required></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Kategori *</label>
                        <select name="kategori" class="form-control" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php if (!empty($categories)): ?>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat); ?>"><?php echo htmlspecialchars($cat); ?></option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">
                            Lokasi UMKM (Tidak ada batasan - bisa tambah unlimited)
                            <button type="button" onclick="addLocationField('addLocations')" class="btn-add-location">
                                <i class="fas fa-plus"></i> Tambah Lokasi
                            </button>
                        </label>
                        <div id="addLocations">
                            <div class="location-field" data-index="0">
                                <div style="margin-bottom: 10px;">
                                    <input type="text" name="lokasi[0]" placeholder="Contoh: Jl. KH. Muchtar Tabrani No.14, Bekasi..." class="form-control" required />
                                </div>
                                <div class="location-coords">
                                    <div>
                                        <input type="number" name="latitude[0]" placeholder="Latitude (opsional)" step="any" class="form-control" />
                                        <small class="help-text">Cth: -6.2146013</small>
                                    </div>
                                    <div>
                                        <input type="number" name="longitude[0]" placeholder="Longitude (opsional)" step="any" class="form-control" />
                                        <small class="help-text">Cth: 107.003479</small>
                                    </div>
                                </div>
                                <button type="button" onclick="removeLocationField(this)" class="btn-remove-location">
                                    <i class="fas fa-times"></i> Hapus
                                </button>
                            </div>
                        </div>
                        <small class="help-text">
                            <i class="fas fa-info-circle"></i> <strong>Alamat:</strong> Wajib diisi (jl., kelurahan, kota)<br/>
                            <i class="fas fa-map-pin"></i> <strong>Lat/Lng:</strong> Opsional (gunakan <a href="https://maps.google.com" target="_blank" style="color: #3b82f6;">Google Maps</a>)
                        </small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Gambar Produk</label>
                        <input type="file" name="gambar" accept="image/*" onchange="previewImage(this, 'addImagePreview')" class="form-control">
                        <small class="help-text">Format: JPG, PNG, GIF, WebP (Max 5MB)</small>
                        <img id="addImagePreview" class="img-preview" alt="Preview">
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" onclick="closeAddProductModal()" class="btn btn-secondary" style="padding: 10px 24px; border: 1px solid #ddd; border-radius: 8px; background: white; color: var(--text-color); cursor: pointer; font-weight: 600;">
                        Batal
                    </button>
                    <button type="submit" class="btn btn-primary" style="padding: 10px 24px; border: none; cursor: pointer; font-weight: 600; color: white;">
                        Tambah Produk
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Edit Produk -->
    <?php if ($edit_product): ?>
    <div id="editProductModal" class="modal show">
        <div class="modal-content">
            <div class="modal-header">
                <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">Edit Produk</h2>
                <a href="products.php" style="background: none; border: none; font-size: 1.5rem; cursor: pointer; color: #999; text-decoration: none;">×</a>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="product_id" value="<?php echo $edit_product['id']; ?>">
                    
                    <div class="form-group">
                        <label class="form-label">Nama Produk</label>
                        <input type="text" name="nama_produk" class="form-control" value="<?php echo htmlspecialchars($edit_product['nama_produk']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Deskripsi</label>
                        <textarea name="deskripsi" class="form-control" required><?php echo htmlspecialchars($edit_product['deskripsi']); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Kategori</label>
                        <select name="kategori" class="form-control" required>
                            <?php if (!empty($categories)): ?>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo ($edit_product['kategori'] == $cat) ? 'selected' : ''; ?>><?php echo htmlspecialchars($cat); ?></option>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <option value="Makanan Berat" <?php echo ($edit_product['kategori'] == 'Makanan Berat') ? 'selected' : ''; ?>>Makanan Berat</option>
                                <option value="Jajanan & Street Food" <?php echo ($edit_product['kategori'] == 'Jajanan & Street Food') ? 'selected' : ''; ?>>Jajanan & Street Food</option>
                                <option value="Minuman" <?php echo ($edit_product['kategori'] == 'Minuman') ? 'selected' : ''; ?>>Minuman</option>
                                <option value="Makanan Rumahan" <?php echo ($edit_product['kategori'] == 'Makanan Rumahan') ? 'selected' : ''; ?>>Makanan Rumahan</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">
                            Lokasi UMKM (Tidak ada batasan - bisa tambah unlimited)
                            <button type="button" onclick="addLocationField('editLocations')" class="btn-add-location">
                                <i class="fas fa-plus"></i> Tambah Lokasi
                            </button>
                        </label>
                        <div id="editLocations">
                            <?php if (!empty($edit_product['locations'])): ?>
                                <?php foreach ($edit_product['locations'] as $idx => $loc): ?>
                                    <div class="location-field" data-index="<?php echo $idx; ?>">
                                        <input type="hidden" name="location_id[<?php echo $idx; ?>]" value="<?php echo $loc['id']; ?>">
                                        <div style="margin-bottom: 10px;">
                                            <input type="text" name="lokasi[<?php echo $idx; ?>]" placeholder="Contoh: Jl. KH. Muchtar Tabrani No.14, Bekasi..." class="form-control" value="<?php echo htmlspecialchars($loc['lokasi']); ?>" required />
                                        </div>
                                        <div class="location-coords">
                                            <div>
                                                <input type="number" name="latitude[<?php echo $idx; ?>]" placeholder="Latitude (opsional)" step="any" class="form-control" value="<?php echo htmlspecialchars($loc['latitude'] ?? ''); ?>" />
                                                <small class="help-text">Cth: -6.2146013</small>
                                            </div>
                                            <div>
                                                <input type="number" name="longitude[<?php echo $idx; ?>]" placeholder="Longitude (opsional)" step="any" class="form-control" value="<?php echo htmlspecialchars($loc['longitude'] ?? ''); ?>" />
                                                <small class="help-text">Cth: 107.003479</small>
                                            </div>
                                        </div>
                                        <button type="button" onclick="removeLocationField(this)" class="btn-remove-location">
                                            <i class="fas fa-times"></i> Hapus
                                        </button>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="location-field" data-index="0">
                                    <div style="margin-bottom: 10px;">
                                        <input type="text" name="lokasi[0]" placeholder="Contoh: Jl. KH. Muchtar Tabrani No.14, Bekasi..." class="form-control" />
                                    </div>
                                    <div class="location-coords">
                                        <div>
                                            <input type="number" name="latitude[0]" placeholder="Latitude (opsional)" step="any" class="form-control" />
                                            <small class="help-text">Cth: -6.2146013</small>
                                        </div>
                                        <div>
                                            <input type="number" name="longitude[0]" placeholder="Longitude (opsional)" step="any" class="form-control" />
                                            <small class="help-text">Cth: 107.003479</small>
                                        </div>
                                    </div>
                                    <button type="button" onclick="removeLocationField(this)" class="btn-remove-location">
                                        <i class="fas fa-times"></i> Hapus
                                    </button>
                                </div>
                            <?php endif; ?>
                        </div>
                        <small class="help-text">
                            <i class="fas fa-info-circle"></i> <strong>Alamat:</strong> Wajib diisi (jl., kelurahan, kota)<br/>
                            <i class="fas fa-map-pin"></i> <strong>Lat/Lng:</strong> Opsional (gunakan <a href="https://maps.google.com" target="_blank" style="color: #3b82f6;">Google Maps</a>)
                        </small>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Gambar Produk</label>
                        <?php if ($edit_product['gambar'] && file_exists('../../' . $edit_product['gambar'])): ?>
                            <div style="margin-bottom: 12px;">
                                <img src="../../<?php echo htmlspecialchars($edit_product['gambar']); ?>" alt="<?php echo htmlspecialchars($edit_product['nama_produk']); ?>" style="max-width: 200px; border-radius: 4px;">
                                <p style="color: #999; font-size: 0.85rem; margin-top: 4px;">Gambar saat ini</p>
                            </div>
                        <?php endif; ?>
                        <input type="file" name="gambar" accept="image/*" onchange="previewImage(this, 'editImagePreview')" class="form-control">
                        <small class="help-text">Biarkan kosong untuk tidak mengubah gambar</small>
                        <img id="editImagePreview" class="img-preview" alt="Preview">
                    </div>
                </div>
                
                <div class="modal-footer">
                    <a href="products.php" class="btn btn-secondary" style="padding: 10px 24px; border: 1px solid #ddd; border-radius: 8px; background: white; color: var(--text-color); cursor: pointer; font-weight: 600; text-decoration: none;">
                        Batal
                    </a>
                    <button type="submit" class="btn btn-primary" style="padding: 10px 24px; border: none; cursor: pointer; font-weight: 600; color: white;">
                        Simpan Perubahan
                    </button>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function openAddProductModal() {
            document.getElementById('addProductModal').classList.add('show');
            document.getElementById('addProductModal').style.display = 'flex';
        }

        function closeAddProductModal() {
            document.getElementById('addProductModal').classList.remove('show');
            document.getElementById('addProductModal').style.display = 'none';
        }

        function searchProductTable() {
            const searchInput = document.getElementById('searchProducts');
            const searchTerm = searchInput.value.toLowerCase().trim();
            const table = document.querySelector('table tbody');
            const rows = table ? table.querySelectorAll('tr') : [];
            let visibleCount = 0;

            if (!table) return;

            rows.forEach(row => {
                const productName = row.querySelector('td:nth-child(3)')?.textContent.toLowerCase() || '';
                const category = row.querySelector('td:nth-child(4)')?.textContent.toLowerCase() || '';
                
                // Search in product name and category
                const matches = productName.includes(searchTerm) || category.includes(searchTerm);
                
                if (searchTerm === '') {
                    row.style.display = '';
                    visibleCount++;
                } else if (matches) {
                    row.style.display = '';
                    visibleCount++;
                    
                    // Highlight matching text in product name
                    const nameCell = row.querySelector('td:nth-child(3)');
                    if (nameCell && searchTerm) {
                        const originalText = nameCell.textContent;
                        const regex = new RegExp(`(${searchTerm})`, 'gi');
                        nameCell.innerHTML = originalText.replace(regex, '<mark style="background-color: #fffacd; font-weight: 600;">$1</mark>');
                    }
                } else {
                    row.style.display = 'none';
                }
            });

            // Show/hide "no results" message
            updateEmptyState(visibleCount, searchTerm);
            updateSearchResultCount(visibleCount, searchTerm);
        }

        function updateEmptyState(visibleCount, searchTerm) {
            const container = document.querySelector('[style*="padding: 24px"]');
            if (!container) return;

            let emptyState = container.querySelector('.search-empty-state');
            
            if (visibleCount === 0 && searchTerm !== '') {
                if (!emptyState) {
                    emptyState = document.createElement('div');
                    emptyState.className = 'search-empty-state';
                    container.appendChild(emptyState);
                }
                emptyState.innerHTML = `
                    <i class="fas fa-search"></i>
                    <h3>Produk tidak ditemukan</h3>
                    <p>Tidak ada produk yang cocok dengan "<strong>${searchTerm}</strong>"</p>
                    <p style="font-size: 0.9rem; color: #aaa;">Coba cari dengan nama produk lain</p>
                `;
                emptyState.style.display = 'block';
            } else if (emptyState) {
                emptyState.style.display = 'none';
            }
        }

        function updateSearchResultCount(visibleCount, searchTerm) {
            const resultCount = document.getElementById('searchResultCount');
            if (!resultCount) return;

            if (searchTerm !== '') {
                resultCount.textContent = `${visibleCount} hasil`;
                resultCount.style.display = 'block';
            } else {
                resultCount.style.display = 'none';
            }
        }

        function addLocationField(containerId) {
            const container = document.getElementById(containerId);
            const currentCount = container.children.length;
            
            // Tidak ada batasan - biarkan unlimited
            const index = currentCount;
            
            const locationField = document.createElement('div');
            locationField.className = 'location-field';
            locationField.setAttribute('data-index', index);
            locationField.innerHTML = `
                <div style="margin-bottom: 10px;">
                    <input type="text" name="lokasi[${index}]" placeholder="Contoh: Jl. KH. Muchtar Tabrani No.14, Bekasi..." class="form-control" required />
                </div>
                <div class="location-coords">
                    <div>
                        <input type="number" name="latitude[${index}]" placeholder="Latitude (opsional)" step="any" class="form-control" />
                        <small class="help-text">Cth: -6.2146013</small>
                    </div>
                    <div>
                        <input type="number" name="longitude[${index}]" placeholder="Longitude (opsional)" step="any" class="form-control" />
                        <small class="help-text">Cth: 107.003479</small>
                    </div>
                </div>
                <button type="button" onclick="removeLocationField(this)" class="btn-remove-location">
                    <i class="fas fa-times"></i> Hapus
                </button>
            `;
            
            container.appendChild(locationField);
        }

        function removeLocationField(button) {
            const container = button.closest('.location-field');
            if (container.parentElement.children.length > 1) {
                container.remove();
            } else {
                alert('Minimal harus ada 1 lokasi atau kosongkan semuanya');
            }
        }

        function previewImage(input, previewId) {
            const file = input.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById(previewId);
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            }
        }

        // Close modal when clicking outside
        document.getElementById('addProductModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeAddProductModal();
            }
        });
    </script>
</body>
</html>
