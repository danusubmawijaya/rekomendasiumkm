<?php
require_once '../../config/database.php';
require_once '../../config/session.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isAdmin()) {
    header("Location: ../../access_denied.php");
    exit();
}

// Cek apakah ini AJAX request untuk statistik
$is_ajax_stats = isset($_GET['ajax']) && $_GET['ajax'] === 'stats';

if ($is_ajax_stats) {
    // Return JSON untuk AJAX request
    header('Content-Type: application/json');
    
    $total_products = 0;
    $total_active_users = 0;
    $total_ratings = 0;
    $overall_avg_rating = 0;
    
    // Total produk
    $query = "SELECT COUNT(*) as count FROM products";
    $result = $conn->query($query);
    if ($result) {
        $data = $result->fetch_assoc();
        $total_products = intval($data['count']);
    }
    
    // Total active users (hitung dari tabel users yang bukan admin, is_admin = 0)
    $query = "SELECT COUNT(*) as total FROM users WHERE is_admin = 0";
    $result = $conn->query($query);
    if ($result) {
        $data = $result->fetch_assoc();
        $total_active_users = intval($data['total']);
    }
    
    // Total ratings
    $query = "SELECT COUNT(*) as count FROM ratings";
    $result = $conn->query($query);
    if ($result) {
        $data = $result->fetch_assoc();
        $total_ratings = intval($data['count']);
    }
    
    // Overall average rating
    $query = "SELECT AVG(rating) as avg_rating FROM ratings";
    $result = $conn->query($query);
    if ($result) {
        $data = $result->fetch_assoc();
        $overall_avg_rating = isset($data['avg_rating']) && $data['avg_rating'] ? round(floatval($data['avg_rating']), 1) : 0;
    }
    
    echo json_encode([
        'total_products' => $total_products,
        'total_active_users' => $total_active_users,
        'total_ratings' => $total_ratings,
        'overall_avg_rating' => $overall_avg_rating,
        'timestamp' => time()
    ]);
    exit();
}

// Hitung statistik untuk initial load
$total_products = 0;
$products_query = "SELECT COUNT(*) as count FROM products";
$products_result = $conn->query($products_query);
if ($products_result) {
    $products_data = $products_result->fetch_assoc();
    $total_products = intval($products_data['count']);
}

$total_active_users = 0;
$users_query = "SELECT COUNT(*) as total FROM users WHERE is_admin = 0";
$users_result = $conn->query($users_query);
if ($users_result) {
    $users_data = $users_result->fetch_assoc();
    $total_active_users = intval($users_data['total']);
}

$total_ratings = 0;
$total_ratings_query = "SELECT COUNT(*) as count FROM ratings";
$total_ratings_result = $conn->query($total_ratings_query);
if ($total_ratings_result) {
    $total_ratings_data = $total_ratings_result->fetch_assoc();
    $total_ratings = isset($total_ratings_data['count']) ? intval($total_ratings_data['count']) : 0;
}

$overall_avg_rating = 0;
$avg_rating_query = "SELECT AVG(rating) as avg_rating FROM ratings";
$avg_rating_result = $conn->query($avg_rating_query);
if ($avg_rating_result) {
    $avg_rating_data = $avg_rating_result->fetch_assoc();
    $overall_avg_rating = isset($avg_rating_data['avg_rating']) && $avg_rating_data['avg_rating'] 
        ? round(floatval($avg_rating_data['avg_rating']), 1) 
        : 0;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../../css/admin.css" rel="stylesheet">
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar Overlay untuk Mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-leaf"></i> UMKM Recommend
        </div>
        <a href="dashboard.php" class="nav-link-admin active">
            <i class="fas fa-chart-line"></i> <span>Dashboard</span>
        </a>
        <a href="products.php" class="nav-link-admin">
            <i class="fas fa-box"></i> <span>Kelola Produk</span>
        </a>
        <a href="evaluasi_mae.php" class="nav-link-admin">
            <i class="fas fa-chart-bar"></i> <span>Evaluasi MAE</span>
        </a>
        <a href="users.php" class="nav-link-admin">
            <i class="fas fa-users"></i> <span>Kelola Pengguna</span>
        </a>
        <hr style="border-color: rgba(255,255,255,0.2); margin: 20px 0;">
        <a href="profile.php" class="nav-link-admin">
            <i class="fas fa-user-cog"></i> <span>Profil Saya</span>
        </a>
        <a href="../../khususjier/admin/logout.php" class="nav-link-admin">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="dashboard-header">
            <div>
                <h1 class="dashboard-title"><i class="fas fa-chart-line"></i> Dashboard</h1>
                <p style="color: #999; margin: 5px 0 0 0;">Selamat datang kembali, Admin!</p>
            </div>
            <div class="user-info">
                <div class="user-avatar">
                    <?php echo strtoupper(substr($_SESSION['user_name'], 0, 1)); ?>
                </div>
                <div>
                    <div style="font-weight: 600; color: var(--dark-color);"><?php echo htmlspecialchars($_SESSION['user_name']); ?></div>
                    <small style="color: #999;">Administrator</small>
                </div>
            </div>
        </div>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-box"></i></div>
                <div class="stat-value" id="stat-products"><?php echo $total_products; ?></div>
                <div class="stat-label">Total Produk</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-users"></i></div>
                <div class="stat-value" id="stat-users"><?php echo $total_active_users; ?></div>
                <div class="stat-label">Pengguna Aktif</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-star"></i></div>
                <div class="stat-value" id="stat-ratings"><?php echo $total_ratings; ?></div>
                <div class="stat-label">Total Rating</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fas fa-heart"></i></div>
                <div class="stat-value" id="stat-rating-avg"><?php echo $overall_avg_rating; ?>★</div>
                <div class="stat-label">Rating Rata-rata</div>
            </div>
        </div>

        <!-- Management Section -->
        <div class="section-divider">
            <h2 class="section-title"><i class="fas fa-cogs"></i> Manajemen Sistem</h2>
        </div>

        <div class="menu-grid">
            <a href="products.php" class="menu-card">
                <div class="menu-icon"><i class="fas fa-box"></i></div>
                <div class="menu-title">Kelola Produk</div>
                <div class="menu-desc">Tambah, edit, atau hapus produk</div>
            </a>
            <a href="evaluasi_mae.php" class="menu-card">
                <div class="menu-icon"><i class="fas fa-chart-bar"></i></div>
                <div class="menu-title">Evaluasi MAE</div>
                <div class="menu-desc">Hitung akurasi rekomendasi</div>
            </a>
            <a href="users.php" class="menu-card">
                <div class="menu-icon"><i class="fas fa-users"></i></div>
                <div class="menu-title">Kelola Pengguna</div>
                <div class="menu-desc">Lihat dan hapus pengguna</div>
            </a>
            <a href="profile.php" class="menu-card">
                <div class="menu-icon"><i class="fas fa-user-cog"></i></div>
                <div class="menu-title">Profil Admin</div>
                <div class="menu-desc">Edit data dan password</div>
            </a>
        </div>

        <!-- Info Section -->
        <div class="section-divider">
            <h2 class="section-title"><i class="fas fa-info-circle"></i> Informasi</h2>
        </div>

        <div style="background: white; padding: 20px; border-radius: 12px; border-left: 5px solid var(--primary-color);">
            <p style="margin: 0; color: var(--text-color); line-height: 1.6;">
                <strong>Sistem UMKM Recommend</strong> menggunakan metode <strong>User-Based Collaborative Filtering</strong> dengan <strong>Cosine Similarity</strong> untuk memberikan rekomendasi produk yang dipersonalisasi. 
                <br><br>
                Setiap interaksi pengguna dengan produk membantu sistem belajar dan memberikan rekomendasi yang semakin akurat.
            </p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Mobile Menu Toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('show');
                sidebarOverlay.classList.toggle('active');
            });

            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('active');
            });

            const navLinks = document.querySelectorAll('.nav-link-admin');
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                });
            });

            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                }
            });
        }

        // Real-time Statistics Auto-Update
        document.addEventListener('DOMContentLoaded', function() {
            const productsEl = document.getElementById('stat-products');
            const usersEl = document.getElementById('stat-users');
            const ratingsEl = document.getElementById('stat-ratings');
            const ratingAvgEl = document.getElementById('stat-rating-avg');
            
            if (!productsEl || !usersEl || !ratingsEl || !ratingAvgEl) {
                return; // Elemen tidak ditemukan
            }
            
            // Fungsi untuk update statistik
            function updateStatistics() {
                const xhr = new XMLHttpRequest();
                xhr.open('GET', 'dashboard.php?ajax=stats&t=' + Date.now(), true);
                xhr.responseType = 'json';
                
                xhr.onload = function() {
                    if (xhr.status === 200 && xhr.response) {
                        const data = xhr.response;
                        
                        // Update produk
                        if (data.total_products !== undefined) {
                            animateNumber(productsEl, data.total_products);
                        }
                        
                        // Update pengguna aktif
                        if (data.total_active_users !== undefined) {
                            animateNumber(usersEl, data.total_active_users);
                        }
                        
                        // Update total rating
                        if (data.total_ratings !== undefined) {
                            animateNumber(ratingsEl, data.total_ratings);
                        }
                        
                        // Update rating rata-rata
                        if (data.overall_avg_rating !== undefined) {
                            const ratingText = data.overall_avg_rating + '★';
                            ratingAvgEl.textContent = ratingText;
                        }
                    }
                };
                
                xhr.onerror = function() {
                    console.log('Error fetching stats');
                };
                
                xhr.send();
            }
            
            // Fungsi animasi angka
            function animateNumber(element, newValue, duration = 300) {
                const currentText = element.textContent.replace('★', '').trim();
                const startValue = parseInt(currentText) || 0;
                const endValue = parseInt(newValue);
                
                if (startValue === endValue) return;
                
                const increment = Math.ceil((endValue - startValue) / (duration / 50));
                let displayValue = startValue;
                
                const interval = setInterval(() => {
                    displayValue += increment;
                    
                    if ((increment > 0 && displayValue >= endValue) || (increment <= 0 && displayValue <= endValue)) {
                        displayValue = endValue;
                        clearInterval(interval);
                    }
                    
                    element.textContent = displayValue;
                }, 50);
            }
            
            // Update pertama kali
            updateStatistics();
            
            // Update otomatis setiap 5 detik
            setInterval(updateStatistics, 5000);
        });
    </script>
</body>
</html>
