<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../classes/Product.php';

redirectIfNotLoggedIn();

// Check jika user adalah admin
$user_id = intval($_SESSION['user_id']);
$check_admin = "SELECT role FROM users WHERE id = $user_id";
$result = $conn->query($check_admin);
$user_data = $result->fetch_assoc();

if (!$user_data || $user_data['role'] !== 'admin') {
    header("Location: dashboard.php");
    exit();
}

$product = new Product($conn);
$geocode_results = [];
$all_products = [];

// GET all products untuk ditampilkan
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $all_products = $product->getAllProducts();
}

// POST - Auto geocode
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? sanitize($_POST['action']) : '';
    
    if ($action === 'auto_fill_product') {
        $product_id = intval($_POST['product_id'] ?? 0);
        
        if ($product_id > 0) {
            $geocode_results = $product->autoFillCoordinates($product_id);
            $geocode_results['product_id'] = $product_id;
            
            // Flash message
            $_SESSION['geocode_message'] = "Auto-geocode berhasil untuk " . $geocode_results['updated'] . " lokasi!";
        }
    } else if ($action === 'auto_fill_all') {
        // Auto geocode SEMUA produk
        $all_products = $product->getAllProducts();
        $total_updated = 0;
        $total_failed = 0;
        
        foreach ($all_products as $prod) {
            $result = $product->autoFillCoordinates($prod['id']);
            $total_updated += $result['updated'];
            $total_failed += $result['failed'];
        }
        
        $geocode_results = [
            'success' => true,
            'updated' => $total_updated,
            'failed' => $total_failed,
            'total' => count($all_products),
            'message' => "Auto-geocode SEMUA produk berhasil!"
        ];
        
        $_SESSION['geocode_message'] = $geocode_results['message'];
    }
}

// Get status untuk setiap produk
$products_with_status = [];
foreach ($all_products as $prod) {
    $locations = $product->getProductLocations($prod['id']);
    $with_coords = array_filter($locations, function($loc) {
        return !empty($loc['latitude']) && !empty($loc['longitude']);
    });
    
    $prod['total_locations'] = count($locations);
    $prod['locations_with_coords'] = count($with_coords);
    $prod['missing_coords'] = count($locations) - count($with_coords);
    
    $products_with_status[] = $prod;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto-Geocode Lokasi | Admin Panel</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1d7e3f;
            --secondary-color: #0f5f2f;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
        }

        body {
            background: #f9fafb;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .page-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            padding: 30px 0;
            margin-bottom: 30px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .stat-icon {
            font-size: 2.5rem;
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
        }

        .stat-icon.success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .stat-icon.warning {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        .stat-icon.danger {
            background: rgba(239, 68, 68, 0.1);
            color: var(--danger-color);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        .stat-label {
            font-size: 0.9rem;
            color: #6b7280;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .btn-action {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-action:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(29, 126, 63, 0.3);
        }

        .btn-action.danger {
            background: var(--warning-color);
        }

        .btn-action.danger:hover {
            background: #d97706;
        }

        .table-container {
            background: white;
            padding: 0;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        table {
            margin: 0;
        }

        th {
            background: #f3f4f6;
            color: var(--primary-color);
            font-weight: 600;
            border: none;
            padding: 15px;
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 15px;
            border: 1px solid #e5e7eb;
            vertical-align: middle;
        }

        tbody tr:hover {
            background: #f9fafb;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }

        .status-badge.complete {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
        }

        .status-badge.incomplete {
            background: rgba(245, 158, 11, 0.1);
            color: var(--warning-color);
        }

        .progress-bar-custom {
            height: 8px;
            background: #e5e7eb;
            border-radius: 4px;
            overflow: hidden;
            margin: 8px 0;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--primary-color), var(--success-color));
            border-radius: 4px;
        }

        .alert-message {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .alert-message.success {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success-color);
            border-left: 4px solid var(--success-color);
        }

        .alert-message.info {
            background: rgba(59, 130, 246, 0.1);
            color: #2563eb;
            border-left: 4px solid #2563eb;
        }

        .info-box {
            background: #f0f9ff;
            border-left: 4px solid var(--primary-color);
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .info-box strong {
            color: var(--primary-color);
        }

        @media (max-width: 768px) {
            .stat-card {
                flex-direction: column;
                text-align: center;
            }

            .action-buttons {
                flex-direction: column;
            }

            .btn-action {
                width: 100%;
                justify-content: center;
            }

            table {
                font-size: 0.9rem;
            }

            th, td {
                padding: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="page-header">
        <div class="container">
            <div style="display: flex; align-items: center; gap: 15px;">
                <i class="fas fa-map-marker-alt" style="font-size: 2.2rem;"></i>
                <div>
                    <h1 style="margin: 0; font-size: 2rem;">Auto-Geocode Lokasi UMKM</h1>
                    <p style="margin: 8px 0 0 0; opacity: 0.9;">Isi koordinat GPS otomatis dari alamat yang sudah ada</p>
                </div>
            </div>
        </div>
    </div>

    <div class="container mb-5">
        <!-- Success Message -->
        <?php if (isset($_SESSION['geocode_message'])): ?>
            <div class="alert-message success">
                <i class="fas fa-check-circle"></i>
                <span><?php echo $_SESSION['geocode_message']; ?></span>
            </div>
            <?php unset($_SESSION['geocode_message']); ?>
        <?php endif; ?>

        <!-- Hasil Geocode -->
        <?php if (!empty($geocode_results) && isset($geocode_results['success']) && $geocode_results['success']): ?>
            <div class="alert-message success">
                <i class="fas fa-check-circle"></i>
                <div>
                    <strong>Auto-Geocode Berhasil!</strong><br>
                    <small>
                        <?php echo $geocode_results['updated']; ?> lokasi berhasil diisi koordinatnya, 
                        <?php echo $geocode_results['failed']; ?> lokasi gagal
                        (Total: <?php echo $geocode_results['total']; ?> lokasi)
                    </small>
                </div>
            </div>
        <?php endif; ?>

        <!-- Info Box -->
        <div class="info-box">
            <i class="fas fa-info-circle"></i>
            <strong>Cara Kerja:</strong> Sistem secara otomatis akan mengambil alamat yang sudah Anda input di database, 
            kemudian mencari koordinat GPS-nya menggunakan Nominatim API (OpenStreetMap). 
            Tidak perlu manual input koordinat! 
            <a href="https://nominatim.org/" target="_blank" style="color: var(--primary-color);">Pelajari lebih lanjut →</a>
        </div>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon success">
                    <i class="fas fa-map-pin"></i>
                </div>
                <div>
                    <div class="stat-value">
                        <?php 
                        $total_locs = 0;
                        $locs_with_coords = 0;
                        foreach ($products_with_status as $p) {
                            $total_locs += $p['total_locations'];
                            $locs_with_coords += $p['locations_with_coords'];
                        }
                        echo $locs_with_coords;
                        ?>
                    </div>
                    <div class="stat-label">Lokasi dengan Koordinat</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon warning">
                    <i class="fas fa-clock"></i>
                </div>
                <div>
                    <div class="stat-value">
                        <?php 
                        $missing = $total_locs - $locs_with_coords;
                        echo $missing;
                        ?>
                    </div>
                    <div class="stat-label">Lokasi Perlu Koordinat</div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-icon danger">
                    <i class="fas fa-box"></i>
                </div>
                <div>
                    <div class="stat-value"><?php echo count($products_with_status); ?></div>
                    <div class="stat-label">Total Produk</div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <div class="action-buttons">
            <form method="POST" style="display: inline;">
                <input type="hidden" name="action" value="auto_fill_all">
                <button type="submit" class="btn-action" onclick="return confirm('Yakin ingin auto-geocode SEMUA produk? Ini bisa memakan waktu beberapa menit...')">
                    <i class="fas fa-bolt"></i> Auto-Geocode Semua Produk
                </button>
            </form>
            
            <a href="products.php" class="btn-action" style="background: #6b7280; text-decoration: none;">
                <i class="fas fa-arrow-left"></i> Kembali ke Produk
            </a>
        </div>

        <!-- Products Table -->
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>Produk</th>
                        <th>Total Lokasi</th>
                        <th>Dengan Koordinat</th>
                        <th>Perlu Koordinat</th>
                        <th>Progress</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($products_with_status)): ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: #999;">
                                <i class="fas fa-inbox"></i> Belum ada produk
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($products_with_status as $prod): ?>
                            <tr>
                                <td>
                                    <strong><?php echo htmlspecialchars($prod['nama_produk']); ?></strong><br>
                                    <small style="color: #999;">ID: <?php echo $prod['id']; ?></small>
                                </td>
                                <td><?php echo $prod['total_locations']; ?></td>
                                <td>
                                    <span style="color: var(--success-color); font-weight: 600;">
                                        <?php echo $prod['locations_with_coords']; ?>
                                    </span>
                                </td>
                                <td>
                                    <span style="color: var(--warning-color); font-weight: 600;">
                                        <?php echo $prod['missing_coords']; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="progress-bar-custom">
                                        <div class="progress-fill" style="width: <?php echo $prod['total_locations'] > 0 ? round(($prod['locations_with_coords'] / $prod['total_locations']) * 100) : 0; ?>%"></div>
                                    </div>
                                    <small style="color: #999;">
                                        <?php echo $prod['total_locations'] > 0 ? round(($prod['locations_with_coords'] / $prod['total_locations']) * 100) : 0; ?>%
                                    </small>
                                </td>
                                <td>
                                    <?php if ($prod['missing_coords'] === 0): ?>
                                        <span class="status-badge complete">
                                            <i class="fas fa-check-circle"></i> Lengkap
                                        </span>
                                    <?php else: ?>
                                        <span class="status-badge incomplete">
                                            <i class="fas fa-clock"></i> Perlu diisi
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ($prod['missing_coords'] > 0): ?>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="auto_fill_product">
                                            <input type="hidden" name="product_id" value="<?php echo $prod['id']; ?>">
                                            <button type="submit" class="btn-action" style="padding: 8px 14px; font-size: 0.85rem; background: var(--primary-color);" title="Auto-geocode lokasi produk ini">
                                                <i class="fas fa-bolt"></i> Isi Sekarang
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span style="color: #999; font-size: 0.9rem;">
                                            <i class="fas fa-check"></i> Sudah lengkap
                                        </span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Info Section -->
        <div style="background: white; padding: 25px; border-radius: 12px; margin-top: 30px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
            <h5 style="color: var(--primary-color); font-weight: 700; margin-bottom: 15px;">
                <i class="fas fa-lightbulb"></i> Informasi Penting
            </h5>
            <ul style="color: #666; line-height: 1.8; margin: 0; padding-left: 20px;">
                <li><strong>Otomatis:</strong> Sistem mengambil alamat dari lokasi yang sudah ada di database</li>
                <li><strong>Nominatim API:</strong> Menggunakan layanan geocoding gratis dari OpenStreetMap</li>
                <li><strong>Rate Limited:</strong> Setiap lokasi memiliki delay 1 detik untuk menghindari spam API</li>
                <li><strong>Akurasi:</strong> Koordinat mungkin tidak 100% akurat, tergantung kelengkapan alamat</li>
                <li><strong>Manual Edit:</strong> Anda masih bisa mengedit koordinat secara manual di halaman produk jika diperlukan</li>
                <li><strong>No Database Changes:</strong> Tidak perlu tambah kolom atau migrasi database baru</li>
            </ul>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
function sanitize($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}
?>
