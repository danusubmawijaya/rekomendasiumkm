<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/config/session.php';
require_once dirname(__DIR__) . '/classes/Product.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isAdmin()) {
    header("Location: ../access_denied.php");
    exit();
}

$product = new Product($conn);
$message = '';
$message_type = '';

// Data mapping produk dengan lokasi UMKM yang sesuai
$locations_data = [
    'Ayam Geprek Pedas' => [
        'Jl. KH. Muchtar Tabrani No.14, RT.4/RW.001, Perwira, Bekasi Utara, Jawa Barat 17143 (Geprek Gold Chick)'
    ],
    'Bakso Sapi Bekasi' => [
        'Jalan Bango 2, Harapan Jaya, Bekasi Utara, Jawa Barat (Bakso Super King Mas War)',
        'Jl. Raya Kaliabang Tengah, Bekasi Utara, Jawa Barat (Bakso Gandarasa)'
    ],
    'Mie Ayam Kuah' => [
        'Jl. KH. Muchtar Tabrani No.9, RT.006/RW.002, Marga Mulya, Bekasi Utara, Jawa Barat (Mi Ayam Baso Inul)',
        'Jl. Kiyai H. Noer Ali, Bekasi Utara, Jawa Barat (Bakso & Mie Ayam Pak Sugeng)'
    ],
    'Seblak Pedas Gurih' => [
        'Bekasi Utara, Jawa Barat (Seblak & Baso Aci Mbak Wati)'
    ],
    'Siomay Rebus Lezat' => [
        'Jl. Kali Abang Tengah, Bekasi Utara, Jawa Barat (Siomay Aan)'
    ],
    'Pecel Lele Gurih' => [
        'Harapan Indah, Bekasi (Pecel Lele Muji)'
    ],
    'Soto Ayam Jamu' => [
        'Bekasi (Area Bekasi Utara) (Soto Ayam Ceker Surabaya Cak Komeng)'
    ],
    'Nasi Uduk Bekasi' => [
        'Jl. Ujung Harapan No.35, Bekasi (Nasi Uduk Betawi Ibu Hj. Adah)'
    ],
    'Nasi Goreng Gerobak' => [
        'Jl. KH. Muchtar Tabrani, Perwira, Bekasi Utara, Jawa Barat (Nasi Goreng nba/una)'
    ],
    'Martabak Manis Terang Bulan' => [
        'Jl. KH. Muchtar Tabrani No.58, Bekasi Utara, Jawa Barat (Martabak Mas Jelly)'
    ],
    'Roti Bakar Bekasi' => [
        'Bekasi (Roti & Pisang Bakar Eko)'
    ],
    'Pisang Goreng Coklat' => [
        'Bekasi (Roti & Pisang Bakar Eko)'
    ],
    'Es Kopi Susu Gula Aren' => [
        'Jl. Kali Baru Barat, Kota Baru, Bekasi (Kedai Kopi Bang Jenggot)'
    ],
    'Thai Tea Premium' => [
        'Jl. Kali Baru Barat, Kota Baru, Bekasi (Kedai Kopi Bang Jenggot)'
    ],
    'Boba Milk Tea Kenyat' => [
        'Jl. Kali Baru Barat, Kota Baru, Bekasi (Kedai Kopi Bang Jenggot)'
    ],
    'Sate Ayam Madura' => [
        'Cari di Google Maps "Sate Ayam Madura Bekasi Utara" atau kunjungi pasar tradisional'
    ],
    'Cilok Goreng Isi' => [
        'Pedagang kaki lima di sekitar sekolah, terminal, pasar tradisional Bekasi Utara'
    ],
    'Cireng Goreng Gurih' => [
        'Pedagang kaki lima di sekitar sekolah, terminal, pasar tradisional Bekasi Utara'
    ],
    'Batagor Kuah Gurih' => [
        'Jl. Kali Abang Tengah, Bekasi Utara, Jawa Barat (Siomay Aan juga menjual Batagor)'
    ],
    'Rendang Rumahan Lezat' => [
        'Rumah Makan Padang di Bekasi Utara (Cari di Google Maps untuk lokasi spesifik)'
    ],
    'Ayam Balado Pedas' => [
        'Rumah Makan Padang di Bekasi Utara (Cari di Google Maps untuk lokasi spesifik)'
    ],
    'Sambal Homemade Pedas' => [
        'Rumah Makan Padang di Bekasi Utara (Cari di Google Maps untuk lokasi spesifik)'
    ]
];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add_locations') {
    $success_count = 0;
    $failed_count = 0;
    $details = '';

    foreach ($locations_data as $product_name => $locations) {
        // Cari product ID berdasarkan nama produk
        $stmt = $conn->prepare("SELECT id FROM products WHERE nama_produk = ?");
        $stmt->bind_param("s", $product_name);
        $stmt->execute();
        
        // Gunakan helper function untuk kompatibilitas
        $product_data = stmt_fetch_assoc($stmt);
        $stmt->close();
        
        if ($product_data) {
            $product_id = $product_data['id'];
            
            // Cek lokasi yang sudah ada
            $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM product_locations WHERE product_id = ?");
            $check_stmt->bind_param("i", $product_id);
            $check_stmt->execute();
            $check_data = stmt_fetch_assoc($check_stmt);
            $check_stmt->close();
            
            if ($check_data['count'] == 0) {
                // Tambahkan lokasi jika belum ada
                foreach ($locations as $lokasi) {
                    $insert_stmt = $conn->prepare("INSERT INTO product_locations (product_id, lokasi) VALUES (?, ?)");
                    $insert_stmt->bind_param("is", $product_id, $lokasi);
                    
                    if ($insert_stmt->execute()) {
                        $success_count++;
                        $details .= "✓ {$product_name}: {$lokasi}\n";
                    } else {
                        $failed_count++;
                        $details .= "✗ {$product_name}: Gagal menambahkan lokasi\n";
                    }
                }
            } else {
                $details .= "⚠ {$product_name}: Sudah memiliki lokasi\n";
            }
        } else {
            $failed_count++;
            $details .= "✗ {$product_name}: Produk tidak ditemukan\n";
        }
    }
    
    $message = "Proses selesai! {$success_count} lokasi berhasil ditambahkan, {$failed_count} gagal.";
    $message_type = ($failed_count == 0) ? 'success' : 'warning';
}

$all_products = $product->getAllProducts();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Lokasi Massal - Admin UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../css/admin.css" rel="stylesheet">
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar Overlay untuk Mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-leaf"></i> UMKM Recommend
        </div>
        <a href="dashboard.php" class="nav-link-admin">
            <i class="fas fa-chart-line"></i> <span>Dashboard</span>
        </a>
        <a href="products.php" class="nav-link-admin">
            <i class="fas fa-box"></i> <span>Kelola Produk</span>
        </a>
        <a href="evaluasi_mae.php" class="nav-link-admin">
            <i class="fas fa-chart-bar"></i> <span>Evaluasi MAE</span>
        </a>
        <a href="users.php" class="nav-link-admin">
            <i class="fas fa-users"></i> <span>Kelola Pengguna</span>
        </a>
        <hr style="border-color: rgba(255,255,255,0.2); margin: 20px 0;">
        <a href="profile.php" class="nav-link-admin">
            <i class="fas fa-user-cog"></i> <span>Profil Saya</span>
        </a>
        <a href="../logout.php" class="nav-link-admin">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="dashboard-header">
            <div>
                <h1 class="dashboard-title"><i class="fas fa-map-marker-alt"></i> Tambah Lokasi UMKM Massal</h1>
                <p style="color: #999; margin: 5px 0 0 0;">Tambahkan lokasi dari Bekasi Utara ke produk yang sesuai</p>
            </div>
        </div>

        <?php if ($message): ?>
        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert" style="margin-bottom: 24px;">
            <div style="display: flex; align-items: center; gap: 8px;">
                <i class="fas fa-<?php echo ($message_type === 'success' ? 'check-circle' : 'exclamation-circle'); ?>"></i>
                <span><?php echo htmlspecialchars($message); ?></span>
            </div>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Info Box -->
        <div style="background: #e3f2fd; border-left: 4px solid #2196f3; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
            <div style="display: flex; gap: 12px;">
                <i class="fas fa-info-circle" style="color: #2196f3; font-size: 1.2rem; flex-shrink: 0;"></i>
                <div>
                    <h4 style="margin: 0 0 8px 0; color: #1565c0;">Informasi</h4>
                    <p style="margin: 0; color: #424242; font-size: 0.95rem;">
                        Sistem ini akan secara otomatis menambahkan lokasi UMKM dari Kecamatan Bekasi Utara ke setiap produk yang sesuai.
                        <strong>Produk yang sudah memiliki lokasi tidak akan diubah.</strong>
                    </p>
                </div>
            </div>
        </div>

        <!-- Data Preview -->
        <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 24px;">
            <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(34, 139, 34, 0.05), rgba(45, 80, 22, 0.05));">
                <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                    <i class="fas fa-list" style="color: var(--primary-color); margin-right: 10px;"></i>
                    Produk & Lokasi yang Akan Ditambahkan
                </h2>
            </div>
            <div style="padding: 24px; overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead style="background: #f8f9fa;">
                        <tr>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">No.</th>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">Nama Produk</th>
                            <th style="padding: 12px; text-align: left; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">Lokasi UMKM</th>
                            <th style="padding: 12px; text-align: center; font-weight: 600; color: var(--dark-color); border-bottom: 2px solid var(--border-color);">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        foreach ($locations_data as $product_name => $locations): 
                            // Cari produk
                            $prod_found = false;
                            $prod_id = null;
                            foreach ($all_products as $prod) {
                                if ($prod['nama_produk'] == $product_name) {
                                    $prod_found = true;
                                    $prod_id = $prod['id'];
                                    break;
                                }
                            }
                            
                            // Cek apakah sudah ada lokasi
                            $has_locations = false;
                            if ($prod_found) {
                                $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM product_locations WHERE product_id = ?");
                                $check_stmt->bind_param("i", $prod_id);
                                $check_stmt->execute();
                                $check_row = stmt_fetch_assoc($check_stmt);
                                $check_stmt->close();
                                $has_locations = $check_row && $check_row['count'] > 0;
                            }
                        ?>
                        <tr style="border-bottom: 1px solid var(--border-color);">
                            <td style="padding: 12px; color: var(--text-color); font-weight: 600;"><?php echo $no; ?></td>
                            <td style="padding: 12px; color: var(--text-color); font-weight: 500;"><?php echo htmlspecialchars($product_name); ?></td>
                            <td style="padding: 12px; color: #666; font-size: 0.9rem;">
                                <?php foreach ($locations as $loc): ?>
                                    <div style="padding: 4px 0;">• <?php echo htmlspecialchars($loc); ?></div>
                                <?php endforeach; ?>
                            </td>
                            <td style="padding: 12px; text-align: center;">
                                <?php if (!$prod_found): ?>
                                    <span style="background: #fff3cd; color: #856404; padding: 4px 8px; border-radius: 4px; font-size: 0.8rem; font-weight: 600;">
                                        <i class="fas fa-exclamation-triangle"></i> Tidak ditemukan
                                    </span>
                                <?php elseif ($has_locations): ?>
                                    <span style="background: #d4edda; color: #155724; padding: 4px 8px; border-radius: 4px; font-size: 0.8rem; font-weight: 600;">
                                        <i class="fas fa-check"></i> Sudah ada
                                    </span>
                                <?php else: ?>
                                    <span style="background: #cfe2ff; color: #084298; padding: 4px 8px; border-radius: 4px; font-size: 0.8rem; font-weight: 600;">
                                        <i class="fas fa-plus"></i> Akan ditambah
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php $no++; endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Action Button -->
        <div style="display: flex; gap: 12px; margin-bottom: 24px;">
            <form method="POST" style="display: inline;" onsubmit="return confirm('Yakin ingin menambahkan semua lokasi? Produk yang sudah memiliki lokasi tidak akan diubah.');">
                <input type="hidden" name="action" value="add_locations">
                <button type="submit" class="btn" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; padding: 12px 32px; border: none; border-radius: 8px; font-weight: 600; transition: all 0.3s; cursor: pointer;">
                    <i class="fas fa-plus"></i> Tambahkan Semua Lokasi
                </button>
            </form>
            <a href="products.php" class="btn" style="background: white; color: var(--text-color); padding: 12px 32px; border: 1px solid #ddd; border-radius: 8px; font-weight: 600; transition: all 0.3s; text-decoration: none; display: inline-block;">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
        </div>

        <!-- Notes -->
        <div style="background: #f0f0f0; border-radius: 12px; padding: 16px; margin-bottom: 24px;">
            <h4 style="margin-top: 0; color: var(--dark-color);">Catatan Penting:</h4>
            <ul style="margin: 0; color: #666; font-size: 0.95rem;">
                <li>Lokasi akan ditambahkan hanya ke produk yang <strong>belum memiliki lokasi</strong></li>
                <li>Lokasi mencakup nama UMKM dalam format: "Alamat (Nama UMKM)"</li>
                <li>Untuk produk tanpa lokasi UMKM spesifik (pedagang kaki lima), informasi umum akan ditambahkan</li>
                <li>Anda dapat mengedit lokasi individual melalui halaman "Kelola Produk"</li>
                <li>Untuk koordinat GPS, gunakan fitur auto-geocode yang tersedia di menu admin</li>
            </ul>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('show');
                sidebarOverlay.classList.toggle('active');
            });

            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('active');
            });
        }
    </script>
</body>
</html>
