<?php
require_once dirname(__DIR__) . '/config/database.php';
require_once dirname(__DIR__) . '/config/session.php';
require_once dirname(__DIR__) . '/classes/Menu.php';

redirectIfNotAdmin();

$menu = new Menu($conn);
$all_menu = $menu->getAllMenu();
$categories = $menu->getCategories();

$message = '';
$message_type = '';
$edit_menu = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    // Add Category
    if ($action == 'add_category') {
        $nama_kategori = $_POST['nama_kategori'] ?? '';
        $deskripsi = $_POST['deskripsi'] ?? '';
        
        $result = $menu->addCategory($nama_kategori, $deskripsi);
        $message = $result['message'];
        $message_type = $result['success'] ? 'success' : 'danger';
        
        if ($result['success']) {
            $categories = $menu->getCategories();
        }
    }
    
    // Edit Category
    elseif ($action == 'edit_category') {
        $category_id = $_POST['category_id'] ?? 0;
        $nama_kategori = $_POST['nama_kategori'] ?? '';
        $deskripsi = $_POST['deskripsi'] ?? '';
        
        $result = $menu->updateCategory($category_id, $nama_kategori, $deskripsi);
        $message = $result['message'];
        $message_type = $result['success'] ? 'success' : 'danger';
        
        if ($result['success']) {
            $categories = $menu->getCategories();
        }
    }
    
    // Delete Category
    elseif ($action == 'delete_category') {
        $category_id = $_POST['category_id'] ?? 0;
        $result = $menu->deleteCategory($category_id);
        $message = $result['message'];
        $message_type = $result['success'] ? 'success' : 'danger';
        
        if ($result['success']) {
            $categories = $menu->getCategories();
        }
    }
    
    // Add Menu
    elseif ($action == 'add') {
        $nama_menu = $_POST['nama_menu'] ?? '';
        $deskripsi = $_POST['deskripsi'] ?? '';
        $kategori_id = $_POST['kategori_id'] ?? 0;
        
        $gambar = null;
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $upload_result = $menu->uploadImage($_FILES['gambar']);
            if (!$upload_result['success']) {
                $message = $upload_result['message'];
                $message_type = 'danger';
            } else {
                $gambar = $upload_result['filepath'];
            }
        }
        
        if (!$message) {
            $result = $menu->addMenu($nama_menu, $deskripsi, 0, $kategori_id, $gambar);
            $message = $result['message'];
            $message_type = $result['success'] ? 'success' : 'danger';
            
            if ($result['success']) {
                $all_menu = $menu->getAllMenu();
            }
        }
    }
    
    // Update Menu
    elseif ($action == 'update') {
        $menu_id = $_POST['menu_id'] ?? 0;
        $nama_menu = $_POST['nama_menu'] ?? '';
        $deskripsi = $_POST['deskripsi'] ?? '';
        $kategori_id = $_POST['kategori_id'] ?? 0;
        
        $current_menu = $menu->getMenuById($menu_id);
        $gambar = $current_menu['gambar'];
        
        // Handle image upload
        if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
            $upload_result = $menu->uploadImage($_FILES['gambar']);
            if (!$upload_result['success']) {
                $message = $upload_result['message'];
                $message_type = 'danger';
            } else {
                // Delete old image
                if ($gambar) {
                    $menu->deleteImage($gambar);
                }
                $gambar = $upload_result['filepath'];
            }
        }
        
        if (!$message) {
            $result = $menu->updateMenu($menu_id, $nama_menu, $deskripsi, 0, $kategori_id, $gambar);
            $message = $result['message'];
            $message_type = $result['success'] ? 'success' : 'danger';
            
            if ($result['success']) {
                $all_menu = $menu->getAllMenu();
            }
        }
    }
    
    // Delete Menu
    elseif ($action == 'delete') {
        $menu_id = $_POST['menu_id'] ?? 0;
        $result = $menu->deleteMenu($menu_id);
        $message = $result['message'];
        $message_type = $result['success'] ? 'success' : 'danger';
        
        if ($result['success']) {
            $all_menu = $menu->getAllMenu();
        }
    }
}

// Get edit menu if requested
if (isset($_GET['edit'])) {
    $edit_menu = $menu->getMenuById($_GET['edit']);
}

?>
<?php require_once '../includes/header.php'; ?>

<style>
    .menu-image {
        max-width: 100px;
        height: auto;
        border-radius: 4px;
    }
    .badge-rating {
        background-color: #ffc107;
        color: #000;
    }
    .img-preview {
        max-width: 200px;
        max-height: 200px;
        margin-top: 10px;
        border-radius: 4px;
        display: none;
    }
</style>

<div class="row mb-4">
    <div class="col-md-12">
        <h1><i class="fas fa-utensils"></i> Manajemen Menu</h1>
        <p class="text-muted">Kelola menu restoran/warung, kategori, dan gambar menu</p>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
        <?php echo $message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Tab Navigation -->
<ul class="nav nav-tabs mb-4" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" data-bs-toggle="tab" href="#daftar-menu">
            <i class="fas fa-list"></i> Daftar Menu
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" data-bs-toggle="tab" href="#kategori">
            <i class="fas fa-folder"></i> Kategori
        </a>
    </li>
</ul>

<!-- Tab Content -->
<div class="tab-content">
    <!-- Tab Daftar Menu -->
    <div id="daftar-menu" class="tab-pane fade show active">
        <div class="row mb-3">
            <div class="col-md-12">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMenuModal">
                    <i class="fas fa-plus"></i> Tambah Menu
                </button>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Daftar Semua Menu</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Gambar</th>
                                        <th>Nama Menu</th>
                                        <th>Kategori</th>
                                        <th>Deskripsi</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($all_menu)): ?>
                                        <tr>
                                            <td colspan="7" class="text-center text-muted py-4">
                                                Belum ada menu. <a href="#" data-bs-toggle="modal" data-bs-target="#addMenuModal">Tambah sekarang</a>
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($all_menu as $item): ?>
                                            <tr>
                                                <td><?php echo $item['id']; ?></td>
                                                <td>
                                                    <?php if ($item['gambar'] && file_exists('../' . $item['gambar'])): ?>
                                                        <img src="../<?php echo htmlspecialchars($item['gambar']); ?>" 
                                                             alt="<?php echo htmlspecialchars($item['nama_menu']); ?>" 
                                                             class="menu-image">
                                                    <?php else: ?>
                                                        <span class="badge bg-secondary">Tidak ada gambar</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><strong><?php echo htmlspecialchars($item['nama_menu']); ?></strong></td>
                                                <td><?php echo htmlspecialchars($item['nama_kategori']); ?></td>
                                                <td><?php echo htmlspecialchars(substr($item['deskripsi'], 0, 40)); ?>...</td>
                                                <td>
                                                    <a href="menu.php?edit=<?php echo $item['id']; ?>" class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form method="POST" style="display:inline;" 
                                                          onsubmit="return confirm('Yakin ingin menghapus menu ini?');">
                                                        <input type="hidden" name="action" value="delete">
                                                        <input type="hidden" name="menu_id" value="<?php echo $item['id']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Tab Kategori -->
    <div id="kategori" class="tab-pane fade">
        <div class="row mb-3">
            <div class="col-md-12">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                    <i class="fas fa-plus"></i> Tambah Kategori
                </button>
            </div>
        </div>
        
        <div class="row">
            <?php foreach ($categories as $cat): ?>
                <div class="col-md-6 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo htmlspecialchars($cat['nama_kategori']); ?></h5>
                            <p class="card-text text-muted"><?php echo htmlspecialchars($cat['deskripsi']); ?></p>
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editCategoryModal" 
                                    onclick="editCategory(<?php echo $cat['id']; ?>, '<?php echo htmlspecialchars($cat['nama_kategori']); ?>', '<?php echo htmlspecialchars($cat['deskripsi']); ?>')">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <form method="POST" style="display:inline;" 
                                  onsubmit="return confirm('Yakin ingin menghapus kategori ini?');">
                                <input type="hidden" name="action" value="delete_category">
                                <input type="hidden" name="category_id" value="<?php echo $cat['id']; ?>">
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash"></i> Hapus
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<!-- Modal Tambah Menu -->
<div class="modal fade" id="addMenuModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Menu Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add">
                    
                    <div class="mb-3">
                        <label for="nama_menu" class="form-label">Nama Menu *</label>
                        <input type="text" class="form-control" id="nama_menu" name="nama_menu" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="kategori_id" class="form-label">Kategori *</label>
                        <select class="form-select" id="kategori_id" name="kategori_id" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>">
                                    <?php echo htmlspecialchars($cat['nama_kategori']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="deskripsi" class="form-label">Deskripsi *</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="gambar" class="form-label">Gambar Menu</label>
                        <input type="file" class="form-control" id="gambar" name="gambar" accept="image/*" 
                               onchange="previewImage(this, 'addMenuImage')">
                        <small class="text-muted">Format: JPG, PNG, GIF, WebP (Max 5MB)</small>
                        <img id="addMenuImage" class="img-preview" alt="Preview">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Tambah Menu</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Menu -->
<?php if ($edit_menu): ?>
<div class="modal fade show" id="editMenuModal" tabindex="-1" style="display: block;">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Menu</h5>
                <a href="menu.php" class="btn-close"></a>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="menu_id" value="<?php echo $edit_menu['id']; ?>">
                    
                    <div class="mb-3">
                        <label for="edit_nama_menu" class="form-label">Nama Menu *</label>
                        <input type="text" class="form-control" id="edit_nama_menu" name="nama_menu" 
                               value="<?php echo htmlspecialchars($edit_menu['nama_menu']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_kategori_id" class="form-label">Kategori *</label>
                        <select class="form-select" id="edit_kategori_id" name="kategori_id" required>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['id']; ?>" 
                                    <?php echo ($cat['id'] == $edit_menu['kategori_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($cat['nama_kategori']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_deskripsi" class="form-label">Deskripsi *</label>
                        <textarea class="form-control" id="edit_deskripsi" name="deskripsi" rows="3" required><?php echo htmlspecialchars($edit_menu['deskripsi']); ?></textarea>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_gambar" class="form-label">Gambar Menu</label>
                        <?php if ($edit_menu['gambar'] && file_exists('../' . $edit_menu['gambar'])): ?>
                            <div class="mb-2">
                                <img src="../<?php echo htmlspecialchars($edit_menu['gambar']); ?>" 
                                     alt="<?php echo htmlspecialchars($edit_menu['nama_menu']); ?>" 
                                     style="max-width: 200px; border-radius: 4px;">
                                <p class="text-muted small">Gambar saat ini</p>
                            </div>
                        <?php endif; ?>
                        <input type="file" class="form-control" id="edit_gambar" name="gambar" accept="image/*"
                               onchange="previewImage(this, 'editMenuImage')">
                        <small class="text-muted">Biarkan kosong untuk tidak mengubah gambar</small>
                        <img id="editMenuImage" class="img-preview" alt="Preview">
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="menu.php" class="btn btn-secondary">Batal</a>
                    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<style>
    .modal.show {
        display: block;
        background-color: rgba(0,0,0,0.5);
    }
</style>
<?php endif; ?>

<!-- Modal Tambah Kategori -->
<div class="modal fade" id="addCategoryModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Kategori Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="add_category">
                    
                    <div class="mb-3">
                        <label for="nama_kategori" class="form-label">Nama Kategori *</label>
                        <input type="text" class="form-control" id="nama_kategori" name="nama_kategori" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="deskripsi_kategori" class="form-label">Deskripsi</label>
                        <textarea class="form-control" id="deskripsi_kategori" name="deskripsi" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Tambah Kategori</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Edit Kategori -->
<div class="modal fade" id="editCategoryModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Kategori</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <input type="hidden" name="action" value="edit_category">
                    <input type="hidden" id="edit_cat_id" name="category_id" value="">
                    
                    <div class="mb-3">
                        <label for="edit_nama_kategori" class="form-label">Nama Kategori *</label>
                        <input type="text" class="form-control" id="edit_nama_kategori" name="nama_kategori" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="edit_deskripsi_kategori" class="form-label">Deskripsi</label>
                        <textarea class="form-control" id="edit_deskripsi_kategori" name="deskripsi" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Simpan Kategori</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function previewImage(input, previewId) {
    const file = input.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById(previewId);
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
}

function editCategory(id, nama, deskripsi) {
    document.getElementById('edit_cat_id').value = id;
    document.getElementById('edit_nama_kategori').value = nama;
    document.getElementById('edit_deskripsi_kategori').value = deskripsi;
}

// Auto-open edit modal if in edit mode
<?php if ($edit_menu): ?>
document.addEventListener('DOMContentLoaded', function() {
    const editModal = new bootstrap.Modal(document.getElementById('editMenuModal'));
    editModal.show();
});
<?php endif; ?>
</script>

<?php require_once '../includes/footer.php'; ?>
