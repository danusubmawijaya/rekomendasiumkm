<?php
/**
 * Run Password Reset Migration
 * This script adds the password reset columns to the users table
 */

session_start();

// Check jika sudah login sebagai admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}

require_once '../config/database.php';

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check kolom sudah ada atau belum
    $check_query = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='users' AND COLUMN_NAME='password_reset_token'";
    $result = $conn->query($check_query);
    
    if ($result && $result->num_rows > 0) {
        $message = 'Kolom password reset sudah ada. Tidak perlu migrasi.';
        $message_type = 'warning';
    } else {
        // Jalankan migrasi
        $migration_sql = "
        ALTER TABLE users 
        ADD COLUMN password_reset_token VARCHAR(255) DEFAULT NULL,
        ADD COLUMN password_reset_expires DATETIME DEFAULT NULL;
        
        CREATE INDEX idx_password_reset_token ON users(password_reset_token);
        ";
        
        if ($conn->multi_query($migration_sql)) {
            // Consume all results
            while ($conn->more_results() && $conn->next_result()) {
                $conn->use_result();
            }
            $message = '✓ Migrasi berhasil! Kolom password reset telah ditambahkan ke tabel users.';
            $message_type = 'success';
        } else {
            $message = 'Error: ' . $conn->error;
            $message_type = 'danger';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Run Password Reset Migration - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: #f9fafb;
            padding: 40px 20px;
        }
        .migration-container {
            background: white;
            max-width: 600px;
            margin: 0 auto;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .migration-header {
            margin-bottom: 28px;
        }
        .migration-header h1 {
            font-size: 1.6rem;
            font-weight: 700;
            color: #1a1a1a;
        }
        .migration-header p {
            color: #6b7280;
            margin-bottom: 0;
        }
        .alert {
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .btn-run {
            background: #1d7e3f;
            color: white;
            border: none;
            padding: 10px 24px;
            font-weight: 600;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            margin-top: 10px;
        }
        .btn-run:hover {
            background: #2d9f52;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(29, 126, 63, 0.3);
        }
        .btn-back {
            display: inline-block;
            margin-top: 20px;
            color: #1d7e3f;
            text-decoration: none;
            font-weight: 600;
        }
        .btn-back:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="migration-container">
        <div class="migration-header">
            <h1><i class="fas fa-database"></i> Password Reset Migration</h1>
            <p>Jalankan migrasi untuk menambahkan fitur reset password</p>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-<?php echo str_replace('warning', 'info', $message_type); ?>" role="alert">
                <i class="fas fa-<?php 
                    if ($message_type === 'success') echo 'check-circle';
                    elseif ($message_type === 'warning') echo 'exclamation-triangle';
                    else echo 'info-circle';
                ?>"></i>
                <?php echo htmlspecialchars($message); ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i>
                <strong>Informasi:</strong> Migrasi ini akan menambahkan 2 kolom baru ke tabel users:
                <ul style="margin-top: 10px; margin-bottom: 0;">
                    <li><code>password_reset_token</code> - Menyimpan token reset password</li>
                    <li><code>password_reset_expires</code> - Menyimpan waktu expired token</li>
                </ul>
            </div>

            <form method="POST" action="">
                <button type="submit" class="btn-run">
                    <i class="fas fa-play"></i> Jalankan Migrasi Sekarang
                </button>
            </form>
        <?php endif; ?>

        <a href="dashboard.php" class="btn-back">
            <i class="fas fa-arrow-left"></i> Kembali ke Dashboard
        </a>
    </div>
</body>
</html>
