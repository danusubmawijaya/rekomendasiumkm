<?php
require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/session.php';
require_once dirname(dirname(__DIR__)) . '/classes/User.php';

if (isLoggedIn()) {
    if (isAdmin()) {
        header("Location: dashboard.php");
        exit();
    } else {
        header("Location: ../../access_denied.php");
        exit();
    }
}

$message = '';
$message_type = '';
$redirect_target = null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = isset($_POST['email']) ? trim(strtolower($_POST['email'])) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    if (empty($email) || empty($password)) {
        $message = 'Email dan password harus diisi';
        $message_type = 'danger';
    } else {
        $user = new User($conn);
        $result = $user->login($email, $password);
        
        if ($result['success']) {
            // Cek apakah user adalah admin
            if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
                $redirect_target = 'dashboard.php';
            } else {
                // User biasa tidak bisa login di admin panel
                session_destroy();
                $message = 'Hanya admin yang dapat login di sini. Silakan gunakan login user biasa.';
                $message_type = 'danger';
            }
        } else {
            $message = $result['message'];
            $message_type = 'danger';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Sistem Rekomendasi Produk UMKM</title>
    <?php if ($redirect_target): ?>
    <meta http-equiv="refresh" content="0; url=<?php echo $redirect_target; ?>">
    <?php endif; ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #FF6A00 0%, #E85D04 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .login-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            padding: 40px;
            width: 100%;
            max-width: 400px;
        }
        
        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-header h1 {
            color: #FF6A00;
            font-weight: bold;
            margin-bottom: 10px;
        }
        
        .login-header p {
            color: #7f8c8d;
        }
        
        .badge-admin {
            background-color: #FFF1E6;
            color: #FF6A00;
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.85rem;
            display: inline-block;
            margin-bottom: 20px;
        }
        
        .form-control {
            border-radius: 5px;
            border: 1px solid #bdc3c7;
            padding: 10px 15px;
            margin-bottom: 15px;
        }
        
        .form-control:focus {
            border-color: #FF6A00;
            box-shadow: 0 0 0 0.2rem rgba(255, 106, 0, 0.25);
        }
        
        .btn-login {
            background-color: #FF6A00;
            border: none;
            padding: 10px;
            font-weight: bold;
            border-radius: 5px;
            width: 100%;
            margin-top: 10px;
            color: white;
        }
        
        .btn-login:hover {
            background-color: #E85D04;
            color: white;
        }
        
        .login-footer {
            text-align: center;
            margin-top: 20px;
        }
        
        .login-footer a {
            color: #FF6A00;
            text-decoration: none;
        }
        
        .login-footer a:hover {
            text-decoration: underline;
        }
        
        .info-box {
            background: #FFF1E6;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #FF6A00;
        }
        
        .info-box p {
            margin: 0;
            color: #555;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <h1><i class="fas fa-lock"></i> Admin Login</h1>
            <div class="badge-admin">
                <i class="fas fa-shield-alt"></i> Admin Panel
            </div>
            <p>Sistem Rekomendasi Produk UMKM</p>
        </div>
        
        <div class="info-box">
            <p><i class="fas fa-info-circle"></i> <strong>Hanya untuk Admin</strong></p>
            <p style="margin-top: 5px;">Jika Anda user biasa, gunakan <a href="../../login.php" style="color: #ee4d2d;">login user</a></p>
        </div>
        
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>" role="alert">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            
            <button type="submit" class="btn btn-login">Login Admin</button>
        </form>
        
        <div class="login-footer">
            <p>Bukan admin? <a href="../../login.php">Login sebagai user</a></p>
        </div>
    </div>
</body>
</html>
