<?php
require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/session.php';

if (!isLoggedIn() || !isAdmin()) {
    http_response_code(403);
    die("Unauthorized");
}

// Get data dari session
$loocv_iterations = isset($_SESSION['last_mae_evaluation']['loocv_iterations']) ? $_SESSION['last_mae_evaluation']['loocv_iterations'] : [];
$loocv_summary = isset($_SESSION['last_mae_evaluation']['loocv_summary']) ? $_SESSION['last_mae_evaluation']['loocv_summary'] : [];
$evaluation_timestamp = isset($_SESSION['last_mae_evaluation']['timestamp']) ? $_SESSION['last_mae_evaluation']['timestamp'] : null;

// Validasi data
if (!is_array($loocv_iterations)) {
    $loocv_iterations = [];
}
if (!is_array($loocv_summary)) {
    $loocv_summary = [
        'total_ratings' => 0,
        'total_iterations' => 0,
        'successful_predictions' => 0,
        'failed_predictions' => 0,
        'total_absolute_error' => 0,
        'mae' => 0
    ];
}

// Generate simple HTML that can be printed to PDF
header('Content-Type: text/html; charset=UTF-8');
header('Content-Disposition: attachment; filename="detail_evaluasi_mae_' . date('Y-m-d_H-i-s') . '.pdf"');

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Evaluasi MAE</title>
    <script>
        window.MathJax = {
            tex: {
                inlineMath: [['$', '$'], ['\\(', '\\)']],
                displayMath: [['$$', '$$'], ['\\[', '\\]']]
            },
            svg: {
                fontCache: 'global'
            }
        };
    </script>
    <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            color: #333;
        }
        h1, h2, h3 {
            color: #228B22;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        th {
            background-color: #228B22;
            color: white;
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        tr:nth-child(even) {
            background-color: #f5f5f5;
        }
        .summary-section {
            margin-top: 30px;
            page-break-before: always;
        }
        .summary-item {
            margin-bottom: 10px;
            display: inline-block;
            width: 45%;
            margin-right: 5%;
        }
        .formula {
            background-color: #f0f0f0;
            padding: 15px;
            margin-top: 10px;
            margin-bottom: 10px;
            border-left: 4px solid #228B22;
        }
        .formula-math {
            text-align: center;
            margin: 15px 0;
            font-size: 1.1rem;
            line-height: 2;
        }
        .timestamp-info {
            background-color: #e8f5e9;
            padding: 10px;
            margin-bottom: 20px;
            border-left: 4px solid #228B22;
        }
    </style>
</head>
<body>
    <h1>Detail Evaluasi MAE</h1>
    <p style="font-style: italic; color: #666;">Laporan Leave-One-Out Cross Validation (LOOCV)</p>

    <?php if ($evaluation_timestamp): ?>
    <div class="timestamp-info">
        <strong>Tanggal Evaluasi:</strong> <?php echo isset($evaluation_timestamp['date']) ? htmlspecialchars($evaluation_timestamp['date']) : '-'; ?> 
        | <strong>Jam:</strong> <?php echo isset($evaluation_timestamp['time']) ? htmlspecialchars($evaluation_timestamp['time']) : '-'; ?>
        | <strong>Durasi:</strong> <?php echo isset($evaluation_timestamp['duration']) ? $evaluation_timestamp['duration'] . ' detik' : '-'; ?>
    </div>
    <?php endif; ?>

    <h2>Tabel Detail LOOCV</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Iterasi</th>
                <th>User ID</th>
                <th>Product ID</th>
                <th>Nama Produk</th>
                <th>Rating Aktual</th>
                <th>Rating Prediksi</th>
                <th>Absolute Error</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            if (is_array($loocv_iterations) && !empty($loocv_iterations)) {
                foreach ($loocv_iterations as $index => $iteration) {
                    if (is_array($iteration)) {
            ?>
            <tr>
                <td><?php echo ($index + 1); ?></td>
                <td><?php echo isset($iteration['iteration']) ? htmlspecialchars($iteration['iteration']) : '-'; ?></td>
                <td><?php echo isset($iteration['user_id']) ? htmlspecialchars($iteration['user_id']) : '-'; ?></td>
                <td><?php echo isset($iteration['product_id']) ? htmlspecialchars($iteration['product_id']) : '-'; ?></td>
                <td><?php echo isset($iteration['product_name']) ? htmlspecialchars($iteration['product_name']) : '-'; ?></td>
                <td><?php echo isset($iteration['actual_rating']) ? htmlspecialchars($iteration['actual_rating']) : '-'; ?></td>
                <td><?php echo isset($iteration['predicted_rating']) ? (floatval($iteration['predicted_rating']) > 0 ? htmlspecialchars($iteration['predicted_rating']) : '-') : '-'; ?></td>
                <td><?php echo isset($iteration['absolute_error']) ? (floatval($iteration['absolute_error']) > 0 ? htmlspecialchars($iteration['absolute_error']) : '-') : '-'; ?></td>
                <td><?php echo isset($iteration['status']) ? htmlspecialchars($iteration['status']) : '-'; ?></td>
            </tr>
            <?php 
                    }
                }
            } else {
            ?>
            <tr>
                <td colspan="9" style="text-align: center; color: #999;">Tidak ada data</td>
            </tr>
            <?php 
            }
            ?>
        </tbody>
    </table>

    <div class="summary-section">
        <h2>Ringkasan Evaluasi</h2>
        
        <div class="summary-item">
            <strong>Jumlah Rating:</strong> <?php echo isset($loocv_summary['total_ratings']) ? htmlspecialchars($loocv_summary['total_ratings']) : '0'; ?>
        </div>
        <div class="summary-item">
            <strong>Iterasi LOOCV:</strong> <?php echo isset($loocv_summary['total_iterations']) ? htmlspecialchars($loocv_summary['total_iterations']) : '0'; ?>
        </div>
        
        <div class="summary-item">
            <strong>Prediksi Berhasil:</strong> <?php echo isset($loocv_summary['successful_predictions']) ? htmlspecialchars($loocv_summary['successful_predictions']) : '0'; ?>
        </div>
        <div class="summary-item">
            <strong>Prediksi Gagal:</strong> <?php echo isset($loocv_summary['failed_predictions']) ? htmlspecialchars($loocv_summary['failed_predictions']) : '0'; ?>
        </div>

        <div class="summary-item">
            <strong>Total Absolute Error:</strong> <?php echo isset($loocv_summary['total_absolute_error']) ? htmlspecialchars(number_format(floatval($loocv_summary['total_absolute_error']), 3)) : '0.000'; ?>
        </div>
        <div class="summary-item">
            <strong>MAE (Mean Absolute Error):</strong> <?php echo isset($loocv_summary['mae']) ? htmlspecialchars(number_format(floatval($loocv_summary['mae']), 4)) : '0.0000'; ?>
        </div>

        <h3>Proses Perhitungan MAE</h3>
        <div class="formula">
            <strong>Rumus Mean Absolute Error (MAE):</strong>
            <div class="formula-math">
                $$\text{MAE}=\frac{1}{n}\sum_{i=1}^{n}|P_i-R_i|$$
            </div>
            <strong>Penjelasan Variabel:</strong><br>
            - P<sub>i</sub> = Rating yang diprediksi menggunakan User-Based Collaborative Filtering dengan Cosine Similarity<br>
            - R<sub>i</sub> = Rating aktual dari database<br>
            - n = Jumlah total rating yang dievaluasi dalam Leave-One-Out Cross Validation<br>
            - |P<sub>i</sub> - R<sub>i</sub>| = Nilai absolut dari selisih prediksi dan aktual
        </div>

        <div class="formula">
            <strong>Perhitungan Akhir:</strong><br>
            MAE = <?php echo isset($loocv_summary['total_absolute_error']) ? htmlspecialchars(number_format(floatval($loocv_summary['total_absolute_error']), 3)) : '0.000'; ?> / <?php echo isset($loocv_summary['total_iterations']) ? htmlspecialchars($loocv_summary['total_iterations']) : '0'; ?> = <strong><?php echo isset($loocv_summary['mae']) ? htmlspecialchars(number_format(floatval($loocv_summary['mae']), 4)) : '0.0000'; ?></strong>
        </div>
    </div>

    <div style="margin-top: 40px; text-align: center; color: #999; font-size: 12px;">
        <p>Generated: <?php echo date('d-m-Y H:i:s'); ?></p>
        <p>UMKM Recommendation System - Evaluasi MAE</p>
    </div>

    <script type="text/javascript">
        // Render MathJax setelah halaman selesai dimuat
        if (window.MathJax) {
            MathJax.typesetPromise().then(() => {
                // Auto-print saat halaman dimuat dan rumus sudah dirender
                if (window.location.search.indexOf('autoprint=1') > -1) {
                    window.print();
                }
            }).catch(err => console.log(err));
        } else {
            // Fallback jika MathJax tidak tersedia
            if (window.location.search.indexOf('autoprint=1') > -1) {
                window.print();
            }
        }
    </script>
</body>
</html>
