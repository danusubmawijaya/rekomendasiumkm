<?php
require_once dirname(dirname(__DIR__)) . '/config/database.php';
require_once dirname(dirname(__DIR__)) . '/config/session.php';
require_once dirname(dirname(__DIR__)) . '/classes/CollaborativeFiltering.php';

if (!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

if (!isAdmin()) {
    header("Location: ../../access_denied.php");
    exit();
}

$cf = new CollaborativeFiltering($conn);
$mae_result = null;
$evaluation_timestamp = null;
$loocv_iterations = [];
$loocv_summary = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'calculate_mae') {
    $evaluation_timestamp = [
        'date' => date('d-m-Y'),
        'time' => date('H:i:s'),
        'start_time' => microtime(true)
    ];
    
    $mae_result = $cf->calculateMAE();
    
    $evaluation_timestamp['end_time'] = microtime(true);
    $evaluation_timestamp['duration'] = round($evaluation_timestamp['end_time'] - $evaluation_timestamp['start_time'], 2);
    
    // Get LOOCV data with validation
    $loocv_iterations = $cf->getLOOCVIterations();
    $loocv_summary = $cf->getLOOCVSummary();
    
    // Ensure data structures are proper arrays
    if (!is_array($loocv_iterations)) {
        $loocv_iterations = [];
    }
    
    // Ensure loocv_summary has all required keys
    if (!is_array($loocv_summary)) {
        $loocv_summary = [];
    }
    
    $required_summary_keys = ['total_ratings', 'total_iterations', 'successful_predictions', 'failed_predictions', 'total_absolute_error', 'mae'];
    foreach ($required_summary_keys as $key) {
        if (!isset($loocv_summary[$key])) {
            $loocv_summary[$key] = 0;
        }
    }
    
    // Store in session for detail page access
    $_SESSION['last_mae_evaluation'] = [
        'mae_result' => $mae_result,
        'timestamp' => $evaluation_timestamp,
        'loocv_iterations' => $loocv_iterations,
        'loocv_summary' => $loocv_summary
    ];
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Evaluasi MAE - Admin UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="../../css/admin.css" rel="stylesheet">
    <script>
        window.MathJax = {
            tex: {
                inlineMath: [['$', '$'], ['\\(', '\\)']],
                displayMath: [['$$', '$$'], ['\\[', '\\]']]
            },
            svg: {
                fontCache: 'global'
            }
        };
    </script>
    <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
</head>
<body>
    <!-- Mobile Menu Toggle -->
    <button class="sidebar-toggle" id="sidebarToggle" aria-label="Toggle menu">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar Overlay untuk Mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-leaf"></i> UMKM Recommend
        </div>
        <a href="dashboard.php" class="nav-link-admin">
            <i class="fas fa-chart-line"></i> <span>Dashboard</span>
        </a>
        <a href="products.php" class="nav-link-admin">
            <i class="fas fa-box"></i> <span>Kelola Produk</span>
        </a>
        <a href="evaluasi_mae.php" class="nav-link-admin active">
            <i class="fas fa-chart-bar"></i> <span>Evaluasi MAE</span>
        </a>
        <a href="users.php" class="nav-link-admin">
            <i class="fas fa-users"></i> <span>Kelola Pengguna</span>
        </a>
        <hr style="border-color: rgba(255,255,255,0.2); margin: 20px 0;">
        <a href="profile.php" class="nav-link-admin">
            <i class="fas fa-user-cog"></i> <span>Profil Saya</span>
        </a>
        <a href="../../logout.php" class="nav-link-admin">
            <i class="fas fa-sign-out-alt"></i> <span>Logout</span>
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <div class="dashboard-header">
            <div>
                <h1 class="dashboard-title"><i class="fas fa-chart-bar"></i> Evaluasi MAE</h1>
                <p style="color: #999; margin: 5px 0 0 0;">Hitung akurasi sistem rekomendasi</p>
            </div>
        </div>

        <!-- Content -->
        <div class="row">
            <div class="col-lg-8">
                <!-- Evaluasi Card -->
                <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden; margin-bottom: 24px;">
                    <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(255, 106, 0, 0.05), rgba(232, 93, 4, 0.05));">
                        <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                            <i class="fas fa-calculator" style="color: var(--primary-color); margin-right: 10px;"></i>
                            Evaluasi Mean Absolute Error (MAE)
                        </h2>
                    </div>
                    <div style="padding: 24px;">
                        <p style="color: #666; margin-bottom: 24px; line-height: 1.6;">
                            Evaluasi akurasi sistem rekomendasi menggunakan <strong>User-Based Collaborative Filtering</strong> dengan <strong>Cosine Similarity</strong>. Sistem akan membandingkan rating prediksi dengan rating sebenarnya untuk menghitung Mean Absolute Error.
                        </p>

                        <form method="POST" class="mb-4">
                            <input type="hidden" name="action" value="calculate_mae">
                            <button type="submit" class="btn" style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); color: white; padding: 10px 24px; border: none; border-radius: 8px; font-weight: 600; transition: all 0.3s; cursor: pointer;">
                                <i class="fas fa-calculator"></i> Hitung MAE Sekarang
                            </button>
                        </form>

                        <?php if ($mae_result !== null): ?>
                        <div style="background: #FFF1E6; border: 2px solid #FF6A00; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
                            <p style="margin: 0; color: #D84315; font-weight: 600;">
                                <i class="fas fa-check-circle"></i> Evaluasi MAE selesai!
                            </p>
                        </div>

                        <!-- Execution Info -->
                        <?php if ($evaluation_timestamp): ?>
                        <div style="background: #FFF1E6; border: 2px solid #FF6A00; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
                            <p style="margin: 0 0 12px 0; color: #D84315; font-weight: 600;">
                                <i class="fas fa-info-circle"></i> Informasi Eksekusi
                            </p>
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 12px;">
                                <div>
                                    <p style="margin: 0; font-size: 0.85rem; color: #999;">Tanggal Evaluasi</p>
                                    <p style="margin: 4px 0 0 0; font-weight: 600; color: #D84315;"><?php echo $evaluation_timestamp['date']; ?></p>
                                </div>
                                <div>
                                    <p style="margin: 0; font-size: 0.85rem; color: #999;">Jam Evaluasi</p>
                                    <p style="margin: 4px 0 0 0; font-weight: 600; color: #D84315;"><?php echo $evaluation_timestamp['time']; ?></p>
                                </div>
                                <div>
                                    <p style="margin: 0; font-size: 0.85rem; color: #999;">Durasi Proses</p>
                                    <p style="margin: 4px 0 0 0; font-weight: 600; color: #D84315;"><?php echo $evaluation_timestamp['duration']; ?> detik</p>
                                </div>
                                <div>
                                    <p style="margin: 0; font-size: 0.85rem; color: #999;">Jumlah Rating</p>
                                    <p style="margin: 4px 0 0 0; font-weight: 600; color: #D84315;"><?php echo isset($_SESSION['last_mae_evaluation']['loocv_summary']['total_ratings']) ? $_SESSION['last_mae_evaluation']['loocv_summary']['total_ratings'] : '-'; ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Results -->
                        <div style="background: #f8f9fa; padding: 24px; border-radius: 12px; border-left: 5px solid var(--primary-color); margin-bottom: 20px;">
                            <h4 style="font-weight: 600; color: var(--dark-color); margin-bottom: 20px;">
                                <i class="fas fa-chart-pie"></i> Hasil Evaluasi
                            </h4>
                            
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 20px;">
                                <div style="background: white; padding: 20px; border-radius: 8px; border: 2px solid #FFE0C3; text-align: center;">
                                    <p style="color: #999; font-size: 0.9rem; margin-bottom: 12px; font-weight: 500;">
                                        <i class="fas fa-ruler" style="color: var(--primary-color); margin-right: 6px;"></i>
                                        Mean Absolute Error
                                    </p>
                                    <h3 style="color: var(--primary-color); margin: 0; font-weight: 700; font-size: 2rem;">
                                        <?php echo number_format($mae_result, 4); ?>
                                    </h3>
                                </div>
                                
                                <div style="background: white; padding: 20px; border-radius: 8px; border: 2px solid #FFE0C3; text-align: center;">
                                    <p style="color: #999; font-size: 0.9rem; margin-bottom: 12px; font-weight: 500;">
                                        <i class="fas fa-thumbs-up" style="color: var(--primary-color); margin-right: 6px;"></i>
                                        Interpretasi
                                    </p>
                                    <p style="margin: 0; font-size: 1rem; font-weight: 600;">
                                        <?php 
                                        if ($mae_result <= 0.5) {
                                            echo '<span style="color: #FF6A00;">✓ Sangat Baik</span><br><small style="color: #999; font-size: 0.85rem; font-weight: normal;">Error ≤ 0.5 bintang</small>';
                                        } elseif ($mae_result <= 1.0) {
                                            echo '<span style="color: #E85D04;">✓ Baik</span><br><small style="color: #999; font-size: 0.85rem; font-weight: normal;">Error ≤ 1.0 bintang</small>';
                                        } else {
                                            echo '<span style="color: #F97316;">◐ Cukup</span><br><small style="color: #999; font-size: 0.85rem; font-weight: normal;">Error > 1.0 bintang</small>';
                                        }
                                        ?>
                                    </p>
                                </div>
                            </div>

                            <div style="padding: 16px; background: #FFF1E6; border-radius: 8px; border-left: 4px solid #FF6A00;">
                                <p style="margin: 0 0 12px 0; color: #D84315; font-size: 0.9rem; font-weight: 600;">
                                    <i class="fas fa-formula"></i> Rumus Perhitungan:
                                </p>
                                <div style="background: white; padding: 16px; border-radius: 6px; border: 1px solid #FFE0C3; overflow-x: auto;">
                                    <div style="margin: 0; color: #D84315; font-size: 0.95rem; text-align: center; line-height: 2;">
                                        $$\text{MAE}=\frac{1}{n}\sum_{i=1}^{n}|P_i-R_i|$$
                                    </div>
                                    <p style="margin: 12px 0 0 0; color: #E85D04; font-size: 0.85rem; text-align: center;">
                                        Dimana: <em>P<sub>i</sub></em> = Predicted Rating, <em>R<sub>i</sub></em> = Actual Rating, <em>n</em> = Total Rating
                                    </p>
                                </div>
                            </div>

                            <div style="margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd;">
                                <a href="detail_evaluasi.php" class="btn" style="background: linear-gradient(135deg, #FF6A00, #E85D04); color: white; padding: 10px 20px; border: none; border-radius: 8px; font-weight: 600; text-decoration: none; display: inline-block; transition: all 0.3s; cursor: pointer;">
                                    <i class="fas fa-magnifying-glass"></i> Lihat Detail Evaluasi
                                </a>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <!-- Info Card -->
                <div style="background: white; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); overflow: hidden;">
                    <div style="padding: 20px; border-bottom: 2px solid var(--border-color); background: linear-gradient(135deg, rgba(255, 106, 0, 0.05), rgba(232, 93, 4, 0.05));">
                        <h2 style="margin: 0; font-size: 1.3rem; font-weight: 600; color: var(--dark-color);">
                            <i class="fas fa-info-circle" style="color: var(--primary-color); margin-right: 10px;"></i>
                            Metode Evaluasi
                        </h2>
                    </div>
                    <div style="padding: 24px;">
                        <div style="margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
                            <p style="font-size: 0.85rem; color: #999; margin-bottom: 8px; font-weight: 600; text-transform: uppercase;">
                                <i class="fas fa-cogs" style="color: var(--primary-color); margin-right: 6px;"></i>
                                Teknik CF
                            </p>
                            <p style="color: var(--dark-color); margin: 0; font-weight: 500;">User-Based Collaborative Filtering</p>
                        </div>

                        <div style="margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
                            <p style="font-size: 0.85rem; color: #999; margin-bottom: 8px; font-weight: 600; text-transform: uppercase;">
                                <i class="fas fa-ruler-combined" style="color: var(--primary-color); margin-right: 6px;"></i>
                                Perhitungan Similarity
                            </p>
                            <p style="color: var(--dark-color); margin: 0; font-weight: 500;">Cosine Similarity</p>
                        </div>

                        <div style="margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
                            <p style="font-size: 0.85rem; color: #999; margin-bottom: 8px; font-weight: 600; text-transform: uppercase;">
                                <i class="fas fa-chart-line" style="color: var(--primary-color); margin-right: 6px;"></i>
                                Prediksi Rating
                            </p>
                            <div style="background: #f8f9fa; padding: 12px; border-radius: 6px; border-left: 3px solid var(--primary-color); overflow-x: auto;">
                                <div style="margin: 0; color: var(--dark-color); font-size: 0.9rem; text-align: center; line-height: 1.8;">
                                    $$P(u,i)= \frac{ \sum_{v}Sim(u,v)\times r(v,i) }{ \sum_{v}|Sim(u,v)| }$$
                                </div>
                            </div>
                        </div>

                        <div style="margin-bottom: 20px; padding-bottom: 16px; border-bottom: 1px solid var(--border-color);">
                            <p style="font-size: 0.85rem; color: #999; margin-bottom: 8px; font-weight: 600; text-transform: uppercase;">
                                <i class="fas fa-award" style="color: var(--primary-color); margin-right: 6px;"></i>
                                Metrik Evaluasi
                            </p>
                            <p style="color: var(--dark-color); margin: 0; font-weight: 500;">Mean Absolute Error (MAE)</p>
                        </div>

                        <div style="padding: 16px; background: #FFF1E6; border-radius: 8px; border-left: 4px solid #FF6A00;">
                            <p style="margin: 0; color: #D84315; font-size: 0.85rem; line-height: 1.6;">
                                <i class="fas fa-lightbulb"></i> Evaluasi membandingkan semua prediksi rating dengan rating sebenarnya untuk mengukur akurasi sistem rekomendasi.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Render MathJax setelah halaman selesai dimuat
        if (window.MathJax) {
            MathJax.typesetPromise().catch(err => console.log(err));
        }

        // Mobile Menu Toggle
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('show');
                sidebarOverlay.classList.toggle('active');
            });

            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('show');
                sidebarOverlay.classList.remove('active');
            });

            const navLinks = document.querySelectorAll('.nav-link-admin');
            navLinks.forEach(link => {
                link.addEventListener('click', function() {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                });
            });

            window.addEventListener('resize', function() {
                if (window.innerWidth > 768) {
                    sidebar.classList.remove('show');
                    sidebarOverlay.classList.remove('active');
                }
            });
        }
    </script>
</body>
</html>
