<?php
require_once '../config/session.php';

if (!isLoggedIn() || !isAdmin()) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>Admin - UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #228B22;
            --secondary-color: #2d5016;
            --dark-color: #1a3a1a;
            --light-color: #e8f5e9;
            --text-color: #1f2937;
            --border-color: #c8e6c9;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-color);
            color: var(--text-color);
        }

        .sidebar {
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--secondary-color) 100%);
            min-height: 100vh;
            padding: 20px 0;
            position: fixed;
            left: 0;
            width: 250px;
            color: white;
            overflow-y: auto;
        }

        .sidebar-brand {
            padding: 20px;
            text-align: center;
            font-size: 1.3rem;
            font-weight: 700;
            margin-bottom: 30px;
            border-bottom: 2px solid rgba(255,255,255,0.2);
        }

        .nav-link-admin {
            color: rgba(255,255,255,0.8);
            padding: 12px 20px;
            margin: 5px 0;
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .nav-link-admin:hover {
            background-color: rgba(255,255,255,0.1);
            color: white;
            border-left-color: white;
        }

        .nav-link-admin.active {
            background-color: rgba(255,255,255,0.15);
            color: white;
            border-left-color: white;
        }

        .main-content {
            margin-left: 250px;
            padding: 30px;
        }

        .page-header {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid var(--border-color);
        }

        .page-title {
            font-size: 2rem;
            font-weight: 700;
            color: var(--dark-color);
        }

        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .card {
            border: 1px solid var(--border-color);
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            border-radius: 12px;
        }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
        }

        .btn-primary:hover {
            background: linear-gradient(135deg, var(--secondary-color), var(--dark-color));
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 200px;
            }

            .main-content {
                margin-left: 200px;
                padding: 20px;
            }

            .page-title {
                font-size: 1.5rem;
            }
        }

        @media (max-width: 576px) {
            .sidebar {
                width: 150px;
                padding: 10px 0;
            }

            .main-content {
                margin-left: 150px;
                padding: 15px;
            }

            .nav-link-admin {
                padding: 10px 15px;
                font-size: 0.85rem;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="fas fa-leaf"></i> UMKM Recommend
        </div>
        <a href="dashboard.php" class="nav-link-admin <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-line"></i> Dashboard
        </a>
        <a href="products.php" class="nav-link-admin <?php echo basename($_SERVER['PHP_SELF']) == 'products.php' ? 'active' : ''; ?>">
            <i class="fas fa-box"></i> Kelola Produk
        </a>
        <a href="auto_geocode_locations.php" class="nav-link-admin <?php echo basename($_SERVER['PHP_SELF']) == 'auto_geocode_locations.php' ? 'active' : ''; ?>">
            <i class="fas fa-map-marker-alt"></i> Auto-Geocode Lokasi
        </a>
        <a href="evaluasi_mae.php" class="nav-link-admin <?php echo basename($_SERVER['PHP_SELF']) == 'evaluasi_mae.php' ? 'active' : ''; ?>">
            <i class="fas fa-chart-bar"></i> Evaluasi MAE
        </a>
        <a href="users.php" class="nav-link-admin <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>">
            <i class="fas fa-users"></i> Kelola Pengguna
        </a>
        <hr style="border-color: rgba(255,255,255,0.2); margin: 20px 0;">
        <a href="profile.php" class="nav-link-admin">
            <i class="fas fa-user-cog"></i> <span>Profil Saya</span>
        </a>
        <a href="../logout.php" class="nav-link-admin">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
