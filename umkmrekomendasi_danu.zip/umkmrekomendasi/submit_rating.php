<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once BASE_PATH . '/classes/Rating.php';

error_log("=== RATING SUBMIT START ===");
error_log("Method: " . $_SERVER['REQUEST_METHOD']);
error_log("POST data: " . json_encode($_POST));

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("Not POST request");
    header("Location: index.php");
    exit();
}

$product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
$rating = isset($_POST['rating']) ? intval($_POST['rating']) : 0;

error_log("Product ID: $product_id");
error_log("Rating: $rating");

if (!$product_id || !$rating || $rating < 1 || $rating > 5) {
    error_log("Validation failed");
    $_SESSION['message'] = 'Data rating tidak valid';
    $_SESSION['message_type'] = 'danger';
    header("Location: product_detail.php?id=" . $product_id);
    exit();
}

try {
    $rating_obj = new Rating($conn);
    
    // Cek apakah user sudah login
    if (isLoggedIn()) {
        $user_id = intval($_SESSION['user_id']);
        $guest_id = null;
        error_log("User logged in - User ID: $user_id");
    } else {
        $user_id = null;
        $guest_id = getGuestId();
        error_log("User not logged in - Guest ID: $guest_id");
        
        // Validate guest_id - HARUS valid dan tidak kosong
        if (!$guest_id || trim($guest_id) === '') {
            error_log("WARNING: Guest ID invalid or empty, generating new one");
            initializeGuestId();
            $guest_id = getGuestId();
            
            if (!$guest_id) {
                error_log("ERROR: Still unable to generate valid guest ID!");
                $_SESSION['message'] = 'Gagal membuat session guest. Coba refresh halaman atau gunakan browser lain.';
                $_SESSION['message_type'] = 'danger';
                header("Location: product_detail.php?id=" . intval($product_id));
                exit();
            }
        }
    }
    
    // Submit rating
    $result = $rating_obj->addRating($user_id, $product_id, $rating, $guest_id);
    
    error_log("Rating result: " . json_encode($result));
    error_log("DEBUG: After rating - user_id=$user_id, guest_id=$guest_id, product_id=$product_id");
    
    $_SESSION['message'] = $result['message'];
    $_SESSION['message_type'] = $result['success'] ? 'success' : 'danger';
    
} catch (Exception $e) {
    error_log("Rating error: " . $e->getMessage());
    $_SESSION['message'] = 'Gagal menyimpan rating: ' . $e->getMessage();
    $_SESSION['message_type'] = 'danger';
}

error_log("=== RATING SUBMIT END ===");
header("Location: product_detail.php?id=" . intval($product_id));
?>
