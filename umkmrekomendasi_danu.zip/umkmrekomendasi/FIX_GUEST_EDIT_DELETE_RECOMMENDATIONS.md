# Fix Guest Edit/Delete Rating dan Rekomendasi

**Date:** 2026-08-14  
**Status:** COMPLETE  
**Priority:** HIGH

## Problem Summary

Setelah memperbaiki foreign key constraint, guest user mengalami 3 masalah baru:
1. **Tidak bisa edit rating** - Rating yang sudah ada tidak terdeteksi
2. **Tidak bisa hapus rating** - Delete button tidak berfungsi
3. **Tidak mendapat rekomendasi** - Sistem rekomendasi tidak bekerja untuk guest

## Root Cause Analysis

Masalah disebabkan oleh inkonsistensi query di beberapa file. Setelah foreign key fix, guest ratings di-store dengan `user_id = NULL` (bukan `user_id = 0`), tetapi beberapa query masih menggunakan kondisi lama `user_id = 0`.

### File yang Bermasalah

| File | Problem | Query Lama | Query Baru |
|------|---------|-----------|-----------|
| `product_detail.php` | Line ~156 | `user_id = 0 AND guest_id = ?` | `user_id IS NULL AND guest_id = ?` |
| `rekomendasi.php` | Line ~40 | `user_id = 0 AND guest_id = ?` | `user_id IS NULL AND guest_id = ?` |
| `classes/CollaborativeFiltering.php` | Line ~82 | `user_id = 0 AND guest_id IS NOT NULL` | `user_id IS NULL AND guest_id IS NOT NULL` |

## Changes Made

### 1. `product_detail.php` (Line ~156)
**Before:**
```php
$stmt = $conn->prepare("SELECT rating FROM ratings WHERE user_id = 0 AND guest_id = ? AND product_id = ?");
```

**After:**
```php
$stmt = $conn->prepare("SELECT rating FROM ratings WHERE user_id IS NULL AND guest_id = ? AND product_id = ?");
```

**Impact:** Guest user sekarang bisa melihat rating mereka yang sudah ada, memungkinkan edit/delete.

### 2. `rekomendasi.php` (Line ~40)
**Before:**
```php
$check_rating_query = "SELECT COUNT(*) as total FROM ratings WHERE user_id = 0 AND guest_id = '" . $conn->real_escape_string($identity['id']) . "'";
```

**After:**
```php
$check_rating_query = "SELECT COUNT(*) as total FROM ratings WHERE user_id IS NULL AND guest_id = '" . $conn->real_escape_string($identity['id']) . "'";
```

**Impact:** Sistem sekarang bisa menghitung rating guest dengan benar, memungkinkan rekomendasi dihasilkan.

### 3. `classes/CollaborativeFiltering.php` (Line ~82)
**Before:**
```php
WHERE (user_id > 0) OR (user_id = 0 AND guest_id IS NOT NULL AND guest_id != '')
```

**After:**
```php
WHERE (user_id > 0) OR (user_id IS NULL AND guest_id IS NOT NULL AND guest_id != '')
```

**Impact:** CF algorithm sekarang memuat guest ratings dengan benar, menghasilkan rekomendasi yang akurat.

## Verification Checklist

### Test 1: Edit Rating (Guest)
- [ ] Login di incognito mode (guest)
- [ ] Buka product detail yang sudah di-rating
- [ ] Lihat rating lama ditampilkan di section "Berikan Rating"
- [ ] Ubah rating (misal 3 -> 5 bintang)
- [ ] Klik "Simpan Rating"
- [ ] Verifikasi: Rating terupdate, message sukses muncul

### Test 2: Delete Rating (Guest)
- [ ] Guest sudah memiliki rating untuk produk
- [ ] Di bawah rating section, lihat button delete/hapus rating
- [ ] Klik button tersebut
- [ ] Verifikasi: Rating terhapus, rating display kembali kosong

### Test 3: Rekomendasi (Guest)
- [ ] Guest berikan 3-5 rating untuk produk berbeda
- [ ] Buka halaman /rekomendasi.php
- [ ] Verifikasi: 
  - Halaman memuat dengan baik (tidak error)
  - Muncul daftar rekomendasi produk
  - Rating count guest sudah terhitung

### Test 4: Logged-in User (Regression)
- [ ] Login dengan user account
- [ ] Edit dan delete rating masih berfungsi
- [ ] Rekomendasi masih muncul untuk user

## Database State Verification

Jalankan query ini untuk memastikan data sudah bersih:

```sql
-- Verifikasi guest ratings menggunakan NULL
SELECT id, user_id, guest_id, product_id, rating 
FROM ratings 
WHERE user_id IS NULL AND guest_id IS NOT NULL 
LIMIT 10;

-- Verifikasi user ratings tetap intact
SELECT id, user_id, guest_id, product_id, rating 
FROM ratings 
WHERE user_id > 0 
LIMIT 10;

-- Count total ratings per type
SELECT 
  SUM(CASE WHEN user_id > 0 THEN 1 ELSE 0 END) as user_ratings,
  SUM(CASE WHEN user_id IS NULL AND guest_id IS NOT NULL THEN 1 ELSE 0 END) as guest_ratings,
  COUNT(*) as total_ratings
FROM ratings;
```

Expected output:
- Guest ratings: `user_id = NULL` dengan valid `guest_id` (UUID format)
- User ratings: `user_id > 0`
- Total ratings: Jumlah semua rating

## Files Modified

1. ✅ `product_detail.php` - Query untuk ambil user rating
2. ✅ `rekomendasi.php` - Query untuk count user ratings
3. ✅ `classes/CollaborativeFiltering.php` - Query untuk load all ratings
4. ✅ `classes/Rating.php` - (sudah diperbaiki sebelumnya)
5. ✅ `delete_rating.php` - (sudah benar, menggunakan Rating class)
6. ✅ `submit_rating.php` - (sudah benar, menggunakan Rating class)

## No Changes Needed

File-file ini sudah benar dan tidak perlu perubahan:
- `classes/Rating.php` ✅ (sudah diperbaiki sebelumnya)
- `delete_rating.php` ✅ (menggunakan Rating class method)
- `submit_rating.php` ✅ (menggunakan Rating class method)
- `config/session.php` ✅ (session management)

## Deployment Checklist

- [ ] Backup database sebelum deploy
- [ ] Update 3 file yang dimodifikasi:
  - `product_detail.php`
  - `rekomendasi.php`
  - `classes/CollaborativeFiltering.php`
- [ ] Clear application cache (if using caching layer)
- [ ] Clear browser cache
- [ ] Test dengan guest user (incognito mode)
- [ ] Test dengan logged-in user (regression test)
- [ ] Monitor error logs untuk 24 jam pertama

## Rollback Plan

Jika ada masalah:
1. Revert 3 file ke versi sebelumnya
2. Tidak perlu database changes
3. Restart application/web server

## Notes

- Tidak ada database migration diperlukan untuk fix ini
- Query change hanya di aplikasi, data sudah bersih dari foreign key fix sebelumnya
- Rekomendasi mungkin masih kosong untuk guest baru (normal - butuh rating dari user lain yang mirip)

---

**Completed By:** System Admin  
**Last Updated:** 2026-08-14  
**Next Review:** 2026-08-15 (setelah testing 24 jam)
