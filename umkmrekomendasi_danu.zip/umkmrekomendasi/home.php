    <?php
    require_once 'config/database.php';
    require_once 'config/session.php';
    require_once BASE_PATH . '/classes/Product.php';



    // Ambil kategori dari database
    $sql_categories = "SELECT DISTINCT kategori FROM products WHERE kategori IS NOT NULL AND kategori != '' ORDER BY kategori ASC";
    $result_categories = $conn->query($sql_categories);
    $categories_from_db = [];
    if ($result_categories) {
        while ($row = $result_categories->fetch_assoc()) {
            if (!empty($row['kategori'])) {
                $categories_from_db[] = $row['kategori'];
            }
        }
    }
    
    // Tambah kategori Makanan Rumahan jika belum ada
    if (!in_array('Makanan Rumahan', $categories_from_db)) {
        $categories_from_db[] = 'Makanan Rumahan';
        sort($categories_from_db);
    }

    // Cek apakah user sudah login
    $is_logged_in = isLoggedIn();
    $user_id = $is_logged_in ? getCurrentUserId() : 0;
    // Ambil jumlah rating 4 dan 5 untuk setiap produk dari database
    $high_ratings_count = [];
    $verified_products = [];

    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta name="google-adsense-account" content="ca-pub-4386407350763103">
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4386407350763103"
        crossorigin="anonymous"></script>
        <base href="/umkmrekomendasi/">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>UMKM Recommend - Temukan Makanan UMKM Favoritmu</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
        <style>
            :root {
                --primary-color: #FF6A00;
                --primary-light: #FFF1E6;
                --primary-lighter: #FFF1E6;
                --secondary-color: #E85D04;
                --dark-color: #1a1a1a;
                --light-bg: #f9fafb;
                --text-color: #2d3748;
                --border-color: #e5e7eb;
                --gray-200: #eeeeee;
                --gray-300: #d0d0d0;
                --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
                --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.07);
                --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
            }

            * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            html, body {
                width: 100%;
                max-width: 100%;
                overflow-x: hidden;
            }

            html {
                scroll-behavior: smooth;
            }

            body {
                font-family: 'Inter', 'Poppins', sans-serif;
                color: var(--text-color);
                background-color: #ffffff;
                line-height: 1.6;
            }

            /* Navbar */
            .navbar-home{
        background:#fff;
        box-shadow:var(--shadow-sm);
        position:sticky;
        top:0;
        z-index:1000;
        padding:12px 0;
    }

    .navbar-home .container-lg{
        display:flex;
        align-items:center;
        justify-content:flex-start;
        gap:10px;
    }

            .navbar-home.scrolled {
                box-shadow: var(--shadow-md);
                padding: 10px 0;
            }

        .navbar-brand-home{
        display:flex;
        align-items:center;
        gap:8px;
        margin:0;
        padding:0;
        color:#000000;
        text-decoration:none;
        font-size:1.3rem;
        font-weight:700;
        flex:0 0 auto;
        flex-shrink: 0;
    }

            .navbar-brand-home i {
                font-size: 1.6rem;
                color: #E85D04 !important;
            }

            /* Hamburger */
            .navbar-toggler{
        margin:0 !important;
        padding:0 !important;
        border:none !important;
        background:none !important;
        box-shadow:none !important;
        display:flex;
        align-items:center;
        justify-content:center;
        flex:0 0 auto;
        flex-shrink: 0;
        min-width: 50px;
        cursor: pointer;
        transition: all 0.3s ease;
        z-index: 1050;
    }

            .navbar-toggler:hover,
            .navbar-toggler:focus,
            .navbar-toggler:active {
                background: transparent !important;
                border: none !important;
                box-shadow: none !important;
                outline: none !important;
            }

            .navbar-toggler-icon {
                background-image: none !important;
                width: auto;
                height: auto;
            }

            .navbar-toggler-icon::before {
                content: "\f0c9";
                font-family: "Font Awesome 6 Free";
                font-weight: 900;
                transition: all 0.3s ease;
                font-size: 1.3rem;
                color: var(--text-color);
            }

            /* Tampilkan hamburger di semua ukuran layar */
            .navbar-toggler {
                display: flex !important;
            }

            /* Mobile: Hamburger lebih ke kiri */
            @media (max-width: 768px) {
                .navbar-toggler {
                    padding: 0 4px !important;
                    margin-left: -8px !important;
                    min-width: 40px;
                }

                .navbar-brand-home {
                    margin-left: 4px;
                }

                .navbar-home .container-lg {
                    padding: 0 8px;
                }
            }

            /* Off-canvas Sidebar */
            .offcanvas-sidebar {
                position: fixed;
                left: 0;
                top: 0;
                height: 100vh;
                width: 280px;
                background: white;
                z-index: 1048;
                transform: translateX(-100%);
                transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
                box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
                overflow-y: auto;
            }

            .offcanvas-sidebar.active {
                transform: translateX(0);
            }

            .offcanvas-backdrop {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 1047;
                opacity: 0;
                pointer-events: none;
                transition: opacity 0.3s ease;
            }

            .offcanvas-backdrop.active {
                opacity: 1;
                pointer-events: auto;
            }

            .offcanvas-header {
                padding: 16px;
                border-bottom: 1px solid #e5e7eb;
                display: flex;
                align-items: center;
                justify-content: space-between;
            }

            .offcanvas-title {
                font-size: 1.2rem;
                font-weight: 700;
                color: var(--primary-color);
                margin: 0;
                display: flex;
                align-items: center;
                gap: 8px;
            }

            .offcanvas-close {
                background: none;
                border: none;
                font-size: 1.5rem;
                color: var(--text-color);
                cursor: pointer;
                transition: all 0.3s ease;
                padding: 4px;
            }

            .offcanvas-close:hover {
                color: #FF6A00;
            }

            .offcanvas-body {
                padding: 0;
            }

            .offcanvas-nav {
                list-style: none;
                margin: 0;
                padding: 0;
            }

            .offcanvas-nav li {
                border-bottom: 1px solid #f3f4f6;
            }

            .offcanvas-nav a {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 14px 16px;
                color: var(--text-color);
                text-decoration: none;
                transition: all 0.3s ease;
                font-weight: 500;
                font-size: 0.95rem;
            }

            .offcanvas-nav a:hover {
                background: var(--primary-lighter);
                color: var(--primary-color);
                padding-left: 20px;
            }

            .offcanvas-nav a i {
                color: #E85D04;
                font-size: 1.1rem;
            }
        </style>
        <link href="css/home.css?v=<?php echo time(); ?>" rel="stylesheet">
        <style>
            /* Footer Quick Links Section */
            .footer-quick-links-section {
                background: #f8f9fa;
                border-top: 1px solid #e5e5e5;
                width: 100%;
                box-sizing: border-box;
                margin: 0;
                padding: 0;
                margin-bottom: 0;
                padding-bottom: 0;
            }

            .footer-quick-links-container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 20px 24px;
                box-sizing: border-box;
            }

            @media (max-width: 768px) {
                .footer-quick-links-container {
                    padding: 0 16px 16px 16px;
                }
            }

            .footer-quick-links-title {
                display: flex;
                align-items: center;
                gap: 10px;
                margin-bottom: 18px;
                margin: 0 0 18px 0;
            }

            .footer-quick-links-title i {
                margin-top: 0;
                display: flex;
                align-items: center;
                justify-content: center;
                flex-shrink: 0;
                width: 14px;
                height: 14px;
                border: 1px solid #999;
                border-radius: 50%;
                color: #666;
                font-size: 8px;
            }

            .footer-quick-links-title span {
                font-weight: 900;
                line-height: 1;
                font-size: 14px;
                color: #1a1a1a;
                margin: 0;
            }

            .footer-quick-links-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 60px;
                margin: 0;
                padding: 0;
                margin-left: 24px;
            }

            .footer-quick-links-column {
                display: flex;
                flex-direction: column;
                gap: 14px;
                margin: 0;
                padding: 0;
            }

            @media (min-width: 1200px) {
                .footer-quick-links-grid {
                    display: flex;
                    flex-wrap: nowrap;
                    gap: 32px;
                    align-items: flex-start;
                    width: fit-content;
                }

                .footer-quick-links-column {
                    display: flex;
                    flex-direction: row;
                    flex-wrap: nowrap;
                    gap: 32px;
                    margin: 0;
                    padding: 0;
                }
            }

            .footer-quick-link {
                color: #3c4043;
                text-decoration: none;
                font-size: 11px;
                font-weight: 700;
                line-height: 1.3;
                transition: color 0.3s ease;
                display: inline-block;
                margin: 0;
                padding: 0;
            }

            .footer-quick-link:hover {
                color: #FF6A00;
            }

            @media (max-width: 768px) {
                .footer-quick-links-grid {
                    gap: 40px;
                }

                .footer-quick-links-column {
                    gap: 8px;
                }

                .footer-quick-links-title span {
                    font-size: 14px;
                }
            }
        </style>
    </head>
    <body>
        <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-home" id="navbar">
        <div class="container-lg">
            <button class="navbar-toggler" type="button" id="sidebarToggleBtn" aria-label="Toggle sidebar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <a class="navbar-brand-home" href="home.php">
                <i class="fas fa-utensils"></i>
                BEKOMIN ID
            </a>

            <!-- Category Dropdown di Header Kanan -->
            <div style="margin-left: auto; z-index: 100; position: relative;">
                <button type="button" id="headerCategoryBtn" style="display: flex; align-items: center; gap: 4px; border: 2px solid #FF6A00; padding: 5px 10px; border-radius: 18px; background: white; color: #2d3748; font-size: 0.8rem; font-family: Inter, sans-serif; font-weight: 500; cursor: pointer; box-sizing: border-box; box-shadow: 0 2px 8px rgba(0,0,0,0.08); transition: all 0.3s ease; height: fit-content;">
                    <i class="fas fa-tag" style="color: #FF6A00; font-size: 0.75rem;"></i>
                    <span id="headerCategoryLabel">Pilih Kategori</span>
                    <i class="fas fa-chevron-down" style="color: #6b7280; font-size: 0.7rem; transition: transform 0.3s ease;"></i>
                </button>
                <div id="headerCategoryMenu" style="display: none; position: absolute; top: calc(100% + 4px); right: 0; background: white; border: 2px solid #FF6A00; border-radius: 12px; box-shadow: 0 8px 20px rgba(0,0,0,0.15); z-index: 1001; overflow-y: auto; max-height: 280px; min-width: 180px;">
                    <?php 
                    $category_order = ['Jajanan & Street Food', 'Makanan Berat', 'Makanan Rumahan', 'Minuman'];
                    foreach ($category_order as $cat):
                        if (in_array($cat, $categories_from_db)):
                    ?>
                        <div class="header-category-option" data-category="<?php echo htmlspecialchars($cat); ?>" style="padding: 7px 10px; color: #2d3748; cursor: pointer; transition: all 0.2s ease; font-size: 0.8rem; font-family: Inter, sans-serif; border-bottom: 1px solid #f3f4f6;">
                            <?php echo htmlspecialchars($cat); ?>
                        </div>
                    <?php 
                        endif;
                    endforeach; 
                    ?>
                </div>
                <input type="hidden" id="headerCategoryFilter" value="">
            </div>
        </div>
    </nav>

        <!-- Off-canvas Sidebar -->
        <div class="offcanvas-backdrop" id="offcanvasBackdrop"></div>
        <div class="offcanvas-sidebar" id="offcanvasSidebar">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title">
                    <i class="fas fa-utensils" style="color: #E85D04;"></i>BEKOMIN ID
                </h5>
                <button class="offcanvas-close" id="offcanvasCloseBtn" aria-label="Close sidebar">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="offcanvas-body">
                <ul class="offcanvas-nav">
                    <li><a href="#home" onclick="closeSidebar()"><i class="fas fa-home"></i>Home</a></li>
                    <li><a href="#produk" onclick="closeSidebar()"><i class="fas fa-box"></i>Produk</a></li>
                    <li><a href="#rekomendasi" onclick="closeSidebar()"><i class="fas fa-star"></i>Lihat Rekomendasi</a></li>
                    <li><a href="about.php" onclick="closeSidebar()"><i class="fas fa-info-circle"></i>Tentang</a></li>
                    <?php if ($is_logged_in): ?>
                        <li><a href="index.php" onclick="closeSidebar()"><i class="fas fa-store"></i>Semua Produk</a></li>
                        <li><a href="profile.php" onclick="closeSidebar()"><i class="fas fa-user"></i>Profil</a></li>
                        <li><a href="logout.php" onclick="closeSidebar()"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
                    <?php else: ?>
                        <li><a href="login.php" onclick="closeSidebar()"><i class="fas fa-sign-in-alt"></i>Login</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>

        <!-- Hero/Search Section - Compact GoFood Style -->
        <section style="background: linear-gradient(to bottom, #FF6A00 0%, white 100%); padding: 8px 0 16px; position: relative;" id="home">
            <div class="container-lg">
                <form id="heroSearchForm" style="display: flex; flex-direction: column; gap: 8px; max-width: 100%;">
                    <!-- Search Input -->
                    <div style="display: flex; align-items: center; gap: 8px; padding: 8px 12px; border-radius: 20px; background: white; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
                        <i class="fas fa-search" style="color: #FF6A00; font-size: 0.9rem; flex-shrink: 0;"></i>
                        <input type="text" id="searchInput" placeholder="Mau cari makanan UMKM apa hari ini?" style="border: none; outline: none; background: transparent; font-size: 0.9rem; font-family: Inter, sans-serif; color: #2d3748; width: 100%; padding: 0;">
                    </div>
                </form>
            </div>
        </section>

        <!-- Promo Slider Section -->
        <section class="promo-section">
            <div class="container-lg">
                <!-- Promo Heading -->
                <div class="promo-heading">
                    <h2 class="promo-title">Mengapa Memilih Kami?</h2>
                </div>
                
                <div class="promo-slider-wrapper">
                    <div class="promo-slider" id="promoSlider">
                        <div class="promo-slide" data-link="index.php">
                            <div class="promo-slide-image" style="background: #f9fafb; display: flex; align-items: center; justify-content: center; overflow: hidden;">
                                <!-- Mockup Website BEKOMIN ID -->
                                <div style="width: 100%; height: 100%; background: white; display: flex; flex-direction: column; font-family: 'Inter', sans-serif; overflow: hidden; box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);">
                                    <!-- Navbar -->
                                    <div style="background: white; border-bottom: 1px solid #e5e7eb; padding: 10px 12px; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.05);">
                                        <div style="display: flex; align-items: center; gap: 6px; font-weight: 800; font-size: 0.85rem; color: #000; white-space: nowrap;">
                                            <i class="fas fa-utensils" style="color: #FF6A00; font-size: 0.95rem;"></i>
                                            <span>BEKOMIN</span>
                                        </div>
                                        <i class="fas fa-bars" style="color: #2d3748; font-size: 0.9rem;"></i>
                                    </div>

                                    <!-- Search Bar -->
                                    <div style="background: white; padding: 8px 10px; border-bottom: 1px solid #e5e7eb; flex-shrink: 0;">
                                        <div style="display: flex; align-items: center; gap: 6px; padding: 6px 10px; background: #f9fafb; border-radius: 14px; border: 1px solid #e5e7eb;">
                                            <i class="fas fa-search" style="color: #FF6A00; font-size: 0.7rem;"></i>
                                            <span style="color: #a0aec0; font-size: 0.7rem; white-space: nowrap;">Cari produk...</span>
                                        </div>
                                    </div>

                                    <!-- Product Grid Container -->
                                    <div style="flex: 1; overflow: hidden; padding: 8px 6px; background: white;">
                                        <!-- Product Cards Grid 2x2 -->
                                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px; height: 100%;">
                                            <!-- Card 1: Sambal Rumahan -->
                                            <div style="background: white; border-radius: 10px; overflow: hidden; border: 1px solid #e5e7eb; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column; position: relative;">
                                                <img src="image/sambal rumahan.png" style="width: 100%; aspect-ratio: 1; object-fit: cover; background: #f3f4f6;">
                                                <div style="padding: 8px; flex: 1; display: flex; flex-direction: column; gap: 3px; min-height: 0;">
                                                    <div style="font-weight: 800; font-size: 0.7rem; color: #1a1a1a; line-height: 1.1; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">Sambal Rumahan</div>
                                                    <div style="font-size: 0.6rem; color: #718096;">Rasanya nyoenyoe</div>
                                                    <div style="display: flex; align-items: center; gap: 2px; font-size: 0.65rem; margin-top: auto;">
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                    </div>
                                                </div>
                                                <div style="position: absolute; top: 6px; right: 6px; background: #FF6A00; color: white; padding: 2px 6px; border-radius: 4px; font-size: 0.55rem; font-weight: 700; white-space: nowrap;">Disimpan</div>
                                            </div>

                                            <!-- Card 2: Ayam Balado -->
                                            <div style="background: white; border-radius: 10px; overflow: hidden; border: 1px solid #e5e7eb; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column; position: relative;">
                                                <img src="image/ayam balado pedas.png" style="width: 100%; aspect-ratio: 1; object-fit: cover; background: #f3f4f6;">
                                                <div style="padding: 8px; flex: 1; display: flex; flex-direction: column; gap: 3px; min-height: 0;">
                                                    <div style="font-weight: 800; font-size: 0.7rem; color: #1a1a1a; line-height: 1.1; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">Ayam Balado Pedas</div>
                                                    <div style="font-size: 0.6rem; color: #718096;">Griya Pedasnya</div>
                                                    <div style="display: flex; align-items: center; gap: 2px; font-size: 0.65rem; margin-top: auto;">
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star-half-alt" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                    </div>
                                                </div>
                                                <div style="position: absolute; top: 6px; right: 6px; background: #FF6A00; color: white; padding: 2px 6px; border-radius: 4px; font-size: 0.55rem; font-weight: 700; white-space: nowrap;">Disimpan</div>
                                            </div>

                                            <!-- Card 3: Rendang -->
                                            <div style="background: white; border-radius: 10px; overflow: hidden; border: 1px solid #e5e7eb; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column; position: relative;">
                                                <img src="image/Rendang Rumahan Lezat.png" style="width: 100%; aspect-ratio: 1; object-fit: cover; background: #f3f4f6;">
                                                <div style="padding: 8px; flex: 1; display: flex; flex-direction: column; gap: 3px; min-height: 0;">
                                                    <div style="font-weight: 800; font-size: 0.7rem; color: #1a1a1a; line-height: 1.1; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">Rendang Rumahan</div>
                                                    <div style="font-size: 0.6rem; color: #718096;">Mama Rena</div>
                                                    <div style="display: flex; align-items: center; gap: 2px; font-size: 0.65rem; margin-top: auto;">
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                    </div>
                                                </div>
                                                <div style="position: absolute; top: 6px; right: 6px; background: #FF6A00; color: white; padding: 2px 6px; border-radius: 4px; font-size: 0.55rem; font-weight: 700; white-space: nowrap;">Disimpan</div>
                                            </div>

                                            <!-- Card 4: Favicon (untuk variasi) -->
                                            <div style="background: white; border-radius: 10px; overflow: hidden; border: 1px solid #e5e7eb; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: flex; flex-direction: column; position: relative;">
                                                <img src="image/sambal rumahan.png" style="width: 100%; aspect-ratio: 1; object-fit: cover; background: #f3f4f6;">
                                                <div style="padding: 8px; flex: 1; display: flex; flex-direction: column; gap: 3px; min-height: 0;">
                                                    <div style="font-weight: 800; font-size: 0.7rem; color: #1a1a1a; line-height: 1.1; overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;">Sambal Khas</div>
                                                    <div style="font-size: 0.6rem; color: #718096;">Mak Minah UMKM</div>
                                                    <div style="display: flex; align-items: center; gap: 2px; font-size: 0.65rem; margin-top: auto;">
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fcd34d; opacity: 0.4; font-size: 0.55rem;"></i>
                                                        <i class="fas fa-star" style="color: #fcd34d; opacity: 0.4; font-size: 0.55rem;"></i>
                                                    </div>
                                                </div>
                                                <div style="position: absolute; top: 6px; right: 6px; background: #FF6A00; color: white; padding: 2px 6px; border-radius: 4px; font-size: 0.55rem; font-weight: 700; white-space: nowrap;">Disimpan</div>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Badge Flow Explanation -->
                                    <div style="background: #fafbfc; border-top: 1px solid #e5e7eb; padding: 6px 8px; flex-shrink: 0; display: flex; align-items: center; gap: 6px; justify-content: center; flex-wrap: wrap;">
                                        <!-- Guest Badge -->
                                        <div style="display: flex; align-items: center; gap: 2px; flex-shrink: 0;">
                                            <span style="background: #e5e7eb; color: #2d3748; padding: 2px 5px; border-radius: 3px; font-weight: 600; font-size: 0.55rem; white-space: nowrap;">Guest</span>
                                            <span style="font-size: 0.5rem; color: #a0aec0; font-weight: 500;">1Th</span>
                                        </div>

                                        <!-- Arrow -->
                                        <span style="color: #cbd5e1; font-size: 0.7rem;">→</span>

                                        <!-- Login Badge -->
                                        <span style="background: #FF6A00; color: white; padding: 2px 5px; border-radius: 3px; font-weight: 600; font-size: 0.55rem; white-space: nowrap;">Login</span>

                                        <!-- Arrow -->
                                        <span style="color: #cbd5e1; font-size: 0.7rem;">→</span>

                                        <!-- Permanent Badge -->
                                        <span style="background: #22c55e; color: white; padding: 2px 5px; border-radius: 3px; font-weight: 600; font-size: 0.55rem; white-space: nowrap;">Permanen</span>
                                    </div>
                                </div>
                            </div>
                            <div class="promo-slide-overlay"></div>
                            <div class="promo-slide-content">
                                <h3>Machine Learning</h3>
                                <p>Rekomendasi cerdas tanpa perlu login.</p>
                            </div>
                        </div>
                        <div class="promo-slide" data-link="rekomendasi.php">
                            <div class="promo-slide-image" style="background-image: url('banner/img/banner2.jpg'); background-size: cover; background-position: center;"></div>
                            <div class="promo-slide-overlay"></div>
                            <div class="promo-slide-content">
                                <h3>UMKM Lokal</h3>
                                <p>Mendukung produk berkualitas dari UMKM lokal Indonesia</p>
                            </div>
                        </div>
                        <div class="promo-slide" data-link="about.php">
                            <div class="promo-slide-image" style="background-image: url('banner/img/banner3.jpg'); background-size: cover; background-position: center;"></div>
                            <div class="promo-slide-overlay"></div>
                            <div class="promo-slide-content">
                                <h3>Mobile Friendly</h3>
                                <p>Akses dari perangkat manapun dengan mudah dan cepat</p>
                            </div>
                        </div>
                        <div class="promo-slide" data-link="index.php">
                            <div class="promo-slide-image" style="background-image: url('banner/img/banner4.jpg'); background-size: cover; background-position: center;"></div>
                            <div class="promo-slide-overlay"></div>
                            <div class="promo-slide-content">
                                <h3>Cepat & Efisien</h3>
                                <p>Proses rekomendasi tercepat dengan teknologi optimal</p>
                            </div>
                        </div>
                        <div class="promo-slide" data-link="rekomendasi.php">
                            <div class="promo-slide-image" style="background-image: url('banner/img/banner5.jpg'); background-size: cover; background-position: center;"></div>
                            <div class="promo-slide-overlay"></div>
                            <div class="promo-slide-content">
                                <h3>Rating Jujur</h3>
                                <p>Sistem rating dari pengguna nyata yang terpercaya</p>
                            </div>
                        </div>
                    </div>
                    <div class="promo-dots" id="promoDots"></div>
                </div>
            </div>
        </section>

        <!-- Products Section -->
        <section class="section" id="produk">
            <div class="container-lg">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                    <h2 class="section-title">Produk UMKM Pilihan</h2>
                    <button class="carousel-next-btn" onclick="scrollCarousel(this.parentElement.parentElement.querySelector('.product-carousel'))" style="display: flex; align-items: center; gap: 3px; background: none; border: none; cursor: pointer; color: #9ca3af; font-size: 0.7rem; font-family: Inter, sans-serif; font-weight: 400; transition: all 0.3s ease; padding: 4px 8px;">
                        Selanjutnya
                        <i class="fas fa-arrow-right" style="font-size: 0.65rem;"></i>
                    </button>
                </div>
                
                <div class="product-carousel-wrapper" style="position: relative; width: 100%; overflow: hidden; margin-top: 8px;">
                    <div class="product-carousel" id="productGrid" style="display: flex; gap: 20px; overflow-x: auto; overflow-y: hidden; padding: 16px 0; scroll-behavior: smooth; -webkit-overflow-scrolling: touch;"></div>
                </div>
            </div>
        </section>

        <!-- Category Sections -->
        <?php
        $category_order = ['Jajanan & Street Food', 'Makanan Berat', 'Makanan Rumahan', 'Minuman'];
        foreach ($category_order as $category):
        ?>
        <section class="section" id="category-<?php echo htmlspecialchars(str_replace(' ', '-', $category)); ?>" style="background: white; padding: 8px 0;">
            <div class="container-lg">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                    <h2 class="section-title"><?php echo htmlspecialchars($category); ?></h2>
                    <button class="carousel-next-btn" onclick="scrollCarousel(this.parentElement.parentElement.querySelector('.product-carousel'))" style="display: flex; align-items: center; gap: 3px; background: none; border: none; cursor: pointer; color: #9ca3af; font-size: 0.7rem; font-family: Inter, sans-serif; font-weight: 400; transition: all 0.3s ease; padding: 4px 8px;">
                        Selanjutnya
                        <i class="fas fa-arrow-right" style="font-size: 0.65rem;"></i>
                    </button>
                </div>
                <div class="product-carousel-wrapper" style="position: relative; width: 100%; overflow: hidden; margin-top: 8px;">
                    <div class="product-carousel" id="grid-<?php echo htmlspecialchars(str_replace(' ', '-', $category)); ?>" style="display: flex; gap: 20px; overflow-x: auto; overflow-y: hidden; padding: 16px 0; scroll-behavior: smooth; -webkit-overflow-scrolling: touch;"></div>
                </div>
            </div>
        </section>
        <?php endforeach; ?>

        <!-- Recommendation Section -->
        <section class="section" id="rekomendasi">
            <div class="container-lg">
                <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
                    <h2 class="section-title"><i class="fas fa-sparkles"></i> Rekomendasi Untuk Anda</h2>
                    <button class="carousel-next-btn" onclick="scrollCarousel(this.parentElement.parentElement.querySelector('.product-carousel'))" style="display: flex; align-items: center; gap: 3px; background: none; border: none; cursor: pointer; color: #9ca3af; font-size: 0.7rem; font-family: Inter, sans-serif; font-weight: 400; transition: all 0.3s ease; padding: 4px 8px;">
                        Selanjutnya
                        <i class="fas fa-arrow-right" style="font-size: 0.65rem;"></i>
                    </button>
                </div>
                <p class="section-subtitle">Rekomendasi personal menggunakan CF berdasarkan rating dari semua pengguna. Guest bisa rating tanpa login dan dapatkan rekomendasi yang dipersonalisasi.</p>
                
                <div class="product-carousel-wrapper" style="position: relative; width: 100%; overflow: hidden; margin-top: 8px;">
                    <div class="product-carousel" id="recommendationGrid" style="display: flex; gap: 20px; overflow-x: auto; overflow-y: hidden; padding: 16px 0; scroll-behavior: smooth; -webkit-overflow-scrolling: touch;"></div>
                </div>
            </div>
        </section>

        <!-- Promo Section: Register & Login Signup -->
        <section class="promo-signup-section">
            <div class="container-lg">
                <div class="promo-signup">
                    <!-- Left Column -->
                    <div class="promo-signup-left">
                        <h3 class="promo-signup-title">Daftar & Login Sekarang</h3>
                        <p class="promo-signup-desc">Masuk atau daftar agar hasil rekomendasi yang Anda simpan tersimpan permanen di akun Anda.</p>
                        <a href="register.php" class="btn-promo-signup">Daftar</a>
                        <p class="promo-signup-note"><i class="fas fa-bookmark"></i> Simpan rekomendasi Anda</p>
                    </div>

                    <!-- Right Column: Mockup with Real Product Images -->
                    <div class="promo-signup-right">
                        <div class="mockup-signup-container">
                            <div class="mockup-signup-card">
                                <!-- Header -->
                                <div class="mockup-signup-header"></div>

                                <!-- Search Bar -->
                                <div class="mockup-signup-search">
                                    <i class="fas fa-search"></i>
                                </div>

                                <!-- Product Grid with Real Images -->
                                <div class="mockup-signup-grid">
                                    <div class="mockup-signup-product">
                                        <img src="uploads/produk/1783141278_sambal rumahan.png" alt="Sambal" class="mockup-signup-product-img">
                                        <div class="mockup-signup-product-name"></div>
                                        <div class="mockup-signup-product-rating">
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </div>
                                    <div class="mockup-signup-product">
                                        <img src="uploads/produk/1783142014_ayam balado pedas.png" alt="Ayam" class="mockup-signup-product-img">
                                        <div class="mockup-signup-product-name"></div>
                                        <div class="mockup-signup-product-rating">
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </div>
                                    <div class="mockup-signup-product">
                                        <img src="uploads/produk/1783142023_Rendang Rumahan Lezat.png" alt="Rendang" class="mockup-signup-product-img">
                                        <div class="mockup-signup-product-name"></div>
                                        <div class="mockup-signup-product-rating">
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </div>
                                    <div class="mockup-signup-product">
                                        <img src="uploads/produk/1783141981_sambal rumahan.png" alt="Sambal 2" class="mockup-signup-product-img">
                                        <div class="mockup-signup-product-name"></div>
                                        <div class="mockup-signup-product-rating">
                                            <i class="fas fa-star"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Stats Section Dihapus -->

        <section class="footer-quick-links-section" style="margin: 0; margin-bottom: 0; padding: 16px 0 0 0;">
            <div class="footer-quick-links-container">
                <div class="footer-quick-links-title">
                    <i class="fas fa-info-circle"></i>
                    <span>Tentang kami</span>
                </div>
                <div class="footer-quick-links-grid">
                    <div class="footer-quick-links-column">
                        <a href="terms.php" class="footer-quick-link">Ketentuan Penggunaan</a>
                        <a href="contact.php" class="footer-quick-link">Kontak Kami</a>
                            <a href="about.php" class="footer-quick-link">About</a>
                    </div>
                    <div class="footer-quick-links-column">
                        <a href="dmca.php" class="footer-quick-link">DMCA Disclaimer</a>
                        <a href="faq.php" class="footer-quick-link">FAQ</a>
                    </div>
                </div>
            </div>
        </section>

        <footer class="footer-home" style="margin: 0; margin-top: 0;">
            <div class="container-lg">
                <p style="font-weight: 700;">&copy; 2026 <a href="home.php" class="footer-copyright-link">BEKOMIN ID</a>. All rights reserved.</p>
            </div>
        </footer>

        <!-- Back to Top Button -->
        <button class="back-to-top" id="backToTopBtn" aria-label="Kembali ke atas">
            <i class="fas fa-chevron-up"></i>
        </button>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/home.js"></script>
        <script>
            // Fetch dan tampilkan produk di home.php
            document.addEventListener('DOMContentLoaded', function() {
                console.log('Page loaded, fetching products and recommendations...');
                fetchProductsForHome();
                fetchRecommendations();
                
                // Product Carousel Next Button
                const productNextBtn = document.getElementById('productNextBtn');
                // Initialize Category Navigation
                initCategoryNavigation();
                fetchProductsByCategories();
                
                // Handle anchor hash dengan smooth scroll
                if (window.location.hash) {
                    setTimeout(function() {
                        const hash = window.location.hash.substring(1);
                        const targetElement = document.getElementById(hash);
                        
                        if (targetElement && hash === 'rekomendasi') {
                            const navbar = document.getElementById('navbar');
                            const navbarHeight = navbar ? navbar.offsetHeight : 60;
                            const elementTop = targetElement.offsetTop;
                            const scrollOffset = elementTop - navbarHeight - 20;
                            
                            window.scrollTo({
                                top: scrollOffset,
                                behavior: 'smooth'
                            });
                        }
                    }, 500);
                }
            });

            function fetchProductsForHome() {
                const productGrid = document.getElementById('productGrid');
                
                console.log('Starting fetch from api_nearest_location.php?action=get_products');
                
                // Fetch dari API yang sama dengan index.php
                fetch('api_nearest_location.php?action=get_products')
                    .then(response => {
                        console.log('✓ Response received, status:', response.status);
                        if (!response.ok) {
                            throw new Error('HTTP Error: ' + response.status);
                        }
                        return response.text();
                    })
                    .then(text => {
                        console.log('✓ Raw response text:', text.substring(0, 200));
                        try {
                            const data = JSON.parse(text);
                            console.log('✓ JSON parsed successfully:', data);
                            
                            // Get products array
                            let products = null;
                            
                            if (data.products && Array.isArray(data.products)) {
                                products = data.products;
                                console.log('✓ Found products in data.products array, count:', products.length);
                            } else if (data.success === true && data.products) {
                                products = data.products;
                                console.log('✓ Found products with success flag, count:', products.length);
                            } else if (Array.isArray(data)) {
                                products = data;
                                console.log('✓ Data is array directly, count:', products.length);
                            }
                            
                            if (products && products.length > 0) {
                                console.log('✓ Rendering', Math.min(8, products.length), 'products');
                                renderProducts(products);
                            } else {
                                console.warn('✗ No products found in response');
                                showEmptyState(productGrid);
                            }
                        } catch (e) {
                            console.error('✗ JSON parse error:', e);
                            showEmptyState(productGrid, true);
                        }
                    })
                    .catch(error => {
                        console.error('✗ Fetch error:', error);
                        showEmptyState(productGrid, true);
                    });
            }
            
            function showEmptyState(productGrid, isError = false) {
                if (isError) {
                    productGrid.innerHTML = '<div class="empty-state" style="grid-column: 1/-1; text-align: center; padding: 60px 20px;"><div class="empty-state-icon" style="font-size: 3rem; margin-bottom: 16px;"><i class="fas fa-exclamation-triangle"></i></div><p style="font-size: 1.1rem; color: #dc2626;">Terjadi kesalahan memuat produk. Periksa console untuk detail.</p></div>';
                } else {
                    productGrid.innerHTML = '<div class="empty-state" style="grid-column: 1/-1; text-align: center; padding: 60px 20px;"><div class="empty-state-icon" style="font-size: 3rem; margin-bottom: 16px;"><i class="fas fa-inbox"></i></div><p style="font-size: 1.1rem; color: #6b7280;">Tidak ada produk tersedia</p></div>';
                }
            }

            function renderProducts(products) {
                const productGrid = document.getElementById('productGrid');
                
                if (!products || products.length === 0) {
                    showEmptyState(productGrid);
                    return;
                }

                console.log('Rendering ALL', products.length, 'products in carousel');
                
                // Detect device type untuk responsive sizing
                const isMobile = window.innerWidth < 768;
                const isTablet = window.innerWidth < 1024 && window.innerWidth >= 768;
                
                // Set flex basis berdasarkan device
                let flexBasis = 'calc(25% - 15px)'; // Desktop: 4 produk
                let minWidth = '260px';
                let maxWidth = '320px';
                let imageHeight = '200px';
                let cardPadding = '16px';
                let fontSize = '15px';
                
                if (isMobile) {
                    flexBasis = 'calc(50% - 10px)'; // Mobile: 2 produk
                    minWidth = '140px';
                    maxWidth = '180px';
                    imageHeight = '120px';
                    cardPadding = '10px';
                    fontSize = '12px';
                } else if (isTablet) {
                    flexBasis = 'calc(33.333% - 14px)'; // Tablet: 3 produk
                    minWidth = '200px';
                    maxWidth = '260px';
                    imageHeight = '160px';
                    cardPadding = '14px';
                    fontSize = '13px';
                }
                
                let html = '';
                products.forEach((product, index) => {
                    try {
                        const imageUrl = product.gambar && product.gambar.trim() ? product.gambar : 'https://via.placeholder.com/300x200?text=' + encodeURIComponent(product.nama_produk || 'Produk ' + product.id);
                        const avgRating = parseFloat(product.avg_rating) || 0;
                        const ratingCount = parseInt(product.rating_count) || 0;
                        
                        // Kartu dengan deskripsi
                        let imageHeight = '120px';
                        
                        if (isMobile) {
                            imageHeight = '100px';
                        } else if (isTablet) {
                            imageHeight = '110px';
                        }

                        html += `
                            <div class="product-card-carousel" style="flex: 0 0 ${flexBasis}; min-width: ${minWidth}; max-width: ${maxWidth}; background: white; border-radius: 12px; overflow: hidden; border: 1px solid #e5e7eb; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); display: flex; flex-direction: column; box-sizing: border-box; position: relative; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);" onmouseover="this.style.transform='translateY(-6px)'; this.style.boxShadow='0 12px 24px rgba(0, 0, 0, 0.15)'; this.style.borderColor='#2d9f52';" onmouseout="this.style.transform=''; this.style.boxShadow='0 2px 8px rgba(0, 0, 0, 0.08)'; this.style.borderColor='#e5e7eb';">
                                <div class="product-category-badge" style="position: absolute; top: 6px; right: 6px; z-index: 10;">
                                    <span class="badge-text" style="display: inline-block; padding: 2px 5px; border-radius: 3px; font-size: 7px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.2px; color: #FFFFFF; background: #FF6A00; box-shadow: 0 1px 3px rgba(255, 106, 0, 0.2);">${product.kategori || 'Umum'}</span>
                                </div>
                                <div class="product-image" style="width: 100%; height: ${imageHeight}; background: linear-gradient(135deg, #1d7e3f 0%, #0f5f2f 100%); display: flex; align-items: center; justify-content: center; overflow: hidden; position: relative; flex-shrink: 0;">
                                    <img src="${imageUrl}" alt="${product.nama_produk}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s ease;" onmouseover="this.style.transform='scale(1.08)'" onmouseout="this.style.transform='scale(1)'" onerror="this.src='https://via.placeholder.com/300x200?text=${encodeURIComponent(product.nama_produk || 'Produk')}'">
                                </div>
                                <div class="product-body" style="padding: 8px; display: flex; flex-direction: column; gap: 3px; box-sizing: border-box;">
                                    <h5 class="product-name" style="font-weight: 700; font-size: 11px; line-height: 1.2; color: #1a1a1a; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; margin: 0;">${product.nama_produk || 'Produk'}</h5>
                                    <p class="product-desc" style="color: #6b7280; font-size: 9px; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; margin: 0;">${product.deskripsi || 'Tidak ada deskripsi'}</p>
                                    <div class="product-rating-info" style="display: flex; align-items: center; gap: 3px; margin-top: 2px;">
                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 9px;"></i>
                                        <span style="font-weight: 700; font-size: 10px; color: #000000;">${avgRating.toFixed(1)}</span>
                                        <span style="font-size: 9px; color: #6b7280;">(${ratingCount})</span>
                                    </div>
                                    <div class="product-actions" style="display: flex; gap: 5px; box-sizing: border-box; margin-top: 4px;">
                                        <button class="btn-action-carousel btn-detail" onclick="openProductDesc(${product.id}, '${product.nama_produk.replace(/'/g, "\\'")}', '${(product.deskripsi || 'Tidak ada deskripsi').replace(/'/g, "\\'")}', '${product.kategori || 'Umum'}', ${avgRating}, ${ratingCount}, '${imageUrl.replace(/'/g, "\\'")}')" style="flex: 1; padding: 5px 4px; border-radius: 6px; color: white; border: none; font-weight: 600; font-size: 9px; transition: all 0.3s; cursor: pointer; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 2px; box-sizing: border-box; min-height: 26px; font-family: 'Poppins', sans-serif; background: #6D28D9; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);" onmouseover="this.style.background='#5B21B6'; this.style.transform='translateY(-1px)'; this.style.boxShadow='0 3px 6px rgba(0, 0, 0, 0.15)'" onmouseout="this.style.background='#6D28D9'; this.style.transform=''; this.style.boxShadow='0 2px 4px rgba(0, 0, 0, 0.1)'">
                                            <i class="fas fa-eye" style="font-size: 8px;"></i>Detail
                                        </button>
                                        <button class="btn-action-carousel btn-rate" onclick="handleRatingClick(${product.id}, event)" style="flex: 1; padding: 5px 4px; border-radius: 6px; color: white; border: none; font-weight: 600; font-size: 9px; transition: all 0.3s; cursor: pointer; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 2px; box-sizing: border-box; min-height: 26px; font-family: 'Poppins', sans-serif; background: #FF6A00; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);" onmouseover="this.style.background='#E85D04'; this.style.transform='translateY(-1px)'; this.style.boxShadow='0 3px 6px rgba(0, 0, 0, 0.15)'" onmouseout="this.style.background='#FF6A00'; this.style.transform=''; this.style.boxShadow='0 2px 4px rgba(0, 0, 0, 0.1)'">
                                            <i class="fas fa-star" style="font-size: 8px;"></i>Rating
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `;
                    } catch (e) {
                        console.error('Error rendering product:', product, e);
                    }
                });

                productGrid.innerHTML = html;
                console.log('✓ Carousel rendering complete with', products.length, 'products');
            }

            function handleRatingClick(productId, event) {
                event.preventDefault();
                const isLoggedIn = <?php echo json_encode($is_logged_in); ?>;
                
                console.log('Rating click - Product ID:', productId, 'Logged in:', isLoggedIn);
                
                // Guest atau login - semua bisa rating langsung
                // Buka halaman detail produk dimana rating form tersedia
                window.location.href = 'product_detail.php?id=' + productId + '#rating';
            }

            function openProductDesc(productId, productName, productDesc, category, rating, ratingCount, imageUrl) {
                // Redirect langsung ke halaman product detail
                console.log('Navigating to product detail page:', productId);
                window.location.href = 'product_detail.php?id=' + productId;
            }

            // Handle form submission dengan redirect ke product detail
            document.addEventListener('DOMContentLoaded', function() {
                const loginForm = document.getElementById('loginForm');
                const registerForm = document.getElementById('registerForm');
                
                if (loginForm) {
                    loginForm.addEventListener('submit', function(e) {
                        // Isi hidden input product_id
                        const productId = sessionStorage.getItem('redirectProductId');
                        const productIdInput = document.getElementById('loginProductId');
                        if (productIdInput && productId) {
                            productIdInput.value = productId;
                        }
                    });
                }
                
                if (registerForm) {
                    registerForm.addEventListener('submit', function(e) {
                        // Isi hidden input product_id
                        const productId = sessionStorage.getItem('redirectProductId');
                        const productIdInput = document.getElementById('registerProductId');
                        if (productIdInput && productId) {
                            productIdInput.value = productId;
                        }
                    });
                }
            });

            // Back to Top Button Functionality
            const backToTopBtn = document.getElementById('backToTopBtn');
            
            window.addEventListener('scroll', function() {
                if (window.pageYOffset > 300) {
                    backToTopBtn.classList.add('show');
                } else {
                    backToTopBtn.classList.remove('show');
                }
            });
            
            backToTopBtn.addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });

            // Header Category Dropdown Handler - Handled by initCategoryNavigation() below

            // Dropdown Kategori Handler - untuk search form jika ada
            const categoryDropdownBtn = document.getElementById('categoryDropdownBtn');
            if (categoryDropdownBtn) {
                const categoryDropdownMenu = document.getElementById('categoryDropdownMenu');
                const categoryOptions = document.querySelectorAll('.category-option-simple');
                const categoryFilter = document.getElementById('categoryFilter');
                const categoryDropdownLabel = document.getElementById('categoryDropdownLabel');
                const categoryDropdownIcon = categoryDropdownBtn.querySelector('i');

                categoryDropdownBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    categoryDropdownMenu.style.display = categoryDropdownMenu.style.display === 'block' ? 'none' : 'block';
                    categoryDropdownIcon.style.transform = categoryDropdownMenu.style.display === 'block' ? 'rotate(180deg)' : 'rotate(0)';
                });

                categoryOptions.forEach(option => {
                    option.addEventListener('click', function(e) {
                        e.stopPropagation();
                        const category = this.getAttribute('data-category');
                        categoryFilter.value = category;
                        categoryDropdownLabel.textContent = category;
                        
                        categoryOptions.forEach(opt => opt.style.background = '');
                        this.style.background = '#d4f4dd';
                        this.style.color = '#0f5f2f';
                        this.style.fontWeight = '600';
                        
                        categoryDropdownMenu.style.display = 'none';
                        categoryDropdownIcon.style.transform = 'rotate(0)';

                        if (category) {
                            window.location.href = 'search_results.php?category=' + encodeURIComponent(category);
                        }
                    });
                });

                document.addEventListener('click', function(e) {
                    if (!e.target.closest('#categoryDropdownBtn') && !e.target.closest('#categoryDropdownMenu')) {
                        categoryDropdownMenu.style.display = 'none';
                        categoryDropdownIcon.style.transform = 'rotate(0)';
                    }
                });
            }

            // Form submission
            const heroSearchForm = document.getElementById('heroSearchForm');
            if (heroSearchForm) {
                heroSearchForm.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const searchInput = document.getElementById('searchInput');
                    const searchQuery = searchInput.value.trim();
                    
                    if (!searchQuery) {
                        alert('Masukkan nama makanan yang ingin dicari');
                        return;
                    }
                    
                    window.location.href = 'search_results.php?search=' + encodeURIComponent(searchQuery);
                });
            }

            // Sidebar Management
            const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
            const offcanvasSidebar = document.getElementById('offcanvasSidebar');
            const offcanvasBackdrop = document.getElementById('offcanvasBackdrop');
            const offcanvasCloseBtn = document.getElementById('offcanvasCloseBtn');

            function closeSidebar() {
                offcanvasSidebar.classList.remove('active');
                offcanvasBackdrop.classList.remove('active');
            }

            function openSidebar() {
                offcanvasSidebar.classList.add('active');
                offcanvasBackdrop.classList.add('active');
            }

            if (sidebarToggleBtn) {
                sidebarToggleBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    openSidebar();
                });
            }

            if (offcanvasCloseBtn) {
                offcanvasCloseBtn.addEventListener('click', closeSidebar);
            }

            if (offcanvasBackdrop) {
                offcanvasBackdrop.addEventListener('click', closeSidebar);
            }

            // Close sidebar saat scroll
            let scrollTimeout;
            window.addEventListener('scroll', function() {
                clearTimeout(scrollTimeout);
                scrollTimeout = setTimeout(function() {
                    if (offcanvasSidebar.classList.contains('active')) {
                        closeSidebar();
                    }
                }, 100);
            });

            // Fetch recommendations (CF untuk semua: user login dan guest)
            function fetchRecommendations() {
                const recommendationGrid = document.getElementById('recommendationGrid');
                
                if (!recommendationGrid) return;
                
                console.log('Fetching CF recommendations for all visitors...');
                
                // Gunakan CF untuk SEMUA (login atau guest)
                fetch('rekomendasi.php?ajax=1')
                    .then(response => {
                        if (!response.ok) throw new Error('HTTP Error: ' + response.status);
                        return response.json();
                    })
                    .then(data => {
                        console.log('✓ CF recommendations received:', data);
                        
                        let products = [];
                        
                        if (data.recommendations && Array.isArray(data.recommendations)) {
                            products = data.recommendations;
                        } else if (data.products && Array.isArray(data.products)) {
                            products = data.products;
                        } else if (Array.isArray(data)) {
                            products = data;
                        }
                        
                        if (products && products.length > 0) {
                            renderRecommendations(products);
                        } else {
                            recommendationGrid.innerHTML = '<div style="width: 100%; text-align: center; padding: 40px;"><p style="color: #6b7280;">Belum ada rekomendasi untuk Anda. Beri rating pada beberapa produk terlebih dahulu agar sistem dapat menampilkan rekomendasi yang lebih personal.</p></div>';
                        }
                    })
                    .catch(error => {
                        console.error('✗ Fetch CF recommendations error:', error);
                        recommendationGrid.innerHTML = '<div style="width: 100%; text-align: center; padding: 40px;"><p style="color: #dc2626;">Gagal memuat rekomendasi CF</p></div>';
                    });
            }

            function renderRecommendations(products) {
                const recommendationGrid = document.getElementById('recommendationGrid');
                
                if (!products || products.length === 0) return;

                const isMobile = window.innerWidth < 768;
                const isTablet = window.innerWidth < 1024 && window.innerWidth >= 768;
                
                let flexBasis = 'calc(25% - 15px)';
                let minWidth = '260px';
                let maxWidth = '320px';
                let imageHeight = '120px';
                
                if (isMobile) {
                    flexBasis = 'calc(50% - 10px)';
                    minWidth = '140px';
                    maxWidth = '180px';
                    imageHeight = '100px';
                } else if (isTablet) {
                    flexBasis = 'calc(33.333% - 14px)';
                    minWidth = '200px';
                    maxWidth = '260px';
                    imageHeight = '110px';
                }
                
                let html = '';
                products.slice(0, 8).forEach((product) => {
                    const imageUrl = product.gambar && product.gambar.trim() ? product.gambar : 'https://via.placeholder.com/300x200?text=' + encodeURIComponent(product.nama_produk || 'Produk');
                    const avgRating = parseFloat(product.avg_rating) || 0;
                    const ratingCount = parseInt(product.rating_count) || 0;

                    html += `
                        <a href="product_detail.php?id=${product.id}" style="flex: 0 0 ${flexBasis}; min-width: ${minWidth}; max-width: ${maxWidth}; text-decoration: none; color: inherit;">
                            <div style="background: white; border-radius: 12px; overflow: hidden; border: 1px solid #e5e7eb; transition: all 0.3s; box-shadow: 0 2px 8px rgba(0,0,0,0.08); cursor: pointer; display: flex; flex-direction: column; position: relative;" onmouseover="this.style.transform='translateY(-6px)'; this.style.boxShadow='0 12px 24px rgba(0,0,0,0.15)';" onmouseout="this.style.transform=''; this.style.boxShadow='0 2px 8px rgba(0,0,0,0.08)';">
                                <div style="position: absolute; top: 6px; right: 6px; z-index: 10;">
                                    <span style="display: inline-block; padding: 2px 5px; border-radius: 3px; font-size: 7px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.2px; color: #FFFFFF; background: #FF6A00; box-shadow: 0 1px 3px rgba(255, 106, 0, 0.2);">${product.kategori || 'Umum'}</span>
                                </div>
                                <div style="width: 100%; height: ${imageHeight}; background: linear-gradient(135deg, #1d7e3f 0%, #0f5f2f 100%); overflow: hidden; display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                                    <img src="${imageUrl}" alt="${product.nama_produk}" style="width: 100%; height: 100%; object-fit: cover;">
                                </div>
                                <div style="padding: 8px; display: flex; flex-direction: column; gap: 3px; box-sizing: border-box;">
                                    <h5 style="margin: 0; font-weight: 700; font-size: 11px; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.2;">${product.nama_produk}</h5>
                                    <p style="color: #6b7280; font-size: 9px; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; margin: 0;">${product.deskripsi || 'Tidak ada deskripsi'}</p>
                                    <div style="display: flex; align-items: center; gap: 3px; margin-top: 2px;">
                                        <i class="fas fa-star" style="color: #FF6A00; font-size: 9px;"></i>
                                        <span style="font-weight: 700; font-size: 10px; color: #FF6A00;">${avgRating.toFixed(1)}</span>
                                        <span style="font-size: 9px; color: #6b7280;">(${ratingCount})</span>
                                    </div>
                                    <button style="width: 100%; padding: 5px 4px; margin-top: 4px; background: #6D28D9; color: white; border: none; border-radius: 6px; font-size: 9px; font-weight: 600; cursor: pointer; font-family: 'Poppins', sans-serif; transition: all 0.3s; min-height: 26px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);" onmouseover="this.style.background='#5B21B6'; this.style.transform='translateY(-1px)'; this.style.boxShadow='0 3px 6px rgba(0, 0, 0, 0.15)'" onmouseout="this.style.background='#6D28D9'; this.style.transform=''; this.style.boxShadow='0 2px 4px rgba(0, 0, 0, 0.1)';">
                                        Detail
                                    </button>
                                </div>
                            </div>
                        </a>
                    `;
                });
                
                recommendationGrid.innerHTML = html;
            }

            // Scroll carousel function
            function scrollCarousel(carouselEl) {
                if (!carouselEl) return;
                const scrollAmount = 300;
                carouselEl.scrollBy({
                    left: scrollAmount,
                    behavior: 'smooth'
                });
            }

            // Category Navigation Functions
            function initCategoryNavigation() {
                const headerCategoryBtn = document.getElementById('headerCategoryBtn');
                const headerCategoryMenu = document.getElementById('headerCategoryMenu');
                const categoryOptions = document.querySelectorAll('.header-category-option');
                
                if (!headerCategoryBtn || !headerCategoryMenu) return;
                
                // Toggle dropdown
                headerCategoryBtn.addEventListener('click', function(e) {
                    e.stopPropagation();
                    const isOpen = headerCategoryMenu.style.display === 'block';
                    headerCategoryMenu.style.display = isOpen ? 'none' : 'block';
                    headerCategoryBtn.querySelector('i:last-child').style.transform = 
                        isOpen ? 'rotate(0deg)' : 'rotate(180deg)';
                });
                
                // Category option click - scroll to section
                categoryOptions.forEach(option => {
                    option.addEventListener('click', function(e) {
                        e.stopPropagation();
                        const category = this.getAttribute('data-category');
                        const sectionId = 'category-' + category.replace(/ /g, '-');
                        const section = document.getElementById(sectionId);
                        
                        if (section) {
                            // Close dropdown
                            headerCategoryMenu.style.display = 'none';
                            headerCategoryBtn.querySelector('i:last-child').style.transform = 'rotate(0deg)';
                            
                            // Smooth scroll dengan offset navbar
                            setTimeout(function() {
                                const navbar = document.getElementById('navbar');
                                const navbarHeight = navbar ? navbar.offsetHeight : 60;
                                const sectionTop = section.offsetTop;
                                const scrollOffset = sectionTop - navbarHeight - 20;
                                
                                window.scrollTo({
                                    top: scrollOffset,
                                    behavior: 'smooth'
                                });
                            }, 100);
                        }
                    });
                });
                
                // Close dropdown when clicking outside
                document.addEventListener('click', function(e) {
                    if (!headerCategoryBtn.contains(e.target) && !headerCategoryMenu.contains(e.target)) {
                        headerCategoryMenu.style.display = 'none';
                        headerCategoryBtn.querySelector('i:last-child').style.transform = 'rotate(0deg)';
                    }
                });
            }

            // Fetch and render products by category
            function fetchProductsByCategories() {
                const categories = ['Jajanan & Street Food', 'Makanan Berat', 'Makanan Rumahan', 'Minuman'];
                
                fetch('api_nearest_location.php?action=get_products')
                    .then(response => response.text())
                    .then(text => {
                        try {
                            const data = JSON.parse(text);
                            let products = [];
                            
                            if (data.products && Array.isArray(data.products)) {
                                products = data.products;
                            } else if (Array.isArray(data)) {
                                products = data;
                            }
                            
                            if (products.length > 0) {
                                categories.forEach(category => {
                                    const categoryProducts = products.filter(p => p.kategori === category);
                                    renderCategoryProducts(category, categoryProducts);
                                });
                            }
                        } catch (e) {
                            console.error('Error parsing products:', e);
                        }
                    })
                    .catch(error => console.error('Error fetching products:', error));
            }

            function renderCategoryProducts(category, products) {
                const gridId = 'grid-' + category.replace(/ /g, '-');
                const grid = document.getElementById(gridId);
                
                if (!grid) return;
                
                if (products.length === 0) {
                    grid.innerHTML = '<div class="empty-state" style="text-align: center; padding: 60px 20px;"><div class="empty-state-icon" style="font-size: 3rem; margin-bottom: 16px;"><i class="fas fa-inbox"></i></div><p style="font-size: 1.1rem; color: #6b7280;">Tidak ada produk tersedia</p></div>';
                    return;
                }

                const isMobile = window.innerWidth < 768;
                const isTablet = window.innerWidth < 1024 && window.innerWidth >= 768;
                
                let flexBasis = 'calc(25% - 15px)';
                let minWidth = '260px';
                let maxWidth = '320px';
                let imageHeight = '200px';
                
                if (isMobile) {
                    flexBasis = 'calc(50% - 10px)';
                    minWidth = '140px';
                    maxWidth = '180px';
                    imageHeight = '120px';
                } else if (isTablet) {
                    flexBasis = 'calc(33.333% - 14px)';
                    minWidth = '200px';
                    maxWidth = '260px';
                    imageHeight = '160px';
                }
                
                let html = '';
                products.forEach(product => {
                    try {
                        const imageUrl = product.gambar && product.gambar.trim() ? product.gambar : 'https://via.placeholder.com/300x200?text=' + encodeURIComponent(product.nama_produk || 'Produk');
                        const avgRating = parseFloat(product.avg_rating) || 0;
                        const ratingCount = parseInt(product.rating_count) || 0;
                        
                        let imageHeight = '120px';
                        
                        if (isMobile) {
                            imageHeight = '100px';
                        } else if (isTablet) {
                            imageHeight = '110px';
                        }

                        html += `
                            <div class="product-card-carousel" style="flex: 0 0 ${flexBasis}; min-width: ${minWidth}; max-width: ${maxWidth}; background: white; border-radius: 12px; overflow: hidden; border: 1px solid #e5e7eb; transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1); display: flex; flex-direction: column; box-sizing: border-box; position: relative; box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);" onmouseover="this.style.transform='translateY(-6px)'; this.style.boxShadow='0 12px 24px rgba(0, 0, 0, 0.15)'; this.style.borderColor='#2d9f52';" onmouseout="this.style.transform=''; this.style.boxShadow='0 2px 8px rgba(0, 0, 0, 0.08)'; this.style.borderColor='#e5e7eb';">
                                <div class="product-category-badge" style="position: absolute; top: 6px; right: 6px; z-index: 10;">
                                    <span class="badge-text" style="display: inline-block; padding: 2px 5px; border-radius: 3px; font-size: 7px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.2px; color: #FFFFFF; background: #FF6A00; box-shadow: 0 1px 3px rgba(255, 106, 0, 0.2);">${product.kategori || 'Umum'}</span>
                                </div>
                                <div class="product-image" style="width: 100%; height: ${imageHeight}; background: linear-gradient(135deg, #1d7e3f 0%, #0f5f2f 100%); display: flex; align-items: center; justify-content: center; overflow: hidden; position: relative; flex-shrink: 0;">
                                    <img src="${imageUrl}" alt="${product.nama_produk}" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s ease;" onmouseover="this.style.transform='scale(1.08)'" onmouseout="this.style.transform='scale(1)'" onerror="this.src='https://via.placeholder.com/300x200?text=${encodeURIComponent(product.nama_produk || 'Produk')}'">
                                </div>
                                <div class="product-body" style="padding: 8px; display: flex; flex-direction: column; gap: 3px; box-sizing: border-box;">
                                    <h5 class="product-name" style="font-weight: 700; font-size: 11px; line-height: 1.2; color: #1a1a1a; display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden; margin: 0;">${product.nama_produk || 'Produk'}</h5>
                                    <p class="product-desc" style="color: #6b7280; font-size: 9px; line-height: 1.3; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; margin: 0;">${product.deskripsi || 'Tidak ada deskripsi'}</p>
                                    <div class="product-rating-info" style="display: flex; align-items: center; gap: 3px; margin-top: 2px;">
                                        <i class="fas fa-star" style="color: #fbbf24; font-size: 9px;"></i>
                                        <span style="font-weight: 700; font-size: 10px; color: #000000;">${avgRating.toFixed(1)}</span>
                                        <span style="font-size: 9px; color: #6b7280;">(${ratingCount})</span>
                                    </div>
                                    <div class="product-actions" style="display: flex; gap: 5px; box-sizing: border-box; margin-top: 4px;">
                                        <button class="btn-action-carousel btn-detail" onclick="openProductDesc(${product.id}, '${product.nama_produk.replace(/'/g, "\\'")}', '${(product.deskripsi || 'Tidak ada deskripsi').replace(/'/g, "\\'")}', '${product.kategori || 'Umum'}', ${avgRating}, ${ratingCount}, '${imageUrl.replace(/'/g, "\\'")}')" style="flex: 1; padding: 5px 4px; border-radius: 6px; color: white; border: none; font-weight: 600; font-size: 9px; transition: all 0.3s; cursor: pointer; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 2px; box-sizing: border-box; min-height: 26px; font-family: 'Poppins', sans-serif; background: #6D28D9; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);" onmouseover="this.style.background='#5B21B6'; this.style.transform='translateY(-1px)'; this.style.boxShadow='0 3px 6px rgba(0, 0, 0, 0.15)'" onmouseout="this.style.background='#6D28D9'; this.style.transform=''; this.style.boxShadow='0 2px 4px rgba(0, 0, 0, 0.1)'">
                                            <i class="fas fa-eye" style="font-size: 8px;"></i>Detail
                                        </button>
                                        <button class="btn-action-carousel btn-rate" onclick="handleRatingClick(${product.id}, event)" style="flex: 1; padding: 5px 4px; border-radius: 6px; color: white; border: none; font-weight: 600; font-size: 9px; transition: all 0.3s; cursor: pointer; text-decoration: none; display: flex; align-items: center; justify-content: center; gap: 2px; box-sizing: border-box; min-height: 26px; font-family: 'Poppins', sans-serif; background: #FF6A00; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);" onmouseover="this.style.background='#E85D04'; this.style.transform='translateY(-1px)'; this.style.boxShadow='0 3px 6px rgba(0, 0, 0, 0.15)'" onmouseout="this.style.background='#FF6A00'; this.style.transform=''; this.style.boxShadow='0 2px 4px rgba(0, 0, 0, 0.1)'">
                                            <i class="fas fa-star" style="font-size: 8px;"></i>Rating
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `;
                    } catch (e) {
                        console.error('Error rendering product:', product, e);
                    }
                });

                grid.innerHTML = html;
            }
        </script>
    </body>
    </html>


        <script>
            const slider = document.getElementById('promoSlider');
            const slides = document.querySelectorAll('.promo-slide');
            const dots = document.querySelectorAll('.promo-dot');
            let currentSlide = 0;
            let autoSlideTimer = null;
            let touchStartX = 0;
            let touchStartY = 0;
            let gestureDetected = null;
            const GESTURE_THRESHOLD = 10;
            const SWIPE_THRESHOLD = 30;
            const AUTO_SLIDE_DELAY = 4000; // 4 detik per slide

            function showSlide(index) {
                slides.forEach((slide, i) => {
                    slide.classList.toggle('active', i === index);
                    dots[i]?.classList.toggle('active', i === index);
                });
                currentSlide = index;
                resetAutoSlide();
            }

            function nextSlide() {
                showSlide((currentSlide + 1) % slides.length);
            }

            function prevSlide() {
                showSlide((currentSlide - 1 + slides.length) % slides.length);
            }

            function resetAutoSlide() {
                if (autoSlideTimer) clearInterval(autoSlideTimer);
                autoSlideTimer = setInterval(nextSlide, AUTO_SLIDE_DELAY);
            }

            slider?.addEventListener('touchstart', (e) => {
                touchStartX = e.touches[0].clientX;
                touchStartY = e.touches[0].clientY;
                gestureDetected = null;
                if (autoSlideTimer) clearInterval(autoSlideTimer);
            }, { passive: true });

            slider?.addEventListener('touchmove', (e) => {
                const currentX = e.touches[0].clientX;
                const currentY = e.touches[0].clientY;
                const deltaX = Math.abs(currentX - touchStartX);
                const deltaY = Math.abs(currentY - touchStartY);

                if (gestureDetected === null && (deltaX > GESTURE_THRESHOLD || deltaY > GESTURE_THRESHOLD)) {
                    gestureDetected = deltaX > deltaY ? 'horizontal' : 'vertical';
                }

                if (gestureDetected === 'horizontal') {
                    e.preventDefault();
                }
            }, { passive: false });

            slider?.addEventListener('touchend', (e) => {
                if (gestureDetected === 'horizontal') {
                    const touchEndX = e.changedTouches[0].clientX;
                    const diff = touchStartX - touchEndX;

                    if (Math.abs(diff) > SWIPE_THRESHOLD) {
                        if (diff > 0) {
                            nextSlide();
                        } else {
                            prevSlide();
                        }
                    } else {
                        resetAutoSlide();
                    }
                } else {
                    resetAutoSlide();
                }
                gestureDetected = null;
            }, { passive: true });

            // Mouse events untuk desktop
            slider?.addEventListener('mouseenter', () => {
                if (autoSlideTimer) clearInterval(autoSlideTimer);
            });

            slider?.addEventListener('mouseleave', () => {
                resetAutoSlide();
            });

            dots.forEach((dot, index) => {
                dot?.addEventListener('click', () => showSlide(index));
            });

            slider?.addEventListener('click', (e) => {
                if (e.target === slider || e.target.closest('.promo-slide-overlay')) {
                    const link = e.currentTarget.querySelector('.promo-slide.active')?.getAttribute('data-link');
                    if (link) window.location.href = link;
                }
            });

            // Inisialisasi slide pertama dan mulai autoplay
            showSlide(0);
        </script>
