<?php
require_once 'config/session.php';

// Cek login untuk halaman yang membutuhkan login
$current_page = basename($_SERVER['PHP_SELF']);
$pages_require_login = ['index.php', 'rekomendasi.php', 'profile.php'];

// Ambil kategori untuk dropdown (hanya di home.php)
$categories_from_db = [];

// Cek apakah user login
$is_logged_in = isLoggedIn();
$user_id = $is_logged_in ? getCurrentUserId() : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta name="google-adsense-account" content="ca-pub-4386407350763103">
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4386407350763103" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@600;700&display=swap" rel="stylesheet">
    <link rel="apple-touch-icon" sizes="180x180" href="/umkmrekomendasi/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/umkmrekomendasi/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/umkmrekomendasi/favicon-16x16.png">
    <link rel="icon" href="/umkmrekomendasi/favicon.ico">
    <link rel="manifest" href="/umkmrekomendasi/site.webmanifest">

    <style>
        :root {
            --primary-color: #1d7e3f;
            --primary-light: #2d9f52;
            --primary-lighter: #d4f4dd;
            --secondary-color: #0f5f2f;
            --dark-color: #1a1a1a;
            --light-bg: #f9fafb;
            --text-color: #2d3748;
            --border-color: #e5e7eb;
            --gray-200: #eeeeee;
            --gray-300: #d0d0d0;
            --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.07);
            --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            width: 100%;
            max-width: 100%;
            overflow-x: hidden;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Poppins', 'Inter', sans-serif;
            color: var(--text-color);
            background-color: #ffffff;
            line-height: 1.6;
        }

        /* Navbar */
        .navbar-home{
            background:#fff;
            box-shadow:var(--shadow-sm);
            position:sticky;
            top:0;
            z-index:1000;
            padding:12px 0;
        }

        .navbar-home .container-lg{
            display:flex;
            align-items:center;
            justify-content:flex-start;
            gap:10px;
        }

        .navbar-home.scrolled {
            box-shadow: var(--shadow-md);
            padding: 10px 0;
        }

        .navbar-brand-home{
            display:flex;
            align-items:center;
            gap:8px;
            margin:0;
            margin-left:12px;
            padding:0;
            color:#000000;
            text-decoration:none;
            font-size:1.3rem;
            font-weight:700;
            flex:0 0 auto;
        }

        .navbar-brand-home i {
            font-size: 1.6rem;
            color: #E85D04 !important;
        }

        /* Hamburger */
        .navbar-toggler{
            margin:0 !important;
            padding:0 8px !important;
            border:none !important;
            background:none !important;
            box-shadow:none !important;
            display:flex;
            align-items:center;
            justify-content:center;
            flex:0 0 auto;
            cursor: pointer;
            transition: all 0.3s ease;
            z-index: 1050;
        }

        .navbar-toggler:hover,
        .navbar-toggler:focus,
        .navbar-toggler:active {
            background: transparent !important;
            border: none !important;
            box-shadow: none !important;
            outline: none !important;
        }

        .navbar-toggler-icon {
            background-image: none !important;
            width: auto;
            height: auto;
        }

        .navbar-toggler-icon::before {
            content: "\f0c9";
            font-family: "Font Awesome 6 Free";
            font-weight: 900;
            transition: all 0.3s ease;
            font-size: 1.3rem;
            color: var(--text-color);
        }

        /* Show hamburger on all screen sizes */
        @media (max-width: 1400px) {
            .navbar-toggler {
                display: flex !important;
            }
        }

        @media (min-width: 1401px) {
            .navbar-toggler {
                display: flex !important;
            }
        }

        /* Mobile: Hamburger lebih ke kiri */
        @media (max-width: 768px) {
            .navbar-toggler {
                padding: 0 4px !important;
                margin-left: -8px !important;
            }

            .navbar-brand-home {
                margin-left: 4px;
            }
        }
            .navbar-toggler {
                display: flex !important;
            }
        }

        /* Off-canvas Sidebar */
        .offcanvas-sidebar {
            position: fixed;
            left: 0;
            top: 0;
            height: 100vh;
            width: 280px;
            background: white;
            z-index: 1048;
            transform: translateX(-100%);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 2px 0 15px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }

        .offcanvas-sidebar.active {
            transform: translateX(0);
        }

        .offcanvas-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1047;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.3s ease;
        }

        .offcanvas-backdrop.active {
            opacity: 1;
            pointer-events: auto;
        }

        .offcanvas-header {
            padding: 16px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .offcanvas-title {
            font-size: 1.2rem;
            font-weight: 700;
            color: #000000;
            margin: 0;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .offcanvas-close {
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--text-color);
            cursor: pointer;
            transition: all 0.3s ease;
            padding: 4px;
        }

        .offcanvas-close:hover {
            color: var(--primary-color);
        }

        .offcanvas-body {
            padding: 0;
        }

        .offcanvas-nav {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .offcanvas-nav li {
            border-bottom: 1px solid #f3f4f6;
        }

        .offcanvas-nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 16px;
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
            font-size: 0.95rem;
        }

        .offcanvas-nav a:hover {
            background: var(--primary-lighter);
            color: var(--primary-color);
            padding-left: 20px;
        }

        .offcanvas-nav a i {
            color: var(--primary-color);
            font-size: 1.1rem;
        }

        .container-lg {
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 16px;
            box-sizing: border-box;
        }

        @media (min-width: 480px) {
            .container-lg {
                padding: 0 16px;
            }
        }

        @media (min-width: 768px) {
            .container-lg {
                padding: 0 20px;
            }
        }

        @media (min-width: 992px) {
            .container-lg {
                padding: 0 24px;
            }
        }

        @media (min-width: 1200px) {
            .container-lg {
                padding: 0 24px;
            }
        }

        .container-main {
            padding: 20px 0;
            min-height: calc(100vh - 200px);
            width: 100%;
            overflow-x: hidden;
        }
    </style>
    <link href="css/home.css?v=<?php echo time(); ?>" rel="stylesheet">
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-home" id="navbar">
        <div class="container-lg">
            <button class="navbar-toggler" type="button" id="sidebarToggleBtn" aria-label="Toggle sidebar">
                <span class="navbar-toggler-icon"></span>
            </button>

            <a class="navbar-brand-home" href="home.php">
                <i class="fas fa-utensils"></i>
                BEKOMIN ID
            </a>
        </div>
    </nav>

    <!-- Off-canvas Sidebar -->
    <div class="offcanvas-backdrop" id="offcanvasBackdrop"></div>
    <div class="offcanvas-sidebar" id="offcanvasSidebar">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">
                <i class="fas fa-utensils" style="color: #E85D04;"></i>BEKOMIN ID
            </h5>
            <button class="offcanvas-close" id="offcanvasCloseBtn" aria-label="Close sidebar">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="offcanvas-body">
            <ul class="offcanvas-nav">
                <li><a href="home.php" onclick="closeSidebar()"><i class="fas fa-home"></i>Home</a></li>
                <li><a href="index.php" onclick="closeSidebar()"><i class="fas fa-box"></i>Semua Produk</a></li>
                <li><a href="rekomendasi.php" onclick="closeSidebar()"><i class="fas fa-star"></i>Lihat Rekomendasi</a></li>
                <li><a href="about.php" onclick="closeSidebar()"><i class="fas fa-info-circle"></i>Tentang</a></li>
                <?php if ($is_logged_in): ?>
                    <li><a href="profile.php" onclick="closeSidebar()"><i class="fas fa-user"></i>Profil</a></li>
                    <li><a href="logout.php" onclick="closeSidebar()"><i class="fas fa-sign-out-alt"></i>Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php" onclick="closeSidebar()"><i class="fas fa-sign-in-alt"></i>Login</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container-lg container-main">

    <script>
        // Sidebar toggle functionality
        const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
        const offcanvasSidebar = document.getElementById('offcanvasSidebar');
        const offcanvasBackdrop = document.getElementById('offcanvasBackdrop');
        const offcanvasCloseBtn = document.getElementById('offcanvasCloseBtn');

        if (sidebarToggleBtn) {
            sidebarToggleBtn.addEventListener('click', function() {
                offcanvasSidebar.classList.add('active');
                offcanvasBackdrop.classList.add('active');
            });
        }

        if (offcanvasCloseBtn) {
            offcanvasCloseBtn.addEventListener('click', function() {
                offcanvasSidebar.classList.remove('active');
                offcanvasBackdrop.classList.remove('active');
            });
        }

        if (offcanvasBackdrop) {
            offcanvasBackdrop.addEventListener('click', function() {
                offcanvasSidebar.classList.remove('active');
                offcanvasBackdrop.classList.remove('active');
            });
        }

        function closeSidebar() {
            offcanvasSidebar.classList.remove('active');
            offcanvasBackdrop.classList.remove('active');
        }

        // Navbar scroll effect
        const navbar = document.getElementById('navbar');
        if (navbar) {
            window.addEventListener('scroll', function() {
                if (window.scrollY > 10) {
                    navbar.classList.add('scrolled');
                } else {
                    navbar.classList.remove('scrolled');
                }
            });
        }
    </script>
