    </div>

    <section class="footer-quick-links-section">
        <div class="footer-quick-links-container">
            <div class="footer-quick-links-title">
                <i class="fas fa-info-circle"></i>
                <span>Tentang kami</span>
            </div>
            <div class="footer-quick-links-grid">
                <div class="footer-quick-links-column">
                    <a href="terms.php" class="footer-quick-link">Ketentuan Penggunaan</a>
                    <a href="contact.php" class="footer-quick-link">Kontak Kami</a>
                    <a href="about.php" class="footer-quick-link">About</a>
                </div>
                <div class="footer-quick-links-column">
                    <a href="dmca.php" class="footer-quick-link">DMCA Disclaimer</a>
                    <a href="faq.php" class="footer-quick-link">FAQ</a>
                </div>
            </div>
        </div>
    </section>
    
    <footer class="footer">
        <div class="container-lg">
            <p style="font-weight: 700; font-size: 12px;">&copy; 2026 <a href="home.php" class="footer-copyright-link">BEKOMIN ID</a>. All rights reserved.</p>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <button class="back-to-top" id="backToTopBtn" aria-label="Kembali ke atas">
        <i class="fas fa-chevron-up"></i>
    </button>
    
    <style>
        /* Footer Styles - Same as home.php */
        .footer {
            background: var(--dark-color);
            color: white;
            padding: 12px 0;
            text-align: center;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin-top: 0;
            margin: 0;
            width: 100%;
            box-sizing: border-box;
        }

        .footer p {
            margin: 0;
            opacity: 0.7;
            font-size: clamp(0.8rem, 1.2vw, 0.9rem);
        }

        /* Footer Quick Links Section */
        .footer-quick-links-section {
            background: #f8f9fa;
            border-top: 1px solid #e5e5e5;
            width: 100%;
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .footer-quick-links-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px 24px;
            box-sizing: border-box;
        }

        @media (max-width: 768px) {
            .footer-quick-links-container {
                padding: 24px 16px;
            }
        }

        .footer-quick-links-title {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 18px;
            margin: 0 0 18px 0;
        }

        .footer-quick-links-title i {
            margin-top: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            width: 14px;
            height: 14px;
            border: 1px solid #999;
            border-radius: 50%;
            color: #666;
            font-size: 8px;
        }

        .footer-quick-links-title span {
            font-weight: 900;
            line-height: 1;
            font-size: 14px;
            color: #1a1a1a;
            margin: 0;
        }

        .footer-quick-links-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 60px;
            margin: 0;
            padding: 0;
            margin-left: 24px;
        }

        .footer-quick-links-column {
            display: flex;
            flex-direction: column;
            gap: 14px;
            margin: 0;
            padding: 0;
        }

        @media (min-width: 1200px) {
            .footer-quick-links-grid {
                display: flex;
                flex-wrap: nowrap;
                gap: 32px;
                align-items: flex-start;
                width: fit-content;
            }

            .footer-quick-links-column {
                display: flex;
                flex-direction: row;
                flex-wrap: nowrap;
                gap: 32px;
                margin: 0;
                padding: 0;
            }
        }

        .footer-quick-link {
            color: #3c4043;
            text-decoration: none;
            font-size: 11px;
            font-weight: 700;
            line-height: 1.3;
            transition: color 0.3s ease;
            display: inline-block;
            margin: 0;
            padding: 0;
        }

        .footer-quick-link:hover {
            color: #1d7e3f;
        }

        .footer-copyright-link {
            color: #FF8747;
            text-decoration: none;
            transition: color 0.3s ease;
            display: inline;
        }

        .footer-copyright-link:hover {
            color: #FFA366;
        }

        @media (max-width: 768px) {
            .footer-quick-links-grid {
                gap: 40px;
            }

            .footer-quick-links-column {
                gap: 8px;
            }

            .footer-quick-link {
                font-size: 11px;
                font-weight: 300;
            }

            .footer-quick-links-title span {
                font-size: 14px;
            }
        }

        /* Back to Top Button */
        .back-to-top {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            background: var(--primary-color, #1d7e3f);
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: none;
            align-items: center;
            justify-content: center;
            z-index: 999;
            transition: all 0.3s ease;
            font-size: 1rem;
        }

        .back-to-top.show {
            display: flex;
        }

        .back-to-top:hover {
            background: var(--primary-light, #2d9f52);
            transform: translateY(-3px);
            box-shadow: 0 4px 12px rgba(29, 126, 63, 0.3);
        }

        @media (max-width: 768px) {
            .footer {
                padding: 16px 0;
            }

            .footer p {
                font-size: 0.7rem;
            }
        }
    </style>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Back to Top Button Functionality
        const backToTopBtn = document.getElementById('backToTopBtn');
        
        window.addEventListener('scroll', function() {
            if (window.pageYOffset > 300) {
                backToTopBtn.classList.add('show');
            } else {
                backToTopBtn.classList.remove('show');
            }
        });
        
        backToTopBtn.addEventListener('click', function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        // Navbar scroll effect (if navbar exists)
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (navbar) {
                if (window.scrollY > 10) {
                    navbar.classList.add('scrolled');
                } else {
                    navbar.classList.remove('scrolled');
                }
            }
        });

        // Rating star functionality
        document.querySelectorAll('.rating-input').forEach(container => {
            const stars = container.querySelectorAll('.star');
            const input = container.querySelector('input[type="hidden"]');
            
            if (!stars.length || !input) return;
            
            stars.forEach((star, index) => {
                star.addEventListener('click', () => {
                    const rating = index + 1;
                    input.value = rating;
                    
                    stars.forEach((s, i) => {
                        if (i < rating) {
                            s.classList.add('active');
                        } else {
                            s.classList.remove('active');
                        }
                    });
                });
                
                star.addEventListener('mouseover', () => {
                    stars.forEach((s, i) => {
                        if (i <= index) {
                            s.style.color = '#fbbf24';
                        } else {
                            s.style.color = '#e5e7eb';
                        }
                    });
                });
            });
            
            container.addEventListener('mouseout', () => {
                const currentRating = parseInt(input.value) || 0;
                stars.forEach((s, i) => {
                    if (i < currentRating) {
                        s.style.color = '#fbbf24';
                    } else {
                        s.style.color = '#e5e7eb';
                    }
                });
            });
        });
    </script>
</body>
</html>
