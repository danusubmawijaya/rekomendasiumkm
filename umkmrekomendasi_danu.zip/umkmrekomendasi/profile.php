<?php
require_once 'config/database.php';
require_once 'config/session.php';

redirectIfNotLoggedIn();

$user_id = getCurrentUserId();
$message = '';
$message_type = '';

// Fetch user data
$user = ['id' => $user_id, 'name' => '', 'email' => ''];
$query = "SELECT id, name, email FROM users WHERE id = ?";
$stmt = $conn->prepare($query);

if ($stmt) {
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $stmt->bind_result($user_id_result, $name, $email);
            $stmt->fetch();
            $user = ['id' => $user_id_result, 'name' => $name, 'email' => $email];
        }
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action == 'update_profile') {
        $name = $_POST['name'] ?? '';
        $email = $_POST['email'] ?? '';
        
        if (empty($name) || empty($email)) {
            $message = 'Nama dan email tidak boleh kosong';
            $message_type = 'danger';
        } else {
            $check_query = "SELECT id FROM users WHERE email = ? AND id != ?";
            $check_stmt = $conn->prepare($check_query);
            $email_exists = false;
            
            if ($check_stmt) {
                $check_stmt->bind_param("si", $email, $user_id);
                if ($check_stmt->execute()) {
                    $check_stmt->store_result();
                    $email_exists = $check_stmt->num_rows > 0;
                }
                $check_stmt->close();
            }
            
            if ($email_exists) {
                $message = 'Email sudah digunakan pengguna lain';
                $message_type = 'danger';
            } else {
                $update_query = "UPDATE users SET name = ?, email = ? WHERE id = ?";
                $update_stmt = $conn->prepare($update_query);
                
                if ($update_stmt) {
                    $update_stmt->bind_param("ssi", $name, $email, $user_id);
                    
                    if ($update_stmt->execute()) {
                        $_SESSION['user_name'] = $name;
                        $_SESSION['user_email'] = $email;
                        $user['name'] = $name;
                        $user['email'] = $email;
                        $message = 'Profil berhasil diperbarui';
                        $message_type = 'success';
                    } else {
                        $message = 'Gagal memperbarui profil';
                        $message_type = 'danger';
                    }
                    $update_stmt->close();
                }
            }
        }
    } elseif ($action == 'update_password') {
        $old_password = $_POST['old_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (empty($old_password) || empty($new_password) || empty($confirm_password)) {
            $message = 'Semua field password harus diisi';
            $message_type = 'danger';
        } elseif ($new_password !== $confirm_password) {
            $message = 'Password baru tidak cocok';
            $message_type = 'danger';
        } elseif (strlen($new_password) < 6) {
            $message = 'Password minimal 6 karakter';
            $message_type = 'danger';
        } else {
            $pass_query = "SELECT password FROM users WHERE id = ?";
            $pass_stmt = $conn->prepare($pass_query);
            $current_password = null;
            $password_valid = false;
            
            if ($pass_stmt) {
                $pass_stmt->bind_param("i", $user_id);
                if ($pass_stmt->execute()) {
                    $pass_stmt->store_result();
                    if ($pass_stmt->num_rows > 0) {
                        $pass_stmt->bind_result($current_password);
                        $pass_stmt->fetch();
                        $password_valid = password_verify($old_password, $current_password);
                    }
                }
                $pass_stmt->close();
            }
            
            if (!$password_valid) {
                $message = 'Password lama salah';
                $message_type = 'danger';
            } else {
                $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                $update_pass_query = "UPDATE users SET password = ? WHERE id = ?";
                $update_pass_stmt = $conn->prepare($update_pass_query);
                
                if ($update_pass_stmt) {
                    $update_pass_stmt->bind_param("si", $hashed_password, $user_id);
                    
                    if ($update_pass_stmt->execute()) {
                        $message = 'Password berhasil diubah';
                        $message_type = 'success';
                    } else {
                        $message = 'Gagal mengubah password';
                        $message_type = 'danger';
                    }
                    $update_pass_stmt->close();
                }
            }
        }
    }
}

$page_title = "Profil Saya";
include_once 'includes/header.php';
?>

<style>
:root {
    --primary-color: #FF6A00;
    --secondary-color: #E85D04;
    --dark-color: #1a1a1a;
    --border-color: #e5e7eb;
    --light-bg: #f9fafb;
}

.profile-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px 16px;
}

.profile-header {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    border-radius: 16px;
    padding: 40px 24px;
    color: white;
    margin-bottom: 40px;
    box-shadow: 0 8px 24px rgba(255, 106, 0, 0.2);
}

.profile-header-content {
    display: flex;
    align-items: center;
    gap: 24px;
}

.profile-avatar {
    width: 100px;
    height: 100px;
    background: rgba(255, 255, 255, 0.2);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 3rem;
    flex-shrink: 0;
    border: 3px solid rgba(255, 255, 255, 0.3);
}

.profile-header-info h1 {
    font-size: 1.8rem;
    font-weight: 700;
    margin-bottom: 8px;
}

.profile-header-info p {
    font-size: 0.95rem;
    opacity: 0.95;
    margin: 0;
}

.profile-sections {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 24px;
}

@media (max-width: 768px) {
    .profile-sections {
        grid-template-columns: 1fr;
    }
    
    .profile-header {
        padding: 24px 16px;
    }
    
    .profile-header-content {
        flex-direction: column;
        text-align: center;
    }
    
    .profile-header-info h1 {
        font-size: 1.5rem;
    }
}

.profile-card {
    background: white;
    border-radius: 12px;
    border: 1px solid var(--border-color);
    padding: 28px 24px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    transition: all 0.3s ease;
}

.profile-card:hover {
    border-color: var(--primary-color);
    box-shadow: 0 8px 24px rgba(255, 106, 0, 0.12);
}

.card-header {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 24px;
    padding-bottom: 16px;
    border-bottom: 2px solid var(--light-bg);
}

.card-header-icon {
    width: 40px;
    height: 40px;
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
    flex-shrink: 0;
}

.card-header h2 {
    font-size: 1.2rem;
    font-weight: 700;
    color: var(--dark-color);
    margin: 0;
}

.form-group {
    margin-bottom: 18px;
}

.form-label {
    display: block;
    font-weight: 600;
    color: var(--dark-color);
    margin-bottom: 8px;
    font-size: 0.9rem;
}

.form-control {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    font-size: 0.95rem;
    font-family: inherit;
    transition: all 0.3s;
    box-sizing: border-box;
    background: white;
    color: var(--dark-color);
}

.form-control:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 4px rgba(255, 106, 0, 0.1);
}

.form-text {
    display: block;
    font-size: 0.85rem;
    color: #6b7280;
    margin-top: 6px;
}

.btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 12px 24px;
    border-radius: 8px;
    font-weight: 600;
    border: none;
    cursor: pointer;
    transition: all 0.3s ease;
    font-size: 0.95rem;
    font-family: inherit;
    width: 100%;
}

.btn-primary {
    background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
    color: white;
}

.btn-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(255, 106, 0, 0.3);
}

.btn-primary:active {
    transform: translateY(0);
}

.alert {
    padding: 16px;
    border-radius: 10px;
    margin-bottom: 24px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 0.95rem;
    border: none;
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        opacity: 0;
        transform: translateY(-10px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.alert-success {
    background: #ecfdf5;
    color: #10b981;
}

.alert-danger {
    background: #fef2f2;
    color: #ef4444;
}

@media (max-width: 480px) {
    .profile-card {
        padding: 20px 16px;
    }
    
    .btn {
        padding: 10px 16px;
        font-size: 0.9rem;
    }
}

/* Back to Top Button */
.back-to-top {
    position: fixed;
    bottom: 30px;
    right: 30px;
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #FF6A00 0%, #E85D04 100%);
    border: none;
    border-radius: 50%;
    color: white;
    cursor: pointer;
    display: none;
    align-items: center;
    justify-content: center;
    font-size: 22px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    box-shadow: 0 6px 20px rgba(255, 106, 0, 0.4);
    z-index: 999;
    opacity: 0;
}

.back-to-top.show {
    display: flex;
    animation: slideInUp 0.3s ease-out;
    opacity: 1;
}

@keyframes slideInUp {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.back-to-top:hover {
    background: linear-gradient(135deg, #E85D04 0%, #D9480F 100%);
    transform: translateY(-6px);
    box-shadow: 0 10px 30px rgba(255, 106, 0, 0.5);
}

.back-to-top:active {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(29, 126, 63, 0.3);
}

@media (max-width: 768px) {
    .back-to-top {
        bottom: 20px;
        right: 20px;
        width: 45px;
        height: 45px;
        font-size: 20px;
    }
}

@media (max-width: 480px) {
    .back-to-top {
        bottom: 16px;
        right: 16px;
        width: 40px;
        height: 40px;
        font-size: 18px;
    }
}
</style>

<div class="profile-container">
    <!-- Header Profile -->
    <div class="profile-header">
        <div class="profile-header-content">
            <div class="profile-avatar">
                <i class="fas fa-user"></i>
            </div>
            <div class="profile-header-info">
                <h1><?php echo htmlspecialchars($user['name']); ?></h1>
                <p><i class="fas fa-envelope" style="margin-right: 6px;"></i><?php echo htmlspecialchars($user['email']); ?></p>
            </div>
        </div>
    </div>

    <!-- Alert Messages -->
    <?php if ($message): ?>
        <div class="alert alert-<?php echo ($message_type === 'success' ? 'success' : 'danger'); ?>" role="alert">
            <i class="fas fa-<?php echo ($message_type === 'success' ? 'check-circle' : 'exclamation-circle'); ?>"></i>
            <span><?php echo htmlspecialchars($message); ?></span>
        </div>
    <?php endif; ?>

    <!-- Profile Sections -->
    <div class="profile-sections">
        <!-- Data Profil -->
        <div class="profile-card">
            <div class="card-header">
                <div class="card-header-icon"><i class="fas fa-user-circle"></i></div>
                <h2>Data Profil</h2>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="update_profile">
                
                <div class="form-group">
                    <label for="name" class="form-label">Nama Lengkap</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan Perubahan
                </button>
            </form>
        </div>

        <!-- Ubah Password -->
        <div class="profile-card">
            <div class="card-header">
                <div class="card-header-icon"><i class="fas fa-lock"></i></div>
                <h2>Ubah Password</h2>
            </div>
            
            <form method="POST">
                <input type="hidden" name="action" value="update_password">
                
                <div class="form-group">
                    <label for="old_password" class="form-label">Password Lama</label>
                    <input type="password" class="form-control" id="old_password" name="old_password" required>
                </div>
                
                <div class="form-group">
                    <label for="new_password" class="form-label">Password Baru</label>
                    <input type="password" class="form-control" id="new_password" name="new_password" required>
                    <span class="form-text">Minimal 6 karakter</span>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password" class="form-label">Konfirmasi Password Baru</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-key"></i> Ubah Password
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Back to Top Button -->
<button class="back-to-top" id="backToTopBtn" aria-label="Kembali ke atas">
    <i class="fas fa-chevron-up"></i>
</button>

<?php include_once 'includes/footer.php'; ?>

<script>
// Back to Top Button Functionality
const backToTopBtn = document.getElementById('backToTopBtn');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        backToTopBtn.classList.add('show');
    } else {
        backToTopBtn.classList.remove('show');
    }
});

backToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});
</script>
