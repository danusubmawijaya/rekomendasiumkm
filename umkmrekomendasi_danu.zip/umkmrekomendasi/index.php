<?php
// Redirect to home.php - index.php adalah entry point
header("Location: home.php");
exit();
?>

<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once BASE_PATH . '/classes/Product.php';
require_once BASE_PATH . '/classes/Rating.php';

// DEBUG: Log table being used
error_log("INDEX.PHP: Using Product class to fetch from products table");

// Guest dan login bisa browse - tidak perlu force login
// Ambil identity untuk rating submittion
$is_logged_in = isLoggedIn();
$user_id = $is_logged_in ? getCurrentUserId() : null;
$guest_id = !$is_logged_in ? getGuestId() : null;

$product = new Product($conn);
$rating = new Rating($conn);

// Get category filter
$selected_category = isset($_GET['kategori']) ? $_GET['kategori'] : '';
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Verify data source - log query
error_log("INDEX.PHP: Getting products from products table - Category: $selected_category, Search: $search_query");

// Get products based on category filter and search
if ($search_query) {
    $products = $product->searchProducts($search_query);
    if ($selected_category && $selected_category !== 'semua') {
        $products = array_filter($products, function($p) use ($selected_category) {
            return $p['kategori'] === $selected_category;
        });
    }
} elseif ($selected_category && $selected_category !== 'semua') {
    $products = $product->getProductsByCategory($selected_category);
} else {
    $products = $product->getAllProducts();
}

error_log("INDEX.PHP: Total products returned: " . count($products));

// Ambil jumlah rating 4 dan 5 untuk setiap produk dari database
$high_ratings_count = []; // array untuk menyimpan count rating 4 dan 5 per produk
$verified_products = [];

// Query untuk mendapatkan produk yang terverifikasi
// Kriteria: minimal 10 rating bintang 5 OR 10 rating bintang 4 (salah satu saja)
$verified_query = "
    SELECT 
        product_id,
        SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five_star_count,
        SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four_star_count
    FROM ratings 
    GROUP BY product_id
    HAVING five_star_count >= 10 OR four_star_count >= 10
";

$verified_result = $conn->query($verified_query);
if ($verified_result) {
    while ($row = $verified_result->fetch_assoc()) {
        $verified_products[$row['product_id']] = true;
        $high_ratings_count[$row['product_id']] = $row['five_star_count'] + $row['four_star_count'];
    }
}

// Get all categories
$categories = $product->getAllCategories();

$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'rate') {
    $product_id = $_POST['product_id'] ?? 0;
    $rating_value = $_POST['rating'] ?? 0;
    
    $result = $rating->addRating($user_id, $product_id, $rating_value, $guest_id);
    $message = $result['message'];
    $message_type = $result['success'] ? 'success' : 'danger';
}
?>
<?php require_once 'includes/header.php'; ?>
<link href="css/global.css" rel="stylesheet">

<div class="container-lg" style="padding: 0 12px;">
<div class="row mb-4">
    <div class="col-md-12">
        <h1 class="section-title"><i class="fas fa-store"></i> Semua Produk</h1>
        <p class="section-subtitle">Jelajahi koleksi produk UMKM terbaik dan berikan rating Anda</p>
    </div>
</div>

<?php if ($message): ?>
    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
        <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i> <?php echo $message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Search Bar -->
<div class="search-section">
    <form method="GET" class="search-form">
        <div class="search-input-wrapper">
            <i class="fas fa-search"></i>
            <input type="text" name="search" class="search-input" placeholder="Cari produk..." 
                   value="<?php echo htmlspecialchars($search_query); ?>">
            <?php if ($search_query): ?>
                <a href="index.php" class="search-clear">
                    <i class="fas fa-times"></i>
                </a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- Category Filter -->
<div class="category-filter">
    <div class="filter-header">
        <h5><i class="fas fa-filter"></i> Kategori</h5>
    </div>
    <div class="category-buttons">
        <a href="index.php" class="category-btn <?php echo ($selected_category === '' || $selected_category === 'semua') ? 'active' : ''; ?>">
            <i class="fas fa-th"></i> Semua
        </a>
        <?php if (!empty($categories)): ?>
            <?php foreach ($categories as $cat): ?>
                <a href="index.php?kategori=<?php echo urlencode($cat); ?>" class="category-btn <?php echo ($selected_category === $cat) ? 'active' : ''; ?>">
                    <?php echo htmlspecialchars($cat); ?>
                </a>
            <?php endforeach; ?>
        <?php else: ?>
            <!-- Fallback jika tidak ada kategori dari database -->
            <a href="index.php?kategori=Makanan%20Berat" class="category-btn <?php echo ($selected_category === 'Makanan Berat') ? 'active' : ''; ?>">Makanan Berat</a>
            <a href="index.php?kategori=Jajanan%20%26%20Street%20Food" class="category-btn <?php echo ($selected_category === 'Jajanan & Street Food') ? 'active' : ''; ?>">Jajanan & Street Food</a>
            <a href="index.php?kategori=Minuman" class="category-btn <?php echo ($selected_category === 'Minuman') ? 'active' : ''; ?>">Minuman</a>
            <a href="index.php?kategori=Makanan%20Rumahan" class="category-btn <?php echo ($selected_category === 'Makanan Rumahan') ? 'active' : ''; ?>">Makanan Rumahan</a>
        <?php endif; ?>
    </div>
</div>

<?php if (empty($products)): ?>
    <div class="recommendation-section" style="margin-top: 32px;">
        <div class="empty-state">
            <div class="empty-state-icon">
                <i class="fas fa-inbox"></i>
            </div>
            <p class="empty-state-text">Tidak ada produk ditemukan</p>
            <p class="empty-state-desc">Coba ubah filter atau cari dengan kata kunci lain</p>
        </div>
    </div>
<?php else: ?>
    <div class="product-grid" style="margin-top: 32px;">
        <?php foreach ($products as $prod): ?>
            <div class="product-card">
                <!-- Category Badge -->
                <div class="product-category-badge">
                    <span class="badge-text" style="background: var(--primary-color);"><?php echo htmlspecialchars($prod['kategori']); ?></span>
                </div>
                
                <!-- Product Image -->
                <div class="product-image">
                    <?php if (!empty($prod['gambar']) && file_exists($prod['gambar'])): ?>
                        <img src="<?php echo htmlspecialchars($prod['gambar']); ?>" alt="<?php echo htmlspecialchars($prod['nama_produk']); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                    <?php else: ?>
                        <i class="fas fa-box"></i>
                    <?php endif; ?>
                </div>
                
                <!-- Product Body -->
                <div class="product-body">
                    <?php if (!empty($verified_products) && isset($verified_products[$prod['id']])): ?>
                        <div style="display: flex; align-items: center; gap: 2px; background: #fef2f2; padding: 2px 5px; border-radius: 6px; white-space: nowrap; flex-shrink: 0; margin-bottom: 8px; width: fit-content;">
                            <i class="fas fa-check-circle" style="color: #dc2626; font-size: 0.65rem;"></i>
                            <span style="color: #dc2626; font-size: 0.65rem; font-weight: 600;">Terverifikasi</span>
                        </div>
                    <?php endif; ?>
                    <h5 class="product-name"><?php echo htmlspecialchars($prod['nama_produk']); ?></h5>
                    <p class="product-desc"><?php echo htmlspecialchars($prod['deskripsi']); ?></p>
                    
                    <!-- Rating Display -->
                    <div class="product-rating">
                        <?php if (isset($prod['avg_rating']) && $prod['avg_rating']): ?>
                            <div class="star-rating">
                                <?php 
                                $rating_val = round($prod['avg_rating']);
                                for ($i = 0; $i < 5; $i++): 
                                ?>
                                    <i class="fas fa-star<?php echo $i < $rating_val ? '' : '-o'; ?>"></i>
                                <?php endfor; ?>
                            </div>
                            <span class="rating-count"><?php echo number_format($prod['avg_rating'], 1); ?> (<?php echo isset($prod['rating_count']) ? $prod['rating_count'] : 0; ?>)</span>
                        <?php else: ?>
                            <span class="rating-count">Belum ada rating</span>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="product-actions">
                        <a href="product_detail.php?id=<?php echo $prod['id']; ?>" class="btn-action btn-detail">
                            <i class="fas fa-eye"></i> Detail
                        </a>
                        <a href="product_detail.php?id=<?php echo $prod['id']; ?>#rating" class="btn-action btn-rate">
                            <i class="fas fa-star"></i> Rating
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

</div>
<?php require_once 'includes/footer.php'; ?>
