-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 09, 2026 at 04:05 PM
-- Server version: 10.6.27-MariaDB
-- PHP Version: 8.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `umkmbeka_umkm_rekomendasi`
--

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `nama_menu` varchar(150) NOT NULL,
  `deskripsi` text NOT NULL,
  `harga` int(11) NOT NULL,
  `kategori_id` int(11) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menu_categories`
--

CREATE TABLE `menu_categories` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_categories`
--

INSERT INTO `menu_categories` (`id`, `nama_kategori`, `deskripsi`, `created_at`, `updated_at`) VALUES
(1, 'Makanan Berat', 'Makanan utama yang mengenyangkan', '2026-07-04 03:59:07', '2026-07-04 03:59:07'),
(2, 'Jajanan & Street Food', 'Makanan ringan dan camilan', '2026-07-04 03:59:07', '2026-07-04 03:59:07'),
(3, 'Minuman', 'Berbagai pilihan minuman segar', '2026-07-04 03:59:07', '2026-07-04 03:59:07'),
(4, 'Makanan Rumahan', 'Makanan tradisional rumahan', '2026-07-04 03:59:07', '2026-07-04 03:59:07');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `nama_produk` varchar(150) NOT NULL,
  `deskripsi` text NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  `kategori` varchar(50) NOT NULL DEFAULT 'Lainnya',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `lokasi` varchar(500) DEFAULT NULL COMMENT 'Lokasi UMKM'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `nama_produk`, `deskripsi`, `gambar`, `kategori`, `created_at`, `lokasi`) VALUES
(1, 'Nasi Uduk Bekasi', 'Nasi uduk dengan santan kental, telur, ikan asin, dan krupuk renyah', 'uploads/produk/1783554888_Screenshot 2026-07-04 121233.png', 'Makanan Berat', '2026-04-03 13:29:27', 'Warung Nasi Uduk H. Soemanto, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Nasi Uduk Betawi Bu Hj. Mimin, Jl. Sudirman No. 67 | -6.170436,107.015878 | Nasi Uduk Ace Hardware, Jl. Perintis No. 11 | -6.176334,107.110137'),
(2, 'Nasi Goreng Gerobak', 'Nasi goreng dengan telur, sayuran, dan bumbu khas Bekasi', 'uploads/produk/1783554905_Screenshot 2026-07-04 121222.png', 'Makanan Berat', '2026-04-03 13:29:27', 'Nasi Goreng Gerobak Pak Haji, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Nasi Goreng Gerobak Mak Yani, Jl. Sudirman No. 67 | -6.170436,107.015878 | Nasi Goreng Bang Toni, Jl. Perintis No. 11 | -6.176334,107.110137'),
(3, 'Sate Ayam Madura', 'Sate ayam dengan bumbu kacang kental dan rasa autentik Madura', 'uploads/produk/1783554917_Screenshot 2026-07-04 121208.png', 'Makanan Berat', '2026-04-03 13:29:27', 'Sate Ayam Madura Pak Budi, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Sate Ayam H. Slamet, Jl. Sudirman No. 67 | -6.170436,107.015878 | Sate Ayam Madura Jl. Perintis, Jl. Perintis No. 11 | -6.176334,107.110137'),
(4, 'Ayam Geprek Pedas', 'Ayam geprek dengan sambal pedas khas Bekasi, daging empuk dan renyah', 'uploads/produk/1783554933_Screenshot 2026-07-04 121158.png', 'Makanan Berat', '2026-04-03 13:29:27', 'Ayam Geprek Pedas Agen Depok, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Ayam Geprek Jaya, Jl. Sudirman No. 67 | -6.170436,107.015878 | Ayam Geprek Mas Hendra, Jl. Perintis No. 11 | -6.176334,107.110137'),
(5, 'Pecel Lele Gurih', 'Pecel lele dengan sambal kental dan lauk pauk lengkap', 'uploads/produk/1783554946_Screenshot 2026-07-04 121147.png', 'Makanan Berat', '2026-04-03 13:29:27', 'Pecel Lele Gurih Pak Karyo, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Pecel Lele H. Soemarto, Jl. Sudirman No. 67 | -6.170436,107.015878 | Pecel Lele Bapak Bambang, Jl. Perintis No. 11 | -6.176334,107.110137'),
(6, 'Soto Ayam Jamu', 'Soto ayam dengan rempah jamu tradisional dan kuning alami', 'uploads/produk/1783554959_Screenshot 2026-07-04 121134.png', 'Makanan Berat', '2026-04-03 13:29:27', 'Soto Ayam Jamu Mak Surti, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Soto Ayam Tradisional H. Mustakim, Jl. Sudirman No. 67 | -6.170436,107.015878 | Soto Ayam Warung Mak Elis, Jl. Perintis No. 11 | -6.176334,107.110137'),
(7, 'Bakso Sapi Bekasi', 'Bakso sapi premium dengan kuah kaldu yang gurih dan daging empuk', 'uploads/produk/1783554978_Screenshot 2026-07-04 121122.png', 'Makanan Berat', '2026-04-03 13:29:27', 'Bakso Sapi Bekasi Pak Toni, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Bakso Sapi Premium H. Amin, Jl. Sudirman No. 67 | -6.170436,107.015878 | Bakso Sapi King Warung Dani, Jl. Perintis No. 11 | -6.176334,107.110137'),
(8, 'Mie Ayam Kuah', 'Mie ayam dengan kuah kaldu ayam yang gurih dan topping ayam shredded', 'uploads/produk/1783554992_Screenshot 2026-07-04 121105.png', 'Makanan Berat', '2026-04-03 13:29:27', 'Mie Ayam Kuah Mas Gunawan, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Mie Ayam H. Suhartono, Jl. Sudirman No. 67 | -6.170436,107.015878 | Mie Ayam Lezat Warung Bambang, Jl. Perintis No. 11 | -6.176334,107.110137'),
(9, 'Seblak Pedas Gurih', 'Seblak dengan krupuk, telur, dan bumbu pedas yang menggugah selera', 'uploads/produk/1783555007_Screenshot 2026-07-04 121052.png', 'Jajanan & Street Food', '2026-04-03 13:29:27', 'Seblak Pedas Bu Desi, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Seblak H. Wahyudi, Jl. Sudirman No. 67 | -6.170436,107.015878 | Seblak Bang Asep, Jl. Perintis No. 11 | -6.176334,107.110137'),
(10, 'Cilok Goreng Isi', 'Cilok goreng dengan isi daging dan sayuran, gurih dan empuk', 'uploads/produk/1783555038_Screenshot 2026-07-04 121036.png', 'Jajanan & Street Food', '2026-04-03 13:29:27', 'Cilok Goreng Isi Mak Rita, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Cilok H. Mulyadi, Jl. Sudirman No. 67 | -6.170436,107.015878 | Cilok Goreng Bang Hendra, Jl. Perintis No. 11 | -6.176334,107.110137'),
(11, 'Cireng Goreng Gurih', 'Cireng (aci goreng) dengan isi daging dan sayuran, gurih dan empuk', 'uploads/produk/1783555058_Screenshot 2026-07-04 121020.png', 'Jajanan & Street Food', '2026-04-03 13:29:27', 'Cireng Goreng Pak Jarwoto, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Cireng H. Suryanto, Jl. Sudirman No. 67 | -6.170436,107.015878 | Cireng Goreng Enak Warung Toto, Jl. Perintis No. 11 | -6.176334,107.110137'),
(12, 'Batagor Kuah Gurih', 'Batagor dengan kuah kental dan topping bawang goreng', 'uploads/produk/1783555072_Screenshot 2026-07-04 121007.png', 'Jajanan & Street Food', '2026-04-03 13:29:27', 'Batagor Kuah Gurih Mak Ijah, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Batagor H. Achmad, Jl. Sudirman No. 67 | -6.170436,107.015878 | Batagor Bandung Bu Ningsih, Jl. Perintis No. 11 | -6.176334,107.110137'),
(13, 'Siomay Rebus Lezat', 'Siomay dengan isi daging dan sayuran, disajikan dengan kuah kental', 'uploads/produk/1783555089_Screenshot 2026-07-04 120956.png', 'Jajanan & Street Food', '2026-04-03 13:29:27', 'Siomay Rebus Lezat Pak Sartono, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Siomay H. Handoko, Jl. Sudirman No. 67 | -6.170436,107.015878 | Siomay Warung Mak Nur, Jl. Perintis No. 11 | -6.176334,107.110137'),
(14, 'Martabak Manis Terang Bulan', 'Martabak manis dengan berbagai pilihan isi coklat, keju, dan kacang', 'uploads/produk/1783555103_Screenshot 2026-07-04 120942.png', 'Jajanan & Street Food', '2026-04-03 13:29:27', 'Martabak Manis Terang Bulan Bu Siti, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Martabak H. Bambang, Jl. Sudirman No. 67 | -6.170436,107.015878 | Martabak Premium Warung Dimas, Jl. Perintis No. 11 | -6.176334,107.110137'),
(15, 'Roti Bakar Bekasi', 'Roti bakar dengan topping coklat, keju, dan telur', 'uploads/produk/1783555117_Screenshot 2026-07-04 120930.png', 'Jajanan & Street Food', '2026-04-03 13:29:27', 'Roti Bakar Bekasi Mak Anah, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Roti Bakar H. Syaiful, Jl. Sudirman No. 67 | -6.170436,107.015878 | Roti Bakar Lezat Bang Adit, Jl. Perintis No. 11 | -6.176334,107.110137'),
(16, 'Pisang Goreng Coklat', 'Pisang goreng berlapis coklat dan keju, manis dan gurih', 'uploads/produk/1783555131_Screenshot 2026-07-04 120916.png', 'Jajanan & Street Food', '2026-04-03 13:29:27', 'Pisang Goreng Coklat Bu Ratih, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Pisang Goreng H. Sutrisno, Jl. Sudirman No. 67 | -6.170436,107.015878 | Pisang Goreng Manis Bang Toto, Jl. Perintis No. 11 | -6.176334,107.110137'),
(17, 'Es Teh Manis Segar', 'Es teh manis dengan teh pilihan, segar dan menyegarkan', 'uploads/produk/1783555144_Screenshot 2026-07-04 120858.png', 'Minuman', '2026-04-03 13:29:27', 'Es Teh Manis Segar Pak Hendra, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Es Teh Warung H. Soemardi, Jl. Sudirman No. 67 | -6.170436,107.015878 | Es Teh Mas Agus, Jl. Perintis No. 11 | -6.176334,107.110137'),
(18, 'Es Jeruk Asam Segar', 'Es jeruk asam segar dengan jeruk pilihan dan gula merah', 'uploads/produk/1783555158_Screenshot 2026-07-04 120845.png', 'Minuman', '2026-04-03 13:29:27', 'Es Jeruk Asam Segar Bu Maryati, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Es Jeruk H. Sutino, Jl. Sudirman No. 67 | -6.170436,107.015878 | Es Jeruk Fresh Warung Cecep, Jl. Perintis No. 11 | -6.176334,107.110137'),
(19, 'Jus Buah Segar Alami', 'Jus buah segar dari buah-buahan pilihan tanpa pengawet', 'uploads/produk/1783555184_Screenshot 2026-07-04 120832.png', 'Minuman', '2026-04-03 13:29:27', 'Jus Buah Segar Alami Mak Soimah, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Jus Buah Segar H. Bambang, Jl. Sudirman No. 67 | -6.170436,107.015878 | Jus Buah Organik Bang Doni, Jl. Perintis No. 11 | -6.176334,107.110137'),
(20, 'Thai Tea Premium', 'Thai tea dengan susu kental manis dan rasa autentik Thailand', 'uploads/produk/1783555195_Screenshot 2026-07-04 120819.png', 'Minuman', '2026-04-03 13:29:27', 'Thai Tea Premium Warung Kopi H. Soekamto, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Thai Tea Kafe H. Kasiyanto, Jl. Sudirman No. 67 | -6.170436,107.015878 | Thai Tea Cafe Bang Budi, Jl. Perintis No. 11 | -6.176334,107.110137'),
(21, 'Es Kopi Susu Gula Aren', 'Es kopi susu dengan gula aren dan kopi pilihan', 'uploads/produk/1783555222_Screenshot 2026-07-04 120749.png', 'Minuman', '2026-04-03 13:29:27', 'Es Kopi Susu Gula Aren Pak Soemardi, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Es Kopi Aren H. Sutino, Jl. Sudirman No. 67 | -6.170436,107.015878 | Es Kopi Susu Cafe Banyu, Jl. Perintis No. 11 | -6.176334,107.110137'),
(22, 'Boba Milk Tea Kenyal', 'Minuman boba dengan milk tea premium dan boba kenyal', 'uploads/produk/1783555236_Screenshot 2026-07-04 120649.png', 'Minuman', '2026-04-03 13:29:27', 'Boba Milk Tea Kenyal Warung Bubble H. Santoso, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Boba Tea Kafe H. Soemardi, Jl. Sudirman No. 67 | -6.170436,107.015878 | Boba Milk Tea Shop Warung Dani, Jl. Perintis No. 11 | -6.176334,107.110137'),
(23, 'Rendang Rumahan Lezat', 'Rendang daging dengan bumbu tradisional dan rasa autentik', 'uploads/produk/1783555267_Rendang Rumahan Lezat.png', 'Makanan Rumahan', '2026-04-03 13:29:27', 'Rendang Rumahan Lezat Bu Siti, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Rendang Daging Ibu Hj. Soemari, Jl. Sudirman No. 67 | -6.170436,107.015878 | Rendang Rumahan Mak Nur, Jl. Perintis No. 11 | -6.176334,107.110137'),
(24, 'Ayam Balado Pedas', 'Ayam balado dengan sambal pedas dan rasa khas Minangkabau', 'uploads/produk/1783142014_ayam balado pedas.png', 'Makanan Rumahan', '2026-04-03 13:29:27', 'Ayam Balado Pedas Mak Soimah, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Ayam Balado H. Mardoyo, Jl. Sudirman No. 67 | -6.170436,107.015878 | Ayam Balado Rumahan Ibu Dwi, Jl. Perintis No. 11 | -6.176334,107.110137'),
(25, 'Sambal Homemade Pedas', 'Sambal buatan tangan dengan bahan pilihan dan rasa pedas nikmat', 'uploads/produk/1783141981_sambal rumahan.png', 'Makanan Rumahan', '2026-04-03 13:29:27', 'Sambal Homemade Pedas Bu Eka, Jl. Raya Bekasi No. 56 | -6.161118,107.020968 | Sambal Buatan Rumah H. Mustakim, Jl. Sudirman No. 67 | -6.170436,107.015878 | Sambal Pedas Maknyus Mak Endah, Jl. Perintis No. 11 | -6.176334,107.110137'),
(106, 'cimol bojot', 'cimol dengan bumbu manis, asin, pedas', '', 'Jajanan & Street Food', '2026-07-09 02:48:06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_locations`
--

CREATE TABLE `product_locations` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `lokasi` varchar(255) NOT NULL,
  `latitude` decimal(10, 8) DEFAULT NULL,
  `longitude` decimal(11, 8) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_locations`
--

INSERT INTO `product_locations` (`id`, `product_id`, `lokasi`, `created_at`) VALUES
(1, 4, 'Jl. KH. Muchtar Tabrani No.14, RT.4/RW.001, Perwira, Bekasi Utara, Jawa Barat 17143 (Geprek Gold Chick - Perwira)', '2026-07-09 02:33:51'),
(2, 7, 'Jalan Bango 2, Harapan Jaya, Bekasi Utara, Jawa Barat (Bakso Super King Mas War)', '2026-07-09 02:33:51'),
(3, 7, 'Jl. Raya Kaliabang Tengah, Bekasi Utara, Jawa Barat (Bakso Gandarasa)', '2026-07-09 02:33:51'),
(4, 8, 'Jl. KH. Muchtar Tabrani No.9, RT.006/RW.002, Marga Mulya, Bekasi Utara, Jawa Barat (Mi Ayam Baso Inul)', '2026-07-09 02:33:51'),
(5, 8, 'Jl. Kiyai H. Noer Ali, Bekasi Utara, Jawa Barat (Bakso & Mie Ayam Pak Sugeng)', '2026-07-09 02:33:51'),
(6, 9, 'Bekasi Utara, Jawa Barat (Seblak & Baso Aci Mbak Wati)', '2026-07-09 02:33:51'),
(7, 13, 'Jl. Kali Abang Tengah, Bekasi Utara, Jawa Barat (Siomay Aan)', '2026-07-09 02:33:51'),
(8, 5, 'Harapan Indah, Bekasi (Pecel Lele Muji)', '2026-07-09 02:33:51'),
(9, 6, 'Bekasi (Area Bekasi Utara) (Soto Ayam Ceker Surabaya Cak Komeng)', '2026-07-09 02:33:51'),
(10, 1, 'Jl. Ujung Harapan No.35, Bekasi (Nasi Uduk Betawi Ibu Hj. Adah)', '2026-07-09 02:33:51'),
(11, 2, 'Jl. KH. Muchtar Tabrani, Perwira, Bekasi Utara, Jawa Barat (Nasi Goreng nba/una)', '2026-07-09 02:33:51'),
(12, 14, 'Jl. KH. Muchtar Tabrani No.58, Bekasi Utara, Jawa Barat (Martabak Mas Jelly)', '2026-07-09 02:33:51'),
(13, 15, 'Bekasi (Roti & Pisang Bakar Eko)', '2026-07-09 02:33:51'),
(14, 16, 'Bekasi (Roti & Pisang Bakar Eko)', '2026-07-09 02:33:51'),
(15, 21, 'Jl. Kali Baru Barat, Kota Baru, Bekasi (Kedai Kopi Bang Jenggot)', '2026-07-09 02:33:51'),
(16, 20, 'Jl. Kali Baru Barat, Kota Baru, Bekasi (Kedai Kopi Bang Jenggot)', '2026-07-09 02:33:51'),
(17, 22, 'Jl. Kali Baru Barat, Kota Baru, Bekasi (Kedai Kopi Bang Jenggot)', '2026-07-09 02:33:51'),
(18, 3, 'Cari di Google Maps \"Sate Ayam Madura Bekasi Utara\" atau kunjungi pasar tradisional Bekasi Utara', '2026-07-09 02:33:51'),
(19, 10, 'Pedagang kaki lima di sekitar sekolah, terminal, pasar tradisional Bekasi Utara', '2026-07-09 02:33:51'),
(20, 11, 'Pedagang kaki lima di sekitar sekolah, terminal, pasar tradisional Bekasi Utara', '2026-07-09 02:33:51'),
(21, 12, 'Jl. Kali Abang Tengah, Bekasi Utara, Jawa Barat (Siomay Aan juga menjual Batagor)', '2026-07-09 02:33:51'),
(22, 23, 'Rumah Makan Padang di Bekasi Utara (Cari di Google Maps untuk lokasi spesifik)', '2026-07-09 02:33:51'),
(23, 24, 'Rumah Makan Padang di Bekasi Utara (Cari di Google Maps untuk lokasi spesifik)', '2026-07-09 02:33:51'),
(24, 25, 'Rumah Makan Padang di Bekasi Utara (Cari di Google Maps untuk lokasi spesifik)', '2026-07-09 02:33:51'),
(25, 106, 'Jalan Pengarangan 11 perumahan vgh bekasi utara', '2026-07-09 02:48:06');

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT 0,
  `guest_id` varchar(36) DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  KEY `idx_guest_id` (`guest_id`),
  KEY `idx_guest_product` (`guest_id`, `product_id`),
  KEY `idx_user_product` (`user_id`, `product_id`),
  CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ratings`
--

INSERT INTO `ratings` (`id`, `user_id`, `guest_id`, `product_id`, `rating`, `created_at`) VALUES
(30, 35, NULL, 1, 5, '2026-07-09 02:05:11'),
(31, 35, NULL, 5, 4, '2026-07-09 02:05:30'),
(32, 35, NULL, 12, 3, '2026-07-09 02:05:46'),
(33, 36, NULL, 1, 5, '2026-07-09 02:07:34'),
(34, 36, NULL, 2, 5, '2026-07-09 02:08:09'),
(35, 36, NULL, 4, 3, '2026-07-09 02:08:31'),
(36, 36, NULL, 15, 2, '2026-07-09 02:08:39'),
(37, 36, NULL, 20, 5, '2026-07-09 02:08:49');

-- --------------------------------------------------------

--
-- Table structure for table `seller_products`
--

CREATE TABLE `seller_products` (
  `id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `tersedia` tinyint(4) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `umkm_sellers`
--

CREATE TABLE `umkm_sellers` (
  `id` int(11) NOT NULL,
  `nama_umkm` varchar(150) NOT NULL,
  `alamat` text NOT NULL,
  `kelurahan` varchar(100) NOT NULL,
  `kecamatan` varchar(100) NOT NULL DEFAULT 'Bekasi Utara',
  `no_telp` varchar(20) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `umkm_sellers`
--

INSERT INTO `umkm_sellers` (`id`, `nama_umkm`, `alamat`, `kelurahan`, `kecamatan`, `no_telp`, `deskripsi`, `created_at`) VALUES
(1, 'Warung Soto Bekasi Jaya', 'Jl. Raya Bekasi No. 45', 'Harapan Baru', 'Bekasi Utara', '0812-3456-7890', 'Soto Bekasi tradisional dengan bumbu asli', '2026-07-04 05:34:08'),
(2, 'RM Ayam Goreng Berkah', 'Jl. Diponegoro No. 78', 'Bantargebang', 'Bekasi Utara', '0823-4567-8901', 'Ayam goreng dan pecel lele fresh', '2026-07-04 05:34:08'),
(3, 'Martabak Manis Terang Bulan', 'Jl. Veteran No. 12', 'Kayuringin Jaya', 'Bekasi Utara', '0834-5678-9012', 'Martabak manis dengan berbagai pilihan isi', '2026-07-04 05:34:08'),
(4, 'Nasi Goreng Gerobak Minang', 'Jl. Kartasura No. 33', 'Pejuang', 'Bekasi Utara', '0845-6789-0123', 'Nasi goreng dengan cita rasa Minangkabau', '2026-07-04 05:34:08'),
(5, 'Bakso Sapi Premium', 'Jl. Raden Saleh No. 56', 'Babakan Asem', 'Bekasi Utara', '0856-7890-1234', 'Bakso sapi dengan kuah kaldu premium', '2026-07-04 05:34:08'),
(6, 'Jus Buah Segar Tropis', 'Jl. Gatot Subroto No. 89', 'Harapan Baru', 'Bekasi Utara', '0867-8901-2345', 'Jus buah segar tanpa pengawet', '2026-07-04 05:34:08'),
(7, 'Warung Kopi Bekasi Kita', 'Jl. Ahmad Yani No. 22', 'Bantargebang', 'Bekasi Utara', '0878-9012-3456', 'Kopi tradisional dan modern terbaik', '2026-07-04 05:34:08'),
(8, 'Seblak & Cilok Lezat', 'Jl. Sudirman No. 11', 'Kayuringin Jaya', 'Bekasi Utara', '0889-0123-4567', 'Seblak dan cilok dengan bumbu khas', '2026-07-04 05:34:08'),
(9, 'Nasi Uduk Ibu Siti', 'Jl. Imam Bonjol No. 44', 'Pejuang', 'Bekasi Utara', '0890-1234-5678', 'Nasi uduk dengan lauk pauk lengkap', '2026-07-04 05:34:08'),
(10, 'Warung Rendang Padang', 'Jl. Permata No. 66', 'Babakan Asem', 'Bekasi Utara', '0891-2345-6789', 'Rendang daging dengan bumbu tradisional Padang', '2026-07-04 05:34:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_admin` tinyint(4) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `password_reset_token` varchar(255) DEFAULT NULL,
  `password_reset_expires` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `is_admin`, `created_at`, `password_reset_token`, `password_reset_expires`) VALUES
(1, 'Admin User', 'admin@umkm.com', '$2y$10$D8KiQD9Sn34DTZWaRwBWMOeEB3TDmL82dbbsfRPF4uMGMmo0qnSBW', 1, '2026-04-03 13:29:27', NULL, NULL),
(35, 'Rehan', 'danurealmeaja@gmail.com', '$2y$10$A/BdsnqqvC.YAHLNS/8E5u2orkE79trjPz9zo0upL6fb8RilGBAC6', 0, '2026-07-09 02:04:51', NULL, NULL),
(36, 'Reza Fahri 992', 'reza@gmail.com', '$2y$10$5shDp5obDlvAqt8PRR3WXu6Fus8o3Ue6r9fDM9WSVkKUnzgXpsnZi', 0, '2026-07-09 02:07:15', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_kategori` (`kategori_id`);

--
-- Indexes for table `menu_categories`
--
ALTER TABLE `menu_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_kategori` (`nama_kategori`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_locations`
--
ALTER TABLE `product_locations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_product_id` (`product_id`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_guest_id` (`guest_id`),
  ADD KEY `idx_guest_product` (`guest_id`, `product_id`),
  ADD KEY `idx_user_product` (`user_id`, `product_id`);

--
-- Indexes for table `seller_products`
--
ALTER TABLE `seller_products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_seller_product` (`seller_id`,`product_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `umkm_sellers`
--
ALTER TABLE `umkm_sellers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu_categories`
--
ALTER TABLE `menu_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;

--
-- AUTO_INCREMENT for table `product_locations`
--
ALTER TABLE `product_locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `seller_products`
--
ALTER TABLE `seller_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `umkm_sellers`
--
ALTER TABLE `umkm_sellers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
  ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`kategori_id`) REFERENCES `menu_categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_locations`
--
ALTER TABLE `product_locations`
  ADD CONSTRAINT `product_locations_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `seller_products`
--
ALTER TABLE `seller_products`
  ADD CONSTRAINT `seller_products_ibfk_1` FOREIGN KEY (`seller_id`) REFERENCES `umkm_sellers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `seller_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
