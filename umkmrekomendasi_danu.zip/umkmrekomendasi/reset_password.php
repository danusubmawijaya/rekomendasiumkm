<?php
session_start();

if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$message = '';
$message_type = '';
$show_form = true;
$token = isset($_GET['token']) ? $_GET['token'] : '';
$user_id = null;
$user_email = null;

if (empty($token)) {
    $message = 'Link tidak valid atau telah expired';
    $message_type = 'danger';
    $show_form = false;
} else {
    require_once 'config/database.php';
    require_once BASE_PATH . '/classes/User.php';
    
    $user = new User($conn);
    $token_result = $user->validatePasswordResetToken($token);
    
    if (!$token_result['success']) {
        $message = $token_result['message'];
        $message_type = 'danger';
        $show_form = false;
    } else {
        $user_id = $token_result['user_id'];
        $user_email = $token_result['email'];
        
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            $password_confirm = isset($_POST['password_confirm']) ? $_POST['password_confirm'] : '';
            
            // Validasi
            if (empty($password) || empty($password_confirm)) {
                $message = 'Password dan konfirmasi password harus diisi';
                $message_type = 'danger';
            } elseif (strlen($password) < 6) {
                $message = 'Password minimal harus 6 karakter';
                $message_type = 'danger';
            } elseif ($password !== $password_confirm) {
                $message = 'Password dan konfirmasi password tidak cocok';
                $message_type = 'danger';
            } else {
                // Reset password
                $reset_result = $user->resetPassword($user_id, $password);
                
                if ($reset_result['success']) {
                    $message = 'Password berhasil direset. Silakan login dengan password baru Anda.';
                    $message_type = 'success';
                    $show_form = false;
                } else {
                    $message = $reset_result['message'];
                    $message_type = 'danger';
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    
    
 <link rel="apple-touch-icon" sizes="180x180" href="/umkmrekomendasi/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="/umkmrekomendasi/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/umkmrekomendasi/favicon-16x16.png">
<link rel="icon" href="/umkmrekomendasi/favicon.ico">
<link rel="manifest" href="/umkmrekomendasi/site.webmanifest">


    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - UMKM Recommend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6A00;
            --secondary-color: #E85D04;
            --dark-color: #1a1a1a;
            --text-color: #2d3748;
            --border-color: #e5e7eb;
            --light-bg: #f9fafb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-family: 'Inter', 'Poppins', sans-serif;
            background: linear-gradient(135deg, #D84315 0%, #FF6A00 50%, #FFB347 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 16px;
        }

        .reset-wrapper {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 48px;
            align-items: center;
            max-width: 1100px;
            width: 100%;
        }

        .reset-illustration {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            color: white;
            text-align: center;
        }

        .reset-illustration-icon {
            font-size: 5rem;
            margin-bottom: 24px;
            opacity: 0.95;
        }

        .reset-illustration h2 {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 16px;
            letter-spacing: -0.5px;
        }

        .reset-illustration p {
            font-size: 1rem;
            opacity: 0.92;
            line-height: 1.6;
        }

        .reset-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 40px;
            width: 100%;
        }

        .reset-header {
            margin-bottom: 28px;
        }

        .reset-header h1 {
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 8px;
            letter-spacing: -0.5px;
        }

        .reset-header p {
            color: #6b7280;
            font-size: 0.95rem;
        }

        .form-group {
            margin-bottom: 18px;
        }

        .form-label {
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 8px;
            display: block;
            font-size: 0.9rem;
        }

        .form-control {
            border-radius: 6px;
            border: 1px solid var(--border-color);
            padding: 10px 14px;
            font-size: 0.95rem;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
            width: 100%;
        }

        .form-control:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(29, 126, 63, 0.1);
            outline: none;
        }

        .form-control::placeholder {
            color: #d1d5db;
        }

        .password-requirements {
            background: #FFF1E6;
            border-left: 4px solid var(--primary-color);
            padding: 14px;
            border-radius: 6px;
            margin-bottom: 20px;
            font-size: 0.85rem;
            color: #D84315;
        }

        .password-requirements i {
            margin-right: 6px;
        }

        .btn-submit {
            background: var(--primary-color);
            border: none;
            color: white;
            padding: 10px 20px;
            font-weight: 600;
            border-radius: 6px;
            width: 100%;
            font-size: 0.95rem;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 6px;
            font-family: 'Inter', 'Poppins', sans-serif;
        }

        .btn-submit:hover {
            background: var(--secondary-color);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(255, 106, 0, 0.3);
            color: white;
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .alert {
            border-radius: 6px;
            border: 1px solid;
            margin-bottom: 18px;
            font-size: 0.9rem;
            padding: 10px 14px;
        }

        .alert-danger {
            background: #fef2f2;
            color: #dc2626;
            border-color: #fecaca;
        }

        .alert-success {
            background: #ecfdf5;
            color: #047857;
            border-color: #a7f3d0;
        }

        .alert i {
            margin-right: 6px;
        }

        .reset-footer {
            text-align: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
        }

        .reset-footer p {
            color: #6b7280;
            font-size: 0.9rem;
            margin: 6px 0;
        }

        .reset-footer a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 700;
        }

        .reset-footer a:hover {
            text-decoration: underline;
        }

        .password-toggle {
            position: absolute;
            right: 14px;
            top: 40px;
            cursor: pointer;
            color: var(--primary-color);
            background: none;
            border: none;
            font-size: 1rem;
        }

        .password-group {
            position: relative;
            margin-bottom: 18px;
        }

        @media (max-width: 768px) {
            .reset-wrapper {
                grid-template-columns: 1fr;
                gap: 24px;
            }

            .reset-illustration {
                display: none;
            }

            .reset-container {
                padding: 28px 20px;
            }

            .reset-header h1 {
                font-size: 1.4rem;
            }
        }
    </style>
</head>
<body>
    <div class="reset-wrapper">
        <div class="reset-illustration">
            <div class="reset-illustration-icon">
                <i class="fas fa-shield-alt"></i>
            </div>
            <h2>Amankan Akun Anda</h2>
            <p>Buat password baru yang kuat untuk melindungi akun UMKM Recommend Anda</p>
        </div>

        <div class="reset-container">
            <div class="reset-header">
                <h1><i class="fas fa-key"></i> Reset Password</h1>
                <p>Masukkan password baru Anda di bawah</p>
            </div>

            <?php if ($message): ?>
                <div class="alert alert-<?php echo $message_type; ?>" role="alert">
                    <i class="fas fa-<?php echo $message_type === 'danger' ? 'exclamation-circle' : 'check-circle'; ?>"></i>
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <?php if ($show_form && $user_id): ?>
                <div class="password-requirements">
                    <i class="fas fa-shield-alt"></i>
                    <strong>Persyaratan Password:</strong> Minimal 6 karakter
                </div>

                <form method="POST" action="">
                    <div class="password-group">
                        <label for="password" class="form-label">Password Baru</label>
                        <input type="password" class="form-control" id="password" name="password" 
                               placeholder="Masukkan password baru Anda" required autofocus>
                        <button type="button" class="password-toggle" onclick="togglePassword('password')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>

                    <div class="password-group">
                        <label for="password_confirm" class="form-label">Konfirmasi Password</label>
                        <input type="password" class="form-control" id="password_confirm" name="password_confirm" 
                               placeholder="Konfirmasi password Anda" required>
                        <button type="button" class="password-toggle" onclick="togglePassword('password_confirm')">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>

                    <button type="submit" class="btn-submit">
                        <i class="fas fa-check-circle"></i> Reset Password
                    </button>
                </form>
            <?php endif; ?>

            <?php if (!$show_form && $message_type === 'success'): ?>
                <div style="text-align: center; padding: 20px 0;">
                    <i class="fas fa-check-circle" style="font-size: 3rem; color: #047857; display: block; margin-bottom: 16px;"></i>
                    <p style="color: #6b7280; margin-bottom: 20px;">Password Anda berhasil direset. Silakan login dengan password baru Anda.</p>
                    <a href="login.php" style="display: inline-block; background: var(--primary-color); color: white; padding: 10px 28px; border-radius: 6px; text-decoration: none; font-weight: 600; transition: all 0.3s;" onmouseover="this.style.background='var(--secondary-color)'" onmouseout="this.style.background='var(--primary-color)'">
                        <i class="fas fa-sign-in-alt"></i> Kembali ke Login
                    </a>
                </div>
            <?php endif; ?>

            <div class="reset-footer">
                <p><a href="login.php"><i class="fas fa-sign-in-alt"></i> Kembali ke Login</a></p>
            </div>
        </div>
    </div>

    <script>
        function togglePassword(fieldId) {
            const field = document.getElementById(fieldId);
            const icon = event.target.closest('button').querySelector('i');
            
            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
