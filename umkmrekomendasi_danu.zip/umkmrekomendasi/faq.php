<?php
require_once 'config/database.php';
require_once 'config/session.php';
$is_logged_in = isLoggedIn();
$page_title = "FAQ";
require_once 'includes/header.php';
?>

<style>
    :root {
        --primary-color: #FF6A00;
        --primary-light: #FFF1E6;
        --primary-dark: #E85D04;
        --dark-color: #1a1a1a;
        --border-color: #e5e7eb;
    }

    .container-lg {
        max-width: 1400px;
        margin: 0 auto;
        padding: 0 16px;
        box-sizing: border-box;
        width: 100%;
    }

    @media (min-width: 768px) {
        .container-lg { padding: 0 24px; }
    }

    /* FAQ Specific Styles */
    .faq-hero {
        background: linear-gradient(135deg, #FF6A00 0%, #E85D04 50%, #D9480F 100%);
        color: white;
        padding: 60px 0;
        text-align: center;
        position: relative;
        overflow: hidden;
    }

    .faq-hero::before {
        content: '';
        position: absolute;
        width: 300px;
        height: 300px;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        top: -100px;
        right: -100px;
    }

    .faq-hero::after {
        content: '';
        position: absolute;
        width: 250px;
        height: 250px;
        background: rgba(255, 255, 255, 0.08);
        border-radius: 50%;
        bottom: -50px;
        left: -50px;
    }

    .faq-hero-content {
        position: relative;
        z-index: 2;
    }

    .faq-hero h1 {
        font-size: clamp(2rem, 5vw, 3.2rem);
        font-weight: 800;
        margin-bottom: 12px;
        line-height: 1.1;
        letter-spacing: -0.5px;
    }

    .faq-hero p {
        font-size: clamp(0.95rem, 2vw, 1.1rem);
        opacity: 0.95;
        max-width: 600px;
        margin: 0 auto;
    }

    /* FAQ Container */
    .faq-container {
        max-width: 1400px;
        margin: 0 auto;
        padding: 60px 16px;
        box-sizing: border-box;
        width: 100%;
    }

    @media (min-width: 768px) {
        .faq-container { padding: 60px 24px; }
    }

    .faq-intro {
        text-align: center;
        margin-bottom: 50px;
    }

    .faq-intro-title {
        font-size: clamp(1.6rem, 4vw, 2.2rem);
        font-weight: 800;
        color: var(--dark-color);
        margin-bottom: 12px;
        letter-spacing: -0.5px;
    }

    .faq-intro-subtitle {
        font-size: 1rem;
        color: #6b7280;
        max-width: 500px;
        margin: 0 auto;
        line-height: 1.6;
    }

    /* FAQ Item */
    .faq-item {
        margin-bottom: 12px;
        border: 1px solid var(--border-color);
        border-radius: 12px;
        overflow: hidden;
        background: white;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    }

    .faq-item:hover {
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        border-color: var(--primary-light);
    }

    .faq-question {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding: 18px 20px;
        cursor: pointer;
        background: white;
        border: none;
        width: 100%;
        text-align: left;
        transition: all 0.3s ease;
        font-family: 'Poppins', sans-serif;
        font-size: 1rem;
        font-weight: 600;
        color: var(--dark-color);
    }

    .faq-item.active .faq-question {
        background: var(--primary-light);
        color: var(--primary-color);
    }

    .faq-question:hover {
        background: #f9fafb;
    }

    .faq-item.active .faq-question:hover {
        background: var(--primary-light);
    }

    .faq-question-text {
        flex: 1;
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .faq-question-icon {
        font-size: 1.2rem;
        color: var(--primary-color);
        flex-shrink: 0;
        transition: all 0.3s ease;
    }

    .faq-item.active .faq-question-icon {
        color: var(--primary-color);
    }

    .faq-toggle-icon {
        font-size: 0.9rem;
        color: #9ca3af;
        flex-shrink: 0;
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .faq-item.active .faq-toggle-icon {
        transform: rotate(180deg);
        color: var(--primary-color);
    }

    .faq-answer {
        display: none;
        padding: 0 20px;
        max-height: 0;
        overflow: hidden;
        background: white;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .faq-item.active .faq-answer {
        display: block;
        padding: 20px;
        max-height: 1000px;
        border-top: 1px solid var(--border-color);
    }

    .faq-answer p {
        color: #6b7280;
        line-height: 1.7;
        font-size: 0.95rem;
        margin: 0;
    }

    .faq-answer p + p {
        margin-top: 12px;
    }

    .faq-answer ul {
        list-style: none;
        margin: 12px 0 0 0;
        padding: 0;
    }

    .faq-answer ul li {
        padding: 8px 0 8px 24px;
        position: relative;
        color: #6b7280;
        line-height: 1.6;
        font-size: 0.95rem;
    }

    .faq-answer ul li::before {
        content: '✓';
        position: absolute;
        left: 0;
        color: var(--primary-color);
        font-weight: 700;
    }

    .faq-answer strong {
        color: var(--dark-color);
        font-weight: 600;
    }

    .faq-answer a {
        color: var(--primary-color);
        text-decoration: none;
        font-weight: 500;
        transition: all 0.3s ease;
    }

    .faq-answer a:hover {
        color: var(--secondary-color);
        text-decoration: underline;
    }

    /* FAQ CTA Section */
    .faq-cta {
        background: linear-gradient(135deg, #FF6A00 0%, #E85D04 100%);
        color: white;
        padding: 50px 30px;
        border-radius: 14px;
        text-align: center;
        margin-top: 60px;
        box-shadow: 0 10px 30px rgba(255, 106, 0, 0.2);
    }

    .faq-cta h3 {
        font-size: 1.5rem;
        font-weight: 800;
        margin-bottom: 10px;
        letter-spacing: -0.5px;
    }

    .faq-cta p {
        margin-bottom: 20px;
        opacity: 0.95;
        font-size: 0.95rem;
    }

    .faq-cta-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        background: white;
        color: var(--primary-color);
        padding: 12px 28px;
        border-radius: 10px;
        border: none;
        font-weight: 700;
        font-size: 0.95rem;
        cursor: pointer;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        text-decoration: none;
        font-family: 'Poppins', sans-serif;
    }

    .faq-cta-btn:hover {
        background: #f3f4f6;
        transform: translateY(-2px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
        color: var(--primary-color);
    }

    .faq-cta-btn:active {
        transform: translateY(0);
    }

    /* Empty State */
    .faq-no-results {
        text-align: center;
        padding: 40px 20px;
        color: #6b7280;
    }

    .faq-no-results i {
        font-size: 3rem;
        color: #d1d5db;
        margin-bottom: 16px;
        display: block;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .faq-container {
            padding: 40px 0;
        }

        .faq-hero {
            padding: 40px 0;
        }

        .faq-hero h1 {
            font-size: 1.8rem;
        }

        .faq-hero p {
            font-size: 0.9rem;
        }

        .faq-intro {
            margin-bottom: 30px;
        }

        .faq-intro-title {
            font-size: 1.4rem;
        }

        .faq-intro-subtitle {
            font-size: 0.9rem;
        }

        .faq-question {
            padding: 14px 16px;
            font-size: 0.95rem;
        }

        .faq-question-text {
            gap: 10px;
        }

        .faq-question-icon {
            font-size: 1rem;
        }

        .faq-item.active .faq-answer {
            padding: 16px;
        }

        .faq-answer p {
            font-size: 0.9rem;
        }

        .faq-cta {
            padding: 35px 20px;
            margin-top: 40px;
        }

        .faq-cta h3 {
            font-size: 1.2rem;
        }

        .faq-cta p {
            font-size: 0.9rem;
        }
    }

    @media (max-width: 480px) {
        .faq-hero {
            padding: 30px 0;
        }

        .faq-hero h1 {
            font-size: 1.5rem;
        }

        .faq-intro-title {
            font-size: 1.2rem;
        }

        .faq-question {
            padding: 12px 14px;
            font-size: 0.9rem;
            gap: 10px;
        }

        .faq-question-text {
            gap: 8px;
        }

        .faq-toggle-icon {
            font-size: 0.8rem;
        }

        .faq-cta {
            padding: 25px 16px;
            margin-top: 30px;
        }

        .faq-cta h3 {
            font-size: 1rem;
        }

        .faq-cta p {
            font-size: 0.85rem;
        }

        .faq-cta-btn {
            padding: 10px 20px;
            font-size: 0.85rem;
        }
    }
</style>

<!-- FAQ Hero Section -->
<section class="faq-hero">
    <div class="container-lg">
        <div class="faq-hero-content">
            <h1>Bantuan Penggunaan BEKOMIN ID</h1>
            <p>Temukan informasi mengenai BEKOMIN ID dan panduan penggunaan fitur yang tersedia pada platform rekomendasi produk UMKM di Bekasi Utara</p>
        </div>
    </div>
</section>

<!-- FAQ Content -->
<section>
    <div class="container-lg faq-container">
        <!-- FAQ Intro -->
        <div class="faq-intro">
            <h2 class="faq-intro-title">Panduan Penggunaan</h2>
            <p class="faq-intro-subtitle">Informasi berikut disediakan untuk membantu pengguna memahami fungsi dan penggunaan fitur pada BEKOMIN ID. Pilih pertanyaan untuk melihat penjelasan terkait fitur yang tersedia pada sistem.</p>
        </div>

        <!-- FAQ Items -->
        <div class="faq-list">
            <!-- FAQ 1 -->
            <div class="faq-item active">
                <button class="faq-question" onclick="toggleFaq(this)">
                    <div class="faq-question-text">
                        <i class="fas fa-lightbulb faq-question-icon"></i>
                        <span>Apa itu BEKOMIN ID?</span>
                    </div>
                    <i class="fas fa-chevron-down faq-toggle-icon"></i>
                </button>
                <div class="faq-answer">
                    <p>BEKOMIN ID merupakan platform yang menyediakan informasi dan rekomendasi produk UMKM di Bekasi Utara. Sistem ini menerapkan metode User-Based Collaborative Filtering sebagai bagian dari sistem rekomendasi untuk menghasilkan rekomendasi produk berdasarkan pola penilaian pengguna.</p>
                    <p>Platform dapat digunakan untuk melihat informasi produk, memberikan rating, memperoleh rekomendasi produk, serta melihat lokasi UMKM yang tersedia pada sistem.</p>
                </div>
            </div>

            <!-- FAQ 2 -->
            <div class="faq-item">
                <button class="faq-question" onclick="toggleFaq(this)">
                    <div class="faq-question-text">
                        <i class="fas fa-brain faq-question-icon"></i>
                        <span>Bagaimana sistem rekomendasi pada BEKOMIN ID bekerja?</span>
                    </div>
                    <i class="fas fa-chevron-down faq-toggle-icon"></i>
                </button>
                <div class="faq-answer">
                    <p>Sistem rekomendasi menggunakan metode User-Based Collaborative Filtering untuk mengidentifikasi tingkat kemiripan antara pengguna berdasarkan data rating yang diberikan terhadap produk. Hasil perhitungan kemiripan tersebut digunakan sebagai dasar dalam menghasilkan rekomendasi produk bagi pengguna.</p>
                </div>
            </div>

            <!-- FAQ 3 -->
            <div class="faq-item">
                <button class="faq-question" onclick="toggleFaq(this)">
                    <div class="faq-question-text">
                        <i class="fas fa-lock faq-question-icon"></i>
                        <span>Apakah BEKOMIN ID dapat digunakan tanpa login?</span>
                    </div>
                    <i class="fas fa-chevron-down faq-toggle-icon"></i>
                </button>
                <div class="faq-answer">
                    <p>Ya. Pengguna dapat mengakses dan melihat informasi produk pada BEKOMIN ID tanpa melakukan login. Fitur tertentu yang berkaitan dengan pemberian rating dan rekomendasi dapat digunakan sesuai dengan mekanisme yang telah diterapkan pada sistem.</p>
                </div>
            </div>

            <!-- FAQ 4 -->
            <div class="faq-item">
                <button class="faq-question" onclick="toggleFaq(this)">
                    <div class="faq-question-text">
                        <i class="fas fa-star faq-question-icon"></i>
                        <span>Bagaimana cara memberikan rating pada produk?</span>
                    </div>
                    <i class="fas fa-chevron-down faq-toggle-icon"></i>
                </button>
                <div class="faq-answer">
                    <p>Pengguna dapat memilih produk yang tersedia, kemudian memberikan penilaian melalui fitur rating yang disediakan. Data rating tersebut digunakan sebagai salah satu data masukan dalam proses sistem rekomendasi.</p>
                </div>
            </div>

            <!-- FAQ 5 -->
            <div class="faq-item">
                <button class="faq-question" onclick="toggleFaq(this)">
                    <div class="faq-question-text">
                        <i class="fas fa-map-pin faq-question-icon"></i>
                        <span>Bagaimana cara melihat lokasi UMKM?</span>
                    </div>
                    <i class="fas fa-chevron-down faq-toggle-icon"></i>
                </button>
                <div class="faq-answer">
                    <p>Informasi lokasi UMKM dapat dilihat melalui fitur lokasi yang tersedia pada halaman produk. Sistem menampilkan informasi lokasi berdasarkan data yang tersimpan pada platform.</p>
                </div>
            </div>

            <!-- FAQ 6 -->
            <div class="faq-item">
                <button class="faq-question" onclick="toggleFaq(this)">
                    <div class="faq-question-text">
                        <i class="fas fa-mobile-alt faq-question-icon"></i>
                        <span>Apakah BEKOMIN ID dapat digunakan melalui perangkat seluler?</span>
                    </div>
                    <i class="fas fa-chevron-down faq-toggle-icon"></i>
                </button>
                <div class="faq-answer">
                    <p>BEKOMIN ID dirancang dengan antarmuka yang menyesuaikan ukuran layar perangkat sehingga dapat digunakan melalui komputer maupun perangkat seluler.</p>
                </div>
            </div>

            <!-- FAQ 7 -->
            <div class="faq-item">
                <button class="faq-question" onclick="toggleFaq(this)">
                    <div class="faq-question-text">
                        <i class="fas fa-shield-alt faq-question-icon"></i>
                        <span>Bagaimana data pengguna digunakan pada sistem?</span>
                    </div>
                    <i class="fas fa-chevron-down faq-toggle-icon"></i>
                </button>
                <div class="faq-answer">
                    <p>Data yang digunakan dalam proses sistem rekomendasi disesuaikan dengan kebutuhan fungsi sistem. Data rating digunakan sebagai masukan dalam proses perhitungan rekomendasi, sedangkan informasi lainnya digunakan untuk mendukung fungsi dan layanan yang tersedia pada platform.</p>
                </div>
            </div>

            <!-- FAQ 8 -->
            <div class="faq-item">
                <button class="faq-question" onclick="toggleFaq(this)">
                    <div class="faq-question-text">
                        <i class="fas fa-envelope faq-question-icon"></i>
                        <span>Bagaimana cara mendapatkan bantuan terkait penggunaan BEKOMIN ID?</span>
                    </div>
                    <i class="fas fa-chevron-down faq-toggle-icon"></i>
                </button>
                <div class="faq-answer">
                    <p>Pengguna dapat menghubungi pihak pengelola melalui informasi kontak yang tersedia pada halaman kontak BEKOMIN ID untuk memperoleh bantuan atau menyampaikan kendala terkait penggunaan platform.</p>
                </div>
            </div>
        </div>

        <!-- FAQ CTA -->
        <div class="faq-cta">
            <h3>Masih Membutuhkan Informasi?</h3>
            <p>Jika informasi yang tersedia belum menjawab kebutuhan Anda, silakan gunakan halaman kontak untuk menyampaikan pertanyaan atau kendala terkait penggunaan BEKOMIN ID</p>
            <a href="contact.php" class="faq-cta-btn">
                <i class="fas fa-envelope"></i>
                Hubungi Kami
            </a>
        </div>
    </div>
</section>

<script>
    function toggleFaq(button) {
        const faqItem = button.closest('.faq-item');
        const isActive = faqItem.classList.contains('active');

        // Tutup semua item FAQ
        document.querySelectorAll('.faq-item').forEach(item => {
            item.classList.remove('active');
        });

        // Buka item yang diklik jika belum aktif
        if (!isActive) {
            faqItem.classList.add('active');
        }
    }

    // Tutup FAQ saat klik di luar (opsional)
    document.addEventListener('click', function(event) {
        if (!event.target.closest('.faq-question')) {
            const activeItem = document.querySelector('.faq-item.active');
            if (activeItem && !activeItem.contains(event.target)) {
                // Biarkan accordion tetap membuka (uncomment jika ingin fitur tutup otomatis)
                // activeItem.classList.remove('active');
            }
        }
    });
</script>

<?php require_once 'includes/footer.php'; ?>

</body>
</html>
