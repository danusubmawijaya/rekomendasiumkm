<?php
/**
 * LISTING PROGRAM LAMPIRAN 3
 * product_detail.php - Halaman Detail Produk
 * Menampilkan inti kode: Pengambilan data produk, rating, lokasi, dan verifikasi
 */

// Koneksi database sudah tersedia dari config/database.php
// Session dan function helper sudah tersedia

// 1. VALIDASI DAN AMBIL PRODUCT ID DARI URL
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$product_id) {
    header("Location: home.php");
    exit();
}

// 2. AMBIL DETAIL PRODUK DARI DATABASE
$stmt = $conn->prepare("SELECT id, nama_produk, deskripsi, gambar, lokasi FROM products WHERE id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$stmt->store_result();
$stmt->bind_result($p_id, $p_nama, $p_desc, $p_gambar, $p_lokasi);

$product = null;
if ($stmt->num_rows > 0) {
    $stmt->fetch();
    $product = [
        'id' => $p_id,
        'nama_produk' => $p_nama,
        'deskripsi' => $p_desc,
        'gambar' => $p_gambar,
        'lokasi' => $p_lokasi
    ];
}
$stmt->close();

if (!$product) {
    header("Location: home.php");
    exit();
}

// 3. AMBIL LOKASI PRODUK
$locations = [];
$loc_stmt = $conn->prepare("SELECT lokasi, latitude, longitude FROM product_locations WHERE product_id = ? ORDER BY id");
$loc_stmt->bind_param("i", $product_id);
$loc_stmt->execute();
$loc_stmt->bind_result($pl_name, $pl_lat, $pl_lng);

while ($loc_stmt->fetch()) {
    $locations[] = [
        'lokasi' => trim($pl_name),
        'latitude' => $pl_lat,
        'longitude' => $pl_lng
    ];
}
$loc_stmt->close();

// 4. AMBIL RATING PENGGUNA (USER ATAU GUEST)
$is_logged_in = isLoggedIn();
$user_id = $is_logged_in ? intval($_SESSION['user_id']) : null;
$user_rating = 0;

if ($user_id) {
    $stmt = $conn->prepare("SELECT rating FROM ratings WHERE user_id = ? AND product_id = ?");
    $stmt->bind_param("ii", $user_id, $product_id);
} else {
    $guest_id = getGuestId();
    $stmt = $conn->prepare("SELECT rating FROM ratings WHERE user_id = 0 AND guest_id = ? AND product_id = ?");
    $stmt->bind_param("si", $guest_id, $product_id);
}

$stmt->execute();
$stmt->bind_result($ur);
if ($stmt->fetch()) {
    $user_rating = intval($ur);
}
$stmt->close();

// 5. AMBIL RATING RATA-RATA DAN TOTAL RATING
$stmt = $conn->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_ratings FROM ratings WHERE product_id = ?");
$stmt->bind_param("i", $product_id);
$stmt->execute();
$stmt->bind_result($avg_rating, $total_ratings);
$stmt->fetch();
$stmt->close();

$avg_rating = $avg_rating ? floatval($avg_rating) : 0;
$total_ratings = intval($total_ratings);

// 6. CEK VERIFIKASI PRODUK
// Kriteria: minimal 10 rating bintang 5 ATAU 10 rating bintang 4
$verified_query = "SELECT 
    SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five_star_count,
    SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four_star_count
    FROM ratings WHERE product_id = ?";
$stmt = $conn->prepare($verified_query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$stmt->bind_result($five_count, $four_count);

$is_verified = false;
if ($stmt->fetch()) {
    $is_verified = ($five_count >= 10 || $four_count >= 10);
}
$stmt->close();

// 7. AMBIL DAFTAR RATING TERBARU
$query = "SELECT r.rating, u.name FROM ratings r 
          LEFT JOIN users u ON r.user_id = u.id 
          WHERE r.product_id = ? 
          ORDER BY r.created_at DESC LIMIT 10";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$stmt->bind_result($rating_val, $user_name);

$all_ratings = [];
while ($stmt->fetch()) {
    $all_ratings[] = [
        'rating' => $rating_val,
        'name' => $user_name ?: 'Guest'
    ];
}
$stmt->close();

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['nama_produk']); ?> - Detail Produk</title>
</head>
<body>
    <!-- Detail Produk -->
    <section class="product-detail">
        <div class="product-header">
            <img src="<?php echo htmlspecialchars($product['gambar']); ?>" alt="<?php echo htmlspecialchars($product['nama_produk']); ?>">
            <h1><?php echo htmlspecialchars($product['nama_produk']); ?></h1>
            <p><?php echo nl2br(htmlspecialchars($product['deskripsi'])); ?></p>
        </div>

        <!-- Rating Section -->
        <div class="rating-section">
            <p>Rating: <?php echo number_format($avg_rating, 1); ?>/5 (<?php echo $total_ratings; ?> rating)</p>
            <?php if ($is_verified): ?>
                <span class="badge-verified">✓ Terverifikasi</span>
            <?php endif; ?>
        </div>

        <!-- Lokasi Section -->
        <div class="location-section">
            <h3>Lokasi</h3>
            <?php foreach ($locations as $idx => $loc): ?>
                <div class="location-item">
                    <span><?php echo $idx + 1; ?>. <?php echo htmlspecialchars($loc['lokasi']); ?></span>
                    <?php if ($loc['latitude'] && $loc['longitude']): ?>
                        <small>(<?php echo number_format($loc['latitude'], 4); ?>, <?php echo number_format($loc['longitude'], 4); ?>)</small>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Rating List Section -->
        <div class="rating-list-section">
            <h3>Rating Pengguna</h3>
            <?php if (!empty($all_ratings)): ?>
                <?php foreach ($all_ratings as $rating): ?>
                    <div class="rating-item">
                        <p><strong><?php echo htmlspecialchars($rating['name']); ?></strong> - <?php echo str_repeat('⭐', $rating['rating']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Belum ada rating</p>
            <?php endif; ?>
        </div>

        <!-- Rating Form (jika logged in) -->
        <?php if ($is_logged_in || $guest_id): ?>
            <div class="rating-form-section">
                <h3>Berikan Rating</h3>
                <form id="ratingForm" method="POST" action="submit_rating.php">
                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                    <div class="star-selector">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <button type="button" class="star-btn" data-rating="<?php echo $i; ?>" 
                                    <?php echo ($user_rating === $i) ? 'class="star-btn active"' : ''; ?>>⭐</button>
                        <?php endfor; ?>
                    </div>
                    <input type="hidden" id="ratingValue" name="rating" value="<?php echo $user_rating; ?>">
                    <button type="submit" class="btn-submit">Simpan Rating</button>
                </form>
            </div>
        <?php else: ?>
            <p><a href="login.php">Login</a> untuk memberikan rating</p>
        <?php endif; ?>
    </section>
</body>
</html>
