/**
 * Geolocation & Location Finder Library
 * Untuk menemukan lokasi terdekat UMKM berdasarkan GPS user
 */

class LocationFinder {
    constructor() {
        this.map = null;
        this.userMarker = null;
        this.locationMarkers = [];
        this.userLocation = null;
        this.isMapInitialized = false;
        
        // Load Leaflet library
        this.loadLeaflet();
    }
    
    loadLeaflet() {
        if (window.L) {
            console.log('Leaflet already loaded');
            return;
        }
        
        // Load CSS
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
        document.head.appendChild(link);
        
        // Load JS
        const script = document.createElement('script');
        script.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
        script.onload = () => console.log('Leaflet library loaded');
        document.head.appendChild(script);
    }
    
    /**
     * Cek apakah browser support Geolocation API
     */
    supportsGeolocation() {
        return !!navigator.geolocation;
    }
    
    /**
     * Request lokasi user
     */
    requestUserLocation(onSuccess, onError) {
        if (!this.supportsGeolocation()) {
            if (onError) onError({ code: 'NOT_SUPPORTED' });
            return;
        }
        
        navigator.geolocation.getCurrentPosition(
            (position) => {
                this.userLocation = {
                    lat: position.coords.latitude,
                    lon: position.coords.longitude,
                    accuracy: position.coords.accuracy
                };
                
                console.log('User Location:', this.userLocation);
                
                if (onSuccess) onSuccess(this.userLocation);
            },
            (error) => {
                console.error('Geolocation Error:', error);
                if (onError) onError(error);
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 0
            }
        );
    }
    
    /**
     * Initialize Leaflet Map
     */
    initializeMap(containerId, defaultLat = -6.2349, defaultLon = 107.0102, defaultZoom = 13) {
        if (this.isMapInitialized || !window.L) {
            return this.map;
        }
        
        this.map = window.L.map(containerId).setView([defaultLat, defaultLon], defaultZoom);
        
        // Add tiles
        window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(this.map);
        
        // Add scale
        window.L.control.scale().addTo(this.map);
        
        this.isMapInitialized = true;
        return this.map;
    }
    
    /**
     * Tambah user marker ke map
     */
    addUserMarker() {
        if (!this.map || !this.userLocation) return;
        
        if (this.userMarker) {
            this.map.removeLayer(this.userMarker);
        }
        
        this.userMarker = window.L.circleMarker(
            [this.userLocation.lat, this.userLocation.lon],
            {
                radius: 10,
                fillColor: '#3b82f6',
                color: '#1e40af',
                weight: 3,
                opacity: 1,
                fillOpacity: 0.8
            }
        ).addTo(this.map);
        
        this.userMarker.bindPopup(
            '<strong>Lokasi Anda</strong><br>' +
            'Lat: ' + this.userLocation.lat.toFixed(4) + '<br>' +
            'Lon: ' + this.userLocation.lon.toFixed(4) + '<br>' +
            'Akurasi: ' + Math.round(this.userLocation.accuracy) + 'm'
        );
        
        // Center map ke user
        this.map.setView([this.userLocation.lat, this.userLocation.lon], 14);
    }
    
    /**
     * Tambah location marker ke map
     */
    addLocationMarker(lat, lon, name, distance) {
        if (!this.map) return;
        
        const marker = window.L.circleMarker(
            [lat, lon],
            {
                radius: 8,
                fillColor: '#ef4444',
                color: '#991b1b',
                weight: 2,
                opacity: 1,
                fillOpacity: 0.7
            }
        ).addTo(this.map);
        
        marker.bindPopup(
            '<strong>' + name + '</strong><br>' +
            'Jarak: <strong>' + distance.toFixed(2) + ' km</strong>'
        );
        
        this.locationMarkers.push(marker);
        return marker;
    }
    
    /**
     * Clear semua markers
     */
    clearMarkers() {
        if (this.userMarker && this.map) {
            this.map.removeLayer(this.userMarker);
        }
        
        this.locationMarkers.forEach(marker => {
            if (this.map) {
                this.map.removeLayer(marker);
            }
        });
        
        this.locationMarkers = [];
        this.userMarker = null;
    }
    
    /**
     * Haversine Formula - hitung jarak antar 2 titik GPS
     */
    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Earth radius in km
        const dLat = this.toRad(lat2 - lat1);
        const dLon = this.toRad(lon2 - lon1);
        const a = 
            Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(this.toRad(lat1)) * Math.cos(this.toRad(lat2)) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
    
    toRad(deg) {
        return deg * Math.PI / 180;
    }
    
    /**
     * Hitung estimasi waktu perjalanan
     */
    calculateTravelTime(distanceKm) {
        const walkingSpeed = 5; // km/h
        const drivingSpeed = 40; // km/h
        
        const walkingMinutes = Math.ceil((distanceKm / walkingSpeed) * 60);
        const drivingMinutes = Math.ceil((distanceKm / drivingSpeed) * 60);
        
        return {
            walking: walkingMinutes,
            driving: drivingMinutes,
            text: this.formatTravelTime(walkingMinutes, drivingMinutes)
        };
    }
    
    /**
     * Format travel time untuk display
     */
    formatTravelTime(walkingMins, drivingMins) {
        if (drivingMins < 60) {
            return drivingMins + 'm berkendara / ' + walkingMins + 'm jalan kaki';
        } else {
            const hours = Math.floor(drivingMins / 60);
            const mins = drivingMins % 60;
            return hours + 'j ' + mins + 'm berkendara';
        }
    }
}

/**
 * Helper function untuk integrasi ke halaman
 */
window.LocationFinderManager = {
    finder: null,
    
    initialize: function() {
        if (!this.finder) {
            this.finder = new LocationFinder();
        }
        return this.finder;
    },
    
    enableGPS: function(onSuccess, onError) {
        const finder = this.initialize();
        
        if (!finder.supportsGeolocation()) {
            if (onError) onError({ message: 'Browser tidak mendukung Geolocation' });
            return false;
        }
        
        finder.requestUserLocation(onSuccess, onError);
        return true;
    },
    
    displayMapAndLocations: function(containerId, locationElements) {
        const finder = this.initialize();
        
        if (!finder.userLocation) {
            console.error('User location not available');
            return;
        }
        
        // Initialize map
        finder.initializeMap(containerId);
        finder.addUserMarker();
        
        // Process locations
        const locationsData = [];
        
        locationElements.forEach((element) => {
            const lat = parseFloat(element.querySelector('.location-lat')?.value);
            const lon = parseFloat(element.querySelector('.location-lon')?.value);
            
            if (!lat || !lon) return;
            
            const distance = finder.calculateDistance(
                finder.userLocation.lat,
                finder.userLocation.lon,
                lat,
                lon
            );
            
            const travelTime = finder.calculateTravelTime(distance);
            
            // Update element
            const distanceDiv = element.querySelector('.location-distance');
            if (distanceDiv) {
                distanceDiv.style.display = 'block';
                distanceDiv.querySelector('.distance-value').textContent = distance.toFixed(2);
                distanceDiv.querySelector('.travel-time').textContent = travelTime.text;
            }
            
            locationsData.push({
                element: element,
                lat: lat,
                lon: lon,
                distance: distance,
                name: element.querySelector('.seller-name')?.textContent?.trim() || 'Location'
            });
            
            // Add marker to map
            finder.addLocationMarker(lat, lon, locationsData[locationsData.length - 1].name, distance);
        });
        
        // Sort by distance
        locationsData.sort((a, b) => a.distance - b.distance);
        
        // Update DOM order dan styling
        const container = locationElements[0]?.parentElement;
        if (container) {
            locationsData.forEach((loc, index) => {
                if (index === 0) {
                    // Highlight terdekat
                    loc.element.style.borderLeft = '4px solid #10b981';
                    loc.element.style.boxShadow = '0 0 0 3px rgba(16, 185, 129, 0.1)';
                    loc.element.style.position = 'relative';
                    
                    const badge = document.createElement('span');
                    badge.style.cssText = `
                        position: absolute;
                        top: -10px;
                        left: 20px;
                        background: #10b981;
                        color: white;
                        padding: 4px 12px;
                        border-radius: 20px;
                        font-size: 0.75rem;
                        font-weight: 700;
                    `;
                    badge.innerHTML = '<i class="fas fa-star"></i> Terdekat';
                    loc.element.appendChild(badge);
                }
                
                container.appendChild(loc.element);
            });
        }
    }
};

// Export untuk digunakan di module
if (typeof module !== 'undefined' && module.exports) {
    module.exports = LocationFinder;
}
