// Promo Slider Initialization
document.addEventListener('DOMContentLoaded', function() {
    initPromoSlider();
});

function initPromoSlider() {
    const slider = document.getElementById('promoSlider');
    const dotsContainer = document.getElementById('promoDots');
    
    if (!slider || !dotsContainer) return;
    
    const slides = document.querySelectorAll('.promo-slide');
    if (slides.length === 0) return;
    
    let currentSlide = 0;
    let autoplayInterval;
    const autoplayDelay = 4000;
    
    // Drag/Swipe variables
    let isDragging = false;
    let startX = 0;
    let currentX = 0;
    let dragThreshold = 50; // pixels
    let lastDragTime = 0;
    const dragCooldown = 500; // ms
    
    // Create dots
    slides.forEach((_, index) => {
        const dot = document.createElement('div');
        dot.className = `promo-dot ${index === 0 ? 'active' : ''}`;
        dot.addEventListener('click', () => goToSlide(index));
        dotsContainer.appendChild(dot);
    });
    
    const dots = document.querySelectorAll('.promo-dot');
    
    function showSlide(index) {
        slides.forEach((slide, i) => {
            if (i === index) {
                slide.classList.add('active');
                // Force reflow untuk ensure rendering konsisten
                slide.offsetHeight;
            } else {
                slide.classList.remove('active');
            }
        });
        dots.forEach((dot, i) => {
            dot.classList.toggle('active', i === index);
        });
    }
    
    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }
    
    function prevSlide() {
        currentSlide = (currentSlide - 1 + slides.length) % slides.length;
        showSlide(currentSlide);
    }
    
    function goToSlide(index) {
        currentSlide = index;
        showSlide(currentSlide);
        resetAutoplay();
    }
    
    function startAutoplay() {
        autoplayInterval = setInterval(nextSlide, autoplayDelay);
    }
    
    function pauseAutoplay() {
        clearInterval(autoplayInterval);
    }
    
    function resetAutoplay() {
        pauseAutoplay();
        startAutoplay();
    }
    
    // Drag handling - Mouse events
    slider.addEventListener('mousedown', handleDragStart);
    slider.addEventListener('mousemove', handleDragMove);
    slider.addEventListener('mouseup', handleDragEnd);
    slider.addEventListener('mouseleave', handleDragEnd);
    
    // Touch handling
    slider.addEventListener('touchstart', handleDragStart, false);
    slider.addEventListener('touchmove', handleDragMove, false);
    slider.addEventListener('touchend', handleDragEnd, false);
    
    function handleDragStart(e) {
        // Jangan drag jika sedang dalam cooldown
        if (Date.now() - lastDragTime < dragCooldown) {
            return;
        }
        
        isDragging = true;
        startX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
        currentX = startX;
        pauseAutoplay();
        slider.style.cursor = 'grabbing';
        
        // Prevent text selection saat drag
        e.preventDefault();
    }
    
    function handleDragMove(e) {
        if (!isDragging) return;
        
        currentX = e.type.includes('touch') ? e.touches[0].clientX : e.clientX;
    }
    
    function handleDragEnd(e) {
        if (!isDragging) return;
        
        isDragging = false;
        slider.style.cursor = 'pointer';
        
        const diff = startX - currentX;
        const absDiff = Math.abs(diff);
        
        // Hanya trigger slide jika drag cukup jauh dan tidak dalam cooldown
        if (absDiff > dragThreshold) {
            lastDragTime = Date.now();
            
            if (diff > 0) {
                // Drag ke kiri = slide berikutnya
                nextSlide();
            } else {
                // Drag ke kanan = slide sebelumnya
                prevSlide();
            }
        }
        
        resetAutoplay();
    }
    
    // Click on slide to navigate (jangan navigate jika sedang drag)
    slides.forEach(slide => {
        slide.addEventListener('click', function(e) {
            // Jangan navigate jika sedang drag atau baru saja drag
            if (isDragging || Math.abs(startX - currentX) > dragThreshold) {
                return;
            }
            
            const link = this.getAttribute('data-link');
            if (link) {
                window.location.href = link;
            }
        });
    });
    
    // Pause on hover
    slider.addEventListener('mouseenter', pauseAutoplay);
    slider.addEventListener('mouseleave', startAutoplay);
    
    // Start autoplay
    startAutoplay();
    showSlide(0);
}

// Navbar scroll effect
window.addEventListener('scroll', function() {
    const navbar = document.getElementById('navbar');
    if (navbar) {
        if (window.scrollY > 10) {
            navbar.classList.add('scrolled');
        } else {
            navbar.classList.remove('scrolled');
        }
    }
});


