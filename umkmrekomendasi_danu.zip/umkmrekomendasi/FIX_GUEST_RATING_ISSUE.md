# Fix Guest Rating Foreign Key Constraint Error

## Masalah
Guest user mendapatkan error saat menyimpan rating:
```
Gagal menyimpan rating: Cannot add or update a child row: a foreign key constraint fails 
(`umkmbeka_umkm_rekomendasi`.`ratings`, CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`user_id`) 
REFERENCES `users` (`id`) ON DELETE SET NULL)
```

## Root Cause
Foreign key constraint pada kolom `user_id` di tabel `ratings` memerlukan:
- Nilai `user_id` harus valid (ada di tabel `users`), ATAU
- `user_id` harus NULL

Namun, sebelumnya sistem mencoba menyimpan guest ratings dengan `user_id = 0`, yang tidak ada di tabel `users` dan bukan NULL, sehingga melanggar constraint.

## Solusi

### Step 1: Jalankan Database Migration
Jalankan SQL script ini di database Anda untuk membersihkan data lama:

**File:** `fix_guest_ratings.sql`

Langkah:
1. Buka phpMyAdmin atau MySQL client
2. Pilih database `umkmbeka_umkm_rekomendasi`
3. Buka tab "SQL" (atau Import)
4. Copy-paste isi file `fix_guest_ratings.sql`
5. Klik "Go/Execute"

**Atau via command line:**
```bash
mysql -u [username] -p [database_name] < fix_guest_ratings.sql
```

Contoh:
```bash
mysql -u root -p umkmbeka_umkm_rekomendasi < fix_guest_ratings.sql
```

### Step 2: Update Source Code
File yang sudah diperbaiki:
- **`classes/Rating.php`** - Diperbarui untuk menggunakan `user_id = NULL` untuk guest ratings

Perubahan utama:
- Guest ratings sekarang insert dengan `user_id = NULL` (bukan `user_id = 0`)
- Query untuk guest ratings menggunakan `WHERE user_id IS NULL AND guest_id = ?`
- UPDATE dan DELETE juga disesuaikan untuk guest ratings

## Verifikasi

Setelah menjalankan kedua step di atas, guest user seharusnya bisa:
1. Membuka halaman detail produk
2. Memberikan rating tanpa error
3. Melihat rating mereka tersimpan dan ditampilkan

### Test Manual
1. Buka browser (atau gunakan private/incognito mode)
2. Navigasi ke halaman detail produk
3. Scroll ke bagian "Berikan Rating"
4. Pilih rating (misal: 4 bintang)
5. Klik "Simpan Rating"
6. Rating seharusnya berhasil disimpan dengan pesan sukses

### Verifikasi Database
Jalankan query ini di database untuk memastikan data sudah benar:
```sql
SELECT id, user_id, guest_id, product_id, rating, created_at 
FROM ratings 
WHERE user_id IS NULL AND guest_id IS NOT NULL 
LIMIT 10;
```

Semua guest ratings seharusnya memiliki:
- `user_id = NULL`
- `guest_id = [valid UUID format]`

## File yang Berubah

### Modified
- `classes/Rating.php` - Logic untuk guest ratings diperbaiki

### New Files
- `fix_guest_ratings.sql` - Database migration script
- `FIX_GUEST_RATING_ISSUE.md` - File dokumentasi ini

## Technical Details

### Sebelumnya (Bug)
```php
// Guest insert dengan user_id = 0 (SALAH - melanggar FK constraint)
$null_user_id = 0;
$insert_stmt = $this->conn->prepare("INSERT INTO ratings (user_id, guest_id, product_id, rating) VALUES (?, ?, ?, ?)");
$insert_stmt->bind_param("isii", $null_user_id, $guest_id, $product_id, $rating);
```

### Sekarang (Fixed)
```php
// Guest insert dengan user_id = NULL (BENAR - memenuhi FK constraint)
$insert_stmt = $this->conn->prepare("INSERT INTO ratings (user_id, guest_id, product_id, rating) VALUES (NULL, ?, ?, ?)");
$insert_stmt->bind_param("sii", $guest_id, $product_id, $rating);
```

## Support

Jika masalah masih persisten setelah mengikuti langkah-langkah di atas:
1. Pastikan database migration script berjalan tanpa error
2. Pastikan code sudah ter-update dengan file `Rating.php` yang baru
3. Clear browser cache dan restart web server
4. Cek file logs untuk error message lebih detail

---
**Last Updated:** 2026-08-14
