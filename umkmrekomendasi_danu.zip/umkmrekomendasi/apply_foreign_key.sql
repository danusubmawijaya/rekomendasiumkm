-- ============================================================================
-- Script untuk menerapkan Foreign Key Constraint pada Database
-- Tambahkan relasi antara ratings.user_id -> users.id
-- ============================================================================

-- Step 1: Drop constraint lama jika ada
ALTER TABLE `ratings` DROP FOREIGN KEY IF EXISTS `ratings_ibfk_1`;
ALTER TABLE `ratings` DROP FOREIGN KEY IF EXISTS `ratings_ibfk_2`;

-- Step 2: Set foreign key checks to OFF untuk menghindari constraint check
SET FOREIGN_KEY_CHECKS=0;

-- Step 3: Bersihkan data yang invalid di kolom user_id
-- Set user_id ke NULL jika tidak ada di tabel users
UPDATE `ratings` 
SET `user_id` = NULL 
WHERE `user_id` IS NOT NULL 
AND `user_id` NOT IN (SELECT `id` FROM `users`);

-- Step 4: Turn foreign key checks kembali ON
SET FOREIGN_KEY_CHECKS=1;

-- Step 5: Tambahkan constraint baru untuk relasi products
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

-- Step 6: Tambahkan constraint baru untuk relasi users
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

-- ============================================================================
-- Verifikasi: Jalankan query ini untuk memastikan constraint sudah ditambahkan
-- SELECT CONSTRAINT_NAME, TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME 
-- FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE 
-- WHERE TABLE_NAME='ratings' AND COLUMN_NAME IN ('user_id', 'product_id');
-- ============================================================================
