<?php
require_once 'config/database.php';
require_once 'config/session.php';
$is_logged_in = isLoggedIn();
$page_title = "Tentang Kami";
require_once 'includes/header.php';
?>

    <style>
        :root {
            --primary-color: #FF6A00;
            --primary-light: #FFF1E6;
            --primary-dark: #E85D04;
            --dark-color: #1a1a1a;
            --light-bg: #f9fafb;
            --text-color: #6b7280;
            --border-color: #e5e7eb;
        }

        body {
            font-family: 'Poppins', 'Inter', sans-serif;
            color: var(--dark-color);
            background: #fff;
        }

        .container-lg {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 16px;
            box-sizing: border-box;
            width: 100%;
        }

        @media (min-width: 768px) {
            .container-lg { padding: 0 24px; }
        }

        /* About Hero Section */
        .about-hero {
            background: linear-gradient(135deg, #FF6A00 0%, #E85D04 50%, #D9480F 100%);
            color: white;
            padding: 60px 0;
            text-align: center;
            position: relative;
            overflow: hidden;
        }

        .about-hero::before {
            content: '';
            position: absolute;
            width: 300px;
            height: 300px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -100px;
            right: -100px;
        }

        .about-hero::after {
            content: '';
            position: absolute;
            width: 250px;
            height: 250px;
            background: rgba(255, 255, 255, 0.08);
            border-radius: 50%;
            bottom: -50px;
            left: -50px;
        }

        .about-hero-content {
            position: relative;
            z-index: 2;
        }

        .about-hero h1 {
            font-size: clamp(2rem, 5vw, 3.2rem);
            font-weight: 800;
            margin-bottom: 12px;
            line-height: 1.1;
            letter-spacing: -0.5px;
        }

        .about-hero p {
            font-size: clamp(0.95rem, 2vw, 1.1rem);
            opacity: 0.95;
            max-width: 600px;
            margin: 0 auto;
        }

        /* About Container */
        .about-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 60px 16px;
            box-sizing: border-box;
            width: 100%;
        }

        @media (min-width: 768px) {
            .about-container { padding: 60px 24px; }
        }

        .about-intro {
            text-align: center;
            margin-bottom: 50px;
        }

        .about-intro-title {
            font-size: clamp(1.6rem, 4vw, 2.2rem);
            font-weight: 800;
            color: var(--dark-color);
            margin-bottom: 12px;
            letter-spacing: -0.5px;
        }

        .about-intro-subtitle {
            font-size: 1rem;
            color: var(--text-color);
            max-width: 500px;
            margin: 0 auto;
            line-height: 1.6;
        }

        /* About Content */
        .about-content {
            background: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 20px;
            border: 1px solid var(--border-color);
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .about-content:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
            border-color: var(--primary-light);
        }

        .about-content h3 {
            font-size: 1.3rem;
            font-weight: 800;
            margin-bottom: 16px;
            color: var(--dark-color);
            display: flex;
            align-items: center;
            gap: 12px;
            letter-spacing: -0.5px;
        }

        .about-content h3 i {
            color: white;
            font-size: 0.95rem;
            background: var(--primary-color);
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            box-shadow: 0 3px 10px rgba(255, 106, 0, 0.25);
            flex-shrink: 0;
        }

        .about-content p {
            color: var(--text-color);
            line-height: 1.7;
            font-size: 0.95rem;
            margin: 0;
        }

        .about-content p + p {
            margin-top: 12px;
        }

        /* About CTA Section */
        .about-cta {
            background: linear-gradient(135deg, #FF6A00 0%, #E85D04 100%);
            color: white;
            padding: 50px 30px;
            border-radius: 14px;
            text-align: center;
            margin-top: 60px;
            box-shadow: 0 10px 30px rgba(255, 106, 0, 0.2);
        }

        .about-cta h3 {
            font-size: 1.5rem;
            font-weight: 800;
            margin-bottom: 10px;
            letter-spacing: -0.5px;
        }

        .about-cta p {
            margin-bottom: 20px;
            opacity: 0.95;
            font-size: 0.95rem;
        }

        .about-cta-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            background: white;
            color: var(--primary-color);
            padding: 12px 28px;
            border-radius: 10px;
            border: none;
            font-weight: 700;
            font-size: 0.95rem;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            text-decoration: none;
            font-family: 'Poppins', sans-serif;
        }

        .about-cta-btn:hover {
            background: #f3f4f6;
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            color: var(--primary-color);
        }

        .about-cta-btn:active {
            transform: translateY(0);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .about-container {
                padding: 40px 0;
            }

            .about-hero {
                padding: 40px 0;
            }

            .about-hero h1 {
                font-size: 1.8rem;
            }

            .about-hero p {
                font-size: 0.9rem;
            }

            .about-intro {
                margin-bottom: 30px;
            }

            .about-intro-title {
                font-size: 1.4rem;
            }

            .about-intro-subtitle {
                font-size: 0.9rem;
            }

            .about-content {
                padding: 24px;
            }

            .about-content h3 {
                font-size: 1.1rem;
                gap: 10px;
            }

            .about-content h3 i {
                font-size: 0.85rem;
                width: 28px;
                height: 28px;
                border-radius: 6px;
            }

            .about-cta {
                padding: 35px 20px;
                margin-top: 40px;
            }

            .about-cta h3 {
                font-size: 1.2rem;
            }

            .about-cta p {
                font-size: 0.9rem;
            }
        }

        @media (max-width: 480px) {
            .about-hero {
                padding: 30px 0;
            }

            .about-hero h1 {
                font-size: 1.5rem;
            }

            .about-intro-title {
                font-size: 1.2rem;
            }

            .about-content {
                padding: 16px;
            }

            .about-content h3 {
                font-size: 1rem;
            }

            .about-cta {
                padding: 25px 16px;
                margin-top: 30px;
            }

            .about-cta h3 {
                font-size: 1rem;
            }

            .about-cta p {
                font-size: 0.85rem;
            }

            .about-cta-btn {
                padding: 10px 20px;
                font-size: 0.85rem;
            }
        }
    </style>

    <!-- About Hero Section -->
    <section class="about-hero">
        <div class="container-lg">
            <div class="about-hero-content">
                <h1>Tentang UMKM Recommend</h1>
                <p>Pelajari lebih lanjut tentang UMKM Recommend, tujuan pengembangan sistem, dan bagaimana teknologi sistem rekomendasi dapat membantu pengguna menemukan produk UMKM lokal di Bekasi Utara</p>
            </div>
        </div>
    </section>

    <!-- About Content -->
    <section>
        <div class="container-lg about-container">
            <!-- About Intro -->
            <div class="about-intro">
                <h2 class="about-intro-title">Kami Siap Membantu</h2>
                <p class="about-intro-subtitle">Pelajari lebih lanjut tentang UMKM Recommend, tujuan pengembangan sistem, dan bagaimana teknologi sistem rekomendasi dapat membantu pengguna menemukan produk UMKM lokal di Bekasi Utara.</p>
            </div>

            <!-- About Items -->
            <div class="about-content">
                <h3><i class="fas fa-lightbulb"></i> Apa itu UMKM Recommend?</h3>
                <p>UMKM Recommend adalah platform sistem rekomendasi yang membantu pengguna menemukan produk dari UMKM lokal di Bekasi Utara berdasarkan preferensi dan pola rating pengguna. Sistem ini menerapkan Machine Learning dengan metode User-Based Collaborative Filtering untuk menghasilkan rekomendasi produk berdasarkan kemiripan preferensi antar pengguna. Pengguna dapat memberikan rating terhadap produk, kemudian data rating tersebut digunakan sebagai dasar dalam proses perhitungan rekomendasi. Pengguna juga dapat memperoleh rekomendasi tanpa harus melakukan login apabila fitur tersebut tersedia pada sistem.</p>
            </div>

            <div class="about-content">
                <h3><i class="fas fa-brain"></i> Teknologi User-Based Collaborative Filtering</h3>
                <p>UMKM Recommend menggunakan metode User-Based Collaborative Filtering untuk menghasilkan rekomendasi produk. Metode ini menganalisis pola rating pengguna dan menghitung tingkat kemiripan antar pengguna. Pengguna yang memiliki pola preferensi atau rating yang serupa dapat digunakan sebagai dasar untuk memberikan rekomendasi produk yang relevan. Semakin banyak data rating yang tersedia, semakin banyak informasi yang dapat digunakan oleh sistem dalam proses perhitungan rekomendasi.</p>
            </div>

            <div class="about-content">
                <h3><i class="fas fa-star"></i> Fitur-Fitur Unggulan</h3>
                <p>Platform UMKM Recommend menyediakan beberapa fitur utama, antara lain sistem rekomendasi produk berdasarkan User-Based Collaborative Filtering, informasi produk dan lokasi UMKM, perhitungan jarak lokasi, pemberian rating terhadap produk, serta antarmuka yang responsif dan dapat digunakan pada berbagai perangkat.</p>
            </div>

            <div class="about-content">
                <h3><i class="fas fa-target"></i> Visi Kami</h3>
                <p>Menjadi platform sistem rekomendasi produk UMKM yang dapat membantu pengguna menemukan produk lokal yang sesuai dengan preferensi mereka serta mendukung pengenalan dan pemasaran produk UMKM di Bekasi Utara melalui pemanfaatan teknologi Machine Learning.</p>
            </div>

            <div class="about-content">
                <h3><i class="fas fa-rocket"></i> Misi Kami</h3>
                <p>Membantu pengguna menemukan produk UMKM yang sesuai dengan preferensi berdasarkan data rating dan sistem rekomendasi. Selain itu, UMKM Recommend dikembangkan untuk mendukung UMKM lokal di Bekasi Utara agar produk mereka lebih mudah ditemukan oleh calon konsumen melalui pemanfaatan teknologi sistem rekomendasi.</p>
            </div>

            <!-- About CTA -->
            <div class="about-cta">
                <h3>Mulai Jelajahi Sekarang</h3>
                <p>Temukan produk UMKM berkualitas dan dapatkan rekomendasi berdasarkan preferensi Anda</p>
                <a href="home.php" class="about-cta-btn">
                    <i class="fas fa-arrow-right"></i>
                    Kembali ke Home
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php require_once 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
