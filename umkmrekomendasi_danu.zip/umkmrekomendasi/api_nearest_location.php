<?php
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once 'config/database.php';

$action = $_GET['action'] ?? '';

if ($action === 'get_products') {
    $query = "
        SELECT 
            p.id,
            p.nama_produk,
            p.deskripsi,
            p.kategori,
            p.gambar,
            COALESCE(AVG(r.rating), 0) as avg_rating,
            COUNT(r.id) as rating_count
        FROM products p
        LEFT JOIN ratings r ON p.id = r.product_id
        WHERE p.gambar IS NOT NULL AND p.gambar != ''
        GROUP BY p.id
        ORDER BY rating_count DESC, avg_rating DESC
        LIMIT 50
    ";
    
    $result = $conn->query($query);
    
    if (!$result) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Database error']);
        exit;
    }
    
    $products = [];
    while ($row = $result->fetch_assoc()) {
        // Verifikasi gambar file benar-benar ada
        $gambar_path = dirname(__FILE__) . '/' . $row['gambar'];
        if (!file_exists($gambar_path)) {
            // Skip produk jika gambar tidak ada
            continue;
        }
        
        $row['avg_rating'] = floatval($row['avg_rating']);
        $row['rating_count'] = intval($row['rating_count']);
        $products[] = $row;
    }
    
    echo json_encode([
        'success' => true, 
        'products' => $products,
        'total' => count($products)
    ]);
    exit;
}

if ($action === 'get_recommendations') {
    // Get top-rated products untuk rekomendasi
    $query = "
        SELECT 
            p.id,
            p.nama_produk,
            p.deskripsi,
            p.kategori,
            p.gambar,
            COALESCE(AVG(r.rating), 0) as avg_rating,
            COUNT(r.id) as rating_count
        FROM products p
        LEFT JOIN ratings r ON p.id = r.product_id
        WHERE p.gambar IS NOT NULL AND p.gambar != ''
        GROUP BY p.id
        HAVING avg_rating >= 3.5 OR rating_count >= 5
        ORDER BY avg_rating DESC, rating_count DESC
        LIMIT 20
    ";
    
    $result = $conn->query($query);
    
    if (!$result) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Database error']);
        exit;
    }
    
    $products = [];
    while ($row = $result->fetch_assoc()) {
        // Verifikasi gambar file benar-benar ada
        $gambar_path = dirname(__FILE__) . '/' . $row['gambar'];
        if (!file_exists($gambar_path)) {
            // Skip produk jika gambar tidak ada
            continue;
        }
        
        $row['avg_rating'] = floatval($row['avg_rating']);
        $row['rating_count'] = intval($row['rating_count']);
        $products[] = $row;
    }
    
    echo json_encode([
        'success' => true, 
        'products' => $products,
        'total' => count($products)
    ]);
    exit;
}

$product_id = intval($_GET['product_id'] ?? 0);
$lat = floatval($_GET['lat'] ?? 0);
$lng = floatval($_GET['lng'] ?? 0);

if ($product_id <= 0) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid product_id']);
    exit;
}

// Query untuk lokasi produk
$query = "SELECT id, lokasi, latitude, longitude FROM product_locations 
          WHERE product_id = ? 
          AND latitude IS NOT NULL 
          AND longitude IS NOT NULL 
          AND latitude != 0 
          AND longitude != 0
          ORDER BY id";

$stmt = $conn->prepare($query);

if (!$stmt) {
    http_response_code(500);
    echo json_encode(['error' => 'Prepare error: ' . $conn->error]);
    exit;
}

$stmt->bind_param('i', $product_id);
if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['error' => 'Execute error: ' . $stmt->error]);
    exit;
}

$stmt->store_result();
$stmt->bind_result($id, $lokasi, $lat2, $lon2);

$locations_with_distance = [];

// Earth radius in km
$earth_radius = 6371;

while ($stmt->fetch()) {
    $lat_val = floatval($lat2);
    $lon_val = floatval($lon2);
    
    // Skip jika koordinat tidak valid
    if ($lat_val == 0 && $lon_val == 0) {
        continue;
    }
    
    // Haversine formula
    $lat1_rad = deg2rad($lat);
    $lon1_rad = deg2rad($lng);
    $lat2_rad = deg2rad($lat_val);
    $lon2_rad = deg2rad($lon_val);
    
    $dlat = $lat2_rad - $lat1_rad;
    $dlon = $lon2_rad - $lon1_rad;
    
    $a = sin($dlat/2) * sin($dlat/2) + 
         cos($lat1_rad) * cos($lat2_rad) * 
         sin($dlon/2) * sin($dlon/2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
    $distance = $earth_radius * $c;
    
    $locations_with_distance[] = [
        'id' => intval($id),
        'lokasi' => trim($lokasi),
        'latitude' => $lat_val,
        'longitude' => $lon_val,
        'distance' => round($distance, 2)
    ];
}

$stmt->close();

if (empty($locations_with_distance)) {
    http_response_code(404);
    echo json_encode(['error' => 'No valid locations found']);
    exit;
}

// Sort by distance ascending (terdekat dulu)
usort($locations_with_distance, function($a, $b) {
    return $a['distance'] <=> $b['distance'];
});

// Return top 10 terdekat
$nearest = array_slice($locations_with_distance, 0, 10);

echo json_encode($nearest);
?>
